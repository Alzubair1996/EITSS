const fs = require('fs');
const path = require('path');

function copyFolderRecursiveSync(source, target) {
  if (!fs.existsSync(source)) {
    return;
  }

  // Create target directory if it doesn't exist
  if (!fs.existsSync(target)) {
    fs.mkdirSync(target, { recursive: true });
  }

  // Read source directory
  const files = fs.readdirSync(source);

  for (const file of files) {
    const curSource = path.join(source, file);
    const curTarget = path.join(target, file);

    if (fs.lstatSync(curSource).isDirectory()) {
      copyFolderRecursiveSync(curSource, curTarget);
    } else {
      fs.copyFileSync(curSource, curTarget);
    }
  }
}

const rootDir = path.resolve(__dirname, '..');
const standaloneDir = path.join(rootDir, '.next', 'standalone');

if (fs.existsSync(standaloneDir)) {
  console.log('[Post-Build] Copying public folder to standalone...');
  copyFolderRecursiveSync(
    path.join(rootDir, 'public'),
    path.join(standaloneDir, 'public')
  );

  console.log('[Post-Build] Copying .next/static folder to standalone...');
  copyFolderRecursiveSync(
    path.join(rootDir, '.next', 'static'),
    path.join(standaloneDir, '.next', 'static')
  );

  // Copy the start batch file as well if it exists in the root
  const startBatSource = path.join(rootDir, 'start-server.bat');
  const startBatTarget = path.join(standaloneDir, 'start-server.bat');
  if (fs.existsSync(startBatSource)) {
    console.log('[Post-Build] Copying start-server.bat to standalone...');
    fs.copyFileSync(startBatSource, startBatTarget);
  }

  // Copy the SERVER_SETUP.md documentation file
  const serverSetupSource = path.join(rootDir, 'SERVER_SETUP.md');
  const serverSetupTarget = path.join(standaloneDir, 'SERVER_SETUP.md');
  if (fs.existsSync(serverSetupSource)) {
    console.log('[Post-Build] Copying SERVER_SETUP.md to standalone...');
    fs.copyFileSync(serverSetupSource, serverSetupTarget);
  }

  console.log('[Post-Build] Standalone folders successfully prepared!');
} else {
  console.error('[Post-Build] Standalone directory not found at:', standaloneDir);
  console.error('Make sure "output: \'standalone\'" is configured in next.config.js and next build ran successfully.');
}
