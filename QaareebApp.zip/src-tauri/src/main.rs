// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use tauri::api::process::{Command, CommandEvent};
use tauri::{Manager, WindowEvent, command};
use std::env;
use std::{fs, path::PathBuf};


// This command can be called from the frontend to perform the database restore.
#[command]
fn restore_db(app: tauri::AppHandle, source_path: String) -> Result<(), String> {
    // Determine the destination path for the database in the app's data directory.
    let db_path = app.path_resolver()
        .app_data_dir()
        .ok_or_else(|| "Failed to get app data directory.".to_string())?
        .join("balla.sqlite");

    let source = PathBuf::from(source_path);

    // Before copying, we must ensure the database connection in the sidecar is closed.
    // However, we can't directly close it. The most robust way is to restart the app
    // after restore. For now, we'll just copy the file. The app restart will handle the rest.
    println!("Attempting to restore DB from '{}' to '{}'", source.display(), db_path.display());

    fs::copy(&source, &db_path).map_err(|e| {
        eprintln!("Failed to copy database file: {}", e);
        e.to_string()
    })?;

    println!("Database file successfully copied.");
    
    // It's highly recommended to restart the app here to ensure the new DB is loaded cleanly.
    // The frontend will handle the reload toast and logic.
    
    Ok(())
}


fn main() {
    tauri::Builder::default()
        .setup(|app| {
            let main_window = app.get_window("main").unwrap();
            let window_clone = main_window.clone();

            let db_path_for_env = app.path_resolver()
                .app_data_dir()
                .expect("failed to get app data dir")
                .join("balla.sqlite");
            
            println!("DATABASE_PATH for sidecar will be: {}", db_path_for_env.to_str().unwrap());
            
            let sidecar_command = Command::new_sidecar("node")
                .expect("failed to create `node` command")
                .args([".next/standalone/server.js"])
                .env("DATABASE_PATH", db_path_for_env.to_str().unwrap());


            tauri::async_runtime::spawn(async move {
                let (mut rx, child) = sidecar_command.spawn()
                    .expect("Failed to spawn sidecar");

                window_clone.on_window_event(move |event| {
                    if let WindowEvent::Destroyed = event {
                        println!("Main window destroyed, killing sidecar...");
                        child.kill().unwrap();
                    }
                });

                while let Some(event) = rx.recv().await {
                    match event {
                        CommandEvent::Stdout(line) => {
                            println!("Sidecar: {}", line);
                        },
                        CommandEvent::Stderr(line) => {
                            eprintln!("Sidecar Error: {}", line);
                        },
                        CommandEvent::Error(payload) => {
                            eprintln!("Sidecar command error: {}", payload);
                        },
                        CommandEvent::Terminated(payload) => {
                            eprintln!("Sidecar terminated with code: {:?}, signal: {:?}", payload.code, payload.signal);
                        },
                        _ => {}
                    }
                }
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![restore_db])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

    