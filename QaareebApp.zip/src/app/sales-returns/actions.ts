'use server';

import { getDbInstance } from '@/lib/db';
import { getSession } from '@/lib/server-auth';
import { getNextSalesReturnNumber } from '@/lib/queries';
import { revalidatePath } from 'next/cache';
import { IS_RESTAURANT_APP } from '@/lib/types';

export async function getInvoiceDetailsAction(invoiceId: string) {
  if (!invoiceId) {
    return { success: false, message: 'معرّف الفاتورة مطلوب.' };
  }

  try {
    const db = await getDbInstance();

    // Get the invoice
    const invoice = await db.get('SELECT * FROM invoices WHERE id = ?', invoiceId);
    if (!invoice) {
      return { success: false, message: 'الفاتورة غير موجودة.' };
    }

    // Get original items
    const items = await db.all('SELECT * FROM invoice_items WHERE invoiceId = ?', invoiceId);

    // Get all returned items for this invoice
    const returnedItems = await db.all(`
      SELECT sri.productId, SUM(sri.quantity) as returnedQty
      FROM sales_return_items sri
      JOIN sales_returns sr ON sri.salesReturnId = sr.id
      WHERE sr.invoiceId = ?
      GROUP BY sri.productId
    `, invoiceId);

    const returnedQtyMap: Record<string, number> = {};
    returnedItems.forEach((ri) => {
      returnedQtyMap[ri.productId] = ri.returnedQty;
    });

    const itemsWithStatus = items.map((item) => {
      const returnedQuantity = returnedQtyMap[item.productId] || 0;
      const remainingQuantity = Math.max(0, item.quantity - returnedQuantity);
      return {
        ...item,
        returnedQuantity,
        remainingQuantity,
      };
    });

    return {
      success: true,
      invoice,
      items: itemsWithStatus,
    };
  } catch (error: any) {
    console.error('Failed to get invoice details:', error);
    return { success: false, message: 'حدث خطأ أثناء جلب تفاصيل الفاتورة.' };
  }
}

export async function createSalesReturn(data: {
  invoiceId: string;
  reason?: string;
  items: { productId: string; quantity: number; price: number }[];
}) {
  const { invoiceId, reason, items } = data;

  if (!invoiceId) {
    return { success: false, message: 'معرّف الفاتورة مطلوب.' };
  }
  if (!reason || !reason.trim()) {
    return { success: false, message: 'سبب الإرجاع مطلوب.' };
  }
  if (!items || items.length === 0) {
    return { success: false, message: 'يجب اختيار صنف واحد على الأقل للإرجاع.' };
  }

  const session = await getSession();
  const userId = session?.userId || null;

  try {
    const db = await getDbInstance();
    await db.exec('BEGIN');

    // Fetch invoice details
    const invoice = await db.get('SELECT * FROM invoices WHERE id = ?', invoiceId);
    if (!invoice) {
      throw new Error('الفاتورة غير موجودة.');
    }
    if (invoice.status === 'cancelled') {
      throw new Error('لا يمكن إرجاع أصناف من فاتورة ملغاة.');
    }

    // Fetch original items to validate quantities
    const originalItems = await db.all('SELECT * FROM invoice_items WHERE invoiceId = ?', invoiceId);
    const originalQtyMap: Record<string, number> = {};
    originalItems.forEach((item) => {
      originalQtyMap[item.productId] = item.quantity;
    });

    // Fetch already returned quantities
    const alreadyReturnedItems = await db.all(`
      SELECT sri.productId, SUM(sri.quantity) as returnedQty
      FROM sales_return_items sri
      JOIN sales_returns sr ON sri.salesReturnId = sr.id
      WHERE sr.invoiceId = ?
      GROUP BY sri.productId
    `, invoiceId);

    const alreadyReturnedMap: Record<string, number> = {};
    alreadyReturnedItems.forEach((item) => {
      alreadyReturnedMap[item.productId] = item.returnedQty;
    });

    // Validate and build return items array
    let totalReturnAmount = 0;
    const validatedItems = [];

    for (const item of items) {
      const origQty = originalQtyMap[item.productId] || 0;
      const returnedQty = alreadyReturnedMap[item.productId] || 0;
      const remainingQty = Math.max(0, origQty - returnedQty);

      if (item.quantity <= 0) {
        throw new Error('كمية المرتجع يجب أن تكون أكبر من الصفر.');
      }
      if (item.quantity > remainingQty) {
        throw new Error('الكمية المرتجعة أكبر من الكمية المتبقية في الفاتورة.');
      }

      totalReturnAmount += item.quantity * item.price;
      validatedItems.push({
        id: `sri_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        productId: item.productId,
        quantity: item.quantity,
        price: item.price,
      });
    }

    // Generate return number
    const returnNumber = await getNextSalesReturnNumber(db);
    const returnId = `sr_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const returnDate = new Date().toISOString();

    // 1. Insert sales return header
    await db.run(
      `INSERT INTO sales_returns (id, invoiceId, returnNumber, returnDate, totalAmount, reason, status, userId)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      returnId,
      invoiceId,
      returnNumber,
      returnDate,
      totalReturnAmount,
      reason || null,
      'completed',
      userId
    );

    // 2. Insert sales return items and restore inventory
    for (const item of validatedItems) {
      await db.run(
        `INSERT INTO sales_return_items (id, salesReturnId, productId, quantity, price)
         VALUES (?, ?, ?, ?, ?)`,
        item.id,
        returnId,
        item.productId,
        item.quantity,
        item.price
      );

      // Restore stock
      if (IS_RESTAURANT_APP) {
        const ingredients = await db.all('SELECT * FROM product_ingredients WHERE productId = ?', item.productId);
        for (const ingredient of ingredients) {
          const totalReturnedStock = ingredient.quantityRequired * item.quantity;
          await db.run(
            'UPDATE raw_materials SET quantityInStock = quantityInStock + ? WHERE id = ?',
            totalReturnedStock,
            ingredient.rawMaterialId
          );
        }
      } else {
        await db.run(
          'UPDATE products SET quantity = quantity + ? WHERE id = ?',
          item.quantity,
          item.productId
        );
      }
    }

    // 3. Update customer balance (reduce debt)
    if (invoice.customerId) {
      await db.run(
        'UPDATE customers SET balance = balance + ? WHERE id = ?',
        totalReturnAmount,
        invoice.customerId
      );
    }

    // 4. Update invoice status if remaining balance changes
    // Get all returns total for this invoice
    const allReturns = await db.get(
      `SELECT SUM(totalAmount) as totalReturns FROM sales_returns WHERE invoiceId = ?`,
      invoiceId
    );
    const sumReturned = allReturns?.totalReturns || 0;

    const remainingInvoiceBalance = Math.max(0, invoice.totalAmount - invoice.amountPaid - sumReturned);
    let newStatus = invoice.status;
    if (remainingInvoiceBalance <= 0) {
      newStatus = 'paid';
    } else if (invoice.amountPaid > 0) {
      newStatus = 'partial';
    } else {
      newStatus = 'unpaid';
    }

    await db.run('UPDATE invoices SET status = ? WHERE id = ?', newStatus, invoiceId);

    await db.exec('COMMIT');

    revalidatePath('/customers');
    revalidatePath(`/customers/${invoice.customerId}`);
    revalidatePath('/invoices');

    return { success: true, message: 'تم تسجيل مرتجع المبيعات بنجاح.' };
  } catch (error: any) {
    console.error('Failed to create sales return:', error);
    try {
      const db = await getDbInstance();
      await db.exec('ROLLBACK');
    } catch (_) {}
    return { success: false, message: error.message || 'حدث خطأ أثناء تسجيل المرتجع.' };
  }
}

export async function deleteSalesReturn(returnId: string) {
  if (!returnId) {
    return { success: false, message: 'معرّف المرتجع مطلوب.' };
  }

  try {
    const db = await getDbInstance();
    await db.exec('BEGIN');

    const salesReturn = await db.get('SELECT * FROM sales_returns WHERE id = ?', returnId);
    if (!salesReturn) {
      throw new Error('مرتجع المبيعات غير موجود.');
    }

    const invoice = await db.get('SELECT * FROM invoices WHERE id = ?', salesReturn.invoiceId);
    if (!invoice) {
      throw new Error('الفاتورة المرتبطة بالمرتجع غير موجودة.');
    }

    const returnItems = await db.all('SELECT * FROM sales_return_items WHERE salesReturnId = ?', returnId);

    // 1. Revert stock (deduct stock since we are deleting the return)
    for (const item of returnItems) {
      if (IS_RESTAURANT_APP) {
        const ingredients = await db.all('SELECT * FROM product_ingredients WHERE productId = ?', item.productId);
        for (const ingredient of ingredients) {
          const totalReturnedStock = ingredient.quantityRequired * item.quantity;
          await db.run(
            'UPDATE raw_materials SET quantityInStock = quantityInStock - ? WHERE id = ?',
            totalReturnedStock,
            ingredient.rawMaterialId
          );
        }
      } else {
        await db.run(
          'UPDATE products SET quantity = quantity - ? WHERE id = ?',
          item.quantity,
          item.productId
        );
      }
    }

    // 2. Revert customer balance (increase debt)
    if (invoice.customerId) {
      await db.run(
        'UPDATE customers SET balance = balance - ? WHERE id = ?',
        salesReturn.totalAmount,
        invoice.customerId
      );
    }

    // 3. Delete return and its items
    await db.run('DELETE FROM sales_return_items WHERE salesReturnId = ?', returnId);
    await db.run('DELETE FROM sales_returns WHERE id = ?', returnId);

    // 4. Update invoice status
    const allReturns = await db.get(
      `SELECT SUM(totalAmount) as totalReturns FROM sales_returns WHERE invoiceId = ?`,
      salesReturn.invoiceId
    );
    const sumReturned = allReturns?.totalReturns || 0;

    const remainingInvoiceBalance = Math.max(0, invoice.totalAmount - invoice.amountPaid - sumReturned);
    let newStatus = invoice.status;
    if (remainingInvoiceBalance <= 0) {
      newStatus = 'paid';
    } else if (invoice.amountPaid > 0) {
      newStatus = 'partial';
    } else {
      newStatus = 'unpaid';
    }

    await db.run('UPDATE invoices SET status = ? WHERE id = ?', newStatus, salesReturn.invoiceId);

    await db.exec('COMMIT');

    revalidatePath('/customers');
    revalidatePath(`/customers/${invoice.customerId}`);
    revalidatePath('/invoices');

    return { success: true, message: 'تم حذف مرتجع المبيعات بنجاح.' };
  } catch (error: any) {
    console.error('Failed to delete sales return:', error);
    try {
      const db = await getDbInstance();
      await db.exec('ROLLBACK');
    } catch (_) {}
    return { success: false, message: error.message || 'حدث خطأ أثناء حذف المرتجع.' };
  }
}
