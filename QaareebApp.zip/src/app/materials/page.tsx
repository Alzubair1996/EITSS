

import { PageHeader } from '@/components/page-header';
import { getRawMaterialsWithUnits, getUnits } from '@/lib/queries';
import MaterialsClientPage from './materials-client-page';
import { IS_RESTAURANT_APP } from '@/lib/types';
import { redirect } from 'next/navigation';

export default async function MaterialsPage() {
  if (!IS_RESTAURANT_APP) {
    // This page is only for restaurants
    redirect('/');
  }

  const materials = await getRawMaterialsWithUnits();
  const units = await getUnits();

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <MaterialsClientPage 
            initialMaterials={materials}
            units={units}
        />
    </div>
  );
}
