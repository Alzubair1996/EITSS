
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import type { RawMaterial, Unit } from '@/lib/types';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const formSchema = z.object({
  name: z.string().min(2, { message: 'اسم المادة الخام مطلوب' }),
  unitId: z.string().min(1, { message: 'وحدة القياس مطلوبة' }),
  quantityInStock: z.coerce.number().min(0, { message: 'الكمية يجب أن تكون موجبة' }),
});

type FormValues = z.infer<typeof formSchema>;

interface MaterialFormProps {
  material: RawMaterial | null;
  units: Unit[];
  onSubmit: (values: FormValues) => void;
  onCancel: () => void;
}

export function MaterialForm({ material, units, onSubmit, onCancel }: MaterialFormProps) {
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: material?.name || '',
      unitId: material?.unitId || '',
      quantityInStock: material?.quantityInStock || 0,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <DialogHeader>
          <DialogTitle>
            {material ? 'تعديل مادة خام' : 'إضافة مادة خام جديدة'}
          </DialogTitle>
          <DialogDescription>
            أدخل تفاصيل المادة الخام التي تستخدمها في الأصناف.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>اسم المادة الخام</FormLabel>
                <FormControl>
                  <Input placeholder="مثال: دقيق، طماطم" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="unitId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>وحدة القياس</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر وحدة" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {units.map((unit) => (
                      <SelectItem key={unit.id} value={unit.id}>
                        {unit.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="quantityInStock"
            render={({ field }) => (
              <FormItem>
                <FormLabel>الكمية الحالية في المخزون</FormLabel>
                <FormControl>
                  <Input type="number" step="0.01" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onCancel}>
            إلغاء
          </Button>
          <Button type="submit">
            {material ? 'حفظ التغييرات' : 'إضافة المادة'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}
