
'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { RawMaterial } from '@/lib/types';
import { randomUUID } from 'crypto';

export async function addRawMaterial(data: Omit<RawMaterial, 'id'>) {
    try {
        const db = await getDbInstance();
        const existing = await db.get('SELECT id FROM raw_materials WHERE name = ?', data.name);
        if (existing) {
            return { success: false, message: 'هذه المادة الخام موجودة بالفعل.' };
        }
        const newId = `raw_${randomUUID()}`;
        await db.run('INSERT INTO raw_materials (id, name, unitId, quantityInStock) VALUES (?, ?, ?, ?)', newId, data.name, data.unitId, data.quantityInStock);
        revalidatePath('/materials');
        return { success: true, message: 'تمت إضافة المادة الخام بنجاح.' };
    } catch (e: any) {
        console.error(e);
        if (e.code === 'SQLITE_CONSTRAINT') {
             return { success: false, message: 'هذه المادة الخام موجودة بالفعل.' };
        }
        return { success: false, message: 'خطأ في قاعدة البيانات: فشلت إضافة المادة الخام.' };
    }
}

export async function updateRawMaterial(material: RawMaterial) {
     try {
        const db = await getDbInstance();
        await db.run('UPDATE raw_materials SET name = ?, unitId = ?, quantityInStock = ? WHERE id = ?', material.name, material.unitId, material.quantityInStock, material.id);
        revalidatePath('/materials');
        return { success: true, message: 'تم تحديث المادة الخام بنجاح.' };
    } catch (e: any) {
        console.error(e);
        if (e.code === 'SQLITE_CONSTRAINT') {
             return { success: false, message: 'هذه المادة الخام موجودة بالفعل.' };
        }
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل تحديث المادة الخام.' };
    }
}

export async function deleteRawMaterial(id: string) {
    try {
        const db = await getDbInstance();
        // Check if the material is used in any product ingredients
        const ingredient = await db.get('SELECT id FROM product_ingredients WHERE rawMaterialId = ?', id);
        if (ingredient) {
            return { success: false, message: 'لا يمكن حذف هذه المادة لأنها مستخدمة في وصفات بعض الأصناف.' };
        }
        await db.run('DELETE FROM raw_materials WHERE id = ?', id);
        revalidatePath('/materials');
        return { success: true, message: 'تم حذف المادة الخام بنجاح.' };
    } catch (e) {
        console.error(e);
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل حذف المادة الخام.' };
    }
}
