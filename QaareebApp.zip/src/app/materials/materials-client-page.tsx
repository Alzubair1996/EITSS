
'use client';

import * as React from 'react';
import { PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/page-header';
import { MaterialsTable } from './materials-table';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { MaterialForm } from './material-form';
import type { RawMaterialDetails, Unit } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { addRawMaterial, updateRawMaterial, deleteRawMaterial } from './actions';
import { useRouter } from 'next/navigation';

interface MaterialsClientPageProps {
  initialMaterials: RawMaterialDetails[];
  units: Unit[];
}

export default function MaterialsClientPage({ initialMaterials, units }: MaterialsClientPageProps) {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [editingMaterial, setEditingMaterial] = React.useState<RawMaterialDetails | null>(null);
  const { toast } = useToast();
  const router = useRouter();

  const handleAdd = () => {
    setEditingMaterial(null);
    setIsDialogOpen(true);
  };

  const handleEdit = (material: RawMaterialDetails) => {
    setEditingMaterial(material);
    setIsDialogOpen(true);
  };

  const handleDelete = async (materialId: string) => {
    const result = await deleteRawMaterial(materialId);
    if (result.success) {
      toast({
        title: 'تم الحذف بنجاح',
        description: result.message,
      });
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ في الحذف',
        description: result.message,
      });
    }
  };

  const handleFormSubmit = async (values: { name: string; unitId: string; quantityInStock: number; }) => {
    const result = editingMaterial
      ? await updateRawMaterial({ ...values, id: editingMaterial.id })
      : await addRawMaterial(values);

    if (result.success) {
      toast({
        title: editingMaterial ? 'تم التحديث بنجاح' : 'تمت الإضافة بنجاح',
        description: result.message,
      });
      setIsDialogOpen(false);
      setEditingMaterial(null);
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ',
        description: result.message,
      });
    }
  };

  return (
    <>
      <PageHeader title="إدارة المواد الخام">
        <Button onClick={handleAdd} className="shadow-md hover:shadow-lg transition-shadow">
          <PlusCircle className="me-2 h-4 w-4" />
          إضافة مادة خام جديدة
        </Button>
      </PageHeader>
      <MaterialsTable
        materials={initialMaterials}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <MaterialForm
            material={editingMaterial}
            units={units}
            onSubmit={handleFormSubmit}
            onCancel={() => setIsDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}
