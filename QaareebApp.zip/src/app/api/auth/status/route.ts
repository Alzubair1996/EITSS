
import { NextResponse } from 'next/server';
import { performActivationCheck } from '@/app/api/auth/queries';

// This forces the route to be dynamically rendered and not cached
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const activationStatus = await performActivationCheck();
    return NextResponse.json(activationStatus);
  } catch (error) {
    console.error('API route /api/auth/status error:', error);
    return NextResponse.json(
      { 
        isActivated: false, 
        isSetupComplete: false,
        trial: { isActive: false, isTampered: false, daysRemaining: 0 },
        error: 'Failed to retrieve status' 
      },
      { status: 500 }
    );
  }
}
