
import 'server-only';
import { getDbInstance } from '@/lib/db';
import { getServerId } from '@/lib/server-id';
import * as crypto from 'crypto';
import { add, differenceInDays } from 'date-fns';

const TRIAL_DAYS = 30;

export async function performActivationCheck(): Promise<{
  isActivated: boolean,
  isSetupComplete: boolean,
  isClockTampered?: boolean,
  trial: {
    isActive: boolean,
    isTampered: boolean,
    daysRemaining: number
  }
}> {
  // On Vercel / Cloud Demo, provide seamless access to the demo
  if (process.env.VERCEL || process.env.NEXT_PUBLIC_DEMO_MODE === 'true') {
    return {
      isActivated: true,
      isSetupComplete: true,
      isClockTampered: false,
      trial: { isActive: true, isTampered: false, daysRemaining: 30 }
    };
  }

  try {
    const db = await getDbInstance();
    
    // 1. Check License Key Activation
    const licenseKeyResult = await db.get("SELECT value FROM settings WHERE key = 'license_key'");
    const storedKey = licenseKeyResult?.value;
    let isActivatedFlag = false;

    if (storedKey) {
        const serverId = await getServerId();
        
        // 1. Check legacy key format (for backward compatibility)
        const legacySha256 = crypto.createHash('sha256').update(serverId).digest('hex');
        const expectedLegacyKey = crypto.createHash('sha512').update(legacySha256).digest('hex');
        
        if (storedKey === expectedLegacyKey) {
            isActivatedFlag = true;
        } else {
            // 2. Check new key format: <expiry>-<signature>
            const parts = storedKey.split('-');
            if (parts.length >= 2) {
                const signature = parts[parts.length - 1];
                const expiry = parts.slice(0, parts.length - 1).join('-');
                
                const sha256Hash = crypto.createHash('sha256').update(serverId + ":" + expiry).digest('hex');
                const expectedSignature = crypto.createHash('sha512').update(sha256Hash).digest('hex');
                
                if (signature === expectedSignature) {
                    if (expiry === 'lifetime') {
                        isActivatedFlag = true;
                    } else {
                        const expiryDate = new Date(expiry);
                        if (!isNaN(expiryDate.getTime())) {
                            const now = new Date();
                            now.setHours(0, 0, 0, 0);
                            expiryDate.setHours(23, 59, 59, 999);
                            if (now <= expiryDate) {
                                isActivatedFlag = true;
                            }
                        }
                    }
                }
            }
        }
    }
    
    // 2. Check Setup Completion
    const appNameResult = await db.get("SELECT value FROM settings WHERE key = 'business_type'");
    const isSetupCompleteFlag = !!appNameResult?.value;
    
    // 3. Clock Tampering Verification
    const lastLaunchDateStr = (await db.get("SELECT value FROM settings WHERE key = 'last_launch_date'"))?.value;
    let isClockTamperedVal = (await db.get("SELECT value FROM settings WHERE key = 'clock_tampered'"))?.value === 'true';
    
    const now = new Date();
    const currentDateStr = now.toISOString();

    if (isClockTamperedVal) {
        if (lastLaunchDateStr) {
            const lastLaunchDate = new Date(lastLaunchDateStr);
            if (now >= lastLaunchDate) {
                await db.run("DELETE FROM settings WHERE key = 'clock_tampered'");
                isClockTamperedVal = false;
            } else {
                isActivatedFlag = false;
            }
        } else {
            isActivatedFlag = false;
        }
    } else if (lastLaunchDateStr) {
        const lastLaunchDate = new Date(lastLaunchDateStr);
        if (now < lastLaunchDate) {
            await db.run("INSERT OR REPLACE INTO settings (key, value) VALUES ('clock_tampered', 'true')");
            isClockTamperedVal = true;
            isActivatedFlag = false;
        } else {
            await db.run("INSERT OR REPLACE INTO settings (key, value) VALUES ('last_launch_date', ?)", currentDateStr);
        }
    } else {
        await db.run("INSERT OR REPLACE INTO settings (key, value) VALUES ('last_launch_date', ?)", currentDateStr);
    }
    
    return {
      isActivated: isActivatedFlag,
      isSetupComplete: isSetupCompleteFlag,
      isClockTampered: isClockTamperedVal,
      trial: { isActive: false, isTampered: false, daysRemaining: 0 }
    };

  } catch (e) {
    console.error("Activation/Setup check failed (this is expected on first run):", e);
    return {
      isActivated: false,
      isSetupComplete: false,
      isClockTampered: false,
      trial: { isActive: false, isTampered: false, daysRemaining: 0 }
    };
  }
}

export async function getLicenseDetails(): Promise<{
  isActivated: boolean;
  expiry: string;
  daysRemaining: number | null;
}> {
  try {
    const db = await getDbInstance();
    const licenseKeyResult = await db.get("SELECT value FROM settings WHERE key = 'license_key'");
    const storedKey = licenseKeyResult?.value;
    
    if (!storedKey) {
      return { isActivated: false, expiry: 'none', daysRemaining: 0 };
    }
    
    const serverId = await getServerId();
    
    // 1. Check legacy key format (backward compatibility)
    const legacySha256 = crypto.createHash('sha256').update(serverId).digest('hex');
    const expectedLegacyKey = crypto.createHash('sha512').update(legacySha256).digest('hex');
    
    if (storedKey === expectedLegacyKey) {
      return { isActivated: true, expiry: 'lifetime', daysRemaining: null };
    }
    
    // 2. Check new key format: <expiry>-<signature>
    const parts = storedKey.split('-');
    if (parts.length >= 2) {
      const signature = parts[parts.length - 1];
      const expiry = parts.slice(0, parts.length - 1).join('-');
      
      const sha256Hash = crypto.createHash('sha256').update(serverId + ":" + expiry).digest('hex');
      const expectedSignature = crypto.createHash('sha512').update(sha256Hash).digest('hex');
      
      if (signature === expectedSignature) {
        if (expiry === 'lifetime') {
          return { isActivated: true, expiry: 'lifetime', daysRemaining: null };
        } else {
          const expiryDate = new Date(expiry);
          if (!isNaN(expiryDate.getTime())) {
            const now = new Date();
            now.setHours(0, 0, 0, 0);
            expiryDate.setHours(23, 59, 59, 999);
            
            if (now <= expiryDate) {
              const diffTime = expiryDate.getTime() - now.getTime();
              const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
              return { isActivated: true, expiry, daysRemaining: diffDays };
            } else {
              return { isActivated: false, expiry: `expired (${expiry})`, daysRemaining: 0 };
            }
          }
        }
      }
    }
    
    return { isActivated: false, expiry: 'invalid', daysRemaining: 0 };
  } catch (error) {
    console.error("Failed to get license details:", error);
    return { isActivated: false, expiry: 'error', daysRemaining: 0 };
  }
}
