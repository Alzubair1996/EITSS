
import { NextResponse } from 'next/server';
import { getCompanyInfo } from '@/lib/queries';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const companyInfo = await getCompanyInfo();
    return NextResponse.json(companyInfo);
  } catch (error) {
    console.error('API route /api/company-info error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve company information' },
      { status: 500 }
    );
  }
}
