'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import {
  type Supplier,
  type Product,
  type PaymentMethod,
  type RawMaterial,
  type CompanyInfo,
  type Category,
} from '@/lib/types';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { LoaderCircle, Package, Search, Trash2, Coins, ChevronRight, ShoppingCart, PlusCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { createPurchaseInvoice } from '@/app/purchases/actions';
import { cn } from '@/lib/utils';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { IS_RESTAURANT_APP } from '@/lib/types';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { SupplierForm } from '@/app/suppliers/supplier-form';
import { addSupplier } from '@/app/suppliers/actions';

interface PurchaseInvoiceFormProps {
  suppliers: Supplier[];
  products: Product[];
  paymentMethods: PaymentMethod[];
  rawMaterials: RawMaterial[];
  companyInfo: CompanyInfo;
  categories: Category[];
}

type CartItem = {
    id: string;
    type: 'product' | 'material';
    name: string;
    quantity: number | string;
    costPrice: number | string;
};

export default function PurchaseInvoiceForm({
  suppliers,
  products,
  paymentMethods,
  rawMaterials,
  companyInfo,
  categories,
}: PurchaseInvoiceFormProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = React.useState(false);
  const searchInputRef = React.useRef<HTMLInputElement>(null);
  const audioRef = React.useRef<HTMLAudioElement | null>(null);

  const [selectedSupplierId, setSelectedSupplierId] = React.useState<string | null>(null);
  const [isSupplierFormOpen, setIsSupplierFormOpen] = React.useState(false);
  const [supplierList, setSupplierList] = React.useState<Supplier[]>(suppliers);
  const [invoiceNumber, setInvoiceNumber] = React.useState('');
  const [cart, setCart] = React.useState<CartItem[]>([]);
  const [itemSearchTerm, setItemSearchTerm] = React.useState('');
  const [selectedCategoryIdFilter, setSelectedCategoryIdFilter] = React.useState<string | null>(null);
  const [paymentMethodId, setPaymentMethodId] = React.useState<string | null>(null);
  const [amountPaid, setAmountPaid] = React.useState<number | string>('');

  React.useEffect(() => {
    if (selectedSupplierId?.startsWith('supp_temp_')) {
      const tempSupplier = supplierList.find(s => s.id === selectedSupplierId);
      if (tempSupplier) {
        const realSupplier = suppliers.find(s => s.phone === tempSupplier.phone);
        if (realSupplier) setSelectedSupplierId(realSupplier.id);
      }
    }
    setSupplierList(suppliers);
  }, [suppliers]);

  React.useEffect(() => {
    if (typeof window !== 'undefined') audioRef.current = new Audio('/beep.mp3');
    searchInputRef.current?.focus();
  }, []);

  const playBeep = () => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(() => {});
    }
  };

  const formatCurrency = (num: number) => Math.round(num).toLocaleString('en-US');

  const totalAmount = React.useMemo(() =>
    cart.reduce((sum, item) => sum + (Number(item.quantity) || 0) * (Number(item.costPrice) || 0), 0),
    [cart]
  );

  const searchableItems = React.useMemo(() => {
    if (IS_RESTAURANT_APP) return rawMaterials.map(m => ({ id: m.id, name: m.name, type: 'material' as const, code: '', categoryId: '' }));
    return products.map(p => ({ id: p.id, name: p.name, type: 'product' as const, code: p.code, categoryId: p.categoryId }));
  }, [products, rawMaterials]);

  const filteredSearchableItems = React.useMemo(() =>
    searchableItems
      .filter(p => IS_RESTAURANT_APP || !selectedCategoryIdFilter || p.categoryId === selectedCategoryIdFilter)
      .filter(p =>
        p.name.toLowerCase().includes(itemSearchTerm.toLowerCase()) ||
        (p.code && p.code.toLowerCase().includes(itemSearchTerm.toLowerCase()))
      ),
    [searchableItems, itemSearchTerm, selectedCategoryIdFilter]
  );

  const handleAddSupplierSubmit = async (values: any) => {
    const result = await addSupplier(values);
    if (result.success) {
      toast({ title: 'تمت الإضافة بنجاح', description: 'تمت إضافة المورد الجديد.' });
      setIsSupplierFormOpen(false);
      const tempId = `supp_temp_${Date.now()}`;
      const newSupplier: Supplier = { id: tempId, name: values.name, phone: values.phone, address: values.address || '', balance: 0 };
      setSupplierList(prev => [...prev, newSupplier]);
      setSelectedSupplierId(tempId);
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }
  };

  const handleAddItem = (item: { id: string; name: string; type: 'product' | 'material' }) => {
    playBeep();
    setCart(prev => {
      const existing = prev.find(c => c.id === item.id && c.type === item.type);
      if (existing) return prev.map(c => c.id === item.id ? { ...c, quantity: (Number(c.quantity) || 0) + 1 } : c);
      const prod = item.type === 'product' ? products.find(p => p.id === item.id) : null;
      return [...prev, { id: item.id, name: item.name, type: item.type, quantity: 1, costPrice: prod?.costPrice || '' }];
    });
    setItemSearchTerm('');
    searchInputRef.current?.focus();
  };

  const handleItemSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && itemSearchTerm) {
      e.preventDefault();
      const product = products.find(p => p.code === itemSearchTerm);
      if (product) handleAddItem({ id: product.id, name: product.name, type: 'product' });
      else if (filteredSearchableItems.length > 0) handleAddItem(filteredSearchableItems[0]);
    }
  };

  const handleQuantityChange = (cartItemId: string, val: number | string) => {
    setCart(prev => prev.map(item => {
      if (`${item.type}-${item.id}` !== cartItemId) return item;
      if (typeof val === 'string') {
        if (val === '') return { ...item, quantity: '' };
        const num = Number(val);
        return { ...item, quantity: isNaN(num) ? item.quantity : Math.max(0, num) };
      }
      return { ...item, quantity: Math.max(0, val) };
    }));
  };

  const handleCostPriceChange = (cartItemId: string, val: number | string) => {
    setCart(prev => prev.map(item => {
      if (`${item.type}-${item.id}` !== cartItemId) return item;
      if (typeof val === 'string') {
        if (val === '') return { ...item, costPrice: '' };
        const num = Number(val);
        return { ...item, costPrice: isNaN(num) ? item.costPrice : Math.max(0, num) };
      }
      return { ...item, costPrice: Math.max(0, val) };
    }));
  };

  const handleRemoveItem = (cartItemId: string) =>
    setCart(prev => prev.filter(item => `${item.type}-${item.id}` !== cartItemId));

  const handleSubmit = async () => {
    const numericAmountPaid = Number(amountPaid) || 0;
    if (!selectedSupplierId) { toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى اختيار المورد.' }); return; }
    if (cart.length === 0) { toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى إضافة أصناف إلى الفاتورة.' }); return; }
    if (numericAmountPaid > totalAmount) { toast({ variant: 'destructive', title: 'خطأ', description: 'المبلغ المدفوع لا يمكن أن يكون أكبر من الإجمالي.' }); return; }
    if (numericAmountPaid > 0 && !paymentMethodId) { toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى اختيار طريقة الدفع.' }); return; }

    setIsLoading(true);
    const result = await createPurchaseInvoice({
      supplierId: selectedSupplierId,
      issueDate: new Date().toISOString(),
      invoiceNumber,
      items: cart.map(item => ({
        productId: item.type === 'product' ? item.id : null,
        rawMaterialId: item.type === 'material' ? item.id : null,
        quantity: Number(item.quantity) || 0,
        costPrice: Number(item.costPrice) || 0,
      })),
      payment: { amountPaid: numericAmountPaid, paymentMethodId },
    });
    setIsLoading(false);

    if (result.success) {
      toast({ title: 'تم بنجاح', description: result.message });
      router.push('/purchases');
    } else {
      toast({ variant: 'destructive', title: 'فشل الإنشاء', description: result.message });
    }
  };

  const remaining = Math.max(0, totalAmount - (Number(amountPaid) || 0));

  return (
    <div className="flex h-full flex-col min-h-0 bg-muted/30" dir="rtl">
      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-2 gap-0">

        {/* ══════════════════════════════════════
            PANEL RIGHT — Products / Materials
        ══════════════════════════════════════ */}
        <div className="h-full flex flex-col min-h-0 border-l border-border/40">

          {/* Header */}
          <div className="shrink-0 bg-card border-b border-border/40 px-5 py-4 shadow-sm">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center border border-primary/20">
                  <Package className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h2 className="text-base font-black text-foreground">
                    {IS_RESTAURANT_APP ? 'المواد الخام' : 'المنتجات'}
                  </h2>
                  <p className="text-xs text-muted-foreground font-medium mt-0.5">
                    {filteredSearchableItems.length} صنف متاح للإضافة
                  </p>
                </div>
              </div>
              <div className="relative w-64">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                <input
                  ref={searchInputRef}
                  placeholder="ابحث بالاسم أو الكود..."
                  value={itemSearchTerm}
                  onChange={(e) => setItemSearchTerm(e.target.value)}
                  onKeyDown={handleItemSearchKeyDown}
                  className="w-full pr-10 pl-4 h-10 rounded-xl border border-border/60 bg-muted/40 text-sm text-right placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/25 focus:border-primary/50 focus:bg-background transition-all"
                />
              </div>
            </div>
          </div>

          {/* Category Pills */}
          {!IS_RESTAURANT_APP && categories.length > 0 && (
            <div className="shrink-0 bg-muted/20 border-b border-border/30 px-4 py-2.5">
              <ScrollArea className="w-full whitespace-nowrap" dir="ltr">
                <div className="flex flex-row-reverse gap-1.5">
                  <button
                    onClick={() => setSelectedCategoryIdFilter(null)}
                    className={cn(
                      'px-4 py-1.5 text-[11px] font-extrabold rounded-full border transition-all duration-150',
                      !selectedCategoryIdFilter
                        ? 'bg-primary text-primary-foreground border-primary shadow-sm shadow-primary/20'
                        : 'bg-background border-border/50 text-muted-foreground hover:border-primary/40 hover:text-primary'
                    )}
                  >الكل</button>
                  {categories.map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategoryIdFilter(cat.id)}
                      className={cn(
                        'px-4 py-1.5 text-[11px] font-extrabold rounded-full border transition-all duration-150',
                        selectedCategoryIdFilter === cat.id
                          ? 'bg-primary text-primary-foreground border-primary shadow-sm shadow-primary/20'
                          : 'bg-background border-border/50 text-muted-foreground hover:border-primary/40 hover:text-primary'
                      )}
                    >{cat.name}</button>
                  ))}
                </div>
                <ScrollBar orientation="horizontal" />
              </ScrollArea>
            </div>
          )}

          {/* Products Grid */}
          <div className="flex-1 min-h-0 overflow-y-auto p-4">
            {filteredSearchableItems.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                {filteredSearchableItems.map(item => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleAddItem(item)}
                    className="group relative flex flex-col items-center text-center rounded-2xl p-3.5 border border-border/50 bg-card hover:border-primary/50 hover:shadow-xl hover:shadow-primary/8 hover:-translate-y-0.5 active:translate-y-0 active:scale-[.98] transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary/30 overflow-hidden"
                  >
                    {/* glow overlay */}
                    <div className="absolute inset-0 bg-gradient-to-b from-primary/0 to-primary/0 group-hover:from-primary/4 group-hover:to-transparent transition-all duration-300 rounded-2xl pointer-events-none" />

                    {/* Icon */}
                    <div className="relative w-full aspect-square bg-gradient-to-br from-muted/70 to-muted/30 group-hover:from-primary/10 group-hover:to-muted/30 rounded-xl mb-3 flex items-center justify-center transition-all duration-200">
                      <Package className="h-9 w-9 text-muted-foreground/25 group-hover:text-primary/30 transition-colors" />
                      {item.code && (
                        <span className="absolute bottom-1.5 right-1.5 bg-background/95 border border-border/50 text-[9px] font-black px-1.5 py-0.5 rounded-lg font-mono text-muted-foreground">
                          {item.code}
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] font-bold leading-snug line-clamp-2 text-foreground group-hover:text-primary transition-colors min-h-[2.5rem] flex items-center justify-center w-full">
                      {item.name}
                    </p>
                  </button>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full py-20 text-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-muted/50 flex items-center justify-center">
                  <Package className="h-8 w-8 text-muted-foreground/25" />
                </div>
                <div>
                  <p className="font-bold text-foreground text-sm">لا توجد أصناف مطابقة</p>
                  <p className="text-xs text-muted-foreground mt-1">جرّب تغيير مصطلح البحث</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ══════════════════════════════════════
            PANEL LEFT — Cart + Supplier + Payment
        ══════════════════════════════════════ */}
        <div className="h-full flex flex-col min-h-0 bg-card border-r border-border/40 shadow-2xl shadow-black/5">

          {/* Cart Header */}
          <div className="shrink-0 bg-gradient-to-br from-primary/8 via-primary/4 to-transparent border-b border-border/40 px-4 py-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
                <ShoppingCart className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-sm font-black text-foreground">فاتورة شراء جديدة</h2>
                <p className="text-[11px] text-muted-foreground font-medium">
                  {cart.length > 0
                    ? `${cart.length} صنف — إجمالي ${formatCurrency(totalAmount)} SDG`
                    : 'لم يتم إضافة أصناف بعد'}
                </p>
              </div>
              {cart.length > 0 && (
                <span className="text-xs font-black text-primary bg-primary/10 border border-primary/20 px-3 py-1.5 rounded-xl tabular-nums">
                  {formatCurrency(totalAmount)} SDG
                </span>
              )}
            </div>

            {/* Supplier + Invoice Number */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="space-y-1.5">
                <label className="text-[10px] font-extrabold text-muted-foreground/80 uppercase tracking-widest">المورد *</label>
                <div className="flex gap-1.5">
                  <div className="flex-grow min-w-0">
                    <Select onValueChange={setSelectedSupplierId} value={selectedSupplierId || undefined}>
                      <SelectTrigger className="rounded-xl h-9 text-xs border-border/50 bg-background/70 hover:bg-background">
                        <SelectValue placeholder="اختر المورد..." />
                      </SelectTrigger>
                      <SelectContent dir="rtl">
                        {supplierList.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button type="button" variant="outline" size="icon" className="h-9 w-9 rounded-xl shrink-0 border-border/50 bg-background/70 hover:bg-background" onClick={() => setIsSupplierFormOpen(true)}>
                          <PlusCircle className="h-3.5 w-3.5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent><p>إضافة مورد جديد</p></TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-extrabold text-muted-foreground/80 uppercase tracking-widest">رقم الفاتورة</label>
                <Input
                  placeholder="اختياري..."
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  className="text-right h-9 text-xs rounded-xl border-border/50 bg-background/70 hover:bg-background"
                />
              </div>
            </div>
          </div>

          {/* ─── Cart Items (scrollable) ─── */}
          <div className="flex-1 min-h-0 overflow-y-auto">
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full py-16 gap-4 text-center">
                <div className="w-16 h-16 rounded-3xl bg-muted/40 flex items-center justify-center">
                  <ShoppingCart className="h-8 w-8 text-muted-foreground/20" />
                </div>
                <div>
                  <p className="text-sm font-bold text-muted-foreground">السلة فارغة</p>
                  <p className="text-xs text-muted-foreground/60 mt-1">اختر أصنافاً من اليسار لإضافتها</p>
                </div>
              </div>
            ) : (
              <table className="w-full border-collapse">
                <thead className="sticky top-0 z-10 bg-muted/60 backdrop-blur-sm">
                  <tr className="border-b border-border/50">
                    <th className="text-right text-[10px] font-extrabold text-muted-foreground py-2.5 px-3 uppercase tracking-widest">الصنف</th>
                    <th className="text-center text-[10px] font-extrabold text-muted-foreground py-2.5 px-1 uppercase tracking-widest w-20">الكمية</th>
                    <th className="text-center text-[10px] font-extrabold text-muted-foreground py-2.5 px-1 uppercase tracking-widest w-24">سعر التكلفة</th>
                    <th className="text-left text-[10px] font-extrabold text-primary/70 py-2.5 px-3 uppercase tracking-widest w-20">الإجمالي</th>
                    <th className="w-8 px-1"></th>
                  </tr>
                </thead>
                <tbody>
                  {cart.map((item, idx) => (
                    <tr
                      key={`${item.type}-${item.id}`}
                      className={cn(
                        'group border-b border-border/20 transition-colors hover:bg-primary/3',
                        idx % 2 === 0 ? 'bg-background' : 'bg-muted/10'
                      )}
                    >
                      <td className="py-2 px-3">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-primary/15 to-primary/5 border border-primary/10 flex items-center justify-center shrink-0">
                            <Package className="h-3.5 w-3.5 text-primary/60" />
                          </div>
                          <p className="text-[11px] font-semibold text-foreground line-clamp-2 leading-tight">{item.name}</p>
                        </div>
                      </td>
                      <td className="py-2 px-1 text-center">
                        <input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => handleQuantityChange(`${item.type}-${item.id}`, e.target.value)}
                          className="w-16 h-7 text-center text-xs font-bold rounded-lg border border-border/40 bg-background/80 focus:outline-none focus:ring-1 focus:ring-primary/30 focus:border-primary/40 transition-all"
                          min="0"
                        />
                      </td>
                      <td className="py-2 px-1 text-center">
                        <input
                          type="number"
                          value={item.costPrice}
                          onChange={(e) => handleCostPriceChange(`${item.type}-${item.id}`, e.target.value)}
                          className="w-20 h-7 text-center text-xs font-bold rounded-lg border border-border/40 bg-background/80 font-mono focus:outline-none focus:ring-1 focus:ring-primary/30 focus:border-primary/40 transition-all"
                          step="0.01"
                          min="0"
                        />
                      </td>
                      <td className="py-2 px-3 text-left">
                        <span className="text-xs font-extrabold text-primary font-mono tabular-nums">
                          {formatCurrency((Number(item.quantity) || 0) * (Number(item.costPrice) || 0))}
                        </span>
                      </td>
                      <td className="py-2 pr-1">
                        <button
                          onClick={() => handleRemoveItem(`${item.type}-${item.id}`)}
                          className="w-6 h-6 rounded-lg flex items-center justify-center text-muted-foreground/30 hover:text-destructive hover:bg-destructive/10 transition-all opacity-60 group-hover:opacity-100"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* ─── Payment Footer ─── */}
          <div className="shrink-0 border-t border-border/40 bg-card px-4 py-4 space-y-3">

            {/* Payment fields */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="space-y-1.5">
                <label className="text-[10px] font-extrabold text-muted-foreground/80 uppercase tracking-widest">المبلغ المدفوع</label>
                <div className="relative">
                  <Coins className="absolute right-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-emerald-500 pointer-events-none" />
                  <Input
                    type="number"
                    placeholder="0"
                    value={amountPaid}
                    onChange={e => setAmountPaid(e.target.value)}
                    className="pr-9 h-9 text-xs font-bold font-mono rounded-xl border-border/50 bg-background text-right"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-extrabold text-muted-foreground/80 uppercase tracking-widest">طريقة الدفع</label>
                <Select
                  onValueChange={setPaymentMethodId}
                  value={paymentMethodId || ''}
                  disabled={(Number(amountPaid) || 0) <= 0}
                >
                  <SelectTrigger className="rounded-xl h-9 text-xs border-border/50 bg-background">
                    <SelectValue placeholder="اختر..." />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentMethods.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Summary strip */}
            <div className="rounded-2xl border border-border/50 overflow-hidden shadow-sm">
              <div className="grid grid-cols-3 divide-x divide-x-reverse divide-border/40">
                <div className="px-3 py-3 text-center bg-muted/20">
                  <p className="text-[9px] font-extrabold text-muted-foreground uppercase tracking-widest mb-1">الإجمالي</p>
                  <p className="text-base font-black text-foreground font-mono leading-none tabular-nums">{formatCurrency(totalAmount)}</p>
                  <p className="text-[9px] text-muted-foreground/60 mt-0.5 font-medium">SDG</p>
                </div>
                <div className="px-3 py-3 text-center bg-emerald-500/5">
                  <p className="text-[9px] font-extrabold text-emerald-600 uppercase tracking-widest mb-1">مدفوع</p>
                  <p className="text-base font-black text-emerald-600 font-mono leading-none tabular-nums">{formatCurrency(Number(amountPaid) || 0)}</p>
                  <p className="text-[9px] text-emerald-500/60 mt-0.5 font-medium">SDG</p>
                </div>
                <div className={cn("px-3 py-3 text-center", remaining > 0 ? 'bg-red-500/5' : 'bg-emerald-500/5')}>
                  <p className={cn("text-[9px] font-extrabold uppercase tracking-widest mb-1", remaining > 0 ? 'text-red-500' : 'text-emerald-600')}>متبقي</p>
                  <p className={cn("text-base font-black font-mono leading-none tabular-nums", remaining > 0 ? 'text-red-500' : 'text-emerald-600')}>{formatCurrency(remaining)}</p>
                  <p className={cn("text-[9px] mt-0.5 font-medium", remaining > 0 ? 'text-red-400/60' : 'text-emerald-500/60')}>SDG</p>
                </div>
              </div>
            </div>

            {/* Save Button */}
            <Button
              className="w-full h-12 text-sm font-black rounded-2xl bg-gradient-to-r from-primary via-primary to-primary/80 hover:opacity-90 shadow-lg shadow-primary/25 hover:shadow-primary/35 active:scale-[.98] transition-all gap-2"
              onClick={handleSubmit}
              disabled={isLoading || cart.length === 0 || !selectedSupplierId}
            >
              {isLoading ? (
                <><LoaderCircle className="h-4 w-4 animate-spin" />جاري الحفظ...</>
              ) : (
                <><ChevronRight className="h-4 w-4" />حفظ الفاتورة وإضافة للمخزون</>
              )}
            </Button>
          </div>
        </div>
      </div>

      <Dialog open={isSupplierFormOpen} onOpenChange={setIsSupplierFormOpen}>
        <DialogContent className="sm:max-w-[425px] rounded-2xl" dir="rtl">
          <SupplierForm
            supplier={null}
            onSubmit={handleAddSupplierSubmit}
            onCancel={() => setIsSupplierFormOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
