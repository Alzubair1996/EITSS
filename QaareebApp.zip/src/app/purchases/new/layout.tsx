
export default function NewPurchaseLayout({
  children,
}: { children: React.ReactNode }) {
  return (
    <div className="h-dvh overflow-hidden flex flex-col">
      <main className="flex-1 min-h-0">
        {children}
      </main>
    </div>
  );
}
