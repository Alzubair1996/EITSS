
import { getSuppliers, getProducts, getPaymentMethods, getRawMaterials, getCompanyInfo, getCategories } from '@/lib/queries';
import PurchaseInvoiceForm from './purchase-invoice-form';

export default async function NewPurchaseInvoicePage() {
  const suppliers = await getSuppliers();
  const products = await getProducts();
  const categories = await getCategories();
  const paymentMethods = await getPaymentMethods();
  const rawMaterials = await getRawMaterials();
  const companyInfo = await getCompanyInfo();

  return (
    <PurchaseInvoiceForm
        suppliers={suppliers}
        products={products}
        paymentMethods={paymentMethods}
        rawMaterials={rawMaterials}
        companyInfo={companyInfo}
        categories={categories}
    />
  );
}
