'use client';

import { Button } from '@/components/ui/button';
import { ArrowLeft, Printer } from 'lucide-react';
import { useRouter } from 'next/navigation';
import * as React from 'react';

export default function PrintClientPage() {
  const router = useRouter();

  const handlePrint = () => {
    window.print();
  };

  React.useEffect(() => {
    // Only auto-print if not inside an iframe (i.e., viewing directly in browser)
    const isInIframe = typeof window !== 'undefined' && window.self !== window.top;
    
    if (!isInIframe) {
      const timeoutId = setTimeout(() => {
          handlePrint();
      }, 500);

      return () => {
        clearTimeout(timeoutId);
      };
    }
  }, []);

  return (
    <>
      <style>{`/* Ensure elements marked as no-print are hidden in the print preview iframe */\n.no-print { display: none !important; }`}</style>
      <div className="no-print fixed top-4 left-4 flex gap-2">
        <Button onClick={() => router.back()} variant="outline" size="icon">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <Button onClick={handlePrint} size="icon">
          <Printer className="h-4 w-4" />
        </Button>
      </div>
    </>
  );
}

