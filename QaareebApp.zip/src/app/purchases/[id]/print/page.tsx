
import { getPurchaseInvoiceDetails, getCompanyInfo, getInvoiceTemplate, getPrintType } from '@/lib/queries';
import { notFound } from 'next/navigation';
import PrintClientPage from './print-client-page';
import { format } from 'date-fns';
import Mustache from 'mustache';
import { IS_RESTAURANT_APP } from '@/lib/types';
import { cn } from '@/lib/utils';
import { getDbInstance } from '@/lib/db';

export default async function PurchaseInvoicePrintPage({ params }: { params: { id: string } }) {
  const invoice = await getPurchaseInvoiceDetails(params.id);
  const companyInfo = await getCompanyInfo();
  let templateHtml = await getInvoiceTemplate();
  const printType = await getPrintType();

  if (!invoice) {
    notFound();
  }

  const invoiceNumberDisplay = `رقم الفاتورة: ${invoice.invoiceNumber || 'N/A'}`;
  const invoiceTitle = 'فاتورة شراء';

  const modernTemplate = `
      <div id="invoice-print" class="font-body print-container-a4 bg-white p-8 w-full mx-auto shadow-lg flex flex-col">
          <header class="flex justify-between items-start pb-4 border-b-4 border-gray-800">
            <div class="text-right">
                {{#companyLogo}}
                    <img src="{{companyLogo}}" alt="Company Logo" style="width: 120px; height: 120px; border-radius: 0.375rem; object-fit: contain; margin-bottom: 0.5rem;" />
                {{/companyLogo}}
                {{^companyLogo}}
                    <div style="width: 120px; height: 120px; background-color: #f1f5f9; border-radius: 0.375rem; display: flex; align-items: center; justify-content: center; margin-bottom: 0.5rem;">
                       <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    </div>
                {{/companyLogo}}
                <h1 class="text-3xl font-bold text-gray-800">{{companyName}}</h1>
                <p class="text-gray-500">{{companyAddress}}</p>
                <p class="text-gray-500">{{companyPhones}}</p>
            </div>
            <div class="text-left mt-4">
                <h2 class="text-4xl font-bold text-gray-500 uppercase">{{invoiceTitle}}</h2>
                <div class="mt-2 text-right" dir="rtl">
                    <p><span class="font-bold">{{invoiceNumberDisplay}}</span></p>
                    <p><span class="font-bold">التاريخ:</span> {{issueDate}}</p>
                </div>
            </div>
        </header>
        <section class="my-8" dir="rtl">
            <div class="bg-gray-100 p-4 rounded-lg">
                <h3 class="text-lg font-bold mb-2">من:</h3>
                <p class="font-semibold text-xl">{{supplierName}}</p>
                <p>{{supplierPhone}}</p>
            </div>
        </section>
        <section class="mb-auto">
            <table class="w-full text-right border-collapse" dir="rtl">
                <thead class="border-b-2 border-gray-300">
                    <tr class="bg-gray-800 text-white">
                        <th class="p-2 text-right">#</th>
                        <th class="p-2 text-right w-3/5">الصنف</th>
                        <th class="p-2 text-center">الكمية</th>
                        <th class="p-2 text-center">سعر الشراء</th>
                        <th class="p-2 text-right">الإجمالي</th>
                    </tr>
                </thead>
                <tbody>
                    {{{items}}}
                </tbody>
            </table>
        </section>
        <div class="flex-grow"></div>
        <section class="flex justify-end mt-8">
            <div class="w-1/2 text-right" dir="rtl">
                <table class="w-full">
                    <tbody>
                        {{{totals}}}
                    </tbody>
                </table>
            </div>
        </section>
        <footer class="mt-auto pt-4 border-t-2 border-gray-800 flex justify-between items-center text-sm text-gray-500">
            <p class="text-left" dir="ltr">© جميع الحقوق محفوظة لدى EITSS الباقرة لتقنية المعلومات</p>
            <p>فاتورة شراء</p>
        </footer>
    </div>
    `;

  const classicTemplate = `
      <div id="invoice-print" class="font-body print-container-a4 bg-white p-8 w-full mx-auto shadow-lg flex flex-col" dir="rtl">
          <header class="text-center pb-4 border-b-2 border-gray-800">
              {{#companyLogo}}
                  <img src="{{companyLogo}}" alt="Company Logo" style="width: 100px; height: 100px; border-radius: 50%; object-fit: contain; margin: 0 auto 1rem;" />
              {{/companyLogo}}
              <h1 class="text-4xl font-bold text-gray-800">{{companyName}}</h1>
              <p class="text-gray-600">{{companyAddress}}</p>
              <p class="text-gray-600">هاتف: {{companyPhones}}</p>
          </header>
          <div class="flex justify-between items-center my-6">
              <div>
                  <h3 class="text-lg font-bold">من:</h3>
                  <p class="font-semibold text-xl">{{supplierName}}</p>
                  <p>{{supplierPhone}}</p>
              </div>
              <div class="text-left">
                  <h2 class="text-2xl font-bold text-gray-700">{{invoiceTitle}}</h2>
                  <p><span class="font-bold">{{invoiceNumberDisplay}}</span></p>
                  <p><span class="font-bold">التاريخ:</span> {{issueDate}}</p>
              </div>
          </div>
          <section class="mb-auto">
              <table class="w-full text-right border-collapse" dir="rtl">
                  <thead>
                      <tr class="border-y-2 border-gray-400">
                          <th class="p-2">م</th>
                          <th class="p-2 w-2/4">البيان</th>
                          <th class="p-2">الكمية</th>
                          <th class="p-2">سعر الوحدة</th>
                          <th class="p-2 text-right">الإجمالي</th>
                      </tr>
                  </thead>
                  <tbody>
                      {{{items}}}
                  </tbody>
              </table>
          </section>
          <div class="flex-grow"></div>
          <section class="flex justify-between mt-8 items-start">
              <div class="w-1/2">
                   <p class="font-bold">ملاحظات:</p>
                   <p class="text-sm"></p>
              </div>
              <div class="w-2/5 text-right" dir="rtl">
                  <table class="w-full">
                      <tbody>
                          {{{totals}}}
                      </tbody>
                  </table>
              </div>
          </section>
          <div class="flex justify-between items-end mt-24">
              <div class="text-center w-1/2">
                  <p>.............................</p>
                  <p class="font-bold">توقيع البائع</p>
              </div>
              <div class="text-center w-1/2">
                  <p>.............................</p>
                  <p class="font-bold">توقيع المستلم</p>
              </div>
          </div>
          <footer class="mt-auto pt-4 flex justify-between items-center text-xs text-gray-400">
              <p class="text-left" dir="ltr">© جميع الحقوق محفوظة لدى EITSS الباقرة لتقنية المعلومات</p>
              <p>فاتورة شراء</p>
          </footer>
      </div>
  `;
  
  const thermalTemplate = `
    <div id="invoice-print" class="font-body print-container-thermal bg-white text-black mx-auto" dir="rtl" style="padding: 0;">
        <header class="flex items-center mb-1">
            {{#companyLogo}}
                <img src="{{companyLogo}}" alt="Logo" style="width: 48px; height: 48px; margin-left: 8px; border-radius: 4px;" />
            {{/companyLogo}}
            <div class="text-right flex-grow">
                <h1 class="font-bold" style="font-size: 14px;">{{companyName}}</h1>
                <p style="font-size: 10px; line-height: 1.2;">{{companyAddress}} - {{companyPhones}}</p>
            </div>
        </header>
        <hr class="border-dashed border-black my-1"/>
        <div class="text-right" style="font-size: 10px;">
            <p>{{invoiceNumberDisplay}} | التاريخ: {{issueDate}}</p>
            <p>المورد: {{supplierName}} | هاتف: {{supplierPhone}}</p>
        </div>
        <hr class="border-dashed border-black my-1"/>
        <table class="w-full text-right" style="font-size: 11px; border-collapse: collapse; border: 1px solid black;">
            <thead>
                <tr style="background-color: black !important; color: white !important;">
                    <th class="p-1 text-right font-bold" style="border: 1px solid black;">الصنف</th>
                    <th class="p-1 text-center font-bold" style="border: 1px solid black;">سعر</th>
                    <th class="p-1 text-center font-bold" style="border: 1px solid black;">ك</th>
                    <th class="p-1 text-right font-bold" style="border: 1px solid black;">إجمالي</th>
                </tr>
            </thead>
            <tbody>
                {{{items}}}
            </tbody>
        </table>
        <hr class="border-dashed border-black my-1"/>
        <table class="w-full" style="font-size: 10px;">
             <tbody>
                {{{totals}}}
            </tbody>
        </table>
        <hr class="border-dashed border-black my-1"/>
        <footer class="text-center mt-1" style="font-size: 9px;">
            <p>فاتورة شراء</p>
             <div style="display: flex; align-items: center; justify-content: center; gap: 4px; margin-top: 4px; font-family: sans-serif;">
                <p>© جميع الحقوق محفوظة لدى EITSS الباقرة لتقنية المعلومات</p>
            </div>
        </footer>
    </div>
  `;

  let finalTemplate: string;
  let itemsHtml: string;
  let totalsHtml: string;

  const db = await getDbInstance();

  // Load returned items and totals for this invoice
  const returnedItems = await db.all(`
      SELECT pri.productId, pri.rawMaterialId, pri.quantity, pri.costPrice
      FROM purchase_return_items pri
      JOIN purchase_returns pr ON pri.purchaseReturnId = pr.id
      WHERE pr.purchaseInvoiceId = ?
  `, params.id) as { productId: string | null; rawMaterialId: string | null; quantity: number; costPrice: number }[];

  const returnedByItem: Record<string, number> = {};
  let totalReturned = 0;
  returnedItems.forEach(item => {
      const key = item.productId || item.rawMaterialId;
      if (key) {
          returnedByItem[key] = (returnedByItem[key] || 0) + item.quantity;
      }
      totalReturned += item.quantity * item.costPrice;
  });

  const formatCurrency = (num: number) => Math.round(num).toLocaleString('en-US');
  const total = invoice.totalAmount;
  const remaining = Math.max(0, invoice.totalAmount - invoice.amountPaid - totalReturned);

  if (printType === 'thermal') {
    finalTemplate = thermalTemplate;
    itemsHtml = invoice.items.map((item) => {
      const returnedQty = returnedByItem[item.productId || item.rawMaterialId || ''] || 0;
      const qtyDisplay = returnedQty > 0 ? `${item.quantity} (-${returnedQty})` : `${item.quantity}`;
      return `
        <tr class="border-b border-black">
          <td class="p-1" style="border: 1px solid black;">${item.productName || item.rawMaterialName || 'N/A'}</td>
          <td class="p-1 text-center" style="border: 1px solid black;">${formatCurrency(item.costPrice)}</td>
          <td class="p-1 text-center" style="border: 1px solid black;">${qtyDisplay}</td>
          <td class="p-1 text-right" style="border: 1px solid black;">${formatCurrency(item.quantity * item.costPrice)}</td>
        </tr>
      `;
    }).join('');
    
    let thermalTotalsContent = '';
    const hasPayment = invoice.status === 'partial' || invoice.status === 'unpaid' || totalReturned > 0;

    if (hasPayment) {
        thermalTotalsContent += `<tr class=""><td class="p-1 font-semibold">الإجمالي الأصلي:</td><td class="p-1 text-right" style="color: black;">${formatCurrency(total)}</td></tr>`;
        if (totalReturned > 0) {
            thermalTotalsContent += `<tr class="text-red-600"><td class="p-1 font-semibold">المرتجع:</td><td class="p-1 text-right font-bold" style="color: red;">-${formatCurrency(totalReturned)}</td></tr>`;
        }
        thermalTotalsContent += `<tr><td class="p-1">المدفوع:</td><td class="p-1 text-right" style="color: black;">${formatCurrency(invoice.amountPaid)}</td></tr>`;
        thermalTotalsContent += `<tr><td class="p-1 font-bold">المتبقي المطلوب:</td><td class="p-1 text-right font-bold" style="color: black;">${formatCurrency(remaining)}</td></tr>`;
    } else {
        thermalTotalsContent = `<tr class="font-bold border-t border-dashed" style="font-size: 12px;"><td class="p-1">الإجمالي:</td><td class="p-1 text-right" style="color: black;">${formatCurrency(invoice.totalAmount)}</td></tr>`;
    }
    
    totalsHtml = thermalTotalsContent;

  } else { // A4 print
    if (templateHtml && templateHtml.trim() !== '') {
        finalTemplate = templateHtml;
    } else {
        finalTemplate = companyInfo.invoiceTemplate === 'classic' ? classicTemplate : modernTemplate;
    }

    itemsHtml = invoice.items.map((item, index) => {
      const returnedQty = returnedByItem[item.productId || item.rawMaterialId || ''] || 0;
      const qtyDisplay = returnedQty > 0 
          ? `<span>${item.quantity}</span> <span class="text-red-500 font-bold block text-xs" dir="rtl">(أرجع ${returnedQty})</span>` 
          : `<span>${item.quantity}</span>`;
      return `
        <tr class="border-b">
          <td class="p-2">${index + 1}</td>
          <td class="p-2">${item.productName || item.rawMaterialName || 'N/A'}</td>
          <td class="p-2 text-center">${qtyDisplay}</td>
          <td class="p-2 text-center">${formatCurrency(item.costPrice)}</td>
          <td class="p-2 text-right">${formatCurrency(item.costPrice * item.quantity)}</td>
        </tr>
      `;
    }).join('');
    
    const hasPayment = invoice.status === 'partial' || invoice.status === 'unpaid' || totalReturned > 0;
    if(hasPayment){
      totalsHtml = `
        <tr>
            <td class="p-2 font-semibold">الإجمالي الأصلي:</td>
            <td class="p-2 text-right">${formatCurrency(total)} SDG</td>
        </tr>
      `;
      if (totalReturned > 0) {
        totalsHtml += `
          <tr class="text-red-600">
              <td class="p-2 font-semibold">قيمة المرتجع:</td>
              <td class="p-2 text-right font-bold">-${formatCurrency(totalReturned)} SDG</td>
          </tr>
        `;
      }
      totalsHtml += `
        <tr>
            <td class="p-2 font-semibold text-green-600">المدفوع:</td>
            <td class="p-2 text-right text-green-600">${formatCurrency(invoice.amountPaid)} SDG</td>
        </tr>
        <tr class="font-bold text-lg bg-red-100 rounded-lg">
            <td class="p-2 text-red-700">المتبقي المطلوب:</td>
            <td class="p-2 text-right text-red-700">${formatCurrency(remaining)} SDG</td>
        </tr>
      `;
    } else {
        totalsHtml = `
          <tr class="font-bold text-lg bg-green-100 rounded-lg">
              <td class="p-2">الإجمالي:</td>
              <td class="p-2 text-right text-green-700">${formatCurrency(invoice.totalAmount)} SDG</td>
          </tr>
        `;
    }
  }

  const view = {
    companyName: companyInfo.name,
    companyLogo: companyInfo.logo,
    companyAddress: companyInfo.address,
    companyPhones: companyInfo.phones,
    invoiceNumber: invoice.invoiceNumber,
    issueDate: format(new Date(invoice.issueDate), 'yyyy/MM/dd HH:mm'),
    supplierName: invoice.supplierName,
    supplierPhone: '',
    items: itemsHtml,
    totals: totalsHtml,
    totalAmount: formatCurrency(invoice.totalAmount),
    amountPaid: formatCurrency(invoice.amountPaid),
    remainingAmount: formatCurrency(remaining),
    invoiceTitle: invoiceTitle,
    invoiceNumberDisplay: invoiceNumberDisplay,
  };

  const renderedHtml = Mustache.render(finalTemplate, view);
  
  return (
    <div className={cn(printType === 'thermal' && 'thermal-print-page')}>
       <PrintClientPage />
       <div className="font-body bg-gray-100 text-black" dangerouslySetInnerHTML={{ __html: renderedHtml }} />
    </div>
  );
}

