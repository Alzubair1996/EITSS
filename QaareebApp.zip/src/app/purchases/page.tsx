import { getPurchaseInvoices, getPurchaseReturns } from '@/lib/queries';
import PurchasesClientPage from './purchases-table';

export default async function PurchasesPage() {
  const purchaseInvoices = await getPurchaseInvoices();
  const purchaseReturns = await getPurchaseReturns();

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
      <PurchasesClientPage 
        initialPurchases={purchaseInvoices} 
        purchaseReturns={purchaseReturns} 
      />
    </div>
  );
}
