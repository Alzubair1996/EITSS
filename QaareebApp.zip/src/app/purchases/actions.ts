
'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import { randomUUID } from 'crypto';
import { IS_RESTAURANT_APP } from '@/lib/types';
import { getSession } from '@/lib/server-auth';

interface PurchaseItemInput {
    productId: string | null;
    rawMaterialId: string | null;
    quantity: number;
    costPrice: number;
}
interface CreatePurchaseInvoiceInput {
    supplierId: string;
    issueDate: string;
    invoiceNumber: string | null;
    items: PurchaseItemInput[];
    payment: {
        amountPaid: number;
        paymentMethodId: string | null;
    }
}

export async function createPurchaseInvoice(data: CreatePurchaseInvoiceInput) {
    const { supplierId, issueDate, invoiceNumber, items, payment } = data;

    if (!supplierId || items.length === 0) {
        return { success: false, message: 'يجب اختيار المورد وإضافة منتجات.' };
    }
    
    const db = await getDbInstance();
    // Get current user to attribute this purchase invoice
    const session = await getSession();
    const userId = session?.userId || null;

    try {
        await db.exec('BEGIN');

        // 1. Calculate total amount
        const totalAmount = items.reduce((sum, item) => sum + item.quantity * item.costPrice, 0);
        if (totalAmount <= 0) {
            throw new Error('مبلغ الفاتورة يجب أن يكون أكبر من صفر.');
        }

        const { amountPaid, paymentMethodId } = payment;
        if (amountPaid > totalAmount) {
            throw new Error('المبلغ المدفوع لا يمكن أن يكون أكبر من الإجمالي.');
        }
        if (amountPaid > 0 && !paymentMethodId) {
            throw new Error('يجب اختيار طريقة الدفع عند وجود مبلغ مدفوع.');
        }

        // 2. Check payment method balance if payment is made
        if (amountPaid > 0 && paymentMethodId) {
            const pm = await db.get('SELECT balance FROM payment_methods WHERE id = ?', paymentMethodId) as { balance: number };
            if (pm.balance < amountPaid) {
                throw new Error('الرصيد في طريقة الدفع غير كافٍ.');
            }
        }

        // 3. Determine status
        let status: 'paid' | 'partial' | 'unpaid' = 'unpaid';
        if (amountPaid > 0) {
            status = Math.abs(amountPaid - totalAmount) < 0.001 ? 'paid' : 'partial';
        }

        // 4. Insert into purchase_invoices table
        const purchaseInvoiceId = `pur_inv_${randomUUID()}`;
        await db.run(`
            INSERT INTO purchase_invoices (id, invoiceNumber, supplierId, issueDate, totalAmount, amountPaid, status, userId)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, purchaseInvoiceId, invoiceNumber || null, supplierId, issueDate, totalAmount, amountPaid, status, userId);

        // 5. Insert items and update product stock
        for (const item of items) {
            await db.run('INSERT INTO purchase_invoice_items (id, purchaseInvoiceId, productId, rawMaterialId, quantity, costPrice) VALUES (?, ?, ?, ?, ?, ?)', 
            `pur_item_${randomUUID()}`, 
            purchaseInvoiceId, 
            item.productId, 
            item.rawMaterialId, 
            item.quantity, 
            item.costPrice
            );

            if (IS_RESTAURANT_APP && item.rawMaterialId) {
                await db.run('UPDATE raw_materials SET quantityInStock = quantityInStock + ? WHERE id = ?', item.quantity, item.rawMaterialId);
            } else if (!IS_RESTAURANT_APP && item.productId) {
                const prod = await db.get('SELECT initialUSDRate FROM products WHERE id = ?', item.productId) as { initialUSDRate?: number } | undefined;
                const rate = prod?.initialUSDRate || 0;
                const costPriceUSD = (item.costPrice > 0 && rate > 0) ? item.costPrice / rate : 0;
                await db.run(
                    'UPDATE products SET quantity = quantity + ?, costPrice = ?, costPriceUSD = ? WHERE id = ?',
                    item.quantity,
                    item.costPrice,
                    costPriceUSD,
                    item.productId
                );
            }
        }

        // 6. Handle payment
        if (amountPaid > 0 && paymentMethodId) {
            // Insert payment record in supplier_payments table
            const paymentDescription = `دفعة لفاتورة شراء ${invoiceNumber ? `#${invoiceNumber}` : ''}`;
            await db.run(`
                INSERT INTO supplier_payments (id, supplierId, paymentMethodId, amount, paymentDate, description, referenceNumber, userId)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `, `sup_pay_${randomUUID()}`, supplierId, paymentMethodId, amountPaid, issueDate, paymentDescription, invoiceNumber, userId);
            
            // This is an expense, so we subtract from the payment method balance
            await db.run('UPDATE payment_methods SET balance = balance - ? WHERE id = ?', amountPaid, paymentMethodId);
        }
        
        // 7. Update supplier balance (our debt to them)
        const debt = totalAmount - amountPaid;
        await db.run('UPDATE suppliers SET balance = balance + ? WHERE id = ?', debt, supplierId);

        await db.exec('COMMIT');

        revalidatePath('/purchases');
        if(IS_RESTAURANT_APP) {
            revalidatePath('/materials');
        } else {
            revalidatePath('/products');
        }
        revalidatePath('/suppliers');
        revalidatePath('/payment-methods');
        revalidatePath('/');
        return { success: true, message: 'تم إنشاء فاتورة الشراء بنجاح.', purchaseInvoiceId };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to create purchase invoice:', e);
        return { success: false, message: e.message || 'خطأ في قاعدة البيانات: فشل إنشاء الفاتورة.' };
    }
}
