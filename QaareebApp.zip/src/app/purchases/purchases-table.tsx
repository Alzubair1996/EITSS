'use client';

import * as React from 'react';
import type { PurchaseInvoiceDetails, PaymentMethod } from '@/lib/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import {
  Eye,
  Printer,
  Search,
  PlusCircle,
  ShoppingCart,
  TrendingUp,
  CreditCard,
  ChevronLeft,
  ChevronRight,
  XCircle,
  FileText,
  RotateCcw,
  Filter,
  CalendarDays,
  DollarSign,
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import { PageHeader } from '@/components/page-header';
import { useRouter } from 'next/navigation';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { IS_RESTAURANT_APP } from '@/lib/types';

interface PurchasesClientPageProps {
  initialPurchases: PurchaseInvoiceDetails[];
  purchaseReturns: any[];
}

const STATUS_CONFIG = {
  paid: { text: 'مدفوعة', variant: 'success' as const, dot: 'bg-emerald-500' },
  partial: { text: 'مدفوعة جزئياً', variant: 'warning' as const, dot: 'bg-amber-500' },
  unpaid: { text: 'غير مدفوعة', variant: 'destructive' as const, dot: 'bg-red-500' },
} as const;

const PAGE_SIZE = 15;

export default function PurchasesClientPage({ initialPurchases, purchaseReturns }: PurchasesClientPageProps) {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [statusFilter, setStatusFilter] = React.useState<string>('all');
  const [dateFilter, setDateFilter] = React.useState<string>('all');
  const [page, setPage] = React.useState(1);
  const [viewInvoiceId, setViewInvoiceId] = React.useState<string | null>(null);
  const router = useRouter();

  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  const stats = React.useMemo(() => {
    const paid = initialPurchases.filter(i => i.status === 'paid').length;
    const partial = initialPurchases.filter(i => i.status === 'partial').length;
    const unpaid = initialPurchases.filter(i => i.status === 'unpaid').length;
    const total = initialPurchases.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const paidSum = initialPurchases.reduce((sum, inv) => sum + inv.amountPaid, 0);
    const returnedSum = purchaseReturns.reduce((sum, ret) => sum + ret.totalAmount, 0);
    const remaining = Math.max(0, total - paidSum - returnedSum);
    return { paid, partial, unpaid, total, paidSum, returnedSum, remaining };
  }, [initialPurchases, purchaseReturns]);

  const filtered = React.useMemo(() => {
    const term = searchTerm.toLowerCase();
    return initialPurchases.filter(inv => {
      const matchText =
        (inv.supplierName || '').toLowerCase().includes(term) ||
        (inv.invoiceNumber || '').toLowerCase().includes(term);
      const matchStatus = statusFilter === 'all' || inv.status === statusFilter;
      
      let matchDate = true;
      if (dateFilter !== 'all') {
        const invDate = new Date(inv.issueDate);
        const now = new Date();
        const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        if (dateFilter === 'today') matchDate = invDate >= startOfToday;
        else if (dateFilter === 'week') {
          const oneWeekAgo = new Date(startOfToday.getTime() - 7 * 24 * 60 * 60 * 1000);
          matchDate = invDate >= oneWeekAgo;
        } else if (dateFilter === 'month') {
          const oneMonthAgo = new Date(startOfToday.getFullYear(), startOfToday.getMonth() - 1, startOfToday.getDate());
          matchDate = invDate >= oneMonthAgo;
        }
      }
      return matchText && matchStatus && matchDate;
    });
  }, [initialPurchases, searchTerm, statusFilter, dateFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  React.useEffect(() => setPage(1), [searchTerm, statusFilter, dateFilter]);

  const filterTabs = [
    { key: 'all', label: 'الكل', count: initialPurchases.length },
    { key: 'paid', label: 'مدفوعة', count: stats.paid },
    { key: 'partial', label: 'جزئية', count: stats.partial },
    { key: 'unpaid', label: 'غير مدفوعة', count: stats.unpaid },
  ];

  const statCards = [
    {
      label: 'إجمالي المشتريات',
      value: formatCurrency(stats.total),
      icon: ShoppingCart,
      color: 'text-primary',
      bg: 'bg-primary/8',
      border: 'border-primary/20',
    },
    {
      label: 'المرتجعات',
      value: formatCurrency(stats.returnedSum),
      icon: RotateCcw,
      color: 'text-amber-600',
      bg: 'bg-amber-500/8',
      border: 'border-amber-500/20',
    },
    {
      label: 'المبلغ المدفوع',
      value: formatCurrency(stats.paidSum),
      icon: TrendingUp,
      color: 'text-emerald-600',
      bg: 'bg-emerald-500/8',
      border: 'border-emerald-500/20',
    },
    {
      label: 'المبلغ المتبقي',
      value: formatCurrency(stats.remaining),
      icon: CreditCard,
      color: 'text-red-600',
      bg: 'bg-red-500/8',
      border: 'border-red-500/20',
    },
  ];

  return (
    <>
      <PageHeader title="المشتريات">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
            <Input
              type="search"
              placeholder="بحث بالمورد أو رقم الفاتورة..."
              className="pr-9 w-[200px] lg:w-[240px] h-9 rounded-xl bg-background border-border/60 text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button asChild size="sm" className="h-9 rounded-xl gap-1.5 px-4 shadow-sm">
            <Link href="/purchases/new">
              <PlusCircle className="h-3.5 w-3.5" />
              تسجيل فاتورة شراء
            </Link>
          </Button>
        </div>
      </PageHeader>

      <div className="flex flex-col gap-4 p-4 md:p-6 max-w-screen-xl mx-auto w-full">

        {/* Compact Stats Row */}
        {initialPurchases.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {statCards.map((s) => (
              <div
                key={s.label}
                className={cn(
                  'rounded-xl border px-3 py-2.5 flex items-center gap-2.5 bg-card',
                  s.border
                )}
              >
                <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center shrink-0', s.bg, s.color)}>
                  <s.icon className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] text-muted-foreground font-medium leading-none mb-0.5 truncate">{s.label}</p>
                  <p className="text-sm font-extrabold text-foreground leading-none truncate">{s.value}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Table Card */}
        <div className="rounded-2xl border border-border/60 bg-card overflow-hidden shadow-sm">

          {/* Unified Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b border-border/50 bg-muted/20">
            <div className="flex items-center gap-1.5 flex-wrap">
              <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
              {filterTabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setStatusFilter(tab.key)}
                  className={cn(
                    'flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition-all duration-150',
                    statusFilter === tab.key
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground hover:bg-background/80'
                  )}
                >
                  {tab.label}
                  {tab.count > 0 && (
                    <span className={cn(
                      'inline-flex items-center justify-center min-w-[16px] h-[16px] rounded-full text-[9px] font-extrabold px-1',
                      statusFilter === tab.key
                        ? 'bg-white/20 text-primary-foreground'
                        : 'bg-muted text-muted-foreground'
                    )}>
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <CalendarDays className="h-3 w-3 text-muted-foreground" />
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger className="w-[120px] bg-background border-border/60 rounded-lg text-[11px] h-7 font-medium">
                  <SelectValue placeholder="كل التواريخ" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">كل التواريخ</SelectItem>
                  <SelectItem value="today">اليوم</SelectItem>
                  <SelectItem value="week">آخر 7 أيام</SelectItem>
                  <SelectItem value="month">آخر 30 يوم</SelectItem>
                </SelectContent>
              </Select>
              <span className="text-[10px] text-muted-foreground bg-muted px-2 py-0.5 rounded-full font-medium">
                {filtered.length} نتيجة
              </span>
            </div>
          </div>

          {/* Empty States */}
          {initialPurchases.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-primary/8 flex items-center justify-center">
                <ShoppingCart className="h-7 w-7 text-primary/50" />
              </div>
              <div>
                <p className="font-bold text-foreground">لا توجد فواتير شراء بعد</p>
                <p className="text-sm text-muted-foreground mt-1">ابدأ بتسجيل أول فاتورة شراء من مورد.</p>
              </div>
              <Button asChild size="sm" className="rounded-xl gap-1.5 mt-1">
                <Link href="/purchases/new">
                  <PlusCircle className="h-3.5 w-3.5" />
                  تسجيل فاتورة شراء
                </Link>
              </Button>
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center gap-2">
              <Search className="h-8 w-8 text-muted-foreground/30" />
              <p className="font-semibold text-foreground text-sm">لا توجد نتائج</p>
              <p className="text-xs text-muted-foreground">جرّب تغيير مصطلحات البحث أو الفلتر</p>
            </div>
          ) : (
            <>
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/30 hover:bg-muted/30 border-b border-border/50">
                    <TableHead className="font-bold text-[11px] text-muted-foreground py-2.5">رقم فاتورة المورد</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground py-2.5">المورد</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground py-2.5">التاريخ</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground text-center py-2.5">الإجمالي</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground text-center py-2.5">المدفوع</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground text-center py-2.5">المرتجع</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground text-center py-2.5">المتبقي</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground text-center py-2.5">الحالة</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground py-2.5">الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TooltipProvider>
                    {paginated.map((invoice) => {
                      const cfg = STATUS_CONFIG[invoice.status as keyof typeof STATUS_CONFIG];
                      const invoiceReturns = purchaseReturns.filter(ret => ret.purchaseInvoiceId === invoice.id);
                      const returnedAmount = invoiceReturns.reduce((sum, ret) => sum + ret.totalAmount, 0);
                      const remainingAmount = Math.max(0, invoice.totalAmount - invoice.amountPaid - returnedAmount);
                      return (
                        <TableRow key={invoice.id} className="transition-colors hover:bg-muted/20 border-b border-border/30">
                          <TableCell className="py-2">
                            <span className="font-mono font-bold text-xs text-primary">
                              {invoice.invoiceNumber || '—'}
                            </span>
                          </TableCell>

                          <TableCell className="py-2">
                            <div className="flex items-center gap-1.5">
                              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                                <span className="text-[10px] font-extrabold text-primary">
                                  {(invoice.supplierName || 'م').charAt(0)}
                                </span>
                              </div>
                              <span className="font-medium text-xs text-foreground truncate max-w-[120px]">
                                {invoice.supplierName || 'مورد عام'}
                              </span>
                            </div>
                          </TableCell>

                          <TableCell className="py-2">
                            <div className="flex flex-col">
                              <span className="text-[11px] font-semibold text-foreground">
                                {format(new Date(invoice.issueDate), 'dd/MM/yyyy')}
                              </span>
                              <span className="text-[9px] text-muted-foreground">
                                {format(new Date(invoice.issueDate), 'HH:mm')}
                              </span>
                            </div>
                          </TableCell>

                          <TableCell className="text-center py-2">
                            <span className="font-extrabold text-xs text-foreground font-sans">
                              {formatCurrency(invoice.totalAmount)}
                            </span>
                          </TableCell>

                          <TableCell className="text-center py-2">
                            <span className="font-bold text-xs text-emerald-600 font-sans">
                              {formatCurrency(invoice.amountPaid)}
                            </span>
                          </TableCell>

                          <TableCell className="text-center py-2">
                            <span className={cn("font-bold text-xs font-sans", returnedAmount > 0 ? "text-amber-600" : "text-muted-foreground/50")}>
                              {formatCurrency(returnedAmount)}
                            </span>
                          </TableCell>

                          <TableCell className="text-center py-2">
                            <span className={cn("font-extrabold text-xs font-sans", remainingAmount > 0 ? "text-red-600" : "text-muted-foreground/50")}>
                              {formatCurrency(remainingAmount)}
                            </span>
                          </TableCell>

                          <TableCell className="text-center py-2">
                            <Badge
                              variant={cfg?.variant || 'default'}
                              className="rounded-full gap-1 px-2 py-0.5 text-[10px] font-bold"
                            >
                              <span className={cn('w-1.5 h-1.5 rounded-full shrink-0', cfg?.dot)} />
                              {cfg?.text || invoice.status}
                            </Badge>
                          </TableCell>

                          <TableCell className="py-2">
                            <div className="flex items-center gap-0.5">
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-7 w-7 rounded-lg hover:bg-primary/10 hover:text-primary"
                                    onClick={() => setViewInvoiceId(invoice.id)}
                                  >
                                    <Eye className="h-3 w-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent><p>عرض الفاتورة</p></TooltipContent>
                              </Tooltip>

                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-7 w-7 rounded-lg hover:bg-primary/10 hover:text-primary"
                                    onClick={() => router.push(`/purchases/${invoice.id}/print`)}
                                  >
                                    <Printer className="h-3 w-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent><p>طباعة</p></TooltipContent>
                              </Tooltip>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TooltipProvider>
                </TableBody>
              </Table>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between px-4 py-2.5 border-t border-border/50 bg-muted/10">
                  <p className="text-[11px] text-muted-foreground">
                    صفحة {page} من {totalPages} — {filtered.length} فاتورة
                  </p>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>
                      <ChevronRight className="h-3.5 w-3.5" />
                    </Button>
                    {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                      const p = i + 1;
                      return (
                        <button key={p} onClick={() => setPage(p)} className={cn('h-7 w-7 rounded-lg text-xs font-bold transition-all', page === p ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:bg-secondary hover:text-foreground')}>
                          {p}
                        </button>
                      );
                    })}
                    <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>
                      <ChevronLeft className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* View Invoice Dialog */}
      <Dialog open={viewInvoiceId !== null} onOpenChange={(open) => !open && setViewInvoiceId(null)}>
        <DialogContent className="sm:max-w-[900px] p-0 overflow-hidden rounded-2xl">
          {viewInvoiceId && (
            <iframe
              src={`/purchases/${viewInvoiceId}/print`}
              className="w-full h-[80vh]"
              style={{ border: 'none' }}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
