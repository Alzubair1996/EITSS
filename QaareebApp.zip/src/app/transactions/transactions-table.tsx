
'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { FinancialTransaction, PaymentMethod, User } from '@/lib/types';
import { format } from 'date-fns';
import { ArrowRightLeft, ArrowUp, ArrowDown, TrendingUp, TrendingDown, Wallet, Filter } from 'lucide-react';
import * as React from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface TransactionsTableProps {
  transactions: FinancialTransaction[];
  paymentMethods: PaymentMethod[];
  users: User[];
}

function FormattedDate({ dateString }: { dateString: string }) {
  const [formattedDate, setFormattedDate] = React.useState('');
  React.useEffect(() => {
    setFormattedDate(format(new Date(dateString), 'dd/MM/yyyy HH:mm'));
  }, [dateString]);
  return <>{formattedDate}</>;
}

export function TransactionsTable({ transactions, paymentMethods, users }: TransactionsTableProps) {
  const [typeFilter, setTypeFilter] = React.useState('all');
  const [paymentMethodFilter, setPaymentMethodFilter] = React.useState('all');
  const [userFilter, setUserFilter] = React.useState('all');
  const [startDate, setStartDate] = React.useState<string>('');
  const [endDate, setEndDate] = React.useState<string>('');

  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  const filteredTransactions = React.useMemo(() => {
    return transactions.filter(t => {
      const typeMatch = typeFilter === 'all' || t.type === typeFilter;
      const paymentMethodMatch = paymentMethodFilter === 'all' || t.paymentMethodId === paymentMethodFilter;
      const userMatch = userFilter === 'all' ||
        (userFilter === 'none' ? !t.userId : t.userId === userFilter);
      const dateObj = new Date(t.date);
      let dateMatch = true;
      if (startDate) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        if (dateObj < start) dateMatch = false;
      }
      if (endDate) {
        const endD = new Date(endDate);
        endD.setHours(23, 59, 59, 999);
        if (dateObj > endD) dateMatch = false;
      }
      return typeMatch && paymentMethodMatch && userMatch && dateMatch;
    });
  }, [transactions, typeFilter, paymentMethodFilter, userFilter, startDate, endDate]);

  const totals = React.useMemo(() => {
    let totalRevenue = 0;
    let totalExpense = 0;
    const byMethod: Record<string, { revenue: number; expense: number; name: string }> = {};
    for (const t of filteredTransactions) {
      if (t.type === 'revenue') {
        totalRevenue += t.amount;
        const entry = byMethod[t.paymentMethodId] || { revenue: 0, expense: 0, name: t.paymentMethodName };
        entry.revenue += t.amount;
        byMethod[t.paymentMethodId] = entry;
      } else if (t.type === 'expense') {
        totalExpense += t.amount;
        const entry = byMethod[t.paymentMethodId] || { revenue: 0, expense: 0, name: t.paymentMethodName };
        entry.expense += t.amount;
        byMethod[t.paymentMethodId] = entry;
      } else if (t.type === 'transfer') {
        if (t.transferDirection === 'in') {
          const entry = byMethod[t.paymentMethodId] || { revenue: 0, expense: 0, name: t.paymentMethodName };
          entry.revenue += t.amount;
          byMethod[t.paymentMethodId] = entry;
        } else if (t.transferDirection === 'out') {
          const entry = byMethod[t.paymentMethodId] || { revenue: 0, expense: 0, name: t.paymentMethodName };
          entry.expense += t.amount;
          byMethod[t.paymentMethodId] = entry;
        }
      }
    }
    return { totalRevenue, totalExpense, byMethod };
  }, [filteredTransactions]);

  return (
    <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
      {/* Summary Stats */}
      <div className="grid grid-cols-3 divide-x divide-x-reverse divide-border/40 border-b border-border/40 bg-secondary/20">
        <div className="px-6 py-4 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-emerald-500/10">
            <TrendingUp className="h-4 w-4 text-emerald-600" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground font-medium">إجمالي الإيرادات</p>
            <p className="text-lg font-bold text-emerald-600 font-mono">{formatCurrency(totals.totalRevenue)}</p>
          </div>
        </div>
        <div className="px-6 py-4 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-red-500/10">
            <TrendingDown className="h-4 w-4 text-red-600" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground font-medium">إجمالي الخصومات</p>
            <p className="text-lg font-bold text-red-600 font-mono">{formatCurrency(totals.totalExpense)}</p>
          </div>
        </div>
        <div className="px-6 py-4 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-primary/10">
            <Wallet className="h-4 w-4 text-primary" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground font-medium">صافي الحركات</p>
            <p className={`text-lg font-bold font-mono ${totals.totalRevenue - totals.totalExpense >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              {formatCurrency(Math.abs(totals.totalRevenue - totals.totalExpense))}
            </p>
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-wrap items-center gap-3 p-5 border-b border-border/40 bg-secondary/5">
        <div className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
          <Filter className="h-4 w-4" />
          فلترة:
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[160px] rounded-xl border-border/50 bg-background">
            <SelectValue placeholder="نوع الحركة" />
          </SelectTrigger>
          <SelectContent className="rounded-xl">
            <SelectItem value="all">كل الأنواع</SelectItem>
            <SelectItem value="revenue">إيرادات</SelectItem>
            <SelectItem value="expense">خصومات</SelectItem>
            <SelectItem value="transfer">تحويلات</SelectItem>
          </SelectContent>
        </Select>
        <Select value={paymentMethodFilter} onValueChange={setPaymentMethodFilter}>
          <SelectTrigger className="w-[200px] rounded-xl border-border/50 bg-background">
            <SelectValue placeholder="طريقة الدفع" />
          </SelectTrigger>
          <SelectContent className="rounded-xl">
            <SelectItem value="all">كل طرق الدفع</SelectItem>
            {paymentMethods.map(pm => (
              <SelectItem key={pm.id} value={pm.id}>{pm.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={userFilter} onValueChange={setUserFilter}>
          <SelectTrigger className="w-[180px] rounded-xl border-border/50 bg-background">
            <SelectValue placeholder="المستخدم" />
          </SelectTrigger>
          <SelectContent className="rounded-xl">
            <SelectItem value="all">كل المستخدمين</SelectItem>
            <SelectItem value="none">غير محدد</SelectItem>
            {users.map(u => (
              <SelectItem key={u.id} value={u.id}>{u.username}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex items-center gap-2">
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="border border-border/60 rounded-xl px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary text-foreground"
            title="من تاريخ"
          />
          <span className="text-muted-foreground text-sm">—</span>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="border border-border/60 rounded-xl px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary text-foreground"
            title="إلى تاريخ"
          />
        </div>
        <div className="mr-auto text-xs font-medium text-muted-foreground bg-background px-3 py-1.5 rounded-full border border-border/40">
          {filteredTransactions.length} معاملة
        </div>
      </div>

      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>التاريخ</TableHead>
              <TableHead>النوع</TableHead>
              <TableHead className="w-1/3">الوصف</TableHead>
              <TableHead>المستخدم</TableHead>
              <TableHead>طريقة الدفع</TableHead>
              <TableHead className="text-right">المبلغ</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTransactions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-40 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-4 rounded-2xl bg-muted/50">
                      <ArrowRightLeft className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">لا توجد معاملات</p>
                      <p className="text-sm text-muted-foreground mt-1">لا توجد معاملات تطابق معايير الفلترة المحددة</p>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              filteredTransactions.map((transaction) => (
                <TableRow key={transaction.id} className="group">
                  <TableCell className="text-muted-foreground text-sm">
                    <FormattedDate dateString={transaction.date} />
                  </TableCell>
                  <TableCell>
                    {transaction.type === 'revenue' && (
                      <Badge variant="success" className="gap-1">
                        <ArrowUp className="h-3 w-3" />
                        إيراد
                      </Badge>
                    )}
                    {transaction.type === 'expense' && (
                      <Badge variant="destructive" className="gap-1">
                        <ArrowDown className="h-3 w-3" />
                        خصم
                      </Badge>
                    )}
                    {transaction.type === 'transfer' && (
                      <Badge variant="info" className="gap-1">
                        <ArrowRightLeft className="h-3 w-3" />
                        تحويل
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-sm text-foreground">{transaction.description}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{transaction.userName || 'غير محدد'}</TableCell>
                  <TableCell>
                    <Badge variant="secondary">{transaction.paymentMethodName}</Badge>
                  </TableCell>
                  <TableCell
                    className={cn(
                      'text-right font-mono font-bold',
                      transaction.type === 'revenue'
                        ? 'text-emerald-600'
                        : transaction.type === 'expense'
                        ? 'text-red-600'
                        : transaction.transferDirection === 'in'
                        ? 'text-emerald-600'
                        : 'text-red-600'
                    )}
                  >
                    {transaction.type === 'revenue'
                      ? '+'
                      : transaction.type === 'expense'
                      ? '-'
                      : transaction.transferDirection === 'in'
                      ? '+'
                      : '-'}{' '}
                    {formatCurrency(transaction.amount)}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>

        {/* Per-Method Breakdown Footer */}
        {Object.keys(totals.byMethod).length > 0 && (
          <div className="p-5 border-t border-border/40 bg-secondary/10">
            <p className="text-xs font-bold text-muted-foreground mb-3 uppercase tracking-wide">ملخص رصيد وحركات طرق الدفع</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {Object.entries(totals.byMethod).map(([methodId, stats]) => {
                const balance = stats.revenue - stats.expense;
                return (
                  <div key={methodId} className="flex flex-col gap-2 bg-background rounded-xl border border-border/40 px-4 py-3 shadow-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-foreground">{stats.name || 'غير محدد'}</span>
                      <span className={cn(
                        "text-sm font-black font-mono",
                        balance >= 0 ? "text-emerald-600" : "text-red-600"
                      )}>
                        {balance >= 0 ? '+' : ''}{formatCurrency(balance)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] font-mono text-muted-foreground border-t border-border/20 pt-1.5 mt-0.5">
                      <span className="text-emerald-600/90 font-medium">وارد: +{formatCurrency(stats.revenue)}</span>
                      <span className="text-red-600/90 font-medium">صادر: -{formatCurrency(stats.expense)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
