import { PageHeader } from '@/components/page-header';
import { getFinancialTransactions, getPaymentMethods, getTopSellingProducts, getExpenses, getPayments, getUsers } from '@/lib/queries';
import { TransactionsTable } from './transactions-table';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';

export default async function TransactionsPage() {
    const transactions = await getFinancialTransactions();
    const paymentMethods = await getPaymentMethods();
    // Include a special entry for transactions that don't have a specific payment method (e.g., invoice events)
    paymentMethods.unshift({ id: 'none', name: 'غير محدد', type: 'cash', bankName: null as any, accountNumber: null as any, branch: null as any, balance: 0 });
    const topExpenses = (await getExpenses()).slice(0, 5);
    const topRevenues = (await getPayments()).slice(0, 5);

    // Fetch all users for filtering by user in the transactions table
    const users = await getUsers();
    
    return (
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
            <PageHeader title="المركز المالي" />
            <TransactionsTable transactions={transactions} paymentMethods={paymentMethods} users={users} />

            <div className="grid gap-4 md:grid-cols-2 pt-4">
                <Card>
                    <CardHeader>
                        <CardTitle>أحدث الإيرادات</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>العميل</TableHead>
                                    <TableHead className="text-right">المبلغ</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {topRevenues.map(p => (
                                    <TableRow key={p.id}>
                                        <TableCell>
                                            <div className="font-medium">{p.customerName}</div>
                                            <div className="text-sm text-muted-foreground">لفاتورة #{p.invoiceNumber}</div>
                                        </TableCell>
                                        <TableCell className="text-right text-green-600 font-medium">
                                            {Math.round(p.amount).toLocaleString('en-US')} SDG
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>أحدث المصروفات</CardTitle>
                    </CardHeader>
                    <CardContent>
                         <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>الوصف</TableHead>
                                    <TableHead className="text-right">المبلغ</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {topExpenses.map(e => (
                                    <TableRow key={e.id}>
                                        <TableCell>
                                            <div className="font-medium">{e.description}</div>
                                            <div className="text-sm text-muted-foreground">{e.supplierName || e.paymentMethodName}</div>
                                        </TableCell>
                                        <TableCell className="text-right text-destructive font-medium">
                                            {Math.round(e.amount).toLocaleString('en-US')} SDG
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
