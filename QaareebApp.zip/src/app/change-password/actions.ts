// Server action to change the current user's password.
// This action verifies the old password, hashes the new password, and
// updates the user's record in the database. It returns an object with
// either an `error` or `success` property. If the user is not authenticated,
// it returns an error.

'use server';

import { getDbInstance } from '@/lib/db';
import { getSession } from '@/lib/server-auth';
import { verifyPassword, hashPassword } from '@/lib/server-auth';

interface Result {
  error?: string;
  success?: boolean;
}

export async function changePassword(formData: FormData): Promise<Result> {
  const oldPassword = (formData.get('oldPassword') as string) || '';
  const newPassword = (formData.get('newPassword') as string) || '';
  const confirmPassword = (formData.get('confirmPassword') as string) || '';

  if (!oldPassword || !newPassword || !confirmPassword) {
    return { error: 'يرجى ملء جميع الحقول.' };
  }
  if (newPassword !== confirmPassword) {
    return { error: 'كلمة المرور الجديدة وتأكيدها غير متطابقين.' };
  }
  if (newPassword.length < 6) {
    return { error: 'يجب أن تكون كلمة المرور الجديدة مكونة من 6 أحرف على الأقل.' };
  }

  const session = await getSession();
  if (!session) {
    return { error: 'لم يتم العثور على جلسة. الرجاء تسجيل الدخول.' };
  }
  const db = await getDbInstance();
  const user = await db.get('SELECT id, password FROM users WHERE id = ?', session.userId);
  if (!user) {
    return { error: 'المستخدم غير موجود.' };
  }
  const valid = await verifyPassword(oldPassword, user.password);
  if (!valid) {
    return { error: 'كلمة المرور الحالية غير صحيحة.' };
  }
  const hashed = await hashPassword(newPassword);
  await db.run('UPDATE users SET password = ? WHERE id = ?', hashed, session.userId);
  return { success: true };
}