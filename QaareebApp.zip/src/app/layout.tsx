
import type { Metadata } from 'next';
import './globals.css';
import { cn } from '@/lib/utils';
import { SidebarProvider } from '@/components/ui/sidebar';
import { Toaster } from "@/components/ui/toaster";
import { Suspense } from 'react';
import { MainSidebar } from '@/components/layout/main-sidebar';
import { performActivationCheck } from '@/app/api/auth/queries';
import ActivationPage from './activation/page';
import SetupPage from './setup/page';
import { getCompanyInfo, getFontSize } from '@/lib/queries';
import { getSession } from '@/lib/server-auth';
import { getUserPermissions } from '@/lib/permissions';
import { MainSidebarSkeleton } from '@/components/layout/main-sidebar';
import { headers } from 'next/headers';

export const metadata: Metadata = {
  title: 'متجر',
  description: 'نظام إدارة المتجر',
};

// This ensures the page is not statically rendered
export const dynamic = 'force-dynamic';


// This new wrapper component is the single source of truth for auth/setup checks.
// It runs on the server within the React render tree, so it can be caught
// by error.tsx and loading.tsx, preventing the "missing error components" crash.
async function AuthWrapper({ children }: { children: React.ReactNode }) {
    const headersList = headers();
    const pathname = headersList.get('x-pathname') || '';

    // These pages are part of the auth flow and should be rendered without the main layout.
    const isAuthOrSetupPage = 
      pathname === '/activation' || pathname === '/setup' || pathname === '/login' ||
      pathname.startsWith('/activation') || pathname.startsWith('/setup') || pathname.startsWith('/login') ||
      pathname === 'activation' || pathname === 'setup' || pathname === 'login';

    if (isAuthOrSetupPage) {
      return <>{children}</>;
    }

    // `performActivationCheck` is designed to be safe and not throw an error, even if the DB doesn't exist.
    const status = await performActivationCheck();

    if (!status.isActivated && !status.trial.isActive) {
        return <ActivationPage />;
    }

    if (!status.isSetupComplete) {
        return <SetupPage />;
    }

    
    // If all checks pass, fetch company info and render the main application layout.
    const companyInfo = await getCompanyInfo();

    // Fetch the current session and allowed permissions for the logged-in user.
    const session = await getSession();
    let allowedPermissions: string[] = [];
    if (session) {
        allowedPermissions = await getUserPermissions(session.userId);
    }

    return (
        <SidebarProvider>
            <div className="flex h-screen w-full overflow-hidden">
                <div className="no-print">
                  <Suspense fallback={<MainSidebarSkeleton />}>
                    {/* Pass the activation status down so the sidebar can show an activation button when needed */}
                    <MainSidebar
                      companyInfo={companyInfo}
                      allowedPermissions={allowedPermissions}
                      isLoggedIn={!!session}
                      isActivated={status.isActivated}
                    />
                  </Suspense>
                </div>
                <main className="flex-1 w-full h-full overflow-y-auto">
                    {children}
                </main>
            </div>
        </SidebarProvider>
    );
}


export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const fontSize = await getFontSize();

  return (
    <html lang="ar" dir="rtl" className={cn(fontSize === 'sm' && 'font-size-sm', fontSize === 'lg' && 'font-size-lg')}>
      <head>
      </head>
      <body className={cn('font-body antialiased bg-background h-screen overflow-hidden')}>
        <Suspense fallback={<div className="flex min-h-screen w-full items-center justify-center"><p>Loading...</p></div>}>
           <AuthWrapper>{children}</AuthWrapper>
        </Suspense>
        <Toaster />
      </body>
    </html>
  );
}
