



'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { saveAppLogo, saveAppName, backupDatabaseAction, resetDatabaseAction, savePrintType, saveWeightBarcodeSetting, restoreDatabaseAction, saveFontSize, saveAutoPrintInvoice, deactivateLicenseAction } from './actions';
import Image from 'next/image';
import { LoaderCircle, Building, DatabaseBackup, Trash2, UploadCloud, AlertTriangle, Weight, Type, ShieldCheck } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { format } from 'date-fns';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Switch } from '@/components/ui/switch';


interface SettingsClientPageProps {
  initialLogo: string | null;
  initialName: string;
  initialUSDRate: number;
  initialPrintType: 'a4' | 'thermal';
  initialIsWeightBarcodeEnabled: boolean;
  initialFontSize: 'sm' | 'md' | 'lg';
  /**
   * Whether invoices should be automatically printed after creation. This is passed from the server.
   */
  initialAutoPrintInvoice: boolean;
  licenseDetails: {
    isActivated: boolean;
    expiry: string;
    daysRemaining: number | null;
  };
}

export default function SettingsClientPage({ 
  initialLogo, 
  initialName, 
  initialUSDRate, 
  initialPrintType, 
  initialIsWeightBarcodeEnabled,
  initialFontSize
  , initialAutoPrintInvoice,
  licenseDetails
}: SettingsClientPageProps) {
  const router = useRouter();
  const { toast } = useToast();
  
  const [isDeactivating, setIsDeactivating] = React.useState(false);

  const handleDeactivateLicense = async () => {
    if (!window.confirm('هل أنت متأكد من رغبتك في إلغاء تفعيل هذا الجهاز؟ سيتوقف البرنامج عن العمل لحين تفعيله مجدداً أونلاين.')) {
      return;
    }
    
    setIsDeactivating(true);
    const result = await deactivateLicenseAction();
    setIsDeactivating(false);
    
    if (result.success) {
      toast({ title: 'تم إلغاء التفعيل', description: result.message });
      window.location.href = '/activation';
    } else {
      toast({ variant: 'destructive', title: 'فشل إلغاء التفعيل', description: result.message });
    }
  };
  
  const [isLogoLoading, setIsLogoLoading] = React.useState(false);
  const [logoPreview, setLogoPreview] = React.useState<string | null>(initialLogo);
  const [logoDataUri, setLogoDataUri] = React.useState<string | null>(null);
  
  const [printType, setPrintType] = React.useState<'a4' | 'thermal'>(initialPrintType);
  const [isPrintTypeLoading, setIsPrintTypeLoading] = React.useState(false);

  const [isWeightBarcodeLoading, setIsWeightBarcodeLoading] = React.useState(false);
  const [isWeightBarcodeEnabled, setIsWeightBarcodeEnabled] = React.useState(initialIsWeightBarcodeEnabled);

  const [fontSize, setFontSize] = React.useState<'sm' | 'md' | 'lg'>(initialFontSize);
  const [isFontSizeLoading, setIsFontSizeLoading] = React.useState(false);

  const [isBackupLoading, setIsBackupLoading] = React.useState(false);
  const [isResetLoading, setIsResetLoading] = React.useState(false);

  const [isRestoreLoading, setIsRestoreLoading] = React.useState(false);
  const restoreFileInputRef = React.useRef<HTMLInputElement>(null);

  // Auto print invoice setting
  const [autoPrintInvoice, setAutoPrintInvoice] = React.useState<boolean>(initialAutoPrintInvoice);
  const [isAutoPrintLoading, setIsAutoPrintLoading] = React.useState<boolean>(false);

  const handleAutoPrintSubmit = async (checked: boolean) => {
    setAutoPrintInvoice(checked);
    setIsAutoPrintLoading(true);
    const result = await saveAutoPrintInvoice(checked);
    setIsAutoPrintLoading(false);
    if (result.success) {
      toast({ title: 'تم الحفظ بنجاح', description: result.message });
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'فشل الحفظ', description: result.message });
      // revert on failure
      setAutoPrintInvoice(!checked);
    }
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
        toast({
          variant: 'destructive',
          title: 'الملف كبير جدًا',
          description: 'يرجى اختيار صورة بحجم أقل من 2 ميجابايت.',
        });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setLogoDataUri(base64String);
        setLogoPreview(base64String);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleLogoSubmit = async () => {
    if (!logoDataUri) {
      toast({
        variant: 'destructive',
        title: 'لم يتم اختيار ملف',
        description: 'يرجى اختيار ملف شعار جديد لحفظه.',
      });
      return;
    }

    setIsLogoLoading(true);
    const result = await saveAppLogo(logoDataUri);
    setIsLogoLoading(false);

    if (result.success) {
      toast({ title: 'تم الحفظ بنجاح', description: 'تم تحديث شعار الشركة.' });
      router.refresh(); 
    } else {
      toast({ variant: 'destructive', title: 'فشل الحفظ', description: result.message });
    }
  };

  const handlePrintTypeSubmit = async () => {
    setIsPrintTypeLoading(true);
    const result = await savePrintType(printType);
    setIsPrintTypeLoading(false);

    if (result.success) {
      toast({ title: 'تم الحفظ بنجاح', description: result.message });
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'فشل الحفظ', description: result.message });
    }
  }

  const handleFontSizeSubmit = async () => {
    setIsFontSizeLoading(true);
    const result = await saveFontSize(fontSize);
    setIsFontSizeLoading(false);

    if (result.success) {
      toast({ title: 'تم الحفظ بنجاح', description: result.message });
      window.location.reload();
    } else {
      toast({ variant: 'destructive', title: 'فشل الحفظ', description: result.message });
    }
  }

  const handleWeightBarcodeSubmit = async (checked: boolean) => {
    setIsWeightBarcodeEnabled(checked);
    setIsWeightBarcodeLoading(true);
    const result = await saveWeightBarcodeSetting(checked);
    setIsWeightBarcodeLoading(false);

    if (result.success) {
      toast({ title: 'تم الحفظ بنجاح', description: result.message });
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'فشل الحفظ', description: result.message });
      // revert on failure
      setIsWeightBarcodeEnabled(!checked);
    }
  };
  
  const handleBackup = async () => {
    setIsBackupLoading(true);
    const result = await backupDatabaseAction();
    setIsBackupLoading(false);

    if (result.success && result.data) {
      const link = document.createElement('a');
      link.href = result.data;
      const timestamp = format(new Date(), 'yyyy-MM-dd_HH-mm-ss');
      link.download = `MatjarakStore_Backup_${timestamp}.sqlite`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast({ title: 'نجاح', description: 'تم تنزيل النسخة الاحتياطية بنجاح.' });
    } else {
      toast({ variant: 'destructive', title: 'فشل', description: result.message });
    }
  };
  
  const handleRestoreFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      toast({ variant: 'default', title: 'تم الإلغاء' });
      return;
    }
    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64Data = event.target?.result as string;
      setIsRestoreLoading(true);
      const result = await restoreDatabaseAction(base64Data);
      setIsRestoreLoading(false);

      if (result.success) {
        toast({
          title: 'نجاح الاستعادة',
          description: result.message,
          duration: 5000,
        });
        setTimeout(() => window.location.reload(), 2000);
      } else {
        toast({
          variant: 'destructive',
          title: 'فشل الاستعادة',
          description: result.message,
          duration: 7000,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleReset = async () => {
    setIsResetLoading(true);
    const result = await resetDatabaseAction();
    setIsResetLoading(false);

    if (result.success) {
      toast({ title: 'نجاح', description: result.message, duration: 5000 });
      // Reload the page to reflect the fresh state
      setTimeout(() => window.location.reload(), 2000);
    } else {
      toast({ variant: 'destructive', title: 'فشل', description: result.message, duration: 7000 });
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {/* License Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-primary" />
            ترخيص البرنامج
          </CardTitle>
          <CardDescription>
            حالة تفعيل نسخة البرنامج وصلاحية الترخيص الحالية للجهاز.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between py-2 border-b border-border/40">
            <span className="text-xs text-muted-foreground">حالة التفعيل:</span>
            {licenseDetails.isActivated ? (
              <span className="text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2.5 py-1 rounded-full flex items-center gap-1">
                <ShieldCheck className="h-3.5 w-3.5" />
                نشط ومفعّل
              </span>
            ) : (
              <span className="text-xs font-bold text-destructive bg-destructive/10 px-2.5 py-1 rounded-full flex items-center gap-1">
                <AlertTriangle className="h-3.5 w-3.5" />
                غير مفعّل
              </span>
            )}
          </div>

          <div className="flex items-center justify-between py-2 border-b border-border/40">
            <span className="text-xs text-muted-foreground">صلاحية الترخيص:</span>
            <span className="text-xs font-semibold font-mono">
              {licenseDetails.expiry === 'lifetime' ? 'مدى الحياة' : licenseDetails.expiry}
            </span>
          </div>

          <div className="flex items-center justify-between py-2">
            <span className="text-xs text-muted-foreground">المدة المتبقية:</span>
            <span className="text-xs font-bold">
              {licenseDetails.expiry === 'lifetime' 
                ? 'مفتوح دائماً' 
                : licenseDetails.daysRemaining !== null 
                  ? `${licenseDetails.daysRemaining} يوم` 
                  : 'منتهي'}
            </span>
          </div>
        </CardContent>
        <CardFooter className="border-t px-6 py-4">
          <Button 
            variant="destructive" 
            size="sm" 
            onClick={handleDeactivateLicense} 
            disabled={isDeactivating} 
            className="w-full text-xs font-bold"
          >
            {isDeactivating ? (
              <LoaderCircle className="me-2 h-4 w-4 animate-spin" />
            ) : (
              <Trash2 className="me-2 h-4 w-4" />
            )}
            إلغاء تفعيل الجهاز / التجديد
          </Button>
        </CardFooter>
      </Card>

        <Card>
            <CardHeader>
                <CardTitle>حجم واجهة التطبيق</CardTitle>
                <CardDescription>
                    اختر الحجم المناسب لواجهة النظام لتناسب شاشتك.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <RadioGroup value={fontSize} onValueChange={(value: 'sm' | 'md' | 'lg') => setFontSize(value)} className="grid grid-cols-3 gap-4">
                    <div>
                        <RadioGroupItem value="sm" id="sm" className="peer sr-only" />
                        <Label
                        htmlFor="sm"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                        >
                        <Type className="mb-3 h-6 w-6" />
                        صغير
                        </Label>
                    </div>
                    <div>
                        <RadioGroupItem value="md" id="md" className="peer sr-only" />
                        <Label
                        htmlFor="md"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                        >
                        <Type className="mb-3 h-8 w-8" />
                        متوسط
                        </Label>
                    </div>
                    <div>
                        <RadioGroupItem value="lg" id="lg" className="peer sr-only" />
                        <Label
                        htmlFor="lg"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                        >
                        <Type className="mb-3 h-10 w-10" />
                        كبير
                        </Label>
                    </div>
                </RadioGroup>
            </CardContent>
            <CardFooter className="border-t px-6 py-4">
            <Button onClick={handleFontSizeSubmit} disabled={isFontSizeLoading || fontSize === initialFontSize}>
                {isFontSizeLoading && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
                حفظ الحجم
            </Button>
            </CardFooter>
        </Card>
      <Card>
        <CardHeader>
          <CardTitle>نوع طباعة الفاتورة</CardTitle>
          <CardDescription>
            اختر نوع الطابعة الافتراضي لطباعة الفواتير والإيصالات.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup value={printType} onValueChange={(value: 'a4' | 'thermal') => setPrintType(value)} className="space-y-2">
            <div className="flex items-center space-x-2 space-x-reverse">
              <RadioGroupItem value="a4" id="a4" />
              <Label htmlFor="a4">طابعة عادية (مقاس A4)</Label>
            </div>
            <div className="flex items-center space-x-2 space-x-reverse">
              <RadioGroupItem value="thermal" id="thermal" />
              <Label htmlFor="thermal">طابعة إيصالات حرارية (مقاس 80mm)</Label>
            </div>
          </RadioGroup>
        </CardContent>
        <CardFooter className="border-t px-6 py-4">
          <Button onClick={handlePrintTypeSubmit} disabled={isPrintTypeLoading || printType === initialPrintType}>
             {isPrintTypeLoading && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
            حفظ نوع الطابعة
          </Button>
        </CardFooter>
      </Card>

      {/* Auto print invoice setting */}
      <Card>
        <CardHeader>
          <CardTitle>طباعة الفاتورة تلقائيًا</CardTitle>
          <CardDescription>
            إذا كانت هذه الميزة مفعلة، سيتم فتح نافذة المعاينة والطباعه تلقائيًا عند إنشاء فاتورة جديدة.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 space-x-reverse">
            <Switch
              id="auto-print-invoice-switch"
              checked={autoPrintInvoice}
              onCheckedChange={handleAutoPrintSubmit}
              disabled={isAutoPrintLoading}
            />
            <Label htmlFor="auto-print-invoice-switch">
              {isAutoPrintLoading ? 'جاري الحفظ...' : (autoPrintInvoice ? 'الطباعة التلقائية مفعلة' : 'الطباعة التلقائية معطلة')}
            </Label>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>شعار الشركة</CardTitle>
          <CardDescription>
            قم برفع شعار الشركة هنا. سيظهر هذا الشعار في الشريط الجانبي والفواتير المطبوعة.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div className="grid w-full max-w-sm items-center gap-1.5">
              <Label htmlFor="logo-upload">اختر ملف الشعار</Label>
              <Input id="logo-upload" type="file" accept="image/png, image/jpeg, image/svg+xml" onChange={handleLogoChange} />
            </div>
            <div>
              <Label>المعاينة الحالية</Label>
              <div className="mt-2 w-32 h-32 p-2 border rounded-md flex items-center justify-center bg-muted">
                 {logoPreview ? (
                    <Image src={logoPreview} alt="معاينة الشعار" width={120} height={120} className="object-contain" />
                  ) : (
                    <Building className="w-16 h-16 text-muted-foreground" />
                  )}
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="border-t px-6 py-4">
          <Button onClick={handleLogoSubmit} disabled={isLogoLoading || !logoDataUri}>
             {isLogoLoading && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
            حفظ الشعار
          </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>ميزة باركود الميزان</CardTitle>
          <CardDescription>
            تفعيل هذه الميزة يسمح للنظام بالتعرف على باركود الوزن المطبوع من الموازين الإلكترونية.
          </CardDescription>
        </CardHeader>
        <CardContent>
           <div className="flex items-center space-x-2 space-x-reverse">
              <Switch 
                id="weight-barcode-switch" 
                checked={isWeightBarcodeEnabled}
                onCheckedChange={handleWeightBarcodeSubmit}
                disabled={isWeightBarcodeLoading}
              />
              <Label htmlFor="weight-barcode-switch">
                {isWeightBarcodeLoading ? "جاري الحفظ..." : (isWeightBarcodeEnabled ? "ميزة باركود الميزان مفعلة" : "ميزة باركود الميزان معطلة")}
              </Label>
          </div>
        </CardContent>
      </Card>

       <Card className="md:col-span-2 lg:col-span-3">
        <CardHeader>
          <CardTitle>إدارة قاعدة البيانات</CardTitle>
          <CardDescription>
            قم بإنشاء نسخة احتياطية من بياناتك أو قم بتهيئة قاعدة البيانات إلى حالتها الأولية.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
             <Button onClick={handleBackup} disabled={isBackupLoading} variant="secondary">
              {isBackupLoading ? <LoaderCircle className="me-2 h-4 w-4 animate-spin" /> : <DatabaseBackup className="me-2 h-4 w-4" />}
              إنشاء نسخة احتياطية
            </Button>
            
            <input
              type="file"
              accept=".sqlite"
              ref={restoreFileInputRef}
              onChange={handleRestoreFileSelect}
              className="hidden"
            />
            <Button onClick={() => restoreFileInputRef.current?.click()} disabled={isRestoreLoading} variant="secondary">
                {isRestoreLoading ? <LoaderCircle className="me-2 h-4 w-4 animate-spin" /> : <UploadCloud className="me-2 h-4 w-4" />}
                استعادة نسخة احتياطية
            </Button>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                 <Button disabled={isResetLoading} variant="destructive">
                  {isResetLoading ? <LoaderCircle className="me-2 h-4 w-4 animate-spin" /> : <Trash2 className="me-2 h-4 w-4" />}
                  تهيئة قاعدة البيانات
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>هل أنت متأكد تماماً؟</AlertDialogTitle>
                  <AlertDialogDescription>
                    هذا الإجراء سيقوم بحذف جميع بياناتك بشكل نهائي (المنتجات، الفواتير، العملاء، إلخ) ويبدأ من جديد. يوصى بشدة بأخذ نسخة احتياطية أولاً.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>إلغاء</AlertDialogCancel>
                  <AlertDialogAction onClick={handleReset} className="bg-destructive hover:bg-destructive/90">
                      نعم، قم بالحذف والتهيئة
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

    
