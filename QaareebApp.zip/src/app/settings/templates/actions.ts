'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';

export async function saveInvoiceTemplate(html: string) {
  try {
    const db = await getDbInstance();
    await db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'invoice_template_html', html);
    revalidatePath('/settings/templates');
    return { success: true, message: 'تم حفظ قالب الفاتورة بنجاح.' };
  } catch (e: any) {
    console.error('Error saving invoice template:', e);
    return { success: false, message: 'فشل حفظ القالب.' };
  }
}
