'use client';

import * as React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { saveInvoiceTemplate } from './actions';
import { LoaderCircle, TabletSmartphone } from 'lucide-react';
import Mustache from 'mustache';
import { ScrollArea } from '@/components/ui/scroll-area';

interface TemplateEditorProps {
  initialTemplate: string;
}

const defaultTemplate = `
<div id="invoice-print" class="font-body print-container bg-white p-8 w-[210mm] min-h-[297mm] mx-auto shadow-lg flex flex-col">
    <header class="flex justify-between items-start pb-4 border-b-4 border-gray-800">
      <div class="text-right">
          {{#companyLogo}}
              <img src="{{companyLogo}}" alt="Company Logo" style="width: 120px; height: 120px; border-radius: 0.375rem; object-fit: contain; margin-bottom: 0.5rem;" />
          {{/companyLogo}}
          {{^companyLogo}}
              <div style="width: 120px; height: 120px; background-color: #f1f5f9; border-radius: 0.375rem; display: flex; align-items: center; justify-content: center; margin-bottom: 0.5rem;">
                  <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              </div>
          {{/companyLogo}}
          <h1 class="text-3xl font-bold text-gray-800">{{companyName}}</h1>
          <p class="text-gray-500">{{companyAddress}}</p>
          <p class="text-gray-500">{{companyPhones}}</p>
      </div>
      <div class="text-left mt-4">
          <h2 class="text-4xl font-bold text-gray-500 uppercase">فاتورة</h2>
          <div class="mt-2 text-right" dir="rtl">
              <p><span class="font-bold">رقم الفاتورة:</span> {{invoiceNumber}}</p>
              <p><span class="font-bold">التاريخ:</span> {{issueDate}}</p>
          </div>
      </div>
  </header>
  <section class="my-8" dir="rtl">
      <div class="bg-gray-100 p-4 rounded-lg">
          <h3 class="text-lg font-bold mb-2">فاتورة إلى:</h3>
          <p class="font-semibold text-xl">{{customerName}}</p>
          <p>{{customerPhone}}</p>
      </div>
  </section>
  <section class="mb-auto">
      <table class="w-full text-right border-collapse" dir="rtl">
          <thead class="border-b-2 border-gray-300">
              <tr class="bg-gray-800 text-white">
                  <th class="p-2 text-right">#</th>
                  <th class="p-2 text-right w-3/5">الصنف</th>
                  <th class="p-2 text-center">الضمان</th>
                  <th class="p-2 text-center">الكمية</th>
                  <th class="p-2 text-center">السعر</th>
                  <th class="p-2 text-left">الإجمالي</th>
              </tr>
          </thead>
          <tbody>
              {{{items}}}
          </tbody>
      </table>
  </section>
  <div class="flex-grow"></div>
   <div class="w-full flex justify-end mt-8 mb-16 me-32">
      <div class="text-center">
          <p class="font-bold text-xl">المبيعات</p>
      </div>
  </div>
  <section class="flex justify-end mt-8">
      <div class="w-1/2 text-right" dir="rtl">
          <table class="w-full">
              <tbody>
                  {{{totals}}}
              </tbody>
          </table>
      </div>
  </section>
  <footer class="mt-auto pt-4 border-t-2 border-gray-800 text-center text-sm text-gray-500">
      <p>شكراً لتعاملكم معنا!</p>
  </footer>
</div>
`;

const availableVariables = [
  { variable: '{{companyName}}', description: 'اسم الشركة' },
  { variable: '{{companyLogo}}', description: 'رابط شعار الشركة (يستخدم داخل `src`)' },
  { variable: '{{companyAddress}}', description: 'عنوان الشركة' },
  { variable: '{{companyPhones}}', description: 'هواتف الشركة' },
  { variable: '{{invoiceNumber}}', description: 'رقم الفاتورة' },
  { variable: '{{issueDate}}', description: 'تاريخ إصدار الفاتورة' },
  { variable: '{{customerName}}', description: 'اسم العميل' },
  { variable: '{{customerPhone}}', description: 'هاتف العميل' },
  { variable: '{{{items}}}', description: 'جدول المنتجات (HTML جاهز)' },
  { variable: '{{{totals}}}', description: 'جدول الإجماليات (HTML جاهز)' },
  { variable: '{{totalAmount}}', description: 'المبلغ الإجمالي (رقم منسق)' },
  { variable: '{{amountPaid}}', description: 'المبلغ المدفوع (رقم منسق)' },
  { variable: '{{remainingAmount}}', description: 'المبلغ المتبقي (رقم منسق)' },
];

function InvoicePreview({ template }: { template: string }) {
  const formatCurrency = (num: number) => num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const mockItems = [
    { productName: 'منتج تجريبي 1', warranty: 'سنة', quantity: 2, unitPrice: 150.00 },
    { productName: 'منتج تجريبي 2', warranty: 'لا يوجد', quantity: 1, unitPrice: 400.50 },
    { productName: 'منتج تجريبي طويل الاسم لاختبار المساحات المتاحة في الجدول', warranty: '6 أشهر', quantity: 5, unitPrice: 25.00 },
  ];

  const itemsHtml = mockItems.map((item, index) => `
    <tr class="border-b">
      <td class="p-2">${index + 1}</td>
      <td class="p-2">${item.productName}</td>
      <td class="p-2 text-center">${item.warranty}</td>
      <td class="p-2 text-center">${item.quantity}</td>
      <td class="p-2 text-center">${formatCurrency(item.unitPrice)}</td>
      <td class="p-2 text-left">${formatCurrency(item.unitPrice * item.quantity)}</td>
    </tr>
  `).join('');

  const total = mockItems.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  const amountPaid = total / 2;
  const remaining = total - amountPaid;

  const totalsHtml = `
    <tr>
        <td class="p-2 font-semibold">الإجمالي الفرعي:</td>
        <td class="p-2 text-left">${formatCurrency(total)} SDG</td>
    </tr>
    <tr class="font-bold text-lg bg-gray-200 rounded-lg">
        <td class="p-2">المتبقي:</td>
        <td class="p-2 text-left text-red-600">${formatCurrency(remaining)} SDG</td>
    </tr>
  `;

  const view = {
    companyName: 'اسم الشركة التجريبي',
    companyLogo: 'https://placehold.co/120x120.png',
    companyAddress: 'العنوان التجريبي، المدينة، الدولة',
    companyPhones: '0123456789 - 0987654321',
    invoiceNumber: 'INV240100001',
    issueDate: new Date().toLocaleDateString('ar-EG'),
    customerName: 'عميل افتراضي',
    customerPhone: '0911223344',
    items: itemsHtml,
    totals: totalsHtml,
    totalAmount: formatCurrency(total),
    amountPaid: formatCurrency(amountPaid),
    remainingAmount: formatCurrency(remaining),
  };

  const renderedHtml = Mustache.render(template, view);

  return (
    <div className="bg-gray-500 p-8 w-full h-full overflow-auto">
        <div className="mx-auto" style={{ width: '210mm', transform: 'scale(0.9)', transformOrigin: 'top center' }}>
             <div className="font-body text-black" dangerouslySetInnerHTML={{ __html: renderedHtml }} />
        </div>
    </div>
  );
}


export default function TemplateEditorClientPage({ initialTemplate }: TemplateEditorProps) {
  const [template, setTemplate] = React.useState(initialTemplate || defaultTemplate);
  const [isLoading, setIsLoading] = React.useState(false);
  const { toast } = useToast();

  const handleSave = async () => {
    setIsLoading(true);
    const result = await saveInvoiceTemplate(template);
    setIsLoading(false);

    if (result.success) {
      toast({ title: 'تم الحفظ', description: result.message });
    } else {
      toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }
  };

  const handleReset = () => {
    setTemplate(defaultTemplate);
    toast({ title: 'تمت الاستعادة', description: 'تمت استعادة القالب الافتراضي.' });
  }

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 h-[85vh]">
        <Card className="flex flex-col">
            <CardHeader>
              <CardTitle>محرر القالب</CardTitle>
              <CardDescription>
                عدّل كود HTML للقالب. ستظهر التغييرات مباشرة في المعاينة.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
              <Textarea
                value={template}
                onChange={(e) => setTemplate(e.target.value)}
                className="font-mono text-sm tracking-wider w-full h-full"
                dir="ltr"
              />
            </CardContent>
            <CardFooter className="gap-2 border-t pt-4">
              <Button onClick={handleSave} disabled={isLoading}>
                {isLoading && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
                حفظ القالب
              </Button>
              <Button variant="outline" onClick={handleReset}>
                استعادة القالب الافتراضي
              </Button>
            </CardFooter>
        </Card>

        <div className="flex flex-col gap-4">
            <Card className="h-full flex flex-col">
                <CardHeader>
                    <div className="flex items-center gap-2">
                        <TabletSmartphone className="w-5 h-5 text-muted-foreground"/>
                        <CardTitle>معاينة حية</CardTitle>
                    </div>
                    <CardDescription>هذه معاينة تقريبية لكيفية ظهور الفاتورة عند الطباعة.</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow p-0 overflow-hidden">
                    <InvoicePreview template={template} />
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle>المتغيرات المتاحة</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-2 h-32 overflow-y-auto">
                        {availableVariables.map(({ variable, description }) => (
                            <div key={variable} className="flex justify-between items-center text-sm p-2 rounded-md bg-muted">
                            <code className="font-mono text-primary">{variable}</code>
                            <span className="text-muted-foreground">{description}</span>
                            </div>
                        ))}
                    </div>
                    <p className="text-xs text-muted-foreground pt-2">
                        ملاحظة: المتغيرات ذات الثلاثة أقواس (`&lbrace;&lbrace;&lbrace;...&rbrace;&rbrace;&rbrace;`) تقوم بإدراج كتل HTML كاملة، بينما المتغيرات ذات القوسين (`&lbrace;&lbrace;...&rbrace;&rbrace;`) تدرج نصوصاً عادية.
                    </p>
                </CardContent>
            </Card>
        </div>
    </div>
  );
}
