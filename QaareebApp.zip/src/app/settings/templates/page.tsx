import { PageHeader } from '@/components/page-header';
import TemplateEditorClientPage from './template-editor-client';
import { getInvoiceTemplate } from '@/lib/queries';

export default async function InvoiceTemplatePage() {
  const templateHtml = await getInvoiceTemplate();

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
      <PageHeader title="محرر قالب الفاتورة" />
      <TemplateEditorClientPage initialTemplate={templateHtml} />
    </div>
  );
}
