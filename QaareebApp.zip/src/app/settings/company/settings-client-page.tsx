
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { saveCompanyInfo } from './actions';
import Image from 'next/image';
import { LoaderCircle, Building } from 'lucide-react';
import type { CompanyInfo } from '@/lib/types';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import Link from 'next/link';

interface CompanySettingsClientPageProps {
  initialData: CompanyInfo;
}

export default function CompanySettingsClientPage({ initialData }: CompanySettingsClientPageProps) {
  const router = useRouter();
  const { toast } = useToast();
  
  const [isLoading, setIsLoading] = React.useState(false);
  const [formData, setFormData] = React.useState<CompanyInfo>(initialData);
  const [logoPreview, setLogoPreview] = React.useState<string | null>(initialData.logo);


  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: parseFloat(value) || 0 }));
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
        toast({
          variant: 'destructive',
          title: 'الملف كبير جدًا',
          description: 'يرجى اختيار صورة بحجم أقل من 2 ميجابايت.',
        });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData(prev => ({ ...prev, logo: base64String }));
        setLogoPreview(base64String);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleSubmit = async () => {
    setIsLoading(true);
    const result = await saveCompanyInfo(formData);
    setIsLoading(false);

    if (result.success) {
      toast({ title: 'تم الحفظ بنجاح', description: 'تم تحديث بيانات الشركة.' });
      router.refresh(); 
    } else {
      toast({ variant: 'destructive', title: 'فشل الحفظ', description: result.message });
    }
  };

  return (
    <>
    <Card>
      <CardHeader>
        <CardTitle>بيانات الشركة</CardTitle>
        <CardDescription>
          هذه البيانات ستظهر في رأس وتذييل الفواتير المطبوعة.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="name">اسم الشركة (عربي)</Label>
              <Input id="name" value={formData.name} onChange={handleInputChange} className="text-right" />
            </div>
            <div>
              <Label htmlFor="nameEn">اسم الشركة (إنجليزي)</Label>
              <Input id="nameEn" value={formData.nameEn} onChange={handleInputChange} className="text-right" />
            </div>
        </div>
        <div>
          <Label htmlFor="address">العنوان</Label>
          <Input id="address" value={formData.address} onChange={handleInputChange} className="text-right" />
        </div>
        <div>
          <Label htmlFor="phones">أرقام الهواتف</Label>
          <Input id="phones" value={formData.phones} onChange={handleInputChange} className="text-right" />
        </div>
         <div className="space-y-2">
          <Label>تصميم الفاتورة</Label>
          <RadioGroup 
            value={formData.invoiceTemplate} 
            onValueChange={(value) => setFormData(prev => ({...prev, invoiceTemplate: value}))}
            className="flex gap-4"
          >
            <Label htmlFor="template-modern" className="cursor-pointer border-2 has-[:checked]:border-primary rounded-lg p-2 transition-all">
                <RadioGroupItem value="modern" id="template-modern" className="sr-only" />
                <div className="w-40 h-56 bg-muted rounded-md flex flex-col items-center p-2">
                    <div className="w-full h-6 bg-gray-400 rounded-sm mb-2"></div>
                    <div className="w-3/4 h-4 bg-gray-300 rounded-sm mb-4"></div>
                    <div className="w-full h-12 bg-gray-200 rounded-sm"></div>
                </div>
                <p className="text-center text-sm font-medium mt-2">عصري</p>
            </Label>
            <Label htmlFor="template-classic" className="cursor-pointer border-2 has-[:checked]:border-primary rounded-lg p-2 transition-all">
                <RadioGroupItem value="classic" id="template-classic" className="sr-only" />
                 <div className="w-40 h-56 bg-muted rounded-md flex flex-col items-center p-2">
                    <div className="w-3/4 h-4 bg-gray-300 rounded-sm mb-2 self-end"></div>
                    <div className="w-full h-6 bg-gray-400 rounded-sm mb-4"></div>
                    <div className="w-full h-12 bg-gray-200 rounded-sm"></div>
                </div>
                <p className="text-center text-sm font-medium mt-2">كلاسيكي</p>
            </Label>
          </RadioGroup>
          <p className="text-sm text-muted-foreground">
              لتحكم كامل، يمكنك تعديل قالب HTML مباشرة من <Button variant="link" className="p-0 h-auto" asChild><Link href="/settings/templates">محرر القوالب المتقدم</Link></Button>.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="vatPercentage">نسبة القيمة المضافة (%)</Label>
              <Input id="vatPercentage" type="number" value={formData.vatPercentage} onChange={handleNumberChange} className="text-right" />
            </div>
             <div className="grid w-full max-w-sm items-center gap-1.5">
              <Label htmlFor="logo-upload">شعار الشركة</Label>
              <Input id="logo-upload" type="file" accept="image/png, image/jpeg, image/svg+xml" onChange={handleLogoChange} />
               <div className="mt-2 w-24 h-24 p-2 border rounded-md flex items-center justify-center bg-muted">
                 {logoPreview ? (
                    <Image src={logoPreview} alt="معاينة الشعار" width={96} height={96} className="object-contain" />
                  ) : (
                    <Building className="w-12 h-12 text-muted-foreground" />
                  )}
              </div>
            </div>
        </div>
      </CardContent>
      <CardFooter className="border-t px-6 py-4">
        <Button onClick={handleSubmit} disabled={isLoading}>
           {isLoading && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
          حفظ التغييرات
        </Button>
      </CardFooter>
    </Card>
    </>
  );
}
