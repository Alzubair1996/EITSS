

'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { CompanyInfo } from '@/lib/types';

export async function saveCompanyInfo(data: CompanyInfo) {
    try {
        const db = await getDbInstance();
        
        const settingsToSave = [
            { key: 'app_name', value: data.name },
            { key: 'app_name_en', value: data.nameEn },
            { key: 'company_address', value: data.address },
            { key: 'company_phones', value: data.phones },
            { key: 'vat_percentage', value: data.vatPercentage.toString() },
            { key: 'invoice_template', value: data.invoiceTemplate },
        ];
        
        if (data.logo) {
            settingsToSave.push({ key: 'app_logo', value: data.logo });
        }
        
        // This is the most critical part for the initial setup
        if (data.businessType) {
            settingsToSave.push({ key: 'business_type', value: data.businessType });
        }

        await db.exec('BEGIN TRANSACTION;');
        for (const setting of settingsToSave) {
            if(setting.value !== undefined && setting.value !== null){
                 await db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', setting.key, setting.value);
            }
        }
        await db.exec('COMMIT;');
        
        revalidatePath('/', 'layout'); // Revalidate everything that might use this data
        return { success: true, message: 'تم حفظ بيانات الشركة بنجاح.' };
    } catch (e: any) {
        console.error('Failed to save company info:', e);
        return { success: false, message: 'فشل حفظ بيانات الشركة.' };
    }
}


export async function getAppLogo(): Promise<string | null> {
    try {
        const db = await getDbInstance();
        const result = await db.get("SELECT value FROM settings WHERE key = 'app_logo'");
        return result?.value || null;
    } catch (error) {
        console.error("Failed to fetch app logo:", error);
        return null;
    }
}

export async function getAppName(): Promise<string | null> {
     try {
        const db = await getDbInstance();
        const result = await db.get("SELECT value FROM settings WHERE key = 'app_name'");
        return result?.value || null;
    } catch (error) {
        console.error("Failed to fetch app name:", error);
        return null;
    }
}

    