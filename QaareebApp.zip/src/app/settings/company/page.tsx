import { PageHeader } from '@/components/page-header';
import { getCompanyInfo } from '@/lib/queries';
import CompanySettingsClientPage from './settings-client-page';

export default async function CompanySettingsPage() {
  const companyInfo = await getCompanyInfo();

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <PageHeader title="بيانات الشركة والطباعة" />
        <CompanySettingsClientPage initialData={companyInfo} />
      </div>
  );
}
