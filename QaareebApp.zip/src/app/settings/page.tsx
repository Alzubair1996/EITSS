



import { PageHeader } from '@/components/page-header';
import { getCompanyInfo, getAppLogo, getAppName, getCurrentUSDRate, getPrintType, getFontSize } from '@/lib/queries';
import { getLicenseDetails } from '@/app/api/auth/queries';
import SettingsClientPage from './settings-client-page';

export default async function SettingsPage() {
  const companyInfo = await getCompanyInfo();
  const licenseDetails = await getLicenseDetails();

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <PageHeader title="الإعدادات المتقدمة" />
        <SettingsClientPage 
          initialLogo={companyInfo.logo} 
          initialName={companyInfo.name} 
          initialUSDRate={await getCurrentUSDRate()}
          initialPrintType={await getPrintType()}
          initialIsWeightBarcodeEnabled={companyInfo.isWeightBarcodeEnabled}
          initialFontSize={await getFontSize()}
          initialAutoPrintInvoice={companyInfo.autoPrintInvoice ?? false}
          licenseDetails={licenseDetails}
        />
      </div>
  );
}

    
