

'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { saveCompanyInfo } from '@/app/settings/company/actions';
import { restoreDatabaseAction } from '../actions';
import Image from 'next/image';
import { LoaderCircle, Building, UploadCloud, AlertTriangle, ShoppingCart, Store, Package, Pill, UtensilsCrossed } from 'lucide-react';
import type { CompanyInfo } from '@/lib/types';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { cn } from '@/lib/utils';

const businessTypes = [
  { id: 'general_store', name: 'متجر عام', label: 'المتجر', icon: Package },
  { id: 'grocery', name: 'بقالة', label: 'البقالة', icon: ShoppingCart },
  { id: 'supermarket', name: 'سوبر ماركت', label: 'السوبر ماركت', icon: Store },
  { id: 'pharmacy', name: 'صيدلية', label: 'الصيدلية', icon: Pill },
  { id: 'restaurant', name: 'مطعم', label: 'المطعم', icon: UtensilsCrossed },
];

interface SetupClientPageProps {
  initialData: CompanyInfo;
}

export default function SetupClientPage({ initialData }: SetupClientPageProps) {
  const router = useRouter();
  const { toast } = useToast();
  
  const [isLoading, setIsLoading] = React.useState(false);
  const [formData, setFormData] = React.useState<CompanyInfo>(initialData);
  const [logoPreview, setLogoPreview] = React.useState<string | null>(initialData.logo);

  const [isRestoreLoading, setIsRestoreLoading] = React.useState(false);
  const restoreFileInputRef = React.useRef<HTMLInputElement>(null);


  const [step, setStep] = React.useState(1);
  const [selectedBusinessType, setSelectedBusinessType] = React.useState<string | null>(null);


  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: parseFloat(value) || 0 }));
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
        toast({
          variant: 'destructive',
          title: 'الملف كبير جدًا',
          description: 'يرجى اختيار صورة بحجم أقل من 2 ميجابايت.',
        });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData(prev => ({ ...prev, logo: base64String }));
        setLogoPreview(base64String);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleSubmit = async () => {
    if (!formData.name || !formData.address || !formData.phones) {
      toast({
        variant: 'destructive',
        title: 'بيانات ناقصة',
        description: 'اسم الشركة، العنوان، والهواتف حقول مطلوبة.',
      });
      return;
    }

    setIsLoading(true);
    const result = await saveCompanyInfo({...formData, businessType: selectedBusinessType});
    setIsLoading(false);

    if (result.success) {
      toast({ title: 'تم الحفظ بنجاح', description: 'تم إعداد شركتك. جاري توجيهك للوحة التحكم...' });
      
      // Force a reload to ensure middleware re-evaluates and redirects correctly
      // This also ensures that any components that rely on the new setup are re-rendered
      window.location.href = '/';
    } else {
      toast({ variant: 'destructive', title: 'فشل الحفظ', description: result.message });
    }
  };

 const handleRestoreFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      toast({ variant: 'default', title: 'تم الإلغاء' });
      return;
    }
    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64Data = event.target?.result as string;
      setIsRestoreLoading(true);
      const result = await restoreDatabaseAction(base64Data);
      setIsRestoreLoading(false);

      if (result.success) {
        toast({
          title: 'نجاح الاستعادة',
          description: result.message,
          duration: 5000,
        });
        setTimeout(() => window.location.reload(), 2000);
      } else {
        toast({
          variant: 'destructive',
          title: 'فشل الاستعادة',
          description: result.message,
          duration: 7000,
        });
      }
    };
    reader.readAsDataURL(file);
  };


  const renderStepOne = () => (
    <Card>
      <CardHeader className="text-right">
          <CardTitle>الخطوة 1 من 2: اختر نوع نشاطك</CardTitle>
          <CardDescription>
              سيساعدنا هذا في تخصيص بعض الميزات لتناسب احتياجاتك. هذا الإعداد لا يمكن تغييره لاحقًا.
          </CardDescription>
      </CardHeader>
      <CardContent className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {businessTypes.map(type => (
          <button 
            key={type.id}
            onClick={() => setSelectedBusinessType(type.id)}
            className={cn(
              "flex flex-col items-center justify-center p-6 border-2 rounded-lg text-center transition-all",
              selectedBusinessType === type.id ? "border-primary bg-primary/10" : "border-border hover:border-primary/50 hover:bg-muted/50"
            )}
          >
            <type.icon className="w-10 h-10 mb-2 text-primary" />
            <span className="font-semibold">{type.name}</span>
          </button>
        ))}
      </CardContent>
      <CardFooter>
        <Button onClick={() => setStep(2)} disabled={!selectedBusinessType} className="w-full" size="lg">
          التالي
        </Button>
      </CardFooter>
    </Card>
  );

  const renderStepTwo = () => {
    const businessNameLabel = businessTypes.find(b => b.id === selectedBusinessType)?.label || 'الشركة';

    return (
        <Card>
          <CardHeader className="text-right">
              <CardTitle>الخطوة 2 من 2: بيانات النشاط</CardTitle>
              <CardDescription>
              هذه البيانات ستظهر في الفواتير. يمكنك تغييرها لاحقًا من الإعدادات.
              </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                  <Label htmlFor="name">اسم {businessNameLabel} (عربي)</Label>
                  <Input id="name" value={formData.name} onChange={handleInputChange} className="text-right" />
                  </div>
                  <div>
                  <Label htmlFor="nameEn">اسم {businessNameLabel} (إنجليزي)</Label>
                  <Input id="nameEn" value={formData.nameEn} onChange={handleInputChange} className="text-right" />
                  </div>
              </div>
              <div>
              <Label htmlFor="address">العنوان</Label>
              <Input id="address" value={formData.address} onChange={handleInputChange} className="text-right" />
              </div>
              <div>
              <Label htmlFor="phones">أرقام الهواتف</Label>
              <Input id="phones" value={formData.phones} onChange={handleInputChange} className="text-right" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                  <Label htmlFor="vatPercentage">نسبة القيمة المضافة (%)</Label>
                  <Input id="vatPercentage" type="number" value={formData.vatPercentage} onChange={handleNumberChange} className="text-right" />
                  </div>
                  <div className="grid w-full max-w-sm items-center gap-1.5">
                  <Label htmlFor="logo-upload">شعار النشاط (اختياري)</Label>
                  <Input id="logo-upload" type="file" accept="image/png, image/jpeg, image/svg+xml" onChange={handleLogoChange} />
                  <div className="mt-2 w-24 h-24 p-2 border rounded-md flex items-center justify-center bg-muted">
                      {logoPreview ? (
                          <Image src={logoPreview} alt="معاينة الشعار" width={96} height={96} className="object-contain" />
                      ) : (
                          <Building className="w-12 h-12 text-muted-foreground" />
                      )}
                  </div>
                  </div>
              </div>
          </CardContent>
          <CardFooter className="border-t px-6 py-4 flex justify-between">
              <Button onClick={() => setStep(1)} variant="outline">
                  السابق
              </Button>
              <Button onClick={handleSubmit} disabled={isLoading} size="lg">
                {isLoading && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
                حفظ وإنهاء الإعداد
              </Button>
          </CardFooter>
        </Card>
    );
  }

  return (
    <Tabs defaultValue="new_setup" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="new_setup">إعداد جديد</TabsTrigger>
            <TabsTrigger value="restore">استعادة من نسخة احتياطية</TabsTrigger>
        </TabsList>
        <TabsContent value="new_setup">
            {step === 1 ? renderStepOne() : renderStepTwo()}
        </TabsContent>
        <TabsContent value="restore">
             <Card>
                <CardHeader className="text-right">
                    <CardTitle>استعادة من نسخة احتياطية</CardTitle>
                    <CardDescription>
                        استخدم هذه الميزة إذا كان لديك ملف نسخة احتياطية من تثبيت سابق.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <Alert variant="destructive">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertTitle>تحذير خطير</AlertTitle>
                        <AlertDescription>
                            هذا الإجراء سيقوم بمسح أي بيانات قد تكون موجودة حالياً بشكل نهائي واستبدالها بالبيانات من الملف الذي سيتم اختياره.
                        </AlertDescription>
                    </Alert>
                    <div className="text-center pt-4">
                        <input
                          type="file"
                          accept=".sqlite"
                          ref={restoreFileInputRef}
                          onChange={handleRestoreFileSelect}
                          className="hidden"
                        />
                        <Button onClick={() => restoreFileInputRef.current?.click()} disabled={isRestoreLoading} size="lg">
                            {isRestoreLoading ? (
                               <LoaderCircle className="me-2 h-4 w-4 animate-spin" />
                            ) : (
                               <UploadCloud className="me-2 h-4 w-4" />
                            )}
                            اختر ملف النسخة الاحتياطية
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </TabsContent>
    </Tabs>
  );
}
