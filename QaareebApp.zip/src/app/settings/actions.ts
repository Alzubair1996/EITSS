




'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance, closeDb, getDbPath, setupDatabase } from '@/lib/db';
import { getAppLogo as getLogoQuery, getAppName as getAppNameQuery } from '@/app/settings/company/actions';
import { promises as fs } from 'fs';
import path from 'path';
import os from 'os';


export async function saveAppLogo(logoDataUri: string) {
    if (!logoDataUri) {
        return { success: false, message: 'لم يتم توفير بيانات الشعار.' };
    }

    try {
        const db = await getDbInstance();
        await db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'app_logo', logoDataUri);

        revalidatePath('/', 'layout');

        return { success: true, message: 'تم حفظ الشعار بنجاح.' };
    } catch (e: any) {
        console.error('Failed to save app logo:', e);
        return { success: false, message: 'فشل حفظ الشعار في قاعدة البيانات.' };
    }
}

export async function saveAppName(name: string) {
    if (!name) {
        return { success: false, message: 'اسم الشركة مطلوب.' };
    }

    try {
        const db = await getDbInstance();
        await db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'app_name', name);

        revalidatePath('/', 'layout');

        return { success: true, message: 'تم حفظ اسم الشركة بنجاح.' };
    } catch (e: any) {
        console.error('Failed to save app name:', e);
        return { success: false, message: 'فشل حفظ اسم الشركة في قاعدة البيانات.' };
    }
}

export async function savePrintType(printType: 'a4' | 'thermal') {
    if (!printType) {
        return { success: false, message: 'نوع الطباعة مطلوب.' };
    }

    try {
        const db = await getDbInstance();
        await db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'print_type', printType);

        revalidatePath('/settings');
        revalidatePath('/invoices');

        return { success: true, message: 'تم حفظ نوع الطباعة بنجاح.' };
    } catch (e: any) {
        console.error('Failed to save print type:', e);
        return { success: false, message: 'فشل حفظ نوع الطباعة.' };
    }
}

export async function backupDatabaseAction(): Promise<{success: boolean, data?: string, message?: string}> {
    try {
        // First, close the database connection to ensure all data is written to the file
        await closeDb();

        const dbPath = getDbPath();
        const buffer = await fs.readFile(dbPath);
        const base64Data = buffer.toString('base64');
        
        // Re-open the database connection so the app can continue working
        await getDbInstance(true);

        return { success: true, data: `data:application/octet-stream;base64,${base64Data}` };
    } catch (e: any) {
        console.error('Database backup failed:', e);
        
        // Attempt to re-open the database on failure to prevent the app from breaking
        try {
            await getDbInstance(true);
        } catch (reopenError) {
            console.error('Failed to reopen database after backup failure:', reopenError);
        }

        return { success: false, message: 'فشل إنشاء نسخة احتياطية من قاعدة البيانات.' };
    }
}


export async function restoreDatabaseAction(base64Data: string): Promise<{success: boolean, message: string}> {
    try {
        await closeDb();
        const dbPath = getDbPath();
        const dbBuffer = Buffer.from(base64Data.split(',')[1], 'base64');
        await fs.writeFile(dbPath, dbBuffer);
        
        (global as any)._db_restored = true;
        await getDbInstance(true); 

        // Invalidate current session on database restore
        const { deleteSession } = await import('@/lib/auth');
        await deleteSession();

        return { success: true, message: 'تم استعادة قاعدة البيانات بنجاح. سيتم إعادة تشغيل التطبيق.' };
    } catch (e: any) {
        console.error('Database restore failed:', e);
        try {
            await getDbInstance(true);
        } catch (reopenError) {
             console.error('Failed to reopen database after restore failure:', reopenError);
        }
        return { success: false, message: 'فشل استعادة قاعدة البيانات.' };
    }
}


export async function resetDatabaseAction(): Promise<{success: boolean, message: string}> {
    try {
        console.log("Attempting to FULLY RESET database by deleting the file...");
        
        // 1. Close any existing connection
        await closeDb();

        // 2. Get the path and delete the file
        const dbPath = getDbPath();
        try {
            await fs.unlink(dbPath);
            console.log(`Successfully deleted database file at ${dbPath}`);
        } catch (err: any) {
            if (err.code !== 'ENOENT') { // ENOENT means file doesn't exist, which is fine
                throw err;
            }
            console.log(`Database file at ${dbPath} did not exist, proceeding to create a new one.`);
        }

        // 3. Re-initialize, which will create and set up a new database from scratch
        const db = await getDbInstance(true);
        const row = await db.get("SELECT sql FROM sqlite_master WHERE type='table' AND name='invoices'");
        console.log("New database created. DDL for invoices is:", row?.sql);
        
        revalidatePath('/', 'layout');
        
        return { success: true, message: 'تمت تهيئة قاعدة البيانات بنجاح. سيتم إعادة تشغيل التطبيق.' };
    } catch (e: any) {
        console.error('Database reset failed:', e);
        try {
            await getDbInstance(true); // Try to get a DB instance even on failure
        } catch (reopenError) {
            console.error('Failed to get DB instance after reset failure:', reopenError);
        }
        return { success: false, message: `فشل تهيئة قاعدة البيانات: ${e.message}` };
    }
}

export async function saveWeightBarcodeSetting(isEnabled: boolean) {
    try {
        const db = await getDbInstance();
        await db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'weight_barcode_enabled', isEnabled.toString());
        revalidatePath('/settings');
        revalidatePath('/invoices/new');
        return { success: true, message: 'تم حفظ إعداد باركود الميزان بنجاح.' };
    } catch (e: any) {
        console.error('Failed to save weight barcode setting:', e);
        return { success: false, message: 'فشل حفظ الإعداد.' };
    }
}

// Save the auto-print invoice setting. This determines whether invoices are automatically printed after creation.
export async function saveAutoPrintInvoice(isEnabled: boolean) {
    try {
        const db = await getDbInstance();
        await db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'auto_print_invoice', isEnabled.toString());
        // Invalidate relevant pages so that the updated setting is reflected.
        revalidatePath('/settings');
        revalidatePath('/invoices/new');
        // Also refresh layout to ensure the setting is available in the context.
        revalidatePath('/', 'layout');
        return { success: true, message: 'تم حفظ إعداد الطباعة التلقائية بنجاح.' };
    } catch (e: any) {
        console.error('Failed to save auto print setting:', e);
        return { success: false, message: 'فشل حفظ إعداد الطباعة التلقائية.' };
    }
}

export async function saveFontSize(size: 'sm' | 'md' | 'lg') {
    if (!['sm', 'md', 'lg'].includes(size)) {
        return { success: false, message: 'حجم الخط غير صالح.' };
    }
    try {
        const db = await getDbInstance();
        await db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'font_size', size);
        revalidatePath('/', 'layout');
        return { success: true, message: 'تم حفظ حجم الواجهة بنجاح.' };
    } catch (e: any) {
        console.error('Failed to save font size:', e);
        return { success: false, message: 'فشل حفظ الإعداد.' };
    }
}

export async function deactivateLicenseAction() {
    try {
        const db = await getDbInstance();
        await db.run("DELETE FROM settings WHERE key = 'license_key'");
        revalidatePath('/', 'layout');
        return { success: true, message: 'تم إلغاء التفعيل بنجاح. سيتم توجيهك لصفحة التفعيل.' };
    } catch (e: any) {
        console.error('Failed to deactivate license:', e);
        return { success: false, message: 'فشل إلغاء التفعيل.' };
    }
}
    
