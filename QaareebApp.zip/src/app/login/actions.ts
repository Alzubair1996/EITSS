// Server actions related to user authentication.
'use server';

import { getDbInstance } from '@/lib/db';
import { verifyPassword } from '@/lib/server-auth';
import { createSession, deleteSession } from '@/lib/auth';
import { redirect } from 'next/navigation';

/**
 * Authenticate a user by username and password. If successful, create a session cookie.
 * Returns either { success: true } or { error: string }. If you wish to automatically
 * redirect the user after a successful login, you can perform a redirect here, but for
 * this implementation we return an object so the client can decide.
 */
export async function login(formData: FormData) {
  try {
    const username = (formData.get('username') as string)?.trim();
    const password = (formData.get('password') as string) || '';
    if (!username || !password) {
      return { error: 'الرجاء إدخال اسم المستخدم وكلمة المرور.' };
    }

    const db = await getDbInstance();
    const user = await db.get('SELECT id, password, roleId FROM users WHERE username = ?', username);
    if (!user) {
      return { error: 'اسم المستخدم غير موجود.' };
    }
    const isValid = await verifyPassword(password, user.password);
    if (!isValid) {
      return { error: 'كلمة المرور غير صحيحة.' };
    }

    await createSession(user.id, username, user.roleId);
    return { success: true };
  } catch (error: any) {
    console.error('Login action error:', error);
    return { error: error?.message || 'حدث خطأ في الخادم أثناء تسجيل الدخول.' };
  }
}

/**
 * Destroy the current session and redirect the user to the login page.
 */
export async function logout() {
  await deleteSession();
  redirect('/login');
}