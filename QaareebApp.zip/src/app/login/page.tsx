'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { login } from './actions';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Eye, EyeOff, Lock, User, Building2, Loader2, TrendingUp, ShieldCheck, ArrowRightLeft, Sparkles, CheckCircle2 } from 'lucide-react';

interface CompanyInfo {
  name: string;
  nameEn: string;
  logo: string | null;
}

export default function LoginPage() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [company, setCompany] = useState<CompanyInfo | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    async function fetchCompany() {
      try {
        const res = await fetch('/api/company-info');
        if (res.ok) {
          const data = await res.json();
          setCompany(data);
        }
      } catch {
        // fail silently
      }
    }
    fetchCompany();
  }, []);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    try {
      const formData = new FormData(event.currentTarget);
      const result = await login(formData);
      if (result && result.error) {
        setError(result.error);
        setIsLoading(false);
      } else if (result && result.success) {
        window.location.href = '/';
      } else {
        setError('حدث خطأ غير متوقع.');
        setIsLoading(false);
      }
    } catch (err: any) {
      console.error('Login submit error:', err);
      setError(err?.message || 'تعذر الاتصال بالخادم.');
      setIsLoading(false);
    }
  }

  return (
    <div className="h-screen w-full flex bg-background font-sans overflow-y-auto lg:overflow-hidden" dir="rtl">
      
      {/* LEFT SIDE: Decorative Brand Panel (Hidden on Mobile) */}
      <div className="hidden lg:flex lg:w-1/2 relative flex-col justify-between p-12 bg-gradient-to-br from-[#090b14] via-[#101426] to-[#05070d] border-l border-[#ffffff]/5 overflow-hidden">
        
        {/* Futuristic glowing orbs */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] pointer-events-none animate-pulse" style={{ animationDuration: '6s' }} />
        <div className="absolute bottom-[-15%] left-[-10%] w-[450px] h-[450px] bg-primary/10 rounded-full blur-[100px] pointer-events-none animate-pulse" style={{ animationDuration: '8s' }} />
        
        {/* Subtle grid pattern overlay */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{
          backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
          backgroundSize: '40px 40px'
        }} />

        {/* Top brand header */}
        <div className="relative z-10 flex items-center gap-4">
          <div className="h-20 w-auto max-w-[240px] rounded-2xl overflow-hidden border border-white bg-white p-2 flex items-center justify-center shadow-xl">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/logoEITSS.png" alt="EITSS Logo" className="h-full w-auto object-contain" />
          </div>
          <span className="text-lg font-extrabold text-white tracking-wide">نظام متجرك المحلي 2026</span>
        </div>

        {/* Center: Live-looking dashboard mock previews */}
        <div className="relative z-10 my-auto space-y-6 max-w-lg">
          
          <div className="space-y-3">
            <h2 className="text-4xl font-extrabold text-white tracking-tight leading-tight">
              إدارة متجرك محلياً بكفاءة وأمان.
            </h2>
            <p className="text-base text-muted-foreground leading-relaxed">
              نظام محلي متكامل بقاعدة بيانات SQLite مخصص للمحلات التجارية في السودان، يضمن لك سرعة التشغيل واستمرارية العمل دون الحاجة لإنترنت.
            </p>
          </div>

          {/* Interactive Glassmorphic Stats Preview */}
          <div className="relative p-6 rounded-3xl border border-white/10 bg-white/[0.03] backdrop-blur-xl shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-white/60">مؤشر نمو المبيعات</span>
              <Badge variant="success" className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/20">قاعدة بيانات محلية</Badge>
            </div>
            
            <div className="flex items-end justify-between">
              <div>
                <span className="text-3xl font-extrabold text-white font-mono">+1,248,000 SDG</span>
                <span className="text-xs text-emerald-400 font-medium block mt-1 flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" /> +18.4% مقارنة بالشهر السابق
                </span>
              </div>
              
              {/* Mini SVG Chart wave */}
              <svg className="w-32 h-12 text-primary" viewBox="0 0 100 30" fill="none">
                <path d="M0 25 C20 20, 30 5, 50 15 C70 25, 80 5, 100 2" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
                <path d="M0 25 C20 20, 30 5, 50 15 C70 25, 80 5, 100 2 L100 30 L0 30 Z" fill="currentColor" fillOpacity="0.05" />
              </svg>
            </div>
          </div>

          {/* Secondary feature cards */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl border border-white/5 bg-white/[0.01] backdrop-blur-md flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs text-white font-bold block">تأمين محلي</span>
                <span className="text-[10px] text-white/50">تشفير قاعدة بيانات SQLite</span>
              </div>
            </div>
            <div className="p-4 rounded-2xl border border-white/5 bg-white/[0.01] backdrop-blur-md flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                <ArrowRightLeft className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs text-white font-bold block">تشغيل دون إنترنت</span>
                <span className="text-[10px] text-white/50">سرعة فائقة واستقرار تام</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom copyright note */}
        <div className="relative z-10 text-xs text-white/30">
          الباقرة لتقنية المعلومات EITSS © 2026. جميع الحقوق محفوظة لـ EITSS.
        </div>
      </div>

      {/* RIGHT SIDE: Active Login Form Panel */}
      <div className="w-full lg:w-1/2 flex flex-col justify-between p-8 md:p-12 lg:p-16 bg-background relative">
        
        {/* Decorative background visual elements for mobile */}
        <div className="lg:hidden absolute top-[-10%] left-[-10%] w-[300px] h-[300px] bg-primary/5 rounded-full blur-[80px] pointer-events-none" />

        {/* Form top logo banner */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-primary to-primary/80 flex items-center justify-center shadow-xl shadow-primary/20 p-1">
              {company?.logo ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={company.logo} alt="Company Logo" className="w-full h-full object-contain" />
              ) : (
                <Building2 className="w-5 h-5 text-white" />
              )}
            </div>
            <h1 className="text-lg font-extrabold text-foreground tracking-tight">
              {company?.name || 'متجر'}
            </h1>
          </div>
        </div>

        {/* Login form box */}
        <div className="my-auto max-w-sm w-full mx-auto space-y-8">
          <div>
            <h2 className="text-3xl font-extrabold text-foreground tracking-tight">تسجيل الدخول</h2>
            <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">يرجى إدخال اسم المستخدم وكلمة المرور للوصول إلى لوحة التحكم.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Username input with elegant shadow/border transition */}
            <div className="space-y-1.5">
              <Label htmlFor="username" className="text-xs font-bold text-foreground">اسم المستخدم</Label>
              <div className="relative">
                <User className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-muted-foreground/80 pointer-events-none transition-colors group-focus-within:text-primary" />
                <input
                  type="text"
                  id="username"
                  name="username"
                  required
                  autoComplete="username"
                  className="w-full pr-11 pl-4 py-3 bg-secondary/30 border border-border/80 rounded-2xl text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all duration-300 text-sm shadow-sm"
                  placeholder="أدخل اسم المستخدم المعتمد"
                />
              </div>
            </div>

            {/* Password input */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <Label htmlFor="password" className="text-xs font-bold text-foreground">كلمة المرور</Label>
              </div>
              <div className="relative">
                <Lock className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-muted-foreground/80 pointer-events-none transition-colors" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  name="password"
                  required
                  autoComplete="current-password"
                  className="w-full pr-11 pl-11 py-3 bg-secondary/30 border border-border/80 rounded-2xl text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all duration-300 text-sm shadow-sm"
                  placeholder="أدخل كلمة المرور الخاصة بك"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground/75 hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="h-4.5 w-4.5" /> : <Eye className="h-4.5 w-4.5" />}
                </button>
              </div>
            </div>

            {/* Error notifications block */}
            {error && (
              <div className="flex items-center gap-2.5 bg-destructive/10 border border-destructive/20 text-destructive rounded-2xl px-4 py-3 text-xs font-semibold animate-shake">
                <span className="w-2 h-2 rounded-full bg-destructive flex-shrink-0" />
                {error}
              </div>
            )}

            {/* CTA action button */}
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full h-12 rounded-2xl bg-gradient-to-l from-primary to-primary/90 text-white font-extrabold text-sm shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 hover:scale-[1.01] active:scale-[0.99] transition-all duration-300"
            >
              {isLoading ? (
                <span className="flex items-center gap-2 justify-center">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  جاري التحقق من الحساب...
                </span>
              ) : (
                'تسجيل الدخول للنظام'
              )}
            </Button>
          </form>
        </div>

        {/* Footer corporate logo tag */}
        <div className="text-center text-[10px] text-muted-foreground leading-relaxed mt-8 border-t border-border/40 pt-4 flex flex-col items-center gap-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/logoEITSS.png" alt="EITSS Logo" className="h-10 w-auto object-contain opacity-75" />
          <span>تم تطوير هذا النظام محلياً بواسطة EITSS الباقرة لتقنية المعلومات • جميع الحقوق محفوظة لـ EITSS الباقرة لتقنية المعلومات © 2026</span>
        </div>
      </div>

    </div>
  );
}