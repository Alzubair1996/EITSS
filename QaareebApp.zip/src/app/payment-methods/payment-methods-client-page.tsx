'use client';

import * as React from 'react';
import { PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/page-header';
import { PaymentMethodsTable } from './payment-methods-table';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { PaymentMethodForm } from './payment-method-form';
import type { PaymentMethod } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { deletePaymentMethod, addPaymentMethod, updatePaymentMethod } from './actions';
import { useRouter } from 'next/navigation';

interface PaymentMethodsClientPageProps {
  initialPaymentMethods: PaymentMethod[];
}

export default function PaymentMethodsClientPage({ initialPaymentMethods }: PaymentMethodsClientPageProps) {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [editingMethod, setEditingMethod] = React.useState<PaymentMethod | null>(null);
  const { toast } = useToast();
  const router = useRouter();

  const handleAdd = () => {
    setEditingMethod(null);
    setIsDialogOpen(true);
  };

  const handleEdit = (method: PaymentMethod) => {
    setEditingMethod(method);
    setIsDialogOpen(true);
  };

  const handleDelete = async (methodId: string) => {
    const result = await deletePaymentMethod(methodId);
    if (result.success) {
      toast({
        title: 'تم الحذف بنجاح',
        description: result.message,
      });
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ في الحذف',
        description: result.message,
      });
    }
  };

  const handleFormSubmit = async (values: Omit<PaymentMethod, 'id'>) => {
    const action = editingMethod
      ? updatePaymentMethod({ ...values, id: editingMethod.id })
      : addPaymentMethod(values);

    const result = await action;

    if (result.success) {
      toast({
        title: editingMethod ? 'تم التحديث بنجاح' : 'تمت الإضافة بنجاح',
        description: result.message,
      });
      setIsDialogOpen(false);
      setEditingMethod(null);
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ',
        description: result.message,
      });
    }
  };

  return (
    <>
      <PageHeader title="إدارة طرق الدفع">
        <Button onClick={handleAdd} className="shadow-md hover:shadow-lg transition-shadow">
          <PlusCircle className="me-2 h-4 w-4" />
          إضافة طريقة دفع
        </Button>
      </PageHeader>
      <PaymentMethodsTable
        paymentMethods={initialPaymentMethods}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <PaymentMethodForm
            paymentMethod={editingMethod}
            onSubmit={handleFormSubmit}
            onCancel={() => setIsDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}
