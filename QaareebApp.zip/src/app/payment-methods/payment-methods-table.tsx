
'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MoreHorizontal, Pencil, Trash2, Wallet, Landmark, Banknote } from 'lucide-react';
import type { PaymentMethod } from '@/lib/types';

interface PaymentMethodsTableProps {
  paymentMethods: PaymentMethod[];
  onEdit: (method: PaymentMethod) => void;
  onDelete: (methodId: string) => void;
}

export function PaymentMethodsTable({ paymentMethods, onEdit, onDelete }: PaymentMethodsTableProps) {
  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  const totalBalance = paymentMethods.reduce((sum, m) => sum + (m.balance || 0), 0);

  return (
    <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
      <CardHeader className="pb-4 border-b border-border/40 bg-secondary/10 flex flex-row justify-between items-center">
        <div>
          <CardTitle className="text-base font-bold text-foreground">طرق الدفع والحسابات</CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">إدارة حسابات الكاش والبنوك</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="text-xs font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-200 dark:border-emerald-500/20">
            إجمالي: {formatCurrency(totalBalance)}
          </div>
          <div className="text-xs font-semibold text-muted-foreground bg-background px-3 py-1.5 rounded-full border border-border/40 shadow-sm">
            {paymentMethods.length} حساب
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>اسم الحساب</TableHead>
              <TableHead>النوع</TableHead>
              <TableHead>البنك</TableHead>
              <TableHead>رقم الحساب</TableHead>
              <TableHead className="text-right">الرصيد</TableHead>
              <TableHead className="text-center">الإجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paymentMethods.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-40 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-4 rounded-2xl bg-muted/50">
                      <Wallet className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">لا توجد طرق دفع</p>
                      <p className="text-sm text-muted-foreground mt-1">قم بإضافة حساب جديد للبدء</p>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              paymentMethods.map((method) => (
                <TableRow key={method.id} className="group">
                  <TableCell className="font-semibold flex items-center gap-2">
                    <div className={`p-1.5 rounded-lg ${method.type === 'bank' ? 'bg-primary/10' : 'bg-emerald-500/10'}`}>
                      {method.type === 'bank'
                        ? <Landmark className="h-3.5 w-3.5 text-primary" />
                        : <Banknote className="h-3.5 w-3.5 text-emerald-600" />
                      }
                    </div>
                    {method.name}
                  </TableCell>
                  <TableCell>
                    <Badge variant={method.type === 'bank' ? 'info' : 'success'}>
                      {method.type === 'bank' ? 'بنك' : 'كاش'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">{method.bankName || '—'}</TableCell>
                  <TableCell className="font-mono text-sm text-muted-foreground">{method.accountNumber || '—'}</TableCell>
                  <TableCell className="text-right font-mono font-bold text-foreground">
                    {formatCurrency(method.balance || 0)}
                  </TableCell>
                  <TableCell className="text-center">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          aria-haspopup="true"
                          size="icon"
                          variant="ghost"
                          className="rounded-full h-8 w-8 hover:bg-primary/5 hover:text-primary opacity-60 group-hover:opacity-100 transition-all"
                        >
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">فتح القائمة</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl shadow-lg border-border/50">
                        <DropdownMenuItem
                          onSelect={() => onEdit(method)}
                          className="rounded-lg cursor-pointer"
                        >
                          <Pencil className="me-2 h-4 w-4 text-primary" />
                          تعديل
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onSelect={() => onDelete(method.id)}
                          className="rounded-lg cursor-pointer text-destructive focus:text-destructive"
                        >
                          <Trash2 className="me-2 h-4 w-4" />
                          حذف
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
