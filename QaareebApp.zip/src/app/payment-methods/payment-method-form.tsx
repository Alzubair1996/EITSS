
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import type { PaymentMethod } from '@/lib/types';

const formSchema = z.object({
    name: z.string().min(2, { message: 'اسم طريقة الدفع مطلوب' }),
    type: z.enum(['cash', 'bank'], { required_error: 'النوع مطلوب' }),
    bankName: z.string().optional(),
    accountNumber: z.string().optional(),
    branch: z.string().optional(),
    balance: z.coerce.number().min(0, { message: 'الرصيد الابتدائي مطلوب' }),
}).superRefine((data, ctx) => {
    if (data.type === 'bank') {
        if (!data.bankName || data.bankName.length < 2) {
            ctx.addIssue({
                code: z.ZodIssueCode.custom,
                message: 'اسم البنك مطلوب',
                path: ['bankName'],
            });
        }
        if (!data.accountNumber || data.accountNumber.length < 5) {
            ctx.addIssue({
                code: z.ZodIssueCode.custom,
                message: 'رقم الحساب مطلوب',
                path: ['accountNumber'],
            });
        }
    }
});


type PaymentMethodFormValues = z.infer<typeof formSchema>;

interface PaymentMethodFormProps {
  paymentMethod: PaymentMethod | null;
  onSubmit: (values: PaymentMethodFormValues) => void;
  onCancel: () => void;
}

export function PaymentMethodForm({ paymentMethod, onSubmit, onCancel }: PaymentMethodFormProps) {
  const form = useForm<PaymentMethodFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: paymentMethod?.name || '',
      type: paymentMethod?.type || 'cash',
      bankName: paymentMethod?.bankName || '',
      accountNumber: paymentMethod?.accountNumber || '',
      branch: paymentMethod?.branch || '',
      balance: paymentMethod?.balance || 0,
    },
  });

  const paymentType = form.watch('type');

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <DialogHeader>
          <DialogTitle>
            {paymentMethod ? 'تعديل طريقة الدفع' : 'إضافة طريقة دفع جديدة'}
          </DialogTitle>
          <DialogDescription>
            {paymentMethod ? 'قم بتعديل تفاصيل طريقة الدفع.' : 'أدخل تفاصيل طريقة الدفع الجديدة.'}
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[70vh] overflow-y-auto pr-2">
            <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                <FormItem className="space-y-3 md:col-span-2">
                    <FormLabel>نوع طريقة الدفع</FormLabel>
                    <FormControl>
                    <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex space-x-4"
                    >
                        <FormItem className="flex items-center space-x-2 space-x-reverse">
                        <FormControl>
                            <RadioGroupItem value="cash" id="cash" />
                        </FormControl>
                        <FormLabel htmlFor="cash" className="font-normal">
                            كاش
                        </FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-2 space-x-reverse">
                        <FormControl>
                            <RadioGroupItem value="bank" id="bank" />
                        </FormControl>
                        <FormLabel htmlFor="bank" className="font-normal">
                            بنك
                        </FormLabel>
                        </FormItem>
                    </RadioGroup>
                    </FormControl>
                    <FormMessage />
                </FormItem>
                )}
            />
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>اسم الطريقة</FormLabel>
                <FormControl>
                  <Input placeholder={paymentType === 'bank' ? 'مثال: بنك فيصل الإسلامي' : 'مثال: الخزينة الرئيسية'} {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="balance"
            render={({ field }) => (
              <FormItem>
                <FormLabel>الرصيد الابتدائي</FormLabel>
                <FormControl>
                  <Input type="number" step="0.01" placeholder="0.00" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {paymentType === 'bank' && (
            <>
                <FormField
                control={form.control}
                name="bankName"
                render={({ field }) => (
                <FormItem>
                    <FormLabel>اسم البنك</FormLabel>
                    <FormControl>
                    <Input placeholder="مثال: بنك الخرطوم" {...field} value={field.value ?? ''} className="text-right" />
                    </FormControl>
                    <FormMessage />
                </FormItem>
                )}
            />
            <FormField
                control={form.control}
                name="accountNumber"
                render={({ field }) => (
                <FormItem>
                    <FormLabel>رقم الحساب</FormLabel>
                    <FormControl>
                    <Input placeholder="مثال: 123456789" {...field} value={field.value ?? ''} className="text-right" />
                    </FormControl>
                    <FormMessage />
                </FormItem>
                )}
            />
             <FormField
                control={form.control}
                name="branch"
                render={({ field }) => (
                <FormItem className="md:col-span-2">
                    <FormLabel>الفرع (اختياري)</FormLabel>
                    <FormControl>
                    <Input placeholder="مثال: فرع الرياض" {...field} value={field.value ?? ''} className="text-right" />
                    </FormControl>
                    <FormMessage />
                </FormItem>
                )}
            />
            </>
          )}

        </div>
        <DialogFooter className="pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            إلغاء
          </Button>
          <Button type="submit">
            {paymentMethod ? 'حفظ التغييرات' : 'إضافة'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}
