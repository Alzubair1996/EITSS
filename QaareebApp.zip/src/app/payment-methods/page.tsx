import PaymentMethodsClientPage from './payment-methods-client-page';
import { getPaymentMethods } from '@/lib/queries';
import { getSession } from '@/lib/server-auth';
import { hasPermission } from '@/lib/permissions';
import { redirect } from 'next/navigation';

export default async function PaymentMethodsPage() {
  // Ensure the user is authenticated
  const session = await getSession();
  if (!session) {
    redirect('/login');
  }
  // Check if the user has permission to manage payment methods
  const allowed = await hasPermission(session.userId, 'manage_payment_methods');
  if (!allowed) {
    // Redirect unauthorized users to home or login page
    redirect('/');
  }

  const initialPaymentMethods = await getPaymentMethods();

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
      <PaymentMethodsClientPage initialPaymentMethods={initialPaymentMethods} />
    </div>
  );
}
