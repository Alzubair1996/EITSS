'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { PaymentMethod } from '@/lib/types';
import { randomUUID } from 'crypto';

export async function addPaymentMethod(paymentMethodData: Omit<PaymentMethod, 'id'>) {
    try {
        const db = await getDbInstance();
        const newId = `pay_${randomUUID()}`;
        await db.run(`
            INSERT INTO payment_methods (id, name, type, bankName, accountNumber, branch, balance)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `,
            newId, 
            paymentMethodData.name, 
            paymentMethodData.type, 
            paymentMethodData.type === 'bank' ? paymentMethodData.bankName : null,
            paymentMethodData.type === 'bank' ? paymentMethodData.accountNumber : null,
            paymentMethodData.type === 'bank' ? paymentMethodData.branch : null,
            paymentMethodData.balance
        );
        revalidatePath('/payment-methods');
        return { success: true, message: 'تمت إضافة طريقة الدفع بنجاح' };
    } catch (e) {
        console.error(e);
        return { success: false, message: 'خطأ في قاعدة البيانات: فشلت إضافة طريقة الدفع' };
    }
}

export async function updatePaymentMethod(paymentMethodData: PaymentMethod) {
     try {
        const db = await getDbInstance();
        await db.run(`
            UPDATE payment_methods
            SET name = ?, type = ?, bankName = ?, accountNumber = ?, branch = ?, balance = ?
            WHERE id = ?
        `,
            paymentMethodData.name,
            paymentMethodData.type,
            paymentMethodData.type === 'bank' ? paymentMethodData.bankName : null,
            paymentMethodData.type === 'bank' ? paymentMethodData.accountNumber : null,
            paymentMethodData.type === 'bank' ? paymentMethodData.branch : null,
            paymentMethodData.balance,
            paymentMethodData.id
        );
        revalidatePath('/payment-methods');
        return { success: true, message: 'تم تحديث طريقة الدفع بنجاح' };
    } catch (e) {
        console.error(e);
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل تحديث طريقة الدفع' };
    }
}

export async function deletePaymentMethod(id: string) {
    try {
        const db = await getDbInstance();
        // Here you might want to check if the payment method has any transactions before deleting.
        // For now, we will delete directly.
        await db.run('DELETE FROM payment_methods WHERE id = ?', id);
        revalidatePath('/payment-methods');
        return { success: true, message: 'تم حذف طريقة الدفع.' };
    } catch (e) {
        console.error(e);
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل حذف طريقة الدفع.' };
    }
}
