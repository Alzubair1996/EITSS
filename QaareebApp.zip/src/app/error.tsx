'use client';

import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { useEffect } from 'react';
import { AlertTriangle } from 'lucide-react';

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error(error);
  }, [error]);

  return (
    <div className="flex items-center justify-center min-h-screen bg-muted">
        <Card className="w-full max-w-lg text-center">
            <CardHeader>
                <div className="mx-auto bg-destructive/10 p-3 rounded-full">
                    <AlertTriangle className="h-8 w-8 text-destructive" />
                </div>
                <CardTitle className="mt-4">حدث خطأ غير متوقع</CardTitle>
                <CardDescription>
                    نعتذر، لقد واجه التطبيق مشكلة. يمكنك محاولة تحديث الصفحة.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="bg-muted p-3 rounded-md text-sm text-destructive overflow-auto max-h-32">
                    <pre className="whitespace-pre-wrap">
                        <code>{error.message || 'An unknown error occurred'}</code>
                    </pre>
                </div>
            </CardContent>
            <CardFooter>
                <Button onClick={() => reset()} className="w-full">
                    إعادة المحاولة
                </Button>
            </CardFooter>
        </Card>
    </div>
  );
}
