
'use client';

import * as React from 'react';
import type { Invoice, PaymentMethod } from '@/lib/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  FileText,
  Printer,
  Search,
  PlusCircle,
  Trash2,
  CheckSquare,
  LoaderCircle,
  TrendingUp,
  Receipt,
  Clock,
  XCircle,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Filter,
  CalendarDays,
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import { PageHeader } from '@/components/page-header';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { IS_RESTAURANT_APP } from '@/lib/types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { cancelInvoice, finalizeProformaInvoice } from './actions';
import { createSalesReturn, getInvoiceDetailsAction } from '@/app/sales-returns/actions';
import { useRouter } from 'next/navigation';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

interface InvoicesClientPageProps {
  initialInvoices: Invoice[];
  paymentMethods: PaymentMethod[];
  isAdmin: boolean;
  salesReturns?: any[];
}

const STATUS_CONFIG = {
  paid:      { text: 'مدفوعة',          variant: 'success'     as const, dot: 'bg-emerald-500' },
  partial:   { text: 'مدفوعة جزئياً',   variant: 'warning'     as const, dot: 'bg-amber-500'   },
  unpaid:    { text: 'غير مدفوعة',      variant: 'destructive' as const, dot: 'bg-red-500'      },
  cancelled: { text: 'ملغاة',           variant: 'secondary'   as const, dot: 'bg-gray-400'     },
  proforma:  { text: 'مبدئية',          variant: 'info'        as const, dot: 'bg-blue-400'     },
} as const;

const PAGE_SIZE = 15;

export default function InvoicesClientPage({
  initialInvoices,
  paymentMethods,
  isAdmin,
  salesReturns = [],
}: InvoicesClientPageProps) {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [statusFilter, setStatusFilter] = React.useState<string>('all');
  const [dateFilter, setDateFilter] = React.useState<string>('all');
  const [page, setPage] = React.useState(1);

  // Cancellation dialog
  const [cancellationReason, setCancellationReason] = React.useState('');
  const [invoiceToCancel, setInvoiceToCancel] = React.useState<Invoice | null>(null);
  const [isCancelDialogOpen, setIsCancelDialogOpen] = React.useState(false);

  // Finalization dialog
  const [isFinalizeDialogOpen, setIsFinalizeDialogOpen] = React.useState(false);
  const [invoiceToFinalize, setInvoiceToFinalize] = React.useState<Invoice | null>(null);
  const [finalizeAmountPaid, setFinalizeAmountPaid] = React.useState<string>('');
  const [finalizePaymentMethodId, setFinalizePaymentMethodId] = React.useState<string | null>(null);
  const [isFinalizing, setIsFinalizing] = React.useState(false);

  const { toast } = useToast();
  const router = useRouter();

  // Return dialog states
  const [isReturnDialogOpen, setIsReturnDialogOpen] = React.useState(false);
  const [selectedInvoiceId, setSelectedInvoiceId] = React.useState<string>('');
  const [invoiceItems, setInvoiceItems] = React.useState<any[]>([]);
  const [cart, setCart] = React.useState<any[]>([]);
  const [reason, setReason] = React.useState('');
  const [loadingInvoice, setLoadingInvoice] = React.useState(false);
  const [isSubmittingReturn, setIsSubmittingReturn] = React.useState(false);

  /* ── helpers ── */
  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  /* ── derived stats ── */
  const stats = React.useMemo(() => {
    const paid    = initialInvoices.filter(i => i.status === 'paid').length;
    const partial = initialInvoices.filter(i => i.status === 'partial').length;
    const unpaid  = initialInvoices.filter(i => i.status === 'unpaid').length;
    const returned = salesReturns.reduce((s, r) => s + (r.totalAmount || 0), 0);
    const total   = initialInvoices.reduce((s, i) => s + (i.status !== 'cancelled' ? i.totalAmount : 0), 0) - returned;
    return { paid, partial, unpaid, total, returned, count: initialInvoices.length };
  }, [initialInvoices, salesReturns]);

  /* ── filtering ── */
  const filtered = React.useMemo(() => {
    const term = searchTerm.toLowerCase();
    return initialInvoices.filter(inv => {
      const matchText =
        inv.customerName.toLowerCase().includes(term) ||
        String(inv.invoiceNumber).includes(term) ||
        (IS_RESTAURANT_APP && String(inv.dailyOrderNumber).includes(term));
      const matchStatus = statusFilter === 'all' || inv.status === statusFilter;
      
      let matchDate = true;
      if (dateFilter !== 'all') {
        const invDate = new Date(inv.issueDate);
        const now = new Date();
        const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        
        if (dateFilter === 'today') {
          matchDate = invDate >= startOfToday;
        } else if (dateFilter === 'week') {
          const oneWeekAgo = new Date(startOfToday.getTime() - 7 * 24 * 60 * 60 * 1000);
          matchDate = invDate >= oneWeekAgo;
        } else if (dateFilter === 'month') {
          const oneMonthAgo = new Date(startOfToday.getFullYear(), startOfToday.getMonth() - 1, startOfToday.getDate());
          matchDate = invDate >= oneMonthAgo;
        }
      }

      return matchText && matchStatus && matchDate;
    });
  }, [initialInvoices, searchTerm, statusFilter, dateFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated  = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  React.useEffect(() => setPage(1), [searchTerm, statusFilter, dateFilter]);

  /* ── cancel handlers ── */
  const handleOpenCancelDialog = (invoice: Invoice) => {
    setInvoiceToCancel(invoice);
    setCancellationReason('');
    setIsCancelDialogOpen(true);
  };

  const handleConfirmCancellation = async () => {
    if (!invoiceToCancel) return;
    if (!cancellationReason) {
      toast({ variant: 'destructive', title: 'خطأ', description: 'سبب الإلغاء مطلوب.' });
      return;
    }
    const result = await cancelInvoice(invoiceToCancel.id, cancellationReason);
    if (result.success) {
      toast({ title: 'نجاح', description: result.message });
      router.refresh();
      setIsCancelDialogOpen(false);
      setInvoiceToCancel(null);
    } else {
      toast({ variant: 'destructive', title: 'فشل', description: result.message });
    }
  };

  /* ── finalize handlers ── */
  const handleOpenFinalizeDialog = (invoice: Invoice) => {
    setInvoiceToFinalize(invoice);
    setFinalizeAmountPaid(!invoice.customerId ? invoice.totalAmount.toString() : '');
    setFinalizePaymentMethodId(paymentMethods[0]?.id || null);
    setIsFinalizeDialogOpen(true);
  };

  const handleConfirmFinalization = async () => {
    if (!invoiceToFinalize) return;
    const amountPaid = Number(finalizeAmountPaid) || 0;
    if (amountPaid < 0) {
      toast({ variant: 'destructive', title: 'خطأ', description: 'المبلغ المدفوع لا يمكن أن يكون سالبًا.' });
      return;
    }
    if (amountPaid > invoiceToFinalize.totalAmount) {
      toast({ variant: 'destructive', title: 'خطأ', description: 'المبلغ المدفوع لا يمكن أن يكون أكبر من إجمالي الفاتورة.' });
      return;
    }
    if (amountPaid > 0 && !finalizePaymentMethodId) {
      toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى اختيار طريقة الدفع.' });
      return;
    }
    setIsFinalizing(true);
    const result = await finalizeProformaInvoice(invoiceToFinalize.id, amountPaid, finalizePaymentMethodId);
    setIsFinalizing(false);
    if (result.success) {
      toast({ title: 'نجاح', description: result.message });
      router.refresh();
      setIsFinalizeDialogOpen(false);
      setInvoiceToFinalize(null);
    } else {
      toast({ variant: 'destructive', title: 'فشل', description: result.message });
    }
  };

  const handleOpenReturnDialog = (invoice: Invoice) => {
    setSelectedInvoiceId(invoice.id);
    setInvoiceItems([]);
    setCart([]);
    setReason('');
    setIsReturnDialogOpen(true);
  };

  const handleAddItem = (item: any) => {
    setCart(prev => [
      ...prev,
      {
        id: item.productId,
        productId: item.productId,
        name: item.productName || '—',
        quantity: item.remainingQuantity || 1,
        maxQuantity: item.remainingQuantity || 1,
        price: item.unitPrice,
        originalItemId: item.id
      }
    ]);
  };

  const handleRemoveItem = (originalItemId: string) => {
    setCart(prev => prev.filter(item => item.originalItemId !== originalItemId));
  };

  const handleQuantityChange = (originalItemId: string, value: string) => {
    setCart(prev => prev.map(item => {
      if (item.originalItemId === originalItemId) {
        const numVal = Number(value);
        if (isNaN(numVal) || numVal < 0) return { ...item, quantity: '' };
        return { ...item, quantity: Math.min(item.maxQuantity, numVal) };
      }
      return item;
    }));
  };

  const handleConfirmReturn = async () => {
    const returnItems = cart.map(item => ({
      productId: item.productId,
      quantity: Number(item.quantity) || 0,
      price: item.price
    })).filter(item => item.quantity > 0);

    if (returnItems.length === 0) {
      toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى إدخال كمية صحيحة لأصناف المرتجع.' });
      return;
    }

    if (!reason.trim()) {
      toast({ variant: 'destructive', title: 'خطأ', description: 'سبب الإرجاع مطلوب.' });
      return;
    }

    setIsSubmittingReturn(true);
    const result = await createSalesReturn({
      invoiceId: selectedInvoiceId,
      reason,
      items: returnItems
    });
    setIsSubmittingReturn(false);

    if (result.success) {
      toast({ title: 'نجاح', description: result.message });
      setIsReturnDialogOpen(false);
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }
  };

  React.useEffect(() => {
    if (isReturnDialogOpen && selectedInvoiceId) {
      async function loadInvoiceDetails() {
        setLoadingInvoice(true);
        try {
          const result = await getInvoiceDetailsAction(selectedInvoiceId);
          if (result.success && result.items) {
            setInvoiceItems(result.items);
          } else {
            toast({
              variant: 'destructive',
              title: 'خطأ',
              description: result.message || 'فشل تحميل فاتورة المبيعات.',
            });
          }
        } catch (error) {
          console.error('Failed to load invoice details:', error);
          toast({
            variant: 'destructive',
            title: 'خطأ',
            description: 'فشل تحميل فاتورة المبيعات.',
          });
        }
        setLoadingInvoice(false);
      }
      loadInvoiceDetails();
    }
  }, [isReturnDialogOpen, selectedInvoiceId, toast]);

  React.useEffect(() => {
    if (!isReturnDialogOpen) {
      setSelectedInvoiceId('');
      setInvoiceItems([]);
      setCart([]);
      setReason('');
    }
  }, [isReturnDialogOpen]);

  /* ── status filter tabs ── */
  const filterTabs = [
    { key: 'all',       label: 'الكل',           count: initialInvoices.length },
    { key: 'paid',      label: 'مدفوعة',          count: stats.paid            },
    { key: 'partial',   label: 'جزئية',           count: stats.partial         },
    { key: 'unpaid',    label: 'غير مدفوعة',      count: stats.unpaid          },
    { key: 'proforma',  label: 'مبدئية',          count: initialInvoices.filter(i=>i.status==='proforma').length },
    { key: 'cancelled', label: 'ملغاة',           count: initialInvoices.filter(i=>i.status==='cancelled').length },
  ];

  /* ── compact stat cards ── */
  const statCards = [
    {
      label: 'إجمالي الإيرادات',
      value: formatCurrency(stats.total),
      icon: TrendingUp,
      color: 'text-primary',
      bg: 'bg-primary/8',
      border: 'border-primary/20',
    },
    {
      label: 'إجمالي المرتجعات',
      value: formatCurrency(stats.returned),
      icon: RotateCcw,
      color: 'text-orange-600',
      bg: 'bg-orange-500/8',
      border: 'border-orange-500/20',
    },
    {
      label: 'مدفوعة',
      value: stats.paid,
      icon: Receipt,
      color: 'text-emerald-600',
      bg: 'bg-emerald-500/8',
      border: 'border-emerald-500/20',
    },
    {
      label: 'جزئية',
      value: stats.partial,
      icon: Clock,
      color: 'text-amber-600',
      bg: 'bg-amber-500/8',
      border: 'border-amber-500/20',
    },
    {
      label: 'غير مدفوعة',
      value: stats.unpaid,
      icon: XCircle,
      color: 'text-red-600',
      bg: 'bg-red-500/8',
      border: 'border-red-500/20',
    },
  ];

  return (
    <>
      {/* ── Page Header ── */}
      <PageHeader title={IS_RESTAURANT_APP ? 'الطلبات' : 'المبيعات'}>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
            <Input
              type="search"
              placeholder={IS_RESTAURANT_APP ? 'ابحث عن طلب...' : 'بحث...'}
              className="pr-9 w-[180px] lg:w-[240px] h-9 rounded-xl bg-background border-border/60 text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button asChild size="sm" className="h-9 rounded-xl gap-1.5 px-4 shadow-sm">
            <Link href="/invoices/new">
              <PlusCircle className="h-3.5 w-3.5" />
              {IS_RESTAURANT_APP ? 'طلب جديد' : 'فاتورة جديدة'}
            </Link>
          </Button>
        </div>
      </PageHeader>

      <div className="flex flex-col gap-4 p-4 md:p-6 max-w-screen-xl mx-auto w-full">

        {/* ── Compact Stats Row ── */}
        {initialInvoices.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
            {statCards.map((s) => (
              <div
                key={s.label}
                className={cn(
                  'rounded-xl border px-3 py-2.5 flex items-center gap-2.5 bg-card',
                  s.border
                )}
              >
                <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center shrink-0', s.bg, s.color)}>
                  <s.icon className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] text-muted-foreground font-medium leading-none mb-0.5 truncate">{s.label}</p>
                  <p className="text-sm font-extrabold text-foreground leading-none truncate">{s.value}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── Table card ── */}
        <div className="rounded-2xl border border-border/60 bg-card overflow-hidden shadow-sm">

          {/* Unified filter bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b border-border/50 bg-muted/20">
            <div className="flex items-center gap-1.5 flex-wrap">
              <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
              {filterTabs.map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setStatusFilter(tab.key)}
                  className={cn(
                    'flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition-all duration-150',
                    statusFilter === tab.key
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground hover:bg-background/80'
                  )}
                >
                  {tab.label}
                  {tab.count > 0 && (
                    <span className={cn(
                      'inline-flex items-center justify-center min-w-[16px] h-[16px] rounded-full text-[9px] font-extrabold px-1',
                      statusFilter === tab.key
                        ? 'bg-white/20 text-primary-foreground'
                        : 'bg-muted text-muted-foreground'
                    )}>
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <CalendarDays className="h-3 w-3" />
              </div>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger className="w-[120px] bg-background border-border/60 rounded-lg text-[11px] h-7 font-medium">
                  <SelectValue placeholder="كل التواريخ" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">كل التواريخ</SelectItem>
                  <SelectItem value="today">اليوم</SelectItem>
                  <SelectItem value="week">آخر 7 أيام</SelectItem>
                  <SelectItem value="month">آخر 30 يوم</SelectItem>
                </SelectContent>
              </Select>
              <span className="text-[10px] text-muted-foreground bg-muted px-2 py-0.5 rounded-full font-medium">
                {filtered.length} نتيجة
              </span>
            </div>
          </div>

          {/* Empty state */}
          {initialInvoices.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-primary/8 flex items-center justify-center">
                <FileText className="h-7 w-7 text-primary/50" />
              </div>
              <div>
                <p className="font-bold text-foreground">لا توجد فواتير بعد</p>
                <p className="text-sm text-muted-foreground mt-1">ابدأ بإنشاء أول فاتورة لك</p>
              </div>
              <Button asChild size="sm" className="rounded-xl gap-1.5 mt-1">
                <Link href="/invoices/new">
                  <PlusCircle className="h-3.5 w-3.5" />
                  إنشاء فاتورة جديدة
                </Link>
              </Button>
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center gap-2">
              <Search className="h-8 w-8 text-muted-foreground/30" />
              <p className="font-semibold text-foreground text-sm">لا توجد نتائج</p>
              <p className="text-xs text-muted-foreground">جرّب تغيير مصطلحات البحث أو الفلتر</p>
            </div>
          ) : (
            <>
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/30 hover:bg-muted/30 border-b border-border/50">
                    <TableHead className="font-bold text-[11px] text-muted-foreground py-2.5">
                      {IS_RESTAURANT_APP ? 'رقم الطلب' : 'رقم الفاتورة'}
                    </TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground py-2.5">العميل</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground py-2.5">التاريخ</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground text-center py-2.5">الإجمالي</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground text-center py-2.5">المدفوع</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground text-center py-2.5">المرتجع</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground text-center py-2.5">المتبقي</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground text-center py-2.5">الحالة</TableHead>
                    <TableHead className="font-bold text-[11px] text-muted-foreground py-2.5">الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TooltipProvider>
                    {paginated.map((invoice) => {
                      const cfg = STATUS_CONFIG[invoice.status as keyof typeof STATUS_CONFIG];
                      const isCancelled = invoice.status === 'cancelled';
                      const invoiceReturns = salesReturns.filter(ret => ret.invoiceId === invoice.id);
                      const returnedAmount = invoiceReturns.reduce((sum, ret) => sum + ret.totalAmount, 0);
                      const remainingAmount = isCancelled ? 0 : Math.max(0, invoice.totalAmount - invoice.amountPaid - returnedAmount);
                      return (
                        <TableRow
                          key={invoice.id}
                          className={cn(
                            'transition-colors hover:bg-muted/20 border-b border-border/30',
                            isCancelled && 'opacity-50'
                          )}
                        >
                          {/* Invoice number */}
                          <TableCell className="py-2">
                            <span className="font-mono font-bold text-xs text-primary">
                              {IS_RESTAURANT_APP
                                ? `#${invoice.dailyOrderNumber}`
                                : invoice.invoiceNumber}
                            </span>
                          </TableCell>

                          {/* Customer */}
                          <TableCell className="py-2">
                            <div className="flex items-center gap-1.5">
                              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                                <span className="text-[10px] font-extrabold text-primary">
                                  {invoice.customerName.charAt(0)}
                                </span>
                              </div>
                              <span className="font-medium text-xs text-foreground truncate max-w-[120px]">
                                {invoice.customerName}
                              </span>
                            </div>
                          </TableCell>

                          {/* Date */}
                          <TableCell className="py-2">
                            <div className="flex flex-col">
                              <span className="text-[11px] font-semibold text-foreground">
                                {format(new Date(invoice.issueDate), 'dd/MM/yyyy')}
                              </span>
                              <span className="text-[9px] text-muted-foreground">
                                {format(new Date(invoice.issueDate), 'HH:mm')}
                              </span>
                            </div>
                          </TableCell>

                          {/* Total Amount */}
                          <TableCell className="text-center py-2">
                            <span className="font-extrabold text-xs text-foreground font-sans">
                              {formatCurrency(invoice.totalAmount)}
                            </span>
                          </TableCell>

                          {/* Paid Amount */}
                          <TableCell className="text-center py-2">
                            <span className="font-bold text-xs text-emerald-600 font-sans">
                              {formatCurrency(invoice.amountPaid)}
                            </span>
                          </TableCell>

                          {/* Return Amount */}
                          <TableCell className="text-center py-2">
                            <span className={cn("font-bold text-xs font-sans", returnedAmount > 0 ? "text-amber-600" : "text-muted-foreground/50")}>
                              {formatCurrency(returnedAmount)}
                            </span>
                          </TableCell>

                          {/* Remaining Amount */}
                          <TableCell className="text-center py-2">
                            <span className={cn("font-extrabold text-xs font-sans", remainingAmount > 0 ? "text-red-600" : "text-muted-foreground/50")}>
                              {formatCurrency(remainingAmount)}
                            </span>
                          </TableCell>

                          {/* Status */}
                          <TableCell className="text-center py-2">
                            {isCancelled && invoice.cancellationReason ? (
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-secondary text-muted-foreground border border-border/50">
                                    <span className={cn('w-1.5 h-1.5 rounded-full shrink-0', cfg?.dot)} />
                                    {cfg?.text}
                                  </span>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>سبب الإلغاء: {invoice.cancellationReason}</p>
                                </TooltipContent>
                              </Tooltip>
                            ) : (
                              <Badge
                                variant={cfg?.variant || 'default'}
                                className={cn(
                                  'rounded-full gap-1 px-2 py-0.5 text-[10px] font-bold',
                                  invoice.status === 'proforma' && 'border-dashed'
                                )}
                              >
                                <span className={cn('w-1.5 h-1.5 rounded-full shrink-0', cfg?.dot)} />
                                {cfg?.text || invoice.status}
                              </Badge>
                            )}
                          </TableCell>

                          {/* Actions */}
                          <TableCell className="py-2">
                            <div className="flex items-center gap-0.5">
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-7 w-7 rounded-lg hover:bg-primary/10 hover:text-primary"
                                    onClick={() => router.push(`/invoices/${invoice.id}/print`)}
                                  >
                                    <Printer className="h-3 w-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent><p>طباعة</p></TooltipContent>
                              </Tooltip>

                              {invoice.status === 'proforma' && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-7 w-7 rounded-lg hover:bg-emerald-500/10 hover:text-emerald-600"
                                      onClick={() => handleOpenFinalizeDialog(invoice)}
                                    >
                                      <CheckSquare className="h-3 w-3" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent><p>تحويل إلى فاتورة</p></TooltipContent>
                                </Tooltip>
                              )}

                              {!isCancelled && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-7 w-7 rounded-lg hover:text-amber-600 hover:bg-amber-500/10"
                                      onClick={() => handleOpenReturnDialog(invoice)}
                                    >
                                      <RotateCcw className="h-3 w-3" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent><p>إرجاع أصناف</p></TooltipContent>
                                </Tooltip>
                              )}

                              {!isCancelled && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-7 w-7 rounded-lg hover:text-destructive hover:bg-destructive/10"
                                      onClick={() => handleOpenCancelDialog(invoice)}
                                    >
                                      <Trash2 className="h-3 w-3" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent><p>إلغاء الفاتورة</p></TooltipContent>
                                </Tooltip>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TooltipProvider>
                </TableBody>
              </Table>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between px-4 py-2.5 border-t border-border/50 bg-muted/10">
                  <p className="text-[11px] text-muted-foreground">
                    صفحة {page} من {totalPages} — {filtered.length} فاتورة
                  </p>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 rounded-lg"
                      disabled={page <= 1}
                      onClick={() => setPage(p => p - 1)}
                    >
                      <ChevronRight className="h-3.5 w-3.5" />
                    </Button>
                    {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                      const p = i + 1;
                      return (
                        <button
                          key={p}
                          onClick={() => setPage(p)}
                          className={cn(
                            'h-7 w-7 rounded-lg text-xs font-bold transition-all',
                            page === p
                              ? 'bg-primary text-primary-foreground shadow-sm'
                              : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                          )}
                        >
                          {p}
                        </button>
                      );
                    })}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 rounded-lg"
                      disabled={page >= totalPages}
                      onClick={() => setPage(p => p + 1)}
                    >
                      <ChevronLeft className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* ── Cancellation Dialog ── */}
      <Dialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
        <DialogContent className="rounded-2xl sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <XCircle className="h-5 w-5" />
              إلغاء الفاتورة #{invoiceToCancel?.invoiceNumber}
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground leading-relaxed">
              سيؤدي هذا الإجراء إلى إلغاء الفاتورة نهائياً وعكس جميع العمليات المرتبطة بها.
            </DialogDescription>
          </DialogHeader>
          <div className="py-3 space-y-2">
            <Label htmlFor="cancellationReason" className="text-sm font-semibold">سبب الإلغاء <span className="text-destructive">*</span></Label>
            <Textarea
              id="cancellationReason"
              value={cancellationReason}
              onChange={(e) => setCancellationReason(e.target.value)}
              placeholder="مثال: خطأ في إدخال المنتجات، طلب العميل..."
              className="resize-none rounded-xl"
              rows={3}
            />
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" className="rounded-xl" onClick={() => setIsCancelDialogOpen(false)}>تراجع</Button>
            <Button
              onClick={handleConfirmCancellation}
              variant="destructive"
              className="rounded-xl"
              disabled={!cancellationReason}
            >
              تأكيد الإلغاء
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Finalization Dialog ── */}
      <Dialog open={isFinalizeDialogOpen} onOpenChange={setIsFinalizeDialogOpen}>
        <DialogContent className="rounded-2xl sm:max-w-[460px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-primary">
              <CheckSquare className="h-5 w-5" />
              تحويل الفاتورة المبدئية #{invoiceToFinalize?.invoiceNumber}
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              سيتم تحويل هذه الفاتورة إلى فاتورة فعلية وخصم الكميات من المخزون.
            </DialogDescription>
          </DialogHeader>
          <div className="py-3 space-y-3">
            <div className="rounded-xl bg-muted/30 p-3 flex items-center justify-between">
              <span className="text-sm text-muted-foreground">إجمالي الفاتورة</span>
              <span className="font-extrabold text-primary">{formatCurrency(invoiceToFinalize?.totalAmount || 0)}</span>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="finalizeAmount" className="text-sm font-semibold">المبلغ المدفوع الآن</Label>
              <Input
                id="finalizeAmount"
                type="number"
                value={finalizeAmountPaid}
                onChange={(e) => setFinalizeAmountPaid(e.target.value)}
                placeholder="0"
                className="rounded-xl"
              />
            </div>
            {Number(finalizeAmountPaid) > 0 && (
              <div className="space-y-1.5">
                <Label className="text-sm font-semibold">طريقة الدفع</Label>
                <Select value={finalizePaymentMethodId || ''} onValueChange={setFinalizePaymentMethodId}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="اختر طريقة الدفع" />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentMethods.map(pm => (
                      <SelectItem key={pm.id} value={pm.id}>{pm.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" className="rounded-xl" onClick={() => setIsFinalizeDialogOpen(false)}>تراجع</Button>
            <Button onClick={handleConfirmFinalization} className="rounded-xl" disabled={isFinalizing}>
              {isFinalizing && <LoaderCircle className="h-4 w-4 animate-spin mr-2" />}
              تأكيد التحويل
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Return Dialog ── */}
      <Dialog open={isReturnDialogOpen} onOpenChange={setIsReturnDialogOpen}>
        <DialogContent className="rounded-2xl sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <RotateCcw className="h-5 w-5 text-amber-600" />
              إرجاع أصناف من الفاتورة
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              اختر الأصناف التي تريد إرجاعها وحدد الكميات.
            </DialogDescription>
          </DialogHeader>
          <div className="py-3 space-y-3">
            {loadingInvoice ? (
              <div className="flex items-center justify-center py-8 gap-2 text-muted-foreground">
                <LoaderCircle className="h-5 w-5 animate-spin" />
                <span className="text-sm">جاري التحميل...</span>
              </div>
            ) : invoiceItems.length === 0 ? (
              <p className="text-sm text-center text-muted-foreground py-6">لا توجد أصناف قابلة للإرجاع</p>
            ) : (
              <>
                <div className="rounded-xl border border-border/50 overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/30">
                        <TableHead className="text-xs font-bold">الصنف</TableHead>
                        <TableHead className="text-xs font-bold text-center">متبقي</TableHead>
                        <TableHead className="text-xs font-bold text-center">السعر</TableHead>
                        <TableHead className="text-xs font-bold text-center">إجراء</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {invoiceItems.map(item => {
                        const inCart = cart.find(c => c.originalItemId === item.id);
                        return (
                          <TableRow key={item.id} className="text-xs">
                            <TableCell className="font-medium py-2">{item.productName}</TableCell>
                            <TableCell className="text-center py-2">{item.remainingQuantity}</TableCell>
                            <TableCell className="text-center py-2">{formatCurrency(item.unitPrice)}</TableCell>
                            <TableCell className="text-center py-2">
                              {inCart ? (
                                <Button variant="ghost" size="sm" className="h-6 text-[10px] text-destructive hover:text-destructive px-2" onClick={() => handleRemoveItem(item.id)}>
                                  إزالة
                                </Button>
                              ) : (
                                <Button variant="ghost" size="sm" className="h-6 text-[10px] text-primary hover:text-primary px-2" onClick={() => handleAddItem(item)} disabled={(item.remainingQuantity || 0) <= 0}>
                                  إضافة
                                </Button>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
                {cart.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs font-bold text-foreground">الكميات المرتجعة:</p>
                    {cart.map(item => (
                      <div key={item.originalItemId} className="flex items-center gap-2 rounded-lg bg-muted/30 px-3 py-1.5">
                        <span className="text-xs flex-1 font-medium">{item.name}</span>
                        <Input
                          type="number"
                          value={item.quantity}
                          onChange={e => handleQuantityChange(item.originalItemId, e.target.value)}
                          className="w-16 h-7 text-xs rounded-lg text-center"
                          min={1}
                          max={item.maxQuantity}
                        />
                        <span className="text-[10px] text-muted-foreground">/ {item.maxQuantity}</span>
                      </div>
                    ))}
                  </div>
                )}
                <div className="space-y-1.5">
                  <Label className="text-sm font-semibold">سبب الإرجاع <span className="text-destructive">*</span></Label>
                  <Textarea
                    value={reason}
                    onChange={e => setReason(e.target.value)}
                    placeholder="سبب الإرجاع..."
                    className="resize-none rounded-xl"
                    rows={2}
                  />
                </div>
              </>
            )}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" className="rounded-xl" onClick={() => setIsReturnDialogOpen(false)}>إلغاء</Button>
            <Button
              onClick={handleConfirmReturn}
              className="rounded-xl"
              disabled={isSubmittingReturn || cart.length === 0 || !reason.trim()}
            >
              {isSubmittingReturn && <LoaderCircle className="h-4 w-4 animate-spin mr-2" />}
              تأكيد الإرجاع
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
