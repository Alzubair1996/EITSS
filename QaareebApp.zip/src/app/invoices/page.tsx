import { getInvoices, getPaymentMethods, getSalesReturns } from '@/lib/queries';
import InvoicesClientPage from './invoices-client-page';
import { getSession } from '@/lib/server-auth';

export default async function InvoicesPage() {
  const session = await getSession();
  const isAdmin = session?.username === 'admin';
  const invoices = await getInvoices();
  const paymentMethods = await getPaymentMethods();
  const salesReturns = await getSalesReturns();

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
      <InvoicesClientPage 
        initialInvoices={invoices} 
        paymentMethods={paymentMethods} 
        isAdmin={isAdmin} 
        salesReturns={salesReturns} 
      />
    </div>
  );
}
