
'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance, hardRebuildInvoicesTable } from '@/lib/db';
import type { InvoiceItem, Customer, OrderType, Invoice, InvoiceStatus, PaymentType } from '@/lib/types';
import { IS_RESTAURANT_APP } from '@/lib/types';
import { randomUUID } from 'crypto';
import { getSession } from '@/lib/server-auth';
import { format, startOfDay, endOfDay } from 'date-fns';

interface CreateInvoiceInput {
    customerId: string | null;
    customerName: string;
    customerPhone: string | null;
    issueDate: string;
    subject: string | null;
    orderType?: OrderType | null;
    items: Omit<InvoiceItem, 'id' | 'invoiceId'>[];
    payment: {
        amountPaid: number;
        paymentMethodId: string | null;
        paymentType: PaymentType;
        paymentProof?: string | null;
    },
}

async function generateNextInvoiceNumber(db: any): Promise<string> {
    const now = new Date();
    const year = format(now, 'yy');
    const month = format(now, 'MM');
    const prefix = `INV${year}${month}`;

    const lastInvoice = await db.get(
        "SELECT invoiceNumber FROM invoices WHERE invoiceNumber LIKE ? ORDER BY invoiceNumber DESC LIMIT 1",
        `${prefix}%`
    ) as { invoiceNumber: string } | undefined;

    let sequence = 1;
    if (lastInvoice) {
        const lastSequence = parseInt(lastInvoice.invoiceNumber.slice(prefix.length), 10);
        sequence = lastSequence + 1;
    }

    return `${prefix}${String(sequence).padStart(5, '0')}`;
}

async function generateNextDailyOrderNumber(db: any): Promise<number> {
    const todayStart = startOfDay(new Date()).toISOString();
    const todayEnd = endOfDay(new Date()).toISOString();
    
    const lastOrder = await db.get(
        "SELECT dailyOrderNumber FROM invoices WHERE issueDate >= ? AND issueDate <= ? ORDER BY dailyOrderNumber DESC LIMIT 1",
        [todayStart, todayEnd]
    ) as { dailyOrderNumber: number } | undefined;

    return (lastOrder?.dailyOrderNumber || 0) + 1;
}


export async function createInvoice(data: CreateInvoiceInput) {
    let { customerId, customerName, customerPhone, issueDate, subject, orderType, items, payment } = data;
    const { paymentType, amountPaid, paymentMethodId, paymentProof } = payment;

    if (!customerName || items.length === 0) {
        return { success: false, message: 'اسم العميل وقائمة المنتجات مطلوبان.' };
    }
    
    const db = await getDbInstance();
    // Retrieve the current user performing this action so that any payment records can be attributed.
    const session = await getSession();
    const userId = session?.userId || null;

    const executeCreateInvoice = async () => {
        await db.exec('BEGIN');
        
        const isProforma = paymentType === 'proforma';

        // 1. Get next invoice/order number
        const nextInvoiceNumber = await generateNextInvoiceNumber(db);
        const dailyOrderNumber = IS_RESTAURANT_APP ? await generateNextDailyOrderNumber(db) : null;

        // 2. Calculate total amount
        const totalAmount = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);

        if (paymentType === 'partial' && !customerId) {
            throw new Error('لا يمكن إنشاء فاتورة دين إلا لعميل مسجل في النظام.');
        }

        const safeAmountPaid = isProforma ? 0 : amountPaid;
        const safePaymentMethodId = isProforma ? null : paymentMethodId;

        // 4. Determine invoice status
         const status: InvoiceStatus = isProforma ? 'proforma'
            : (safeAmountPaid > 0
                ? (Math.abs(safeAmountPaid - totalAmount) < 0.001 ? 'paid' : 'partial')
                : 'unpaid');
        
        if (!isProforma && safeAmountPaid > totalAmount) {
            throw new Error('المبلغ المدفوع لا يمكن أن يكون أكبر من الإجمالي.');
        }
        
        if (paymentType === 'full' && Math.abs(safeAmountPaid - totalAmount) >= 0.001) {
            throw new Error('في الدفع الكامل، يجب أن يكون المبلغ المدفوع مساويًا للإجمالي.');
        }
        

        // 5. Insert into invoices table
        const invoiceId = `inv_${randomUUID()}`;
        console.log("[INSERT CHECK]", { status, safeAmountPaid, safePaymentMethodId, totalAmount, isProforma });


        await db.run(`
            INSERT INTO invoices (id, invoiceNumber, dailyOrderNumber, customerId, customerName, customerPhone, subject, orderType, issueDate, totalAmount, amountPaid, status, userId)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, invoiceId, nextInvoiceNumber, dailyOrderNumber, customerId, customerName, customerPhone, subject, orderType, issueDate, totalAmount, safeAmountPaid, status, userId);

        // 6. Insert invoice items
        for (const item of items) {
            await db.run('INSERT INTO invoice_items (id, invoiceId, productId, productName, quantity, unitPrice, warranty) VALUES (?, ?, ?, ?, ?, ?, ?)', `item_${randomUUID()}`, invoiceId, item.productId, item.productName, item.quantity, item.unitPrice, item.warranty);
        }

        // --- All logic below is skipped for Proforma Invoices ---
        if (!isProforma) {
             // Update stock
            for (const item of items) {
                if (IS_RESTAURANT_APP) {
                    const ingredients = await db.all('SELECT * FROM product_ingredients WHERE productId = ?', item.productId);
                    for (const ingredient of ingredients) {
                        const totalRequired = ingredient.quantityRequired * item.quantity;
                        const material = await db.get('SELECT quantityInStock FROM raw_materials WHERE id = ?', ingredient.rawMaterialId) as { quantityInStock: number };
                        if (material.quantityInStock < totalRequired) {
                            const materialDetails = await db.get('SELECT name FROM raw_materials WHERE id = ?', ingredient.rawMaterialId);
                            throw new Error(`كمية غير كافية من المادة الخام: ${materialDetails.name}`);
                        }
                        await db.run('UPDATE raw_materials SET quantityInStock = quantityInStock - ? WHERE id = ?', totalRequired, ingredient.rawMaterialId);
                    }
                } else {
                    const product = await db.get('SELECT quantity FROM products WHERE id = ?', item.productId) as { quantity: number };
                    if (product.quantity < item.quantity) {
                        throw new Error(`كمية غير كافية للمنتج: ${item.productName}`);
                    }
                    await db.run('UPDATE products SET quantity = quantity - ? WHERE id = ?', item.quantity, item.productId);
                }
            }

            // Handle payment
            if (safeAmountPaid > 0 && safePaymentMethodId) {
                const paymentMethod = await db.get('SELECT balance FROM payment_methods WHERE id = ?', safePaymentMethodId);
                if (!paymentMethod) {
                    throw new Error('طريقة الدفع المحددة غير موجودة.');
                }
                // Record the payment with the userId so we know who entered this revenue
                await db.run(
                    'INSERT INTO payments (id, invoiceId, paymentMethodId, amount, paymentDate, paymentProof, userId) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    `paym_${randomUUID()}`,
                    invoiceId,
                    safePaymentMethodId,
                    safeAmountPaid,
                    issueDate,
                    payment.paymentProof || null,
                    userId
                );
                await db.run('UPDATE payment_methods SET balance = balance + ? WHERE id = ?', safeAmountPaid, safePaymentMethodId);
            }
            
            // Update customer balance (debt)
            if (customerId) {
                const debt = totalAmount - safeAmountPaid;
                await db.run('UPDATE customers SET balance = balance - ? WHERE id = ?', debt, customerId);
            }
        }
        // --- End of Proforma skip logic ---

        await db.exec('COMMIT');

        revalidatePath('/invoices');
        if (!isProforma) {
            revalidatePath('/products');
            if (IS_RESTAURANT_APP) {
                revalidatePath('/materials');
            }
            if (customerId) {
                revalidatePath('/customers');
                revalidatePath(`/customers/${customerId}`);
            }
            revalidatePath('/');
        }
        // Return both invoiceId and invoiceNumber so the client can show the new number
        return { success: true, message: 'تم إنشاء الفاتورة بنجاح.', invoiceId, invoiceNumber: nextInvoiceNumber };
    };

    try {
        return await executeCreateInvoice();
    } catch (e: any) {
        await db.exec('ROLLBACK').catch(() => {});
        console.error('Failed to create invoice:', e);
        console.error('Invoice creation payload that caused the error:', JSON.stringify(data, null, 2));
         try {
            const dbPathNow = require('path').resolve((await import('@/lib/db')).getDbPath());
            const rNow = await db.get("SELECT sql FROM sqlite_master WHERE type='table' AND name='invoices'");
            console.error("[HARD PROOF] DB PATH AT ERROR =", dbPathNow);
            console.error("[HARD PROOF] INVOICES DDL AT ERROR =", rNow?.sql || "<missing>");
        } catch (ee) {
            console.error("[HARD PROOF] failed to read DDL in catch", ee);
        }
        return { success: false, message: e.message || 'خطأ في قاعدة البيانات: فشل إنشاء الفاتورة.' };
    }
}


export async function finalizeProformaInvoice(invoiceId: string, amountPaid: number, paymentMethodId: string | null) {
    if (!invoiceId) {
        return { success: false, message: 'معرّف الفاتورة مطلوب.' };
    }
    const db = await getDbInstance();
    try {
        await db.exec('BEGIN');

        const invoice = await db.get('SELECT * FROM invoices WHERE id = ? AND status = ?', invoiceId, 'proforma') as Invoice;
        if (!invoice) {
            throw new Error('الفاتورة المبدئية غير موجودة أو تم تحويلها بالفعل.');
        }

        if (amountPaid > invoice.totalAmount) {
            throw new Error('المبلغ المدفوع لا يمكن أن يكون أكبر من إجمالي الفاتورة.');
        }
        if (amountPaid > 0 && !paymentMethodId) {
            throw new Error('يجب اختيار طريقة الدفع عند وجود مبلغ مدفوع.');
        }

        const items = await db.all('SELECT * FROM invoice_items WHERE invoiceId = ?', invoiceId) as InvoiceItem[];
        const issueDate = new Date().toISOString();

        // 1. Deduct stock
        for (const item of items) {
             if (IS_RESTAURANT_APP) {
                const ingredients = await db.all('SELECT * FROM product_ingredients WHERE productId = ?', item.productId);
                for (const ingredient of ingredients) {
                    const totalRequired = ingredient.quantityRequired * item.quantity;
                    const material = await db.get('SELECT quantityInStock FROM raw_materials WHERE id = ?', ingredient.rawMaterialId) as { quantityInStock: number };
                    if (material.quantityInStock < totalRequired) {
                        const materialDetails = await db.get('SELECT name FROM raw_materials WHERE id = ?', ingredient.rawMaterialId);
                        throw new Error(`كمية غير كافية من المادة الخام: ${materialDetails.name}`);
                    }
                    await db.run('UPDATE raw_materials SET quantityInStock = quantityInStock - ? WHERE id = ?', totalRequired, ingredient.rawMaterialId);
                }
            } else {
                const product = await db.get('SELECT quantity FROM products WHERE id = ?', item.productId) as { quantity: number };
                if (product.quantity < item.quantity) {
                    throw new Error(`كمية غير كافية للمنتج: ${item.productName}`);
                }
                await db.run('UPDATE products SET quantity = quantity - ? WHERE id = ?', item.quantity, item.productId);
            }
        }
        
        // 2. Handle Payment
        if (amountPaid > 0 && paymentMethodId) {
            // Attribute the payment to the current user
            const session = await getSession();
            const userId = session?.userId || null;
            await db.run(
                'INSERT INTO payments (id, invoiceId, paymentMethodId, amount, paymentDate, userId) VALUES (?, ?, ?, ?, ?, ?)',
                `paym_${randomUUID()}`,
                invoiceId,
                paymentMethodId,
                amountPaid,
                issueDate,
                userId
            );
            await db.run('UPDATE payment_methods SET balance = balance + ? WHERE id = ?', amountPaid, paymentMethodId);
        }
        
        // 3. Update customer balance (debt)
        if (invoice.customerId) {
            const debt = invoice.totalAmount - amountPaid;
            await db.run('UPDATE customers SET balance = balance - ? WHERE id = ?', debt, invoice.customerId);
        }

        // 4. Change invoice status and details
        const status: InvoiceStatus = amountPaid > 0
            ? (Math.abs(amountPaid - invoice.totalAmount) < 0.001 ? 'paid' : 'partial')
            : 'unpaid';

        await db.run('UPDATE invoices SET status = ?, issueDate = ?, amountPaid = ? WHERE id = ?', status, issueDate, amountPaid, invoiceId);

        await db.exec('COMMIT');

        revalidatePath('/invoices');
        revalidatePath('/products');
        if (IS_RESTAURANT_APP) revalidatePath('/materials');
        if (invoice.customerId) {
            revalidatePath('/customers');
            revalidatePath(`/customers/${invoice.customerId}`);
        }
        revalidatePath('/');
        
        return { success: true, message: 'تم تحويل الفاتورة المبدئية إلى فاتورة فعلية بنجاح.' };

    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to finalize proforma invoice:', e);
        return { success: false, message: e.message || 'فشل تحويل الفاتورة.' };
    }
}


export async function cancelInvoice(invoiceId: string, reason: string) {
    if (!invoiceId) {
        return { success: false, message: 'معرّف الفاتورة مطلوب.' };
    }
    if (!reason) {
        return { success: false, message: 'سبب الإلغاء مطلوب.' };
    }

    const db = await getDbInstance();
    const executeCancelInvoice = async () => {
        await db.exec('BEGIN');

        const invoice = await db.get('SELECT * FROM invoices WHERE id = ?', invoiceId) as Invoice;
        if (!invoice) throw new Error('الفاتورة غير موجودة.');
        if (invoice.status === 'cancelled') throw new Error('الفاتورة ملغاة بالفعل.');

        // For proforma invoices, we just change the status, no other logic needed.
        if (invoice.status === 'proforma') {
            const now = new Date().toISOString();
            await db.run(
                'UPDATE invoices SET status = ?, cancellationReason = ?, cancellationDate = ? WHERE id = ?',
                'cancelled',
                reason,
                now,
                invoiceId
            );
            await db.exec('COMMIT');
            revalidatePath('/invoices');
            return { success: true, message: 'تم إلغاء الفاتورة المبدئية بنجاح.' };
        }


        const items = await db.all('SELECT * FROM invoice_items WHERE invoiceId = ?', invoiceId) as InvoiceItem[];
        const payments = await db.all('SELECT * FROM payments WHERE invoiceId = ?', invoiceId) as { id: string; paymentMethodId: string; amount: number }[];

        // 1. Restore stock
        for (const item of items) {
            if (IS_RESTAURANT_APP) {
                const ingredients = await db.all('SELECT * FROM product_ingredients WHERE productId = ?', item.productId);
                for (const ingredient of ingredients) {
                    const totalReturned = ingredient.quantityRequired * item.quantity;
                    await db.run('UPDATE raw_materials SET quantityInStock = quantityInStock + ? WHERE id = ?', totalReturned, ingredient.rawMaterialId);
                }
            } else {
                await db.run('UPDATE products SET quantity = quantity + ? WHERE id = ?', item.quantity, item.productId);
            }
        }

        // 2. Revert customer balance
        if (invoice.customerId) {
            const debtCreated = invoice.totalAmount - invoice.amountPaid;
            await db.run('UPDATE customers SET balance = balance + ? WHERE id = ?', debtCreated, invoice.customerId);
        }

        // 3. Create expense records for paid amounts (instead of deleting payments)
        const session = await getSession();
        const userId = session?.userId || null;
        const now = new Date().toISOString();
        
        // First, create expense for each payment to the same payment method
        for (const payment of payments) {
            const expenseId = `exp_${randomUUID()}`;
            await db.run(`
                INSERT INTO expenses (id, description, amount, expenseDate, paymentMethodId, userId)
                VALUES (?, ?, ?, ?, ?, ?)
            `,
            expenseId,
            `إلغاء فاتورة #${invoice.invoiceNumber} - ${reason}`,
            payment.amount,
            now,
            payment.paymentMethodId,
            userId
            );
            
            // Deduct from payment method balance
            await db.run('UPDATE payment_methods SET balance = balance - ? WHERE id = ?', payment.amount, payment.paymentMethodId);
        }
        
        // 4. Keep the payments as revenue records (don't delete them)
        // This way they will show as revenue in reports
        
        // 5. Update invoice status, cancellation reason, and record the cancellation timestamp
        await db.run(
            'UPDATE invoices SET status = ?, cancellationReason = ?, cancellationDate = ? WHERE id = ?',
            'cancelled',
            reason,
            now,
            invoiceId
        );

        await db.exec('COMMIT');

        revalidatePath('/invoices');
        revalidatePath('/products');
        if (IS_RESTAURANT_APP) revalidatePath('/materials');
        if (invoice.customerId) {
            revalidatePath('/customers');
            revalidatePath(`/customers/${invoice.customerId}`);
        }
        revalidatePath('/');
        revalidatePath('/reports');
        revalidatePath('/transactions');
        revalidatePath('/expenses');
        
        return { success: true, message: 'تم إلغاء الفاتورة بنجاح.' };
    };

    try {
        return await executeCancelInvoice();
    } catch (e: any) {
        await db.exec('ROLLBACK').catch(() => {});
        console.error('Failed to cancel invoice:', e);
        return { success: false, message: e.message || 'فشل إلغاء الفاتورة.' };
    }
}
