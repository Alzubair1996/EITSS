
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import {
  type Customer,
  type Product,
  type PaymentMethod,
  type InvoiceItem,
  type Category,
  type Unit,
  type CompanyInfo,
  type OrderType,
  type PaymentType,
} from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { LoaderCircle, Package, PlusCircle, Search, Trash2, UserPlus, Users, Wallet, Landmark, X, CalculatorIcon, HandCoins, Receipt, FileClock, Percent, ChevronRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { createInvoice } from '@/app/invoices/actions';
import { cn } from '@/lib/utils';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import Image from 'next/image';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { CustomerForm, type CustomerFormValues } from '@/app/customers/customer-form';
import { addCustomer } from '@/app/customers/actions';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Calculator } from '@/components/calculator';


interface InvoiceFormProps {
  customers: Customer[];
  products: Product[];
  paymentMethods: PaymentMethod[];
  categories: Category[];
  units: Unit[];
  companyInfo: CompanyInfo;
  currentUSDRate: number;
  pageTitle: string;
}

type CartItem = Omit<InvoiceItem, 'id' | 'invoiceId' | 'quantity' | 'unitPrice'> & { 
  quantity: number | string; 
  unitPrice: number | string; 
  stock: number; 
};

interface CartSession {
  id: number;
  customer: {
    selectedCustomerId: string | null;
    customerName: string;
    customerPhone: string;
    customerSearch: string;
  };
  items: CartItem[];
  payment: {
    paymentType: PaymentType;
    paymentMethodId: string | null;
    amountPaid: number | string;
  };
  orderType: OrderType;
}

const createNewCart = (id: number): CartSession => ({
  id,
  customer: {
    selectedCustomerId: null,
    customerName: '',
    customerPhone: '',
    customerSearch: '',
  },
  items: [],
  payment: {
    paymentType: 'full',
    paymentMethodId: null,
    amountPaid: '',
  },
  orderType: 'dine-in',
});


export default function InvoiceForm({
  customers,
  products,
  paymentMethods,
  categories,
  units,
  companyInfo,
  currentUSDRate,
  pageTitle,
}: InvoiceFormProps) {
  const router = useRouter();
  const { toast } = useToast();
  const searchInputRef = React.useRef<HTMLInputElement>(null);
  const [isLoading, setIsLoading] = React.useState(false);
  const audioRef = React.useRef<HTMLAudioElement | null>(null);

  // State to manage printing preview and saved invoices. When an invoice is created,
  // we store its id and number so we can show a print preview in-page rather than
  // navigating away to a separate route. We also keep a list of saved invoices and
  // their customer names for quick reference (عميل 1، عميل 2، ...).
  const [printInvoiceId, setPrintInvoiceId] = React.useState<string | null>(null);
  const [isPrintOpen, setIsPrintOpen] = React.useState(false);
  const [newInvoiceNumber, setNewInvoiceNumber] = React.useState<string | null>(null);
  const [savedInvoices, setSavedInvoices] = React.useState<{ invoiceNumber: string; customerName: string }[]>([]);

  // Listen for messages from the print preview iframe indicating that printing has completed.
  React.useEffect(() => {
    const handlePrintComplete = (event: MessageEvent) => {
      if (event.data && event.data.type === 'print-complete') {
        setIsPrintOpen(false);
      }
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('message', handlePrintComplete);
    }
    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('message', handlePrintComplete);
      }
    };
  }, []);

  // Dialog states
  const [isCustomerFormOpen, setIsCustomerFormOpen] = React.useState(false);
  const [isCalculatorOpen, setIsCalculatorOpen] = React.useState(false);
  
  // Multi-cart state
  const [carts, setCarts] = React.useState<CartSession[]>([createNewCart(1)]);
  const [activeCartId, setActiveCartId] = React.useState<number>(1);
  const nextCartId = React.useRef(2);

  const activeCartIndex = React.useMemo(() => carts.findIndex(c => c.id === activeCartId), [carts, activeCartId]);
  const activeCart = carts[activeCartIndex];


  // State setters that operate on the active cart
  const updateActiveCart = (updater: (cart: CartSession) => CartSession) => {
    setCarts(prevCarts =>
      prevCarts.map(cart => (cart.id === activeCartId ? updater(cart) : cart))
    );
  };
  

  const [isCustomerPopoverOpen, setIsCustomerPopoverOpen] = React.useState(false);
  const [productSearchTerm, setProductSearchTerm] = React.useState('');
  const [selectedCategoryIdFilter, setSelectedCategoryIdFilter] = React.useState<string | null>(null);

  const canOfferCreditTerms = !!activeCart?.customer.selectedCustomerId;

  React.useEffect(() => {
    // Preload the audio
    if (typeof window !== 'undefined') {
        audioRef.current = new Audio('/beep.mp3');
    }
    searchInputRef.current?.focus();
  }, []);

  React.useEffect(() => {
    if (!activeCart) return;

    if (activeCart.payment.paymentType === 'partial' && !canOfferCreditTerms) {
        updateActiveCart(cart => ({
          ...cart,
          payment: { ...cart.payment, paymentType: 'full' }
        }));
        toast({
            variant: 'destructive',
            title: 'تم تغيير نوع الدفع',
            description: 'الدفع بالدين يتطلب اختيار عميل مسجل.',
        })
    }
  }, [canOfferCreditTerms, activeCart?.payment.paymentType]);
  
  const playBeep = () => {
    if (audioRef.current) {
        audioRef.current.currentTime = 0;
        audioRef.current.play().catch(error => console.error("Error playing sound:", error));
    }
  };

  const totalAmount = React.useMemo(() => {
    if (!activeCart) return 0;
    return activeCart.items.reduce((sum, item) => sum + (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0), 0);
  }, [activeCart]);


  React.useEffect(() => {
    if (!activeCart) return;
    if (activeCart.payment.paymentType === 'full') {
      updateActiveCart(cart => ({ ...cart, payment: { ...cart.payment, amountPaid: totalAmount }}));
    } else if (activeCart.payment.paymentType === 'partial') {
        if (activeCart.payment.amountPaid === totalAmount) {
            updateActiveCart(cart => ({ ...cart, payment: { ...cart.payment, amountPaid: '' }}));
        }
    } else if (activeCart.payment.paymentType === 'proforma') {
        updateActiveCart(cart => ({ ...cart, payment: { ...cart.payment, amountPaid: 0, paymentMethodId: null }}));
    }
  }, [totalAmount, activeCart?.payment.paymentType]);

  const filteredProducts = React.useMemo(() => {
    return products
      .filter(p => !selectedCategoryIdFilter || p.categoryId === selectedCategoryIdFilter)
      .filter(
        (p) =>
          p.name.toLowerCase().includes(productSearchTerm.toLowerCase()) ||
          (p.code && p.code.toLowerCase().includes(productSearchTerm.toLowerCase()))
      );
  }, [products, productSearchTerm, selectedCategoryIdFilter]);

  const filteredCustomers = React.useMemo(() => {
    if (!activeCart?.customer.customerSearch) return customers;
    return customers.filter(
      (c) =>
        c.fullName.toLowerCase().includes(activeCart.customer.customerSearch.toLowerCase()) ||
        (c.phone && c.phone.includes(activeCart.customer.customerSearch))
    );
  }, [customers, activeCart?.customer.customerSearch]);
  
  const selectedPaymentMethod = React.useMemo(() => {
    if (!activeCart) return null;
    return paymentMethods.find(p => p.id === activeCart.payment.paymentMethodId)
  }, [activeCart?.payment.paymentMethodId, paymentMethods]);


  const handleSelectCustomer = (customer: Customer) => {
    updateActiveCart(cart => ({
        ...cart,
        customer: {
            selectedCustomerId: customer.id,
            customerName: customer.fullName,
            customerPhone: customer.phone || '',
            customerSearch: customer.fullName,
        }
    }));
    setIsCustomerPopoverOpen(false);
  };
  
  const handleCustomerInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const value = e.target.value;
      
      const currentlySelectedCustomer = customers.find(c => c.id === activeCart.customer.selectedCustomerId);
      
      updateActiveCart(cart => ({
          ...cart,
          customer: {
              ...cart.customer,
              customerSearch: value,
              customerName: value,
              customerPhone: (currentlySelectedCustomer && value !== currentlySelectedCustomer.fullName) ? '' : cart.customer.customerPhone,
              selectedCustomerId: (currentlySelectedCustomer && value !== currentlySelectedCustomer.fullName) ? null : cart.customer.selectedCustomerId,
          }
      }));
      
      if (!isCustomerPopoverOpen) {
          setIsCustomerPopoverOpen(true);
      }
  };


  const handleAddProduct = (product: Product, quantity = 1, unitPrice?: number) => {
    if (companyInfo.businessType !== 'restaurant' && (product.quantity ?? 0) <= 0) {
        toast({
            variant: 'destructive',
            title: 'نفذ المخزون',
            description: `المنتج "${product.name}" غير متوفر في المخزون.`,
        });
        setProductSearchTerm('');
        return;
    }
    
    playBeep();
    updateActiveCart(cart => {
        const existingItem = cart.items.find((item) => item.productId === product.id);
        let newItems;
        if (existingItem) {
            const newQuantity = (Number(existingItem.quantity) || 0) + quantity;
            if (companyInfo.businessType !== 'restaurant' && newQuantity > (product.quantity ?? 0)) {
                toast({
                    variant: 'destructive',
                    title: 'الكمية غير كافية',
                    description: `الكمية المتاحة من "${product.name}" هي ${product.quantity} فقط.`,
                });
                return cart; // Return original cart without changes
            }
            newItems = cart.items.map((item) =>
            item.productId === product.id
                ? { ...item, quantity: newQuantity }
                : item
            );
        } else {
            if (companyInfo.businessType !== 'restaurant' && quantity > (product.quantity ?? 0)) {
                 toast({
                    variant: 'destructive',
                    title: 'الكمية غير كافية',
                    description: `الكمية المتاحة من "${product.name}" هي ${product.quantity} فقط.`,
                });
                return cart;
            }
            newItems = [
            ...cart.items,
            {
                productId: product.id,
                productName: product.name,
                quantity: quantity,
                unitPrice: unitPrice || (product.price === 0 ? '' : product.price),
                stock: product.quantity,
                warranty: product.warranty
            },
            ];
        }
        return { ...cart, items: newItems };
    });

    setProductSearchTerm('');
    searchInputRef.current?.focus();
  };
  
  const handleProductSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && productSearchTerm) {
        e.preventDefault();
        const term = productSearchTerm.trim();
        let wasHandled = false;

        const checkStockAndAdd = (product: Product, quantity: number, price?: number) => {
            if (companyInfo.businessType !== 'restaurant' && (product.quantity ?? 0) < quantity) {
                toast({
                    variant: 'destructive',
                    title: 'الكمية غير كافية',
                    description: `الكمية المطلوبة للمنتج "${product.name}" غير متوفرة.`,
                });
                return false;
            }
            handleAddProduct(product, quantity, price);
            return true;
        };
        
        if (companyInfo.isWeightBarcodeEnabled && !isNaN(Number(term)) && (term.length === 16)) {
            let pluCode: string;
            let weightKg: number;
            
            pluCode = term.substring(0, 4); // e.g., 9998
            const weightString = term.substring(4, 8); // e.g., 0045
            weightKg = parseInt(weightString, 10) / 100; // e.g., 0.45
            
            const product = products.find(p => p.code === pluCode);
            if (product) {
                // Assuming weight is quantity
                if (checkStockAndAdd(product, weightKg, product.price)) {
                    wasHandled = true;
                }
            }
        }
        
        if (!wasHandled) {
             const product = products.find(p => p.code === term);
             if (product) {
                 if(checkStockAndAdd(product, 1, product.price)) {
                    wasHandled = true;
                 }
             }
        }
        
        if (!wasHandled && filteredProducts.length === 1) {
            if(checkStockAndAdd(filteredProducts[0], 1, filteredProducts[0].price)) {
                wasHandled = true;
            }
        }

        if (wasHandled) {
            setProductSearchTerm('');
        } else if (!wasHandled && term) {
             toast({
                variant: 'destructive',
                title: 'منتج غير موجود',
                description: `لم يتم العثور على منتج بالرمز "${term}" أو أن كميته غير كافية.`,
            });
            setProductSearchTerm('');
        }
    }
  };


  const handleQuantityChange = (productId: string, newQuantity: number | string) => {
    updateActiveCart(cart => ({
        ...cart,
        items: cart.items.map((item) => {
            if (item.productId === productId) {
                let val = newQuantity;
                if (typeof val === 'string') {
                    if (val === '') {
                        return { ...item, quantity: '' };
                    }
                    const num = Number(val);
                    if (!isNaN(num)) {
                        val = Math.max(0, Math.min(num, item.stock || 99999));
                    }
                } else if (typeof val === 'number') {
                    val = Math.max(0, Math.min(val, item.stock || 99999));
                }
                return { ...item, quantity: val };
            }
            return item;
        })
    }));
  };

  const handlePriceChange = (productId: string, newPrice: number | string) => {
    updateActiveCart(cart => ({
        ...cart,
        items: cart.items.map((item) => {
            if (item.productId === productId) {
                let val = newPrice;
                if (typeof val === 'string') {
                    if (val === '') {
                        return { ...item, unitPrice: '' };
                    }
                    const num = Number(val);
                    if (!isNaN(num)) {
                        val = Math.max(0, num);
                    }
                } else if (typeof val === 'number') {
                    val = Math.max(0, val);
                }
                return { ...item, unitPrice: val };
            }
            return item;
        })
    }));
  };

  const handleRemoveItem = (productId: string) => {
    updateActiveCart(cart => ({
        ...cart,
        items: cart.items.filter((item) => item.productId !== productId)
    }));
  };

  const handleAddCustomerSubmit = async (values: CustomerFormValues) => {
    const result = await addCustomer(values as any);
    if (result.success) {
        toast({ title: 'تمت الإضافة بنجاح', description: 'تمت إضافة العميل الجديد.' });
        setIsCustomerFormOpen(false);
        router.refresh(); // This will fetch the new customer list
    } else {
        toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }
  };

  const handleAddNewCart = () => {
    const newId = nextCartId.current;
    setCarts([...carts, createNewCart(newId)]);
    setActiveCartId(newId);
    nextCartId.current++;
    searchInputRef.current?.focus();
  };

  const handleCloseCart = (cartIdToClose: number) => {
    if (carts.length === 1) {
      toast({ variant: 'destructive', title: 'خطأ', description: 'لا يمكن إغلاق العميل الأخير.' });
      return;
    }
    const cartToCloseIndex = carts.findIndex(c => c.id === cartIdToClose);
    const newCarts = carts.filter(c => c.id !== cartIdToClose);
    
    // If we're closing the active cart, switch to another one
    if (activeCartId === cartIdToClose) {
      const newActiveIndex = Math.max(0, cartToCloseIndex - 1);
      setActiveCartId(newCarts[newActiveIndex].id);
    }
    
    setCarts(newCarts);
  };


  const handleSubmit = async () => {
    if (activeCart.items.length === 0) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى إضافة منتجات إلى الفاتورة.' });
        return;
    }

    if (activeCart.payment.paymentType !== 'proforma') {
      if (activeCart.payment.paymentType === 'partial') {
          if (!activeCart.customer.selectedCustomerId) {
              toast({ variant: 'destructive', title: 'خطأ', description: 'الدفع بالدين يتطلب اختيار عميل مسجل.' });
              return;
          }
      }
      
      const numericAmountPaid = Number(activeCart.payment.amountPaid) || 0;
      if (numericAmountPaid > 0 && !activeCart.payment.paymentMethodId) {
          toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى اختيار طريقة الدفع.' });
          return;
      }
    }


    setIsLoading(true);

    const invoicePayload = {
      customerId: activeCart.customer.selectedCustomerId,
      customerName: activeCart.customer.customerName.trim() === '' ? 'عميل' : activeCart.customer.customerName,
      customerPhone: activeCart.customer.customerPhone,
      issueDate: new Date().toISOString(),
      orderType: companyInfo.businessType === 'restaurant' ? activeCart.orderType : null,
      subject: null,
      items: activeCart.items.map(item => ({
        ...item,
        quantity: Number(item.quantity) || 0,
        unitPrice: Number(item.unitPrice) || 0,
      })),
      payment: {
        paymentType: activeCart.payment.paymentType,
        amountPaid: Number(activeCart.payment.amountPaid) || 0,
        paymentMethodId: activeCart.payment.paymentMethodId,
      },
    };
    
    const result = await createInvoice(invoicePayload) as any;

    setIsLoading(false);

    if (result.success && result.invoiceId) {
      // Display success toast including the invoice number when available
      toast({
        title: 'تم بنجاح',
        description: `تم إنشاء ${activeCart.payment.paymentType === 'proforma' ? 'الفاتورة المبدئية' : 'الفاتورة'} بنجاح برقم ${result.invoiceNumber ?? ''}.`,
      });
      // Save the newly created invoice details in local state so we can display
      // a list of saved invoices and their customers.
      if (result.invoiceNumber) {
        setSavedInvoices(prev => [...prev, { invoiceNumber: result.invoiceNumber as string, customerName: invoicePayload.customerName }]);
      }
      // Set the print preview state so that a dialog appears with the print page if auto print is enabled
      setPrintInvoiceId(result.invoiceId);
      setNewInvoiceNumber(result.invoiceNumber ?? null);
      if (companyInfo.autoPrintInvoice) {
        setIsPrintOpen(true);
      }

      // Close the current cart and switch to another, or create a new one if it was the last one
      const cartToCloseId = activeCartId;
      const remainingCarts = carts.filter(c => c.id !== cartToCloseId);
      if (remainingCarts.length > 0) {
        handleCloseCart(cartToCloseId);
      } else {
        // This was the last cart, so just reset it
        setCarts([createNewCart(1)]);
        setActiveCartId(1);
        nextCartId.current = 2;
      }

      // Do not navigate to a new page for printing; instead, open the print preview in a dialog

    } else {
      toast({ variant: 'destructive', title: 'فشل الإنشاء', description: result.message });
    }
  };

  const formatCurrency = (num: number) => {
    return Math.round(num).toLocaleString('en-US');
  };

  if (!activeCart) {
    return <div className="flex items-center justify-center h-full"><LoaderCircle className="animate-spin" /></div>;
  }

  return (
    <div className="flex h-full flex-col min-h-0 bg-muted/30" dir="rtl">
       <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-2 gap-0">
        
        {/* Right Column: Product Selection */}
        <div className="h-full flex flex-col min-h-0 border-l border-border/40">

            {/* Header */}
            <div className="shrink-0 bg-card border-b border-border/40 px-5 py-4 shadow-sm">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/20 flex items-center justify-center">
                    <Package className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-base font-black text-foreground">{pageTitle}</h2>
                    <p className="text-xs text-muted-foreground font-medium mt-0.5">{filteredProducts.length} منتج متاح</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="relative w-56">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                    <input
                      ref={searchInputRef}
                      placeholder="ابحث بالاسم أو الكود..."
                      value={productSearchTerm}
                      onChange={(e) => setProductSearchTerm(e.target.value)}
                      onKeyDown={handleProductSearchKeyDown}
                      className="w-full pr-10 pl-4 h-10 rounded-xl border border-border/60 bg-muted/40 text-sm text-right placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/25 focus:border-primary/50 focus:bg-background transition-all"
                    />
                  </div>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button type="button" variant="outline" size="icon" className="h-10 w-10 rounded-xl border-border/60" asChild>
                          <Link href="/products/new"><PlusCircle className="h-4 w-4" /></Link>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent><p>إضافة منتج جديد</p></TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>
            </div>

            {/* Category Pills */}
            <div className="shrink-0 bg-muted/20 border-b border-border/30 px-4 py-2.5">
              <ScrollArea className="w-full whitespace-nowrap" dir="ltr">
                <div className="flex flex-row-reverse gap-1.5">
                  <button
                    onClick={() => setSelectedCategoryIdFilter(null)}
                    className={cn(
                      'px-4 py-1.5 text-[11px] font-extrabold rounded-full border transition-all duration-150',
                      !selectedCategoryIdFilter
                        ? 'bg-primary text-primary-foreground border-primary shadow-sm shadow-primary/20'
                        : 'bg-background border-border/50 text-muted-foreground hover:border-primary/40 hover:text-primary'
                    )}
                  >الكل</button>
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategoryIdFilter(cat.id)}
                      className={cn(
                        'px-4 py-1.5 text-[11px] font-extrabold rounded-full border transition-all duration-150',
                        selectedCategoryIdFilter === cat.id
                          ? 'bg-primary text-primary-foreground border-primary shadow-sm shadow-primary/20'
                          : 'bg-background border-border/50 text-muted-foreground hover:border-primary/40 hover:text-primary'
                      )}
                    >{cat.name}</button>
                  ))}
                </div>
                <ScrollBar orientation="horizontal" />
              </ScrollArea>
            </div>

            {/* Products Grid */}
            <div className="flex-1 min-h-0 overflow-y-auto p-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                {filteredProducts.length > 0 ? filteredProducts.map((p) => {
                  const outOfStock = companyInfo.businessType !== 'restaurant' && (p.quantity ?? 0) <= 0;
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => handleAddProduct(p, 1, p.price)}
                      disabled={outOfStock}
                      className={cn(
                        'group relative flex flex-col items-center text-center rounded-2xl p-3.5 border transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary/30 overflow-hidden',
                        outOfStock
                          ? 'opacity-40 cursor-not-allowed border-border/40 bg-muted/20'
                          : 'border-border/50 bg-card hover:border-primary/50 hover:shadow-xl hover:shadow-primary/8 hover:-translate-y-0.5 active:translate-y-0 active:scale-[.98]'
                      )}
                    >
                      <div className="absolute inset-0 bg-gradient-to-b from-primary/0 to-primary/0 group-hover:from-primary/4 group-hover:to-transparent transition-all duration-300 rounded-2xl pointer-events-none" />
                      <div className="relative w-full aspect-square bg-gradient-to-br from-muted/70 to-muted/30 group-hover:from-primary/10 group-hover:to-muted/30 rounded-xl mb-3 overflow-hidden flex items-center justify-center transition-all duration-200">
                        {p.image ? (
                          <Image src={p.image} alt={p.name} fill className="object-cover transition-transform duration-200 group-hover:scale-105" />
                        ) : (
                          <Package className="h-9 w-9 text-muted-foreground/25 group-hover:text-primary/30 transition-colors" />
                        )}
                        {p.quantity > 0 && companyInfo.businessType !== 'restaurant' && (
                          <div className="absolute top-1.5 right-1.5 bg-emerald-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full shadow-sm">{p.quantity}</div>
                        )}
                        {outOfStock && (
                          <div className="absolute inset-0 bg-background/70 flex items-center justify-center">
                            <Badge variant="destructive" className="text-[10px] font-black">نفذ</Badge>
                          </div>
                        )}
                      </div>
                      <p className="text-[11px] font-bold leading-snug line-clamp-2 text-foreground group-hover:text-primary transition-colors min-h-[2.5rem] flex items-center justify-center w-full">{p.name}</p>
                      <p className="text-xs font-extrabold text-primary mt-1.5 tabular-nums">{formatCurrency(p.price)} <span className="font-medium text-muted-foreground text-[10px]">SDG</span></p>
                    </button>
                  );
                }) : (
                  <div className="col-span-full flex flex-col items-center justify-center py-16 text-center gap-4">
                    <div className="w-16 h-16 rounded-2xl bg-muted/50 flex items-center justify-center">
                      <Package className="h-8 w-8 text-muted-foreground/25" />
                    </div>
                    <div>
                      <p className="font-bold text-foreground text-sm">لا توجد منتجات مطابقة</p>
                      <p className="text-xs text-muted-foreground mt-1">جرّب تغيير مصطلح البحث</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
        </div>

        {/* Left Column: Cart and Payment */}
        <div className="h-full flex flex-col min-h-0 bg-card border-r border-border/40 shadow-2xl shadow-black/5">

            {/* Cart tabs + header */}
            <div className="shrink-0 border-b border-border/40 bg-gradient-to-br from-primary/8 via-primary/4 to-transparent">
              {/* Cart tabs */}
              <div className="flex items-center gap-1 px-2 pt-1">
                <ScrollArea className="flex-grow whitespace-nowrap">
                  <div className="flex">
                    {carts.map((cart, index) => (
                      <button
                        key={cart.id}
                        onClick={() => setActiveCartId(cart.id)}
                        className={cn(
                          'px-3 py-2 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-all duration-150',
                          activeCartId === cart.id
                            ? 'border-primary text-primary bg-primary/5'
                            : 'border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/40'
                        )}
                      >
                        <span>عميل {index + 1}</span>
                        {carts.length > 1 && (
                          <X className="h-3 w-3 rounded hover:bg-muted" onClick={(e) => { e.stopPropagation(); handleCloseCart(cart.id); }} />
                        )}
                      </button>
                    ))}
                  </div>
                  <ScrollBar orientation="horizontal" />
                </ScrollArea>
                <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0 hover:text-primary rounded-xl" onClick={handleAddNewCart}>
                  <PlusCircle className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>

            {/* Customer + payment options */}
            <div className="shrink-0 px-4 py-3 space-y-3 border-b border-border/30 bg-card/80">
                    <div className="flex items-center gap-3">
                        <Label htmlFor="customerName" className="whitespace-nowrap text-xs font-bold text-muted-foreground">العميل</Label>
                        <div className="flex-grow">
                            <Popover open={isCustomerPopoverOpen} onOpenChange={setIsCustomerPopoverOpen}>
                                <PopoverTrigger asChild>
                                    <div className="relative">
                                        <Users className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                        <Input
                                            id="customerName"
                                            placeholder="ابحث عن عميل..."
                                            value={activeCart.customer.customerSearch}
                                            onChange={handleCustomerInputChange}
                                            onClick={() => setIsCustomerPopoverOpen(true)}
                                            className="pr-10 text-right"
                                            autoComplete="off"
                                        />
                                    </div>
                                </PopoverTrigger>
                                <PopoverContent onOpenAutoFocus={(e) => e.preventDefault()} className="w-[--radix-popover-trigger-width] p-0">
                                    <ScrollArea className="h-[200px]">
                                        {filteredCustomers.length > 0 ? filteredCustomers.map((c) => (
                                            <Button key={c.id} variant="ghost" className="w-full justify-start h-11" onClick={() => handleSelectCustomer(c)}>
                                                {c.fullName} - {c.phone}
                                            </Button>
                                        )) : (
                                        <div className="p-4 text-center text-sm text-muted-foreground">
                                                <UserPlus className="mx-auto h-6 w-6" />
                                                <p>لا يوجد عميل مطابق. استمر في الكتابة لعميل جديد.</p>
                                            </div>
                                        )}
                                    </ScrollArea>
                                </PopoverContent>
                            </Popover>
                        </div>
                        <TooltipProvider>
                            <div className="flex items-center gap-1.5">
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <Button type="button" variant="outline" size="icon" className="h-11 w-11 shrink-0" onClick={() => setIsCalculatorOpen(true)}>
                                            <CalculatorIcon className="h-5 w-5" />
                                            <span className="sr-only">آلة حاسبة</span>
                                        </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        <p>آلة حاسبة</p>
                                    </TooltipContent>
                                </Tooltip>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <Button type="button" variant="outline" size="icon" className="h-11 w-11 shrink-0" onClick={() => setIsCustomerFormOpen(true)}>
                                            <PlusCircle className="h-5 w-5" />
                                            <span className="sr-only">إضافة عميل</span>
                                        </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        <p>إضافة عميل جديد</p>
                                    </TooltipContent>
                                </Tooltip>
                            </div>
                        </TooltipProvider>
                    </div>
                    {companyInfo.businessType === 'restaurant' ? (
                        <div className="space-y-4">
                             <div className="flex items-center gap-4">
                                <Label className="whitespace-nowrap">نوع الطلب</Label>
                                <RadioGroup value={activeCart.orderType} onValueChange={(v: any) => updateActiveCart(c => ({...c, orderType: v}))} className="grid grid-cols-2 gap-2 flex-grow">
                                    <div>
                                        <RadioGroupItem value="dine-in" id="dine-in" className="peer sr-only" />
                                        <Label htmlFor="dine-in" className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-3 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                            محلي
                                        </Label>
                                    </div>
                                    <div>
                                        <RadioGroupItem value="takeaway" id="takeaway" className="peer sr-only" />
                                        <Label htmlFor="takeaway" className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-3 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                            سفري
                                        </Label>
                                    </div>
                                </RadioGroup>
                            </div>
                             <div className="flex items-center gap-4">
                                <Label className="whitespace-nowrap">طريقة الدفع</Label>
                                {paymentMethods.length > 0 ? (
                                    <RadioGroup 
                                        onValueChange={(v) => updateActiveCart(c => ({...c, payment: {...c.payment, paymentMethodId: v}}))}
                                        value={activeCart.payment.paymentMethodId || undefined} 
                                        className="grid grid-cols-2 gap-4 flex-grow"
                                    >
                                    {paymentMethods.map(p => (
                                            <div key={p.id}>
                                                <RadioGroupItem value={p.id} id={`restaurant-pm-${p.id}-${activeCart.id}`} className="peer sr-only" />
                                                <Label htmlFor={`restaurant-pm-${p.id}-${activeCart.id}`} className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-2 text-center hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                                    <span className="font-semibold">{p.name}</span>
                                                </Label>
                                            </div>
                                    ))}
                                    </RadioGroup>
                                ) : (
                                    <Alert className="flex-grow">
                                        <AlertTitle>لا توجد طرق دفع</AlertTitle>
                                        <AlertDescription>
                                            يرجى إضافة طريقة دفع أولاً من صفحة <Button variant="link" className="p-0 h-auto" asChild><Link href="/payment-methods">طرق الدفع</Link></Button> للمتابعة.
                                        </AlertDescription>
                                    </Alert>
                                )}
                            </div>
                        </div>
                    ) : (
                        <div className='space-y-4'>
                             <div className="flex items-center gap-4">
                                <Label className="whitespace-nowrap">نوع الدفع</Label>
                                <TooltipProvider>
                                    <RadioGroup value={activeCart.payment.paymentType} onValueChange={(v: any) => updateActiveCart(c => ({...c, payment: {...c.payment, paymentType: v}}))} className="grid grid-cols-3 gap-2 flex-grow">
                                        <div>
                                            <RadioGroupItem value="full" id={`full-${activeCart.id}`} className="peer sr-only" />
                                            <Label htmlFor={`full-${activeCart.id}`} className="flex items-center justify-center rounded-xl border-2 border-border bg-background p-2 text-sm font-semibold cursor-pointer hover:border-primary/50 hover:bg-primary/5 hover:text-primary peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 peer-data-[state=checked]:text-primary [&:has([data-state=checked])]:border-primary transition-all">
                                                دفع كامل
                                            </Label>
                                        </div>
                                        <Tooltip>
                                            <TooltipTrigger asChild>
                                                <div className={cn(!canOfferCreditTerms && "cursor-not-allowed")}>
                                                    <RadioGroupItem value="partial" id={`partial-${activeCart.id}`} className="peer sr-only" disabled={!canOfferCreditTerms}/>
                                                    <Label htmlFor={`partial-${activeCart.id}`} className={cn("flex items-center justify-center rounded-xl border-2 border-border bg-background p-2 text-sm font-semibold transition-all", canOfferCreditTerms ? "cursor-pointer hover:border-amber-500/50 hover:bg-amber-500/5 hover:text-amber-600 peer-data-[state=checked]:border-amber-500 peer-data-[state=checked]:bg-amber-500/10 peer-data-[state=checked]:text-amber-700 [&:has([data-state=checked])]:border-amber-500" : "opacity-40 cursor-not-allowed")}>
                                                        دين
                                                    </Label>
                                                </div>
                                            </TooltipTrigger>
                                            {!canOfferCreditTerms && (
                                                <TooltipContent><p>الدفع بالدين يتطلب اختيار عميل مسجل.</p></TooltipContent>
                                            )}
                                        </Tooltip>
                                        <div>
                                            <RadioGroupItem value="proforma" id={`proforma-${activeCart.id}`} className="peer sr-only" />
                                            <Label htmlFor={`proforma-${activeCart.id}`} className="flex items-center justify-center rounded-xl border-2 border-border bg-background p-2 text-sm font-semibold cursor-pointer hover:border-primary/50 hover:bg-primary/5 hover:text-primary peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 peer-data-[state=checked]:text-primary [&:has([data-state=checked])]:border-primary transition-all">
                                                مبدئية
                                            </Label>
                                        </div>
                                    </RadioGroup>
                                </TooltipProvider>
                            </div>
                            
                            {activeCart.payment.paymentType !== 'proforma' && (
                             <div className="flex items-center gap-4">
                                <Label className="whitespace-nowrap">طريقة الدفع</Label>
                                {paymentMethods.length > 0 ? (
                                    // Use a key tied to the activeCart.id to force remounting the RadioGroup when switching carts.
                                    <RadioGroup
                                        key={`payment-method-${activeCart.id}`}
                                        onValueChange={(v) =>
                                            updateActiveCart((c) => ({
                                                ...c,
                                                payment: {
                                                    ...c.payment,
                                                    // When no option is selected, set paymentMethodId to null
                                                    paymentMethodId: v || null,
                                                },
                                            }))
                                        }
                                        value={activeCart.payment.paymentMethodId ?? ''}
                                        className={cn(
                                            'grid grid-cols-2 gap-4 flex-grow',
                                            (Number(activeCart.payment.amountPaid) || 0) <= 0 && 'opacity-50 pointer-events-none'
                                        )}
                                    >
                                        {paymentMethods.map((p) => (
                                            <div key={p.id}>
                                                <RadioGroupItem
                                                    value={p.id}
                                                    id={`${p.id}-${activeCart.id}`}
                                                    className="peer sr-only"
                                                />
                                                <Label
                                                    htmlFor={`${p.id}-${activeCart.id}`}
                                                    className="flex items-center justify-center rounded-xl border-2 border-border bg-background p-2 text-center cursor-pointer hover:border-primary/50 hover:bg-primary/5 hover:text-primary peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 peer-data-[state=checked]:text-primary [&:has([data-state=checked])]:border-primary transition-all"
                                                >
                                                    <span className="text-sm font-bold">{p.name}</span>
                                                </Label>
                                            </div>
                                        ))}
                                    </RadioGroup>
                                ) : (
                                    <Alert className="flex-grow">
                                        <AlertTitle>لا توجد طرق دفع</AlertTitle>
                                        <AlertDescription>
                                            يرجى إضافة طريقة دفع أولاً من صفحة <Button variant="link" className="p-0 h-auto" asChild><Link href="/payment-methods">طرق الدفع</Link></Button> للمتابعة.
                                        </AlertDescription>
                                    </Alert>
                                )}
                            </div>
                            )}
                        </div>
                    )}
            </div>

            {/* Cart table — scrollable */}
            <div className="flex-1 min-h-0 overflow-y-auto">
                {activeCart.items.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full py-16 gap-4 text-center">
                    <div className="w-16 h-16 rounded-3xl bg-muted/40 flex items-center justify-center">
                      <Package className="h-8 w-8 text-muted-foreground/20" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-muted-foreground">السلة فارغة</p>
                      <p className="text-xs text-muted-foreground/60 mt-1">اختر منتجات من اليسار</p>
                    </div>
                  </div>
                ) : (
                  <table className="w-full border-collapse">
                    <thead className="sticky top-0 z-10 bg-muted/60 backdrop-blur-sm">
                      <tr className="border-b border-border/50">
                        <th className="text-right text-[10px] font-extrabold text-muted-foreground py-2.5 px-3 uppercase tracking-widest">المنتج</th>
                        <th className="text-center text-[10px] font-extrabold text-muted-foreground py-2.5 px-1 uppercase tracking-widest w-20">كمية</th>
                        <th className="text-center text-[10px] font-extrabold text-muted-foreground py-2.5 px-1 uppercase tracking-widest w-24">السعر</th>
                        <th className="text-left text-[10px] font-extrabold text-primary/70 py-2.5 px-3 uppercase tracking-widest w-20">الإجمالي</th>
                        <th className="w-8 px-1"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {activeCart.items.map((item, idx) => (
                        <tr
                          key={item.productId}
                          className={cn(
                            'group border-b border-border/20 transition-colors hover:bg-primary/3',
                            idx % 2 === 0 ? 'bg-background' : 'bg-muted/10'
                          )}
                        >
                          <td className="py-2 px-3">
                            <div className="flex items-center gap-2">
                              <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-primary/15 to-primary/5 border border-primary/10 flex items-center justify-center shrink-0">
                                <Package className="h-3.5 w-3.5 text-primary/60" />
                              </div>
                              <p className="text-[11px] font-semibold text-foreground line-clamp-2 leading-tight">{item.productName}</p>
                            </div>
                          </td>
                          <td className="py-2 px-1 text-center">
                            <input
                              type="number"
                              value={item.quantity}
                              onChange={(e) => handleQuantityChange(item.productId, e.target.value)}
                              className="w-16 h-7 text-center text-xs font-bold rounded-lg border border-border/40 bg-background/80 focus:outline-none focus:ring-1 focus:ring-primary/30 focus:border-primary/40 transition-all"
                              min="0"
                              max={item.stock}
                            />
                          </td>
                          <td className="py-2 px-1 text-center">
                            <input
                              type="number"
                              value={item.unitPrice}
                              onChange={(e) => handlePriceChange(item.productId, e.target.value)}
                              className="w-20 h-7 text-center text-xs font-bold rounded-lg border border-border/40 bg-background/80 font-mono focus:outline-none focus:ring-1 focus:ring-primary/30 focus:border-primary/40 transition-all"
                              step="0.01"
                              min="0"
                            />
                          </td>
                          <td className="py-2 px-3 text-left">
                            <span className="text-xs font-extrabold text-primary font-mono tabular-nums">
                              {formatCurrency((Number(item.quantity) || 0) * (Number(item.unitPrice) || 0))}
                            </span>
                          </td>
                          <td className="py-2 pr-1">
                            <button
                              onClick={() => handleRemoveItem(item.productId)}
                              className="w-6 h-6 rounded-lg flex items-center justify-center text-muted-foreground/30 hover:text-destructive hover:bg-destructive/10 transition-all opacity-60 group-hover:opacity-100"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
                </div>

            {/* Summary + Save footer */}
            <div className="shrink-0 border-t border-border/40 bg-card px-4 py-3 space-y-3">
              {/* Summary strip */}
              <div className="rounded-2xl border border-border/50 overflow-hidden shadow-sm">
                {activeCart.payment.paymentType === 'partial' && activeCart.items.length > 0 ? (
                  <div className="grid grid-cols-3 divide-x divide-x-reverse divide-border/40">
                    <div className="px-3 py-2.5 text-center bg-muted/20">
                      <p className="text-[9px] font-extrabold text-muted-foreground uppercase tracking-widest mb-1">الإجمالي</p>
                      <p className="text-base font-black text-foreground font-mono leading-none tabular-nums">{formatCurrency(totalAmount)}</p>
                      <p className="text-[9px] text-muted-foreground/60 mt-0.5 font-medium">SDG</p>
                    </div>
                    <div className="px-3 py-2.5 text-center bg-emerald-500/5">
                      <p className="text-[9px] font-extrabold text-emerald-600 uppercase tracking-widest mb-1">مدفوع</p>
                      <input
                        type="number"
                        placeholder="0"
                        className="w-full h-8 text-center text-sm font-black font-mono rounded-lg border border-border/40 bg-background/80 text-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-400/40 transition-all"
                        value={activeCart.payment.amountPaid}
                        onChange={(e) => updateActiveCart(c => ({...c, payment: {...c.payment, amountPaid: e.target.value}}))}
                      />
                    </div>
                    <div className="px-3 py-2.5 text-center bg-red-500/5">
                      <p className="text-[9px] font-extrabold text-red-500 uppercase tracking-widest mb-1">متبقي</p>
                      <p className="text-base font-black text-red-500 font-mono leading-none tabular-nums">{formatCurrency(Math.max(0, totalAmount - (Number(activeCart.payment.amountPaid) || 0)))}</p>
                      <p className="text-[9px] text-red-400/60 mt-0.5 font-medium">SDG</p>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between px-4 py-3 bg-primary/5">
                    <p className="text-[11px] font-extrabold text-muted-foreground uppercase tracking-widest">الإجمالي الكلي</p>
                    <p className="text-xl font-black text-foreground font-mono tabular-nums">{formatCurrency(totalAmount)} <span className="text-xs font-semibold text-muted-foreground">SDG</span></p>
                  </div>
                )}
              </div>

              <Button
                className="w-full h-12 text-sm font-black rounded-2xl bg-gradient-to-r from-primary via-primary to-primary/80 hover:opacity-90 shadow-lg shadow-primary/25 hover:shadow-primary/35 active:scale-[.98] transition-all gap-2"
                onClick={handleSubmit}
                disabled={isLoading || activeCart.items.length === 0}
              >
                {isLoading ? (
                  <><LoaderCircle className="h-4 w-4 animate-spin" />جاري الحفظ...</>
                ) : (
                  <><ChevronRight className="h-4 w-4" />{activeCart.payment.paymentType === 'proforma' ? 'حفظ الفاتورة المبدئية' : 'حفظ وطباعة الفاتورة'}</>
                )}
              </Button>
            </div>
        </div>
      </div>

      <Dialog open={isCustomerFormOpen} onOpenChange={setIsCustomerFormOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <CustomerForm
            customer={null}
            onSubmit={handleAddCustomerSubmit}
            onCancel={() => setIsCustomerFormOpen(false)}
          />
        </DialogContent>
      </Dialog>
      <Dialog open={isCalculatorOpen} onOpenChange={setIsCalculatorOpen}>
        <DialogContent className="sm:max-w-[350px]">
          <Calculator />
        </DialogContent>
      </Dialog>

      {/* Print preview dialog: opens after an invoice is created. Shows the print page in an iframe */}
      <Dialog open={isPrintOpen} onOpenChange={setIsPrintOpen}>
        <DialogContent className="sm:max-w-[900px]">
          {printInvoiceId && (
            <iframe
              src={`/invoices/${printInvoiceId}/print`}
              className="w-full h-[80vh]"
              // Allow printing within the iframe
              style={{ border: 'none' }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* List of saved invoices within the current session. Helps keep track of newly created invoices and their customers. */}
      {savedInvoices.length > 0 && (
        <div className="mt-4 rounded-xl border border-border/60 bg-card p-4 shadow-sm">
          <h3 className="text-sm font-bold mb-3 text-foreground flex items-center gap-2">
            <Receipt className="h-4 w-4 text-primary" />
            الفواتير المحفوظة في هذه الجلسة
          </h3>
          <ul className="space-y-1.5">
            {savedInvoices.map((inv, index) => (
              <li key={index} className="flex justify-between items-center px-3 py-2 rounded-lg bg-secondary/50 text-sm">
                <span className="font-medium text-foreground">{inv.customerName || `عميل ${index + 1}`}</span>
                <span className="font-bold text-primary text-xs bg-primary/10 px-2 py-1 rounded-full">{inv.invoiceNumber}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
