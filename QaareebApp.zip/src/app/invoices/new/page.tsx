
import { getCustomers, getProducts, getPaymentMethods, getNextInvoiceNumber, getCategories, getUnits, getCompanyInfo, getNextDailyOrderNumber, getCurrentUSDRate } from '@/lib/queries';
import InvoiceForm from './invoice-form';
import { IS_RESTAURANT_APP } from '@/lib/types';

export default async function NewInvoicePage() {
  const customers = await getCustomers();
  const products = await getProducts();
  const paymentMethods = await getPaymentMethods();
  const categories = await getCategories();
  const units = await getUnits();
  const companyInfo = await getCompanyInfo();
  const currentUSDRate = await getCurrentUSDRate();

  let pageTitle: string;
  if (IS_RESTAURANT_APP) {
    const nextOrderNumber = await getNextDailyOrderNumber();
    pageTitle = `طلب جديد #${nextOrderNumber}`;
  } else {
    const nextInvoiceNumber = await getNextInvoiceNumber();
    pageTitle = `فاتورة جديدة #${nextInvoiceNumber}`;
  }

  const availableProducts = products;

  return (
      <InvoiceForm
          customers={customers}
          products={availableProducts}
          paymentMethods={paymentMethods}
          categories={categories}
          units={units}
          companyInfo={companyInfo}
          currentUSDRate={currentUSDRate}
          pageTitle={pageTitle}
      />
  );
}
