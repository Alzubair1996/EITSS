import React from 'react';

// This layout ensures the print page has a clean, empty body tag
// without inheriting styles from the main RootLayout.
export default function PrintLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <>
      {children}
    </>
  )
}
