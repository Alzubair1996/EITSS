import { getInvoiceDetails, getCompanyInfo, getInvoiceTemplate, getPrintType } from '@/lib/queries';
import { notFound } from 'next/navigation';
import PrintClientPage from './print-client-page';
import { format } from 'date-fns';
import Mustache from 'mustache';
import { IS_RESTAURANT_APP } from '@/lib/types';
import { cn } from '@/lib/utils';
import { getDbInstance } from '@/lib/db';

export default async function InvoicePrintPage({ params }: { params: { id: string } }) {
  const invoice = await getInvoiceDetails(params.id);
  const companyInfo = await getCompanyInfo();
  let templateHtml = await getInvoiceTemplate();
  const printType = await getPrintType();

  if (!invoice) {
    notFound();
  }

  const invoiceNumberDisplay = IS_RESTAURANT_APP 
    ? `طلب رقم: ${invoice.dailyOrderNumber}` 
    : `رقم الفاتورة: ${invoice.invoiceNumber}`;
  const invoiceTitle = IS_RESTAURANT_APP ? 'طلب مبيعات' : 'فاتورة مبيعات';
  const orderTypeDisplay = invoice.orderType === 'dine-in' ? 'محلي' : invoice.orderType === 'takeaway' ? 'سفري' : null;

  const modernTemplate = `
    <div id="invoice-print" class="font-body print-container-a4 bg-white w-full mx-auto flex flex-col" style="font-family: 'Cairo', 'Segoe UI', sans-serif; direction: rtl; min-height: 297mm; box-sizing: border-box;">
      <!-- Top blue/indigo gradient accent line -->
      <div style="height: 6px; background: linear-gradient(to left, #1e3a5f, #3b82f6, #1d4ed8);"></div>

      <!-- Main Header Container -->
      <div style="padding: 30px 40px 20px; display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid #f1f5f9;">
        <!-- Right side: Company Logo & Info -->
        <div style="text-align: right; display: flex; align-items: center; gap: 16px;">
          {{#companyLogo}}
            <img src="{{companyLogo}}" alt="Logo" style="width: 80px; height: 80px; object-fit: contain; border-radius: 12px; border: 1px solid #f1f5f9; padding: 4px;" />
          {{/companyLogo}}
          {{^companyLogo}}
            <div style="width: 70px; height: 70px; background: #eff6ff; border-radius: 12px; display: flex; align-items: center; justify-content: center; border: 1px solid #bfdbfe;">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#1e3a5f" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            </div>
          {{/companyLogo}}
          <div>
            <div style="font-size: 22px; font-weight: 800; color: #1e3a5f; line-height: 1.2;">{{companyName}}</div>
            <div style="font-size: 12px; color: #64748b; margin-top: 6px; font-weight: 500;">
              <span style="display: inline-block; margin-left: 8px;">📍 {{companyAddress}}</span>
              <span style="display: inline-block; direction: ltr;">📞 {{companyPhones}}</span>
            </div>
          </div>
        </div>

        <!-- Left side: Invoice Metadata Badge -->
        <div style="text-align: left; min-width: 220px;">
          <div style="background: #1e3a5f; color: white; padding: 6px 18px; border-radius: 8px; display: inline-block; font-size: 16px; font-weight: 800; margin-bottom: 12px; text-align: center; float: left;">
            {{invoiceTitle}}
          </div>
          <div style="clear: both;"></div>
          <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px 14px; text-align: right;" dir="rtl">
            <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 12px;">
              <span style="color: #64748b; font-weight: 600;">رقم الفاتورة:</span>
              <span style="font-weight: 800; color: #1e3a5f; font-family: monospace;">{{invoiceNumber}}</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 4px;">
              <span style="color: #64748b; font-weight: 600;">التاريخ:</span>
              <span style="font-weight: 700; color: #334155;">{{issueDate}}</span>
            </div>
            {{#orderTypeDisplay}}
            <div style="margin-top: 8px; padding-top: 8px; border-top: 1px dashed #e2e8f0; display: flex; justify-content: space-between; font-size: 12px;">
              <span style="color: #64748b; font-weight: 600;">نوع الطلب:</span>
              <span style="font-weight: 800; color: #2563eb;">{{orderTypeDisplay}}</span>
            </div>
            {{/orderTypeDisplay}}
          </div>
        </div>
      </div>

      <!-- Customer Billing Card -->
      <div style="padding: 20px 40px 10px;" dir="rtl">
        <div style="background: linear-gradient(135deg, #eff6ff 0%, #f8fafc 100%); border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px 20px; display: flex; align-items: center; gap: 14px;">
          <div style="width: 42px; height: 42px; background: #2563eb; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.1);">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          </div>
          <div>
            <div style="font-size: 10px; color: #2563eb; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px;">فاتورة إلى العميل</div>
            <div style="font-size: 16px; font-weight: 800; color: #1e3a5f;">{{customerName}}</div>
            {{#customerPhone}}
              <div style="font-size: 12px; color: #64748b; margin-top: 2px; font-family: monospace;">📱 {{customerPhone}}</div>
            {{/customerPhone}}
          </div>
        </div>
      </div>

      <!-- Items Table Container -->
      <div style="padding: 15px 40px; flex: 1;" dir="rtl">
        <table style="width: 100%; border-collapse: separate; border-spacing: 0; font-size: 13px; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;">
          <thead>
            <tr style="background: #1e3a5f; color: white;">
              <th style="padding: 12px 14px; text-align: right; font-weight: 700; font-size: 12px; border-bottom: 1px solid #1e3a5f;">#</th>
              <th style="padding: 12px 14px; text-align: right; font-weight: 700; font-size: 12px; border-bottom: 1px solid #1e3a5f; width: 45%;">الصنف</th>
              <th style="padding: 12px 14px; text-align: center; font-weight: 700; font-size: 12px; border-bottom: 1px solid #1e3a5f;">الضمان</th>
              <th style="padding: 12px 14px; text-align: center; font-weight: 700; font-size: 12px; border-bottom: 1px solid #1e3a5f;">الكمية</th>
              <th style="padding: 12px 14px; text-align: center; font-weight: 700; font-size: 12px; border-bottom: 1px solid #1e3a5f;">سعر الوحدة</th>
              <th style="padding: 12px 14px; text-align: left; font-weight: 700; font-size: 12px; border-bottom: 1px solid #1e3a5f;">الإجمالي</th>
            </tr>
          </thead>
          <tbody>
            {{{items}}}
          </tbody>
        </table>
      </div>

      <!-- Spacer -->
      <div style="flex-grow: 1; min-height: 20px;"></div>

      <!-- Bottom Summary & Totals -->
      <div style="padding: 15px 40px 25px; display: flex; justify-content: space-between; align-items: flex-end;" dir="rtl">
        <!-- Notes or Payment details -->
        <div style="width: 50%; padding-left: 20px;">
          <div style="font-size: 12px; font-weight: 800; color: #1e3a5f; margin-bottom: 6px;">ملاحظات وشروط الفاتورة:</div>
          <div style="font-size: 11px; color: #64748b; line-height: 1.5; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; padding: 10px 12px; min-height: 60px;">
            يرجى مراجعة الأصناف والضمان عند الاستلام. شكراً لثقتكم بنا واختياركم خدماتنا.
          </div>
        </div>

        <!-- Totals Card -->
        <div style="width: 40%; min-width: 250px;">
          <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px 0 rgba(0,0,0,0.05);">
            <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
              <tbody>
                {{{totals}}}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Footer Branding -->
      <div style="margin: 0 40px 30px; padding-top: 16px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;" dir="rtl">
        <div style="font-size: 10px; color: #94a3b8;" dir="ltr">© جميع الحقوق محفوظة لدى EITSS الباقرة لتقنية المعلومات</div>
        <div style="font-size: 13px; font-weight: 800; color: #1e3a5f; display: flex; align-items: center; gap: 4px;">
          شكراً لتعاملكم معنا 🙏
        </div>
      </div>
      
      <!-- Bottom decorative stripe -->
      <div style="height: 4px; background: linear-gradient(to left, #1e3a5f, #3b82f6, #1d4ed8);"></div>
    </div>
  `;

  const classicTemplate = `
    <div id="invoice-print" class="font-body print-container-a4 bg-white w-full mx-auto flex flex-col" style="font-family: 'Cairo', 'Segoe UI', sans-serif; direction: rtl; min-height: 297mm; box-sizing: border-box;">
      <!-- Centered Classic Header -->
      <div style="padding: 40px 40px 20px; text-align: center; border-bottom: 2px solid #1e293b;">
        {{#companyLogo}}
          <img src="{{companyLogo}}" alt="Logo" style="width: 75px; height: 75px; object-fit: contain; border-radius: 50%; border: 2px solid #1e293b; padding: 3px; margin: 0 auto 12px;" />
        {{/companyLogo}}
        <div style="font-size: 26px; font-weight: 900; color: #1e293b; letter-spacing: -0.5px;">{{companyName}}</div>
        <div style="font-size: 12px; color: #475569; margin-top: 6px; font-weight: 600;">
          📍 {{companyAddress}} &nbsp;|&nbsp; 📞 {{companyPhones}}
        </div>
      </div>

      <!-- Metadata Box / Title & Info Grid -->
      <div style="padding: 20px 40px 10px; display: flex; justify-content: space-between; align-items: stretch; gap: 20px;">
        <!-- Customer Info Card -->
        <div style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 14px 18px; flex: 1.2; text-align: right;">
          <div style="font-size: 11px; color: #4f46e5; font-weight: 800; letter-spacing: 0.5px; margin-bottom: 4px;">العميل / العميل الكريم:</div>
          <div style="font-size: 17px; font-weight: 800; color: #1e293b;">{{customerName}}</div>
          {{#customerPhone}}
            <div style="font-size: 12px; color: #475569; margin-top: 4px; font-family: monospace;">📱 {{customerPhone}}</div>
          {{/customerPhone}}
        </div>

        <!-- Invoice Details Card -->
        <div style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 14px 18px; flex: 0.8; text-align: right; display: flex; flex-direction: column; justify-content: center;">
          <div style="font-size: 16px; font-weight: 900; color: #1e293b; border-bottom: 2px solid #1e293b; padding-bottom: 4px; margin-bottom: 8px; display: inline-block;">
            {{invoiceTitle}}
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 4px;">
            <span style="color: #475569; font-weight: 600;">الرقم:</span>
            <span style="font-weight: 800; color: #1e293b; font-family: monospace;">{{invoiceNumber}}</span>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 12px;">
            <span style="color: #475569; font-weight: 600;">التاريخ:</span>
            <span style="font-weight: 700; color: #1e293b;">{{issueDate}}</span>
          </div>
          {{#orderTypeDisplay}}
            <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 4px; padding-top: 4px; border-top: 1px dashed #cbd5e1;">
              <span style="color: #475569; font-weight: 600;">نوع الطلب:</span>
              <span style="font-weight: 800; color: #4f46e5;">{{orderTypeDisplay}}</span>
            </div>
          {{/orderTypeDisplay}}
        </div>
      </div>

      <!-- Classic Table Grid -->
      <div style="padding: 15px 40px; flex: 1;" dir="rtl">
        <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
          <thead>
            <tr style="border-bottom: 3px solid #1e293b; background: #f1f5f9;">
              <th style="padding: 10px 8px; text-align: right; font-weight: 800; color: #1e293b; font-size: 12px;">م</th>
              <th style="padding: 10px 8px; text-align: right; font-weight: 800; color: #1e293b; font-size: 12px; width: 45%;">البيان (أصناف الفاتورة)</th>
              <th style="padding: 10px 8px; text-align: center; font-weight: 800; color: #1e293b; font-size: 12px;">الضمان</th>
              <th style="padding: 10px 8px; text-align: center; font-weight: 800; color: #1e293b; font-size: 12px;">الكمية</th>
              <th style="padding: 10px 8px; text-align: center; font-weight: 800; color: #1e293b; font-size: 12px;">سعر الوحدة</th>
              <th style="padding: 10px 8px; text-align: left; font-weight: 800; color: #1e293b; font-size: 12px;">الإجمالي</th>
            </tr>
          </thead>
          <tbody>
            {{{items}}}
          </tbody>
        </table>
      </div>

      <!-- Spacer -->
      <div style="flex-grow: 1; min-height: 25px;"></div>

      <!-- Signatures & Totals -->
      <div style="padding: 15px 40px 30px; display: flex; justify-content: space-between; align-items: flex-end; gap: 30px;" dir="rtl">
        <!-- Receipt & Notes Block -->
        <div style="flex: 1.2;">
          <div style="font-size: 12px; font-weight: 700; color: #1e293b; margin-bottom: 6px;">ملاحظات:</div>
          <div style="border: 1px solid #cbd5e1; border-radius: 6px; padding: 8px 10px; font-size: 11px; color: #475569; min-height: 50px;">
            البضاعة المستلمة سليمة ولا تُرد ولا تُستبدل إلا حسب الشروط المعمول بها.
          </div>
          <!-- Customer Signature Line -->
          <div style="margin-top: 35px; display: flex; justify-content: space-between; align-items: center; width: 85%;">
            <div style="text-align: center; width: 140px; border-top: 1px dashed #1e293b; padding-top: 4px;">
              <span style="font-size: 11px; font-weight: 700; color: #1e293b;">توقيع العميل / المستلم</span>
            </div>
            <div style="text-align: center; width: 140px; border-top: 1px dashed #1e293b; padding-top: 4px;">
              <span style="font-size: 11px; font-weight: 700; color: #1e293b;">الختم والتوقيع الرسمي</span>
            </div>
          </div>
        </div>

        <!-- Totals Card -->
        <div style="width: 38%; min-width: 240px;">
          <div style="background: #f8fafc; border: 2px solid #1e293b; border-radius: 8px; overflow: hidden;">
            <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
              <tbody>
                {{{totals}}}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Classic Footer -->
      <div style="background: #1e293b; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; color: white;" dir="rtl">
        <div style="font-size: 10px; color: #cbd5e1;" dir="ltr">© جميع الحقوق محفوظة لدى EITSS الباقرة لتقنية المعلومات</div>
        <div style="font-size: 12px; font-weight: 700;">شكراً لتعاملكم معنا 🙏</div>
      </div>
    </div>
  `;

  const thermalTemplate = `
    <div id="invoice-print" class="font-body print-container-thermal bg-white text-black mx-auto" dir="rtl" style="padding: 0;">
        <header class="flex items-center mb-1">
            {{#companyLogo}}
                <img src="{{companyLogo}}" alt="Logo" style="width: 48px; height: 48px; margin-left: 8px; border-radius: 4px;" />
            {{/companyLogo}}
            <div class="text-right flex-grow">
                <h1 class="font-bold" style="font-size: 14px;">{{companyName}}</h1>
                <p style="font-size: 10px; line-height: 1.2;">{{companyAddress}} - {{companyPhones}}</p>
            </div>
        </header>
        {{#orderTypeDisplay}}
             <p class="text-center font-bold text-lg my-1 py-1 bg-black text-white">نوع الطلب: {{orderTypeDisplay}}</p>
        {{/orderTypeDisplay}}
        <hr class="border-dashed border-black my-1"/>
        <div class="text-right" style="font-size: 10px;">
            <p>{{invoiceNumberDisplay}} | التاريخ: {{issueDate}}</p>
            <p>العميل: {{customerName}} | هاتف: {{customerPhone}}</p>
        </div>
        <hr class="border-dashed border-black my-1"/>
        <table class="w-full text-right" style="font-size: 11px; border-collapse: collapse; border: 1px solid black;">
            <thead>
                <tr style="background-color: black !important; color: white !important;">
                    <th class="p-1 text-right font-bold" style="border: 1px solid black;">الصنف</th>
                    <th class="p-1 text-center font-bold" style="border: 1px solid black;">سعر</th>
                    <th class="p-1 text-center font-bold" style="border: 1px solid black;">ك</th>
                    <th class="p-1 text-right font-bold" style="border: 1px solid black;">إجمالي</th>
                </tr>
            </thead>
            <tbody>
                {{{items}}}
            </tbody>
        </table>
        <hr class="border-dashed border-black my-1"/>
        <table class="w-full" style="font-size: 10px;">
             <tbody>
                {{{totals}}}
            </tbody>
        </table>
        <hr class="border-dashed border-black my-1"/>
        <footer class="text-center mt-1" style="font-size: 9px;">
            <p>شكراً لتعاملكم معنا!</p>
             <div style="display: flex; align-items: center; justify-content: center; gap: 4px; margin-top: 4px; font-family: sans-serif;">
                <p>© جميع الحقوق محفوظة لدى EITSS الباقرة لتقنية المعلومات</p>
            </div>
        </footer>
    </div>
  `;

  const db = await getDbInstance();
  const salesReturns = await db.all(`
    SELECT sr.*, sri.productId, sri.quantity, sri.price
    FROM sales_returns sr
    JOIN sales_return_items sri ON sr.id = sri.salesReturnId
    WHERE sr.invoiceId = ?
  `, params.id) as any[];

  const returnedQtyMap: Record<string, number> = {};
  let totalReturned = 0;
  salesReturns.forEach(ret => {
    returnedQtyMap[ret.productId] = (returnedQtyMap[ret.productId] || 0) + ret.quantity;
    totalReturned += ret.quantity * ret.price;
  });

  let finalTemplate: string;
  let itemsHtml: string;
  let totalsHtml: string;

  const formatCurrency = (num: number) => Math.round(num).toLocaleString('en-US');
  const total = invoice.totalAmount;
  const remaining = Math.max(0, invoice.totalAmount - invoice.amountPaid - totalReturned);

  if (printType === 'thermal') {
    finalTemplate = thermalTemplate;
    itemsHtml = invoice.items.map((item) => {
      const returnedQty = returnedQtyMap[item.productId] || 0;
      let qtyDisplay = `${item.quantity}`;
      if (returnedQty > 0) {
        qtyDisplay = `${item.quantity} (أرجع ${returnedQty})`;
      }
      return `
        <tr class="border-b border-black">
          <td class="p-1" style="border: 1px solid black;">${item.productName}</td>
          <td class="p-1 text-center" style="border: 1px solid black;">${formatCurrency(item.unitPrice)}</td>
          <td class="p-1 text-center" style="border: 1px solid black;">${qtyDisplay}</td>
          <td class="p-1 text-right" style="border: 1px solid black;">${formatCurrency(item.quantity * item.unitPrice)}</td>
        </tr>
      `;
    }).join('');
    
    let thermalTotalsContent = '';

    thermalTotalsContent += `<tr class=""><td class="p-1 font-semibold">الإجمالي الفرعي:</td><td class="p-1 text-right" style="color: black;">${formatCurrency(total)}</td></tr>`;
    if (totalReturned > 0) {
      thermalTotalsContent += `<tr><td class="p-1" style="color: #ea580c;">المرتجع:</td><td class="p-1 text-right" style="color: #ea580c;">-${formatCurrency(totalReturned)}</td></tr>`;
    }
    thermalTotalsContent += `<tr><td class="p-1">المدفوع:</td><td class="p-1 text-right" style="color: black;">${formatCurrency(invoice.amountPaid)}</td></tr>`;
    thermalTotalsContent += `<tr><td class="p-1 font-bold">المتبقي:</td><td class="p-1 text-right font-bold" style="color: black;">${formatCurrency(remaining)}</td></tr>`;
    
    totalsHtml = thermalTotalsContent;

  } else { // A4 print
    finalTemplate = companyInfo.invoiceTemplate === 'classic' ? classicTemplate : modernTemplate;
    if (templateHtml && templateHtml.trim() !== '' && templateHtml.includes('{{{items}}}')) {
      finalTemplate = templateHtml;
    }

    const warrantyColumn = IS_RESTAURANT_APP ? '' : '<th style="padding: 10px 12px; text-align: center; font-weight: 700; font-size: 12px; border-bottom: 1px solid #cbd5e1;">الضمان</th>';
    const warrantyCell = (warranty: string | null | undefined) => IS_RESTAURANT_APP ? '' : `<td style="padding: 10px 12px; text-align: center; color: #6b7280; font-size: 12px; border-bottom: 1px solid #f1f5f9;">${warranty || '—'}</td>`;

    itemsHtml = invoice.items.map((item, index) => {
      const bg = index % 2 === 0 ? '' : 'background: #f9fafb;';
      const totalVal = formatCurrency(item.unitPrice * item.quantity);
      const returnedQty = returnedQtyMap[item.productId] || 0;
      
      let quantityDisplay = `${item.quantity}`;
      if (returnedQty > 0) {
        quantityDisplay = `${item.quantity} <span style="color: #ea580c; font-weight: bold; font-size: 11px;">(أرجع ${returnedQty})</span>`;
      }

      return `
      <tr style="border-bottom: 1px solid #f1f5f9; ${bg}">
        <td style="padding: 12px 14px; font-size: 12px; color: #9ca3af; font-weight: 600; border-bottom: 1px solid #f1f5f9;">${index + 1}</td>
        <td style="padding: 12px 14px; font-size: 13px; font-weight: 700; color: #1e293b; border-bottom: 1px solid #f1f5f9;">${item.productName}</td>
        ${warrantyCell(item.warranty)}
        <td style="padding: 12px 14px; text-align: center; font-size: 13px; font-weight: 600; color: #374151; border-bottom: 1px solid #f1f5f9;">${quantityDisplay}</td>
        <td style="padding: 12px 14px; text-align: center; font-size: 12px; color: #6b7280; border-bottom: 1px solid #f1f5f9;">${formatCurrency(item.unitPrice)}</td>
        <td style="padding: 12px 14px; text-align: left; font-size: 13px; font-weight: 800; color: #1e3a5f; border-bottom: 1px solid #f1f5f9;">${totalVal}</td>
      </tr>`;
    }).join('');
    
    finalTemplate = finalTemplate
      .replace('<th style="padding: 10px 12px; text-align: center; font-weight: 700; font-size: 12px;">الضمان</th>', warrantyColumn)
      .replace('<th class="p-2 text-center">الضمان</th>', warrantyColumn);
    
    if (IS_RESTAURANT_APP) {
         totalsHtml = `
            <tr style="background: #1e3a5f; color: white;">
                <td style="padding: 14px 16px; font-size: 14px; font-weight: 800;">الإجمالي الكلي</td>
                <td style="padding: 14px 16px; text-align: left; font-size: 16px; font-weight: 900; font-family: monospace;">${formatCurrency(invoice.totalAmount)} SDG</td>
            </tr>
         `;
    } else {
        totalsHtml = `
          <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 10px 16px; font-size: 12px; font-weight: 600; color: #64748b;">الإجمالي الفرعي</td>
              <td style="padding: 10px 16px; text-align: left; font-size: 13px; font-weight: 700; color: #334155; font-family: monospace;">${formatCurrency(total)} SDG</td>
          </tr>
        `;
        if (totalReturned > 0) {
            totalsHtml += `
              <tr style="border-bottom: 1px solid #e2e8f0;">
                  <td style="padding: 10px 16px; font-size: 12px; font-weight: 600; color: #ea580c;">إجمالي المرتجع</td>
                  <td style="padding: 10px 16px; text-align: left; font-size: 13px; font-weight: 700; color: #ea580c; font-family: monospace;">-${formatCurrency(totalReturned)} SDG</td>
              </tr>
            `;
        }
        totalsHtml += `
          <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 10px 16px; font-size: 12px; font-weight: 600; color: #16a34a;">المبلغ المدفوع</td>
              <td style="padding: 10px 16px; text-align: left; font-size: 13px; font-weight: 700; color: #16a34a; font-family: monospace;">${formatCurrency(invoice.amountPaid)} SDG</td>
          </tr>
          <tr style="background: #fef2f2;">
              <td style="padding: 14px 16px; font-size: 13px; font-weight: 800; color: #dc2626;">المبلغ المتبقي (دين)</td>
              <td style="padding: 14px 16px; text-align: left; font-size: 15px; font-weight: 900; color: #dc2626; font-family: monospace;">${formatCurrency(remaining)} SDG</td>
          </tr>
        `;
    }
  }

  const view = {
    companyName: companyInfo.name,
    companyLogo: companyInfo.logo,
    companyAddress: companyInfo.address,
    companyPhones: companyInfo.phones,
    invoiceNumber: invoice.invoiceNumber,
    issueDate: format(new Date(invoice.issueDate), 'yyyy/MM/dd HH:mm'),
    customerName: invoice.customerName,
    customerPhone: invoice.customerPhone || '',
    items: itemsHtml,
    totals: totalsHtml,
    totalAmount: formatCurrency(invoice.totalAmount),
    amountPaid: formatCurrency(invoice.amountPaid),
    remainingAmount: formatCurrency(remaining),
    invoiceTitle: invoiceTitle,
    invoiceNumberDisplay: invoiceNumberDisplay,
    orderTypeDisplay: orderTypeDisplay,
  };

  const renderedHtml = Mustache.render(finalTemplate, view);
  
  return (
    <div className={cn(printType === 'thermal' && 'thermal-print-page')}>
       <PrintClientPage />
       <div className="font-body bg-gray-100 text-black" dangerouslySetInnerHTML={{ __html: renderedHtml }} />
    </div>
  );
}
