'use client';

import { Button } from '@/components/ui/button';
import { ArrowLeft, Printer } from 'lucide-react';
import { useRouter } from 'next/navigation';
import * as React from 'react';

export default function PrintClientPage() {
  const router = useRouter();

  const handlePrint = () => {
    window.print();
  };

  React.useEffect(() => {
    // This will trigger the print dialog automatically when the page loads
    const timeoutId = setTimeout(() => {
        handlePrint();
    }, 500); // Small delay to ensure content is rendered

    // When printing completes (e.g. the print dialog is closed), notify the parent window so
    // that it can close the print preview dialog. The 'afterprint' event fires after the
    // print dialog has been dismissed.
    const afterPrintHandler = () => {
      try {
        if (typeof window !== 'undefined' && window.parent) {
          window.parent.postMessage({ type: 'print-complete' }, '*');
        }
      } catch {
        // Ignore any errors (e.g. cross-origin restrictions)
      }
    };
    window.addEventListener('afterprint', afterPrintHandler);

    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('afterprint', afterPrintHandler);
    };
  }, []);

  return (
    <>
      {/* Hide any elements with the `no-print` class (such as sidebars) when rendering the print preview. */}
      <style>{`/* Ensure elements marked as no-print are hidden in the print preview iframe */\n.no-print { display: none !important; }`}</style>
      <div className="no-print fixed top-4 left-4 flex gap-2">
        <Button onClick={() => router.back()} variant="outline" size="icon">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <Button onClick={handlePrint} size="icon">
          <Printer className="h-4 w-4" />
        </Button>
      </div>
    </>
  );
}
