'use client';

import { useState } from 'react';
import { updatePassword } from './actions';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { PageHeader } from '@/components/page-header';
import { Lock, KeyRound, User, ShieldCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';

interface UserData {
  id: string;
  username: string;
  fullName: string;
  roleName: string;
}

export default function ProfileClientPage({ initialUser }: { initialUser: UserData }) {
  const [user, setUser] = useState(initialUser);
  const [passwordLoading, setPasswordLoading] = useState(false);
  const { toast } = useToast();

  async function handlePasswordSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPasswordLoading(true);
    const formData = new FormData(event.currentTarget);
    const result = await updatePassword(formData);
    setPasswordLoading(false);

    if (result && result.error) {
      toast({
        variant: 'destructive',
        title: 'خطأ في تغيير كلمة المرور',
        description: result.error,
      });
    } else {
      toast({
        title: 'نجاح التغيير',
        description: 'تم تحديث كلمة المرور بنجاح.',
      });
      (event.currentTarget as HTMLFormElement).reset();
    }
  }

  return (
    <div className="flex flex-1 flex-col gap-6 p-4 md:gap-8 md:p-8 max-w-5xl mx-auto w-full">
      <PageHeader 
        title="الملف الشخصي" 
        subtitle="إدارة بيانات حسابك وتعديل معلومات الدخول وتحديث كلمة المرور"
      />

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        {/* Left: User info summary card */}
        <div className="md:col-span-4">
          <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
            <div className="bg-gradient-to-l from-primary/10 via-primary/5 to-transparent p-6 flex flex-col items-center text-center border-b border-border/40">
              <div className="w-16 h-16 rounded-3xl bg-primary/20 flex items-center justify-center mb-3.5 shadow-md border border-primary/20">
                <User className="w-8 h-8 text-primary" />
              </div>
              <h3 className="font-extrabold text-lg text-foreground">{user.fullName || 'مدير النظام'}</h3>
              <p className="text-xs text-muted-foreground font-mono mt-0.5">@{user.username}</p>
              <div className="mt-4 flex items-center gap-1.5 bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 px-3.5 py-1.5 rounded-full text-xs font-bold shadow-sm">
                <ShieldCheck className="w-4 h-4" />
                <span>{user.roleName || 'مدير النظام'}</span>
              </div>
            </div>
            <div className="px-6 py-4 bg-secondary/10 flex items-center justify-between text-xs text-muted-foreground font-medium">
              <span>معرّف الحساب:</span>
              <span className="font-mono truncate max-w-[120px]">{user.id}</span>
            </div>
          </Card>
        </div>

        {/* Right: Change Password Card */}
        <Card className="md:col-span-8 rounded-3xl border border-border/50 bg-card shadow-lg shadow-black/[0.02]">
          <CardHeader className="pb-4 border-b border-border/40 bg-secondary/15">
            <CardTitle className="text-base font-bold text-foreground flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-primary" />
              تغيير كلمة المرور
            </CardTitle>
            <CardDescription className="text-xs">تحديث كلمة المرور الحالية لحماية حسابك من الوصول غير المصرح به</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={handlePasswordSubmit} className="space-y-5">
              <div className="space-y-1.5">
                <Label htmlFor="old-password" className="text-sm font-semibold">كلمة المرور الحالية</Label>
                <div className="relative">
                  <Lock className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                  <Input
                    type="password"
                    id="old-password"
                    name="oldPassword"
                    required
                    placeholder="أدخل كلمة المرور الحالية لتأكيد هويتك"
                    className="pr-10 rounded-xl border-border/60 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="new-password" className="text-sm font-semibold">كلمة المرور الجديدة</Label>
                  <div className="relative">
                    <Lock className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                    <Input
                      type="password"
                      id="new-password"
                      name="newPassword"
                      required
                      placeholder="6 أحرف على الأقل"
                      className="pr-10 rounded-xl border-border/60 text-sm"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="confirm-password" className="text-sm font-semibold">تأكيد كلمة المرور الجديدة</Label>
                  <div className="relative">
                    <Lock className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                    <Input
                      type="password"
                      id="confirm-password"
                      name="confirmPassword"
                      required
                      placeholder="أعد كتابة كلمة المرور"
                      className="pr-10 rounded-xl border-border/60 text-sm"
                    />
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                disabled={passwordLoading}
                variant="secondary"
                className="w-full h-11 rounded-xl shadow-md hover:shadow-lg transition-all font-bold text-sm bg-primary/10 text-primary hover:bg-primary hover:text-white"
              >
                {passwordLoading ? 'جاري تحديث كلمة المرور...' : 'تحديث كلمة المرور'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
