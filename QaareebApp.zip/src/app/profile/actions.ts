'use server';

import { getDbInstance } from '@/lib/db';
import { getSession, hashPassword, verifyPassword } from '@/lib/server-auth';

interface Result {
  error?: string;
  success?: boolean;
}

export async function updateProfile(formData: FormData): Promise<Result> {
  const session = await getSession();
  if (!session) {
    return { error: 'لم يتم العثور على جلسة. الرجاء تسجيل الدخول.' };
  }

  const fullName = (formData.get('fullName') as string)?.trim();

  if (!fullName) {
    return { error: 'يجب إدخال الاسم الكامل.' };
  }

  const db = await getDbInstance();

  try {
    // Update database for fullName only
    await db.run(
      'UPDATE users SET fullName = ? WHERE id = ?',
      fullName,
      session.userId
    );

    return { success: true };
  } catch (error: any) {
    console.error('Failed to update profile:', error);
    return { error: error.message || 'فشل تحديث البيانات في قاعدة البيانات.' };
  }
}

export async function updatePassword(formData: FormData): Promise<Result> {
  const oldPassword = (formData.get('oldPassword') as string) || '';
  const newPassword = (formData.get('newPassword') as string) || '';
  const confirmPassword = (formData.get('confirmPassword') as string) || '';

  if (!oldPassword || !newPassword || !confirmPassword) {
    return { error: 'يرجى ملء جميع الحقول الخاصة بكلمة المرور.' };
  }
  if (newPassword !== confirmPassword) {
    return { error: 'كلمة المرور الجديدة وتأكيدها غير متطابقين.' };
  }
  if (newPassword.length < 6) {
    return { error: 'يجب أن تكون كلمة المرور الجديدة مكونة من 6 أحرف على الأقل.' };
  }

  const session = await getSession();
  if (!session) {
    return { error: 'لم يتم العثور على جلسة. الرجاء تسجيل الدخول.' };
  }

  const db = await getDbInstance();
  try {
    const user = await db.get('SELECT password FROM users WHERE id = ?', session.userId);
    if (!user) {
      return { error: 'المستخدم غير موجود.' };
    }

    const valid = await verifyPassword(oldPassword, user.password);
    if (!valid) {
      return { error: 'كلمة المرور الحالية غير صحيحة.' };
    }

    const hashed = await hashPassword(newPassword);
    await db.run('UPDATE users SET password = ? WHERE id = ?', hashed, session.userId);

    return { success: true };
  } catch (error: any) {
    console.error('Failed to update password:', error);
    return { error: error.message || 'فشل تحديث كلمة المرور في قاعدة البيانات.' };
  }
}
