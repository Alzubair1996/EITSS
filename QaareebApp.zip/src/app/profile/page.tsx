import { getSession } from '@/lib/server-auth';
import { getDbInstance } from '@/lib/db';
import { redirect } from 'next/navigation';
import ProfileClientPage from './profile-client-page';

export const dynamic = 'force-dynamic';

export default async function ProfilePage() {
  const session = await getSession();
  if (!session) {
    redirect('/login');
  }

  const db = await getDbInstance();
  const user = await db.get(`
    SELECT u.id, u.username, u.fullName, r.name as roleName
    FROM users u
    LEFT JOIN roles r ON u.roleId = r.id
    WHERE u.id = ?
  `, session.userId) as { id: string; username: string; fullName: string | null; roleName: string | null } | undefined;

  if (!user) {
    redirect('/login');
  }

  const userData = {
    id: user.id,
    username: user.username,
    fullName: user.fullName || (user.username === 'admin' ? 'مدير النظام' : ''),
    roleName: user.roleName || (user.username === 'admin' ? 'المدير العام' : 'موظف'),
  };

  return <ProfileClientPage initialUser={userData} />;
}
