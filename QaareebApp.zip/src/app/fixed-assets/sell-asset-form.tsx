
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import type { PaymentMethod } from '@/lib/types';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const formSchema = z.object({
  salePrice: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
    message: "سعر البيع مطلوب ويجب أن يكون أكبر من صفر",
  }),
  saleDate: z.date({ required_error: 'تاريخ البيع مطلوب' }),
  paymentMethodId: z.string({ required_error: 'طريقة الدفع مطلوبة' }),
});

type SellAssetFormValues = z.infer<typeof formSchema>;

interface SellAssetFormProps {
  assetName: string;
  paymentMethods: PaymentMethod[];
  onSubmit: (values: Omit<SellAssetFormValues, 'saleDate' | 'salePrice'> & { saleDate: string; salePrice: number }) => void;
  onCancel: () => void;
  isAdmin: boolean;
}

export function SellAssetForm({ assetName, paymentMethods, onSubmit, onCancel, isAdmin }: SellAssetFormProps) {
  const form = useForm<SellAssetFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      salePrice: '',
      saleDate: new Date(),
      paymentMethodId: '',
    },
  });

  const handleSubmit = (values: SellAssetFormValues) => {
    onSubmit({
      salePrice: Number(values.salePrice),
      saleDate: values.saleDate.toISOString(),
      paymentMethodId: values.paymentMethodId,
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)}>
        <DialogHeader>
          <DialogTitle>بيع الأصل: {assetName}</DialogTitle>
          <DialogDescription>
            أدخل تفاصيل عملية البيع. سيتم إضافة المبلغ إلى الحساب المحدد.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="salePrice"
            render={({ field }) => (
              <FormItem>
                <FormLabel>سعر البيع</FormLabel>
                <FormControl>
                  <Input type="number" step="0.01" placeholder="0.00" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="saleDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>تاريخ البيع</FormLabel>
                 <Popover>
                    <PopoverTrigger asChild>
                    <FormControl>
                        <Button
                            variant={"outline"}
                            className={cn(
                            "w-full justify-start text-left font-normal",
                            !field.value && "text-muted-foreground"
                            )}
                        >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {field.value ? format(field.value, "PPP") : <span>اختر تاريخاً</span>}
                        </Button>
                    </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                    <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        initialFocus
                    />
                    </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="paymentMethodId"
            render={({ field }) => (
              <FormItem className="md:col-span-2">
                <FormLabel>استقبال المبلغ في حساب</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر حساب لاستقبال المبلغ" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {paymentMethods.map((pm) => (
                      <SelectItem key={pm.id} value={pm.id}>
                        {pm.name}
                        {isAdmin && ` (الرصيد: ${pm.balance.toFixed(0)})`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <DialogFooter className="pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            إلغاء
          </Button>
          <Button type="submit">تأكيد البيع</Button>
        </DialogFooter>
      </form>
    </Form>
  );
}

