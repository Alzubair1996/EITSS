'use client';

import * as React from 'react';
import { PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/page-header';
import { FixedAssetsTable } from './fixed-assets-table';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { FixedAssetForm } from './fixed-asset-form';
import { SellAssetForm } from './sell-asset-form';
import type { FixedAssetDetails, PaymentMethod } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { addFixedAsset, sellFixedAsset, deleteFixedAsset, updateFixedAsset } from './actions';
import { useRouter } from 'next/navigation';

interface FixedAssetsClientPageProps {
  initialAssets: FixedAssetDetails[];
  paymentMethods: PaymentMethod[];
  isAdmin: boolean;
}

export default function FixedAssetsClientPage({ initialAssets, paymentMethods, isAdmin }: FixedAssetsClientPageProps) {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [isSellDialogOpen, setIsSellDialogOpen] = React.useState(false);
  const [selectedAsset, setSelectedAsset] = React.useState<FixedAssetDetails | null>(null);
  const { toast } = useToast();
  const router = useRouter();

  const handleDelete = async (assetId: string) => {
    const result = await deleteFixedAsset(assetId);
    if (result.success) {
      toast({
        title: 'تم الحذف بنجاح',
        description: result.message,
      });
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ في الحذف',
        description: result.message,
      });
    }
  };

  const handleSell = (asset: FixedAssetDetails) => {
    setSelectedAsset(asset);
    setIsSellDialogOpen(true);
  };

  const handleSellSubmit = async (values: { salePrice: number; saleDate: string; paymentMethodId: string }) => {
    if (!selectedAsset) return;
    
    const result = await sellFixedAsset(selectedAsset.id, values.salePrice, values.saleDate, values.paymentMethodId);

    if (result.success) {
      toast({
        title: 'تم البيع بنجاح',
        description: result.message,
      });
      setIsSellDialogOpen(false);
      setSelectedAsset(null);
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ',
        description: result.message,
      });
    }
  };

  const handleFormSubmit = async (values: any) => {
    const result = selectedAsset 
      ? await updateFixedAsset(selectedAsset.id, values)
      : await addFixedAsset(values);

    if (result.success) {
      toast({
        title: selectedAsset ? 'تم التعديل بنجاح' : 'تمت الإضافة بنجاح',
        description: result.message,
      });
      setIsDialogOpen(false);
      setSelectedAsset(null);
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ',
        description: result.message,
      });
    }
  };

  const handleEdit = (asset: FixedAssetDetails) => {
    setSelectedAsset(asset);
    setIsDialogOpen(true);
  };

  return (
    <>
      <PageHeader title="إدارة الأصول الثابتة">
        <Button onClick={() => setIsDialogOpen(true)} className="shadow-md hover:shadow-lg transition-shadow">
          <PlusCircle className="me-2 h-4 w-4" />
          إضافة أصل ثابت جديد
        </Button>
      </PageHeader>
      <FixedAssetsTable
        assets={initialAssets}
        onDelete={handleDelete}
        onSell={handleSell}
        onEdit={handleEdit}
      />
      <Dialog open={isDialogOpen} onOpenChange={(open) => {
        setIsDialogOpen(open);
        if (!open) setSelectedAsset(null);
      }}>
        <DialogContent className="sm:max-w-[500px]">
          <FixedAssetForm
            paymentMethods={paymentMethods}
            onSubmit={handleFormSubmit}
            onCancel={() => {
              setIsDialogOpen(false);
              setSelectedAsset(null);
            }}
            isAdmin={isAdmin}
            initialData={selectedAsset ? {
              name: selectedAsset.name,
              description: selectedAsset.description,
              purchasePrice: selectedAsset.purchasePrice,
              purchaseDate: new Date(selectedAsset.purchaseDate),
              bookValue: selectedAsset.bookValue,
              depreciationRate: selectedAsset.depreciationRate,
              paymentMethodId: selectedAsset.paymentMethodId,
            } : null}
          />
        </DialogContent>
      </Dialog>
      <Dialog open={isSellDialogOpen} onOpenChange={setIsSellDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          {selectedAsset && (
            <SellAssetForm
              assetName={selectedAsset.name}
              paymentMethods={paymentMethods}
              onSubmit={handleSellSubmit}
              onCancel={() => {
                setIsSellDialogOpen(false);
                setSelectedAsset(null);
              }}
              isAdmin={isAdmin}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

