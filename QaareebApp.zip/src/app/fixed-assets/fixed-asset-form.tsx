
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import type { PaymentMethod } from '@/lib/types';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const formSchema = z.object({
  name: z.string().min(2, { message: 'اسم الأصل مطلوب ويجب أن يكون حرفين على الأقل' }),
  description: z.string().optional(),
  purchasePrice: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
    message: "سعر الشراء مطلوب ويجب أن يكون أكبر من صفر",
  }),
  purchaseDate: z.date({ required_error: 'تاريخ الشراء مطلوب' }),
  bookValue: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, {
    message: "القيمة الدفترية مطلوبة ويجب أن تكون أكبر من أو تساوي الصفر",
  }),
  depreciationRate: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0 && parseFloat(val) <= 100, {
    message: "معدل الاستهلاك يجب أن يكون بين 0 و 100",
  }),
  paymentMethodId: z.string().optional(),
});

type FixedAssetFormValues = z.infer<typeof formSchema>;

interface FixedAssetFormProps {
  paymentMethods: PaymentMethod[];
  onSubmit: (values: Omit<FixedAssetFormValues, 'purchaseDate' | 'purchasePrice' | 'bookValue' | 'depreciationRate'> & { 
    purchaseDate: string; 
    purchasePrice: number;
    bookValue: number;
    depreciationRate: number;
  }) => void;
  onCancel: () => void;
  /**
   * Indicates whether the current user is the admin. If true, show available balances.
   */
  isAdmin: boolean;
  initialData?: {
    name: string;
    description?: string | null;
    purchasePrice: number;
    purchaseDate: Date;
    bookValue: number;
    depreciationRate: number;
    paymentMethodId?: string | null;
  } | null;
}

export function FixedAssetForm({ paymentMethods, onSubmit, onCancel, isAdmin, initialData }: FixedAssetFormProps) {
  const form = useForm<FixedAssetFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: initialData?.name || '',
      description: initialData?.description || '',
      purchasePrice: initialData?.purchasePrice ? initialData.purchasePrice.toString() : '',
      purchaseDate: initialData?.purchaseDate || new Date(),
      bookValue: initialData?.bookValue ? initialData.bookValue.toString() : '',
      depreciationRate: initialData?.depreciationRate ? initialData.depreciationRate.toString() : '0',
      paymentMethodId: initialData?.paymentMethodId || '',
    },
  });

  const handleSubmit = (values: FixedAssetFormValues) => {
    onSubmit({
      ...values,
      purchasePrice: Number(values.purchasePrice),
      bookValue: Number(values.bookValue),
      depreciationRate: Number(values.depreciationRate),
      purchaseDate: values.purchaseDate.toISOString(),
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)}>
        <DialogHeader>
          <DialogTitle>{initialData ? 'تعديل الأصل الثابت' : 'إضافة أصل ثابت جديد'}</DialogTitle>
          <DialogDescription>
            {initialData ? 'قم بتعديل بيانات الأصل الثابت' : 'سجل الأصول الثابتة للشركة مثل الأجهزة والمعدات والمركبات.'}
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>اسم الأصل</FormLabel>
                <FormControl>
                  <Input placeholder="مثال: حاسوب محمول، سيارة، طابعة..." {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>الوصف (اختياري)</FormLabel>
                <FormControl>
                  <Input placeholder="وصف إضافي للأصل..." {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="purchasePrice"
            render={({ field }) => (
              <FormItem>
                <FormLabel>سعر الشراء</FormLabel>
                <FormControl>
                  <Input type="number" step="0.01" placeholder="0.00" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="purchaseDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>تاريخ الشراء</FormLabel>
                 <Popover>
                    <PopoverTrigger asChild>
                    <FormControl>
                        <Button
                            variant={"outline"}
                            className={cn(
                            "w-full justify-start text-left font-normal",
                            !field.value && "text-muted-foreground"
                            )}
                        >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {field.value ? format(field.value, "PPP") : <span>اختر تاريخاً</span>}
                        </Button>
                    </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                    <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        initialFocus
                    />
                    </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="bookValue"
            render={({ field }) => (
              <FormItem>
                <FormLabel>القيمة الدفترية</FormLabel>
                <FormControl>
                  <Input type="number" step="0.01" placeholder="0.00" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="depreciationRate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>معدل الاستهلاك (% سنوياً)</FormLabel>
                <FormControl>
                  <Input type="number" step="0.01" placeholder="0" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="paymentMethodId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>الدفع من حساب (اختياري)</FormLabel>
                <Select onValueChange={(value) => field.onChange(value === 'none' ? '' : value)} value={field.value || ''}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر حساب للدفع منه" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="none">لا يوجد</SelectItem>
                    {paymentMethods.map((pm) => (
                      <SelectItem key={pm.id} value={pm.id}>
                        {pm.name}
                        {isAdmin && ` (الرصيد: ${pm.balance.toFixed(0)})`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <DialogFooter className="pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            إلغاء
          </Button>
          <Button type="submit">{initialData ? 'حفظ التغييرات' : 'إضافة الأصل'}</Button>
        </DialogFooter>
      </form>
    </Form>
  );
}

