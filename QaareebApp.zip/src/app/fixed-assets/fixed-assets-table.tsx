'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MoreHorizontal, Trash2, Building2, TrendingUp, Edit } from 'lucide-react';
import type { FixedAssetDetails } from '@/lib/types';
import { format } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import * as React from 'react';

interface FixedAssetsTableProps {
  assets: FixedAssetDetails[];
  onDelete: (assetId: string) => void;
  onSell: (asset: FixedAssetDetails) => void;
  onEdit?: (asset: FixedAssetDetails) => void;
}

export function FixedAssetsTable({ assets, onDelete, onSell, onEdit }: FixedAssetsTableProps) {
  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  const totalValue = assets.filter(a => a.status === 'active').reduce((sum, a) => sum + a.bookValue, 0);

  const statusMap: Record<string, { text: string; variant: 'success' | 'info' | 'destructive' }> = {
    active: { text: 'نشط', variant: 'success' },
    sold: { text: 'تم البيع', variant: 'info' },
    disposed: { text: 'تم التخلص', variant: 'destructive' },
  };

  return (
    <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
      <CardHeader className="pb-4 border-b border-border/40 bg-secondary/10 flex flex-row justify-between items-center">
        <div>
          <CardTitle className="text-base font-bold text-foreground">قائمة الأصول الثابتة</CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">تتبع أصول وقيم واستهلاك الممتلكات المادية للمؤسسة</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="text-xs font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-200 dark:border-emerald-500/20">
            إجمالي الدفترية للأصول النشطة: {formatCurrency(totalValue)}
          </div>
          <div className="text-xs font-semibold text-muted-foreground bg-background px-3 py-1.5 rounded-full border border-border/40 shadow-sm">
            {assets.length} أصل
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>اسم الأصل</TableHead>
              <TableHead>تاريخ الشراء</TableHead>
              <TableHead className="text-right">سعر الشراء</TableHead>
              <TableHead className="text-right">القيمة الدفترية</TableHead>
              <TableHead className="text-right">معدل الاستهلاك السنوي</TableHead>
              <TableHead>الحالة</TableHead>
              <TableHead className="text-center">الإجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {assets.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-40 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-4 rounded-2xl bg-muted/50">
                      <Building2 className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">لا توجد أصول ثابتة</p>
                      <p className="text-sm text-muted-foreground mt-1">قم بإضافة أول أصل ثابت للمؤسسة</p>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              assets.map((asset) => {
                const status = statusMap[asset.status] || { text: asset.status, variant: 'destructive' as const };
                return (
                  <TableRow key={asset.id} className="group">
                    <TableCell className="font-semibold text-foreground">{asset.name}</TableCell>
                    <TableCell className="text-muted-foreground text-xs">{format(new Date(asset.purchaseDate), 'dd/MM/yyyy')}</TableCell>
                    <TableCell className="text-right font-mono font-bold text-muted-foreground">{formatCurrency(asset.purchasePrice)}</TableCell>
                    <TableCell className="text-right font-mono font-bold text-primary">{formatCurrency(asset.bookValue)}</TableCell>
                    <TableCell className="text-right font-mono font-semibold text-foreground">{asset.depreciationRate.toFixed(2)}%</TableCell>
                    <TableCell>
                      <Badge variant={status.variant}>{status.text}</Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <AlertDialog>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              aria-haspopup="true"
                              size="icon"
                              variant="ghost"
                              className="rounded-full h-8 w-8 hover:bg-primary/5 hover:text-primary opacity-60 group-hover:opacity-100 transition-all"
                            >
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">فتح القائمة</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="rounded-xl shadow-lg border-border/50">
                            {onEdit && (
                              <DropdownMenuItem
                                onSelect={(e) => {
                                  e.preventDefault();
                                  onEdit(asset);
                                }}
                                className="rounded-lg cursor-pointer"
                              >
                                <Edit className="me-2 h-4 w-4 text-primary" />
                                تعديل الأصل
                              </DropdownMenuItem>
                            )}
                            {asset.status === 'active' && (
                              <DropdownMenuItem
                                onSelect={(e) => {
                                  e.preventDefault();
                                  onSell(asset);
                                }}
                                className="rounded-lg cursor-pointer text-emerald-600 focus:text-emerald-600"
                              >
                                <TrendingUp className="me-2 h-4 w-4" />
                                تسجيل بيع الأصل
                              </DropdownMenuItem>
                            )}
                            <AlertDialogTrigger asChild>
                              <DropdownMenuItem
                                onSelect={(e) => e.preventDefault()}
                                className="rounded-lg cursor-pointer text-destructive focus:text-destructive"
                              >
                                <Trash2 className="me-2 h-4 w-4" />
                                حذف الأصل
                              </DropdownMenuItem>
                            </AlertDialogTrigger>
                          </DropdownMenuContent>
                        </DropdownMenu>
                        <AlertDialogContent className="rounded-3xl">
                          <AlertDialogHeader>
                            <AlertDialogTitle>هل أنت متأكد تماماً؟</AlertDialogTitle>
                            <AlertDialogDescription>
                              سيتم حذف هذا الأصل الثابت نهائياً وإعادة مبلغ الشراء (إن تم الشراء من حساب محدد) إلى حساب الدفع المخصص له. لا يمكن التراجع عن هذا الإجراء.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel className="rounded-xl">إلغاء</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => onDelete(asset.id)}
                              className="rounded-xl bg-destructive hover:bg-destructive/90"
                            >
                              نعم، قم بالحذف
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
