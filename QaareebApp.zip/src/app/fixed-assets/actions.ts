'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { FixedAsset, FixedAssetTransaction } from '@/lib/types';
import { randomUUID } from 'crypto';
import { getSession } from '@/lib/server-auth';

type AddFixedAssetData = Omit<FixedAsset, 'id' | 'status' | 'salePrice' | 'saleDate'>;

export async function addFixedAsset(data: AddFixedAssetData) {
    if (data.purchasePrice <= 0) {
        return { success: false, message: 'سعر الشراء يجب أن يكون أكبر من صفر.' };
    }
    
    const db = await getDbInstance();
    const session = await getSession();
    const userId = session?.userId || null;
    
    try {
        await db.exec('BEGIN');

        // Insert into fixed_assets table
        const newId = `asset_${randomUUID()}`;
        await db.run(`
            INSERT INTO fixed_assets (id, name, description, purchasePrice, purchaseDate, bookValue, depreciationRate, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'active')
        `,
        newId,
        data.name,
        data.description || null,
        data.purchasePrice,
        data.purchaseDate,
        data.bookValue,
        data.depreciationRate
        );

        // If payment method is provided, deduct from its balance
        if (data.paymentMethodId) {
            // Insert transaction record
            const transactionId = `trans_${randomUUID()}`;
            await db.run(`
                INSERT INTO fixed_asset_transactions (id, assetId, transactionType, amount, transactionDate, description, paymentMethodId, userId)
                VALUES (?, ?, 'purchase', ?, ?, ?, ?, ?)
            `,
            transactionId,
            newId,
            data.purchasePrice,
            data.purchaseDate,
            `شراء ${data.name}`,
            data.paymentMethodId,
            userId
            );

            // Check if payment method has enough balance
            const paymentMethod = await db.get('SELECT balance FROM payment_methods WHERE id = ?', data.paymentMethodId) as { balance: number };
            if (!paymentMethod || paymentMethod.balance < data.purchasePrice) {
                throw new Error('الرصيد في طريقة الدفع غير كافٍ لتغطية تكلفة الأصل.');
            }

            // Update payment method balance
            await db.run('UPDATE payment_methods SET balance = balance - ? WHERE id = ?', data.purchasePrice, data.paymentMethodId);
        }

        await db.exec('COMMIT');

        revalidatePath('/fixed-assets');
        revalidatePath('/reports');
        revalidatePath('/'); // For dashboard stats
        return { success: true, message: 'تم تسجيل الأصل الثابت بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to add fixed asset:', e);
        return { success: false, message: e.message || 'فشل تسجيل الأصل الثابت.' };
    }
}

export async function sellFixedAsset(assetId: string, salePrice: number, saleDate: string, paymentMethodId: string) {
    if (salePrice <= 0) {
        return { success: false, message: 'سعر البيع يجب أن يكون أكبر من صفر.' };
    }
    
    const db = await getDbInstance();
    const session = await getSession();
    const userId = session?.userId || null;
    
    try {
        await db.exec('BEGIN');

        // Get the asset
        const asset = await db.get('SELECT * FROM fixed_assets WHERE id = ?', assetId) as FixedAsset;
        if (!asset) {
            throw new Error('الأصل الثابت غير موجود.');
        }

        if (asset.status !== 'active') {
            throw new Error('لا يمكن بيع أصل تم بيعه أو التخلص منه بالفعل.');
        }

        // Update asset status
        await db.run(`
            UPDATE fixed_assets 
            SET status = 'sold', salePrice = ?, saleDate = ?, paymentMethodId = ?
            WHERE id = ?
        `, salePrice, saleDate, paymentMethodId, assetId);

        // Insert transaction record
        const transactionId = `trans_${randomUUID()}`;
        await db.run(`
            INSERT INTO fixed_asset_transactions (id, assetId, transactionType, amount, transactionDate, description, paymentMethodId, userId)
            VALUES (?, ?, 'sale', ?, ?, ?, ?, ?)
        `,
        transactionId,
        assetId,
        salePrice,
        saleDate,
        `بيع ${asset.name}`,
        paymentMethodId,
        userId
        );

        // Add to payment method balance
        await db.run('UPDATE payment_methods SET balance = balance + ? WHERE id = ?', salePrice, paymentMethodId);

        await db.exec('COMMIT');

        revalidatePath('/fixed-assets');
        revalidatePath('/reports');
        revalidatePath('/');
        return { success: true, message: 'تم بيع الأصل الثابت بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to sell fixed asset:', e);
        return { success: false, message: e.message || 'فشل بيع الأصل الثابت.' };
    }
}

export async function updateFixedAsset(assetId: string, data: AddFixedAssetData) {
    if (data.purchasePrice <= 0) {
        return { success: false, message: 'سعر الشراء يجب أن يكون أكبر من صفر.' };
    }
    
    const db = await getDbInstance();
    
    try {
        await db.exec('BEGIN');

        // Get the current asset
        const currentAsset = await db.get('SELECT * FROM fixed_assets WHERE id = ?', assetId) as FixedAsset;
        if (!currentAsset) {
            throw new Error('الأصل الثابت غير موجود.');
        }

        // Update the asset
        await db.run(`
            UPDATE fixed_assets 
            SET name = ?, description = ?, purchasePrice = ?, purchaseDate = ?, bookValue = ?, depreciationRate = ?
            WHERE id = ?
        `,
        data.name,
        data.description || null,
        data.purchasePrice,
        data.purchaseDate,
        data.bookValue,
        data.depreciationRate,
        assetId
        );

        await db.exec('COMMIT');

        revalidatePath('/fixed-assets');
        revalidatePath('/reports');
        revalidatePath('/');
        revalidatePath('/financial-accounts');
        return { success: true, message: 'تم تحديث الأصل الثابت بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to update fixed asset:', e);
        return { success: false, message: e.message || 'فشل تحديث الأصل الثابت.' };
    }
}

export async function deleteFixedAsset(assetId: string) {
    const db = await getDbInstance();
    try {
        await db.exec('BEGIN');
        
        const asset = await db.get('SELECT * FROM fixed_assets WHERE id = ?', assetId) as FixedAsset;
        if (!asset) {
            throw new Error('الأصل الثابت غير موجود.');
        }

        if (asset.status === 'active') {
            // If the asset was purchased with a payment method, refund the purchase price
            if (asset.paymentMethodId) {
                const purchaseTransaction = await db.get(
                    'SELECT * FROM fixed_asset_transactions WHERE assetId = ? AND transactionType = "purchase" LIMIT 1',
                    assetId
                ) as FixedAssetTransaction;

                if (purchaseTransaction && purchaseTransaction.paymentMethodId) {
                    await db.run('UPDATE payment_methods SET balance = balance + ? WHERE id = ?', asset.purchasePrice, purchaseTransaction.paymentMethodId);
                }
            }
        }

        // Delete the asset and its transactions (CASCADE will handle this)
        await db.run('DELETE FROM fixed_assets WHERE id = ?', assetId);

        await db.exec('COMMIT');

        revalidatePath('/fixed-assets');
        revalidatePath('/reports');
        revalidatePath('/');
        return { success: true, message: 'تم حذف الأصل الثابت بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to delete fixed asset:', e);
        return { success: false, message: e.message || 'فشل حذف الأصل الثابت.' };
    }
}

