import FixedAssetsClientPage from './fixed-assets-client-page';
import { getFixedAssets, getPaymentMethods } from '@/lib/queries';
import { getSession } from '@/lib/server-auth';

export default async function FixedAssetsPage() {
  const session = await getSession();
  // Determine if the current user is admin
  const isAdmin = session?.username === 'admin';
  const initialAssets = await getFixedAssets();
  const paymentMethods = await getPaymentMethods();

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <FixedAssetsClientPage 
            initialAssets={initialAssets}
            paymentMethods={paymentMethods}
            isAdmin={isAdmin}
        />
      </div>
  );
}

