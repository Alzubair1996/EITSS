'use client';

import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Cell } from 'recharts';

const chartConfig = {
  sales: {
    label: 'المبيعات',
    color: 'hsl(var(--primary))',
  },
};

type SalesChartProps = {
  data: { month: string; sales: number }[];
};

export function SalesChart({ data }: SalesChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className="h-full w-full flex items-center justify-center text-sm text-muted-foreground">
        لا توجد بيانات مبيعات متوفرة حالياً لعرضها.
      </div>
    );
  }

  const maxVal = Math.max(...data.map((d) => d.sales));

  return (
    <ChartContainer config={chartConfig} className="h-full w-full min-h-[200px]">
      <BarChart
        data={data}
        margin={{ top: 4, right: 4, left: 4, bottom: 0 }}
        barCategoryGap="28%"
      >
        <defs>
          <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={1} />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0.45} />
          </linearGradient>
          <linearGradient id="barGradMuted" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.35} />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0.15} />
          </linearGradient>
        </defs>
        <CartesianGrid
          strokeDasharray="4 4"
          vertical={false}
          stroke="hsl(var(--border))"
          strokeOpacity={0.5}
        />
        <XAxis
          dataKey="month"
          tickLine={false}
          axisLine={false}
          tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))', fontFamily: 'Cairo, sans-serif' }}
          dy={8}
        />
        <YAxis
          tickLine={false}
          axisLine={false}
          tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))', fontFamily: 'Cairo, sans-serif' }}
          tickFormatter={(val) => (val >= 1000 ? `${(val / 1000).toFixed(0)}k` : String(val))}
          dx={-4}
          width={38}
        />
        <ChartTooltip
          cursor={{ fill: 'hsl(var(--primary) / .06)', radius: 6 }}
          content={
            <ChartTooltipContent
              className="bg-popover border border-border shadow-xl rounded-xl p-3 font-headline text-xs"
              labelFormatter={(label) => `شهر: ${label}`}
              formatter={(value) => [
                `${Math.round(Number(value)).toLocaleString('en-US')} SDG`,
                'المبيعات',
              ]}
            />
          }
        />
        <Bar dataKey="sales" radius={[6, 6, 0, 0]} maxBarSize={32}>
          {data.map((entry, index) => (
            <Cell
              key={`cell-${index}`}
              fill={entry.sales === maxVal ? 'url(#barGrad)' : 'url(#barGradMuted)'}
            />
          ))}
        </Bar>
      </BarChart>
    </ChartContainer>
  );
}
