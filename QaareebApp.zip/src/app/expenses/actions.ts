'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { Expense } from '@/lib/types';
import { randomUUID } from 'crypto';
import { getSession } from '@/lib/server-auth';

type AddExpenseData = Omit<Expense, 'id'>;

export async function addExpense(data: AddExpenseData) {
    if (data.amount <= 0) {
        return { success: false, message: 'مبلغ المصروف يجب أن يكون أكبر من صفر.' };
    }
    
    const db = await getDbInstance();
    // Get the current user performing this action
    const session = await getSession();
    const userId = session?.userId || null;
    try {
        await db.exec('BEGIN');

        // 1. Check if payment method has enough balance
        const paymentMethod = await db.get('SELECT balance FROM payment_methods WHERE id = ?', data.paymentMethodId) as { balance: number };
        if (!paymentMethod || paymentMethod.balance < data.amount) {
            throw new Error('الرصيد في طريقة الدفع غير كافٍ لتغطية المصروف.');
        }

        // 2. Insert into expenses table, including userId for auditing
        const newId = `exp_${randomUUID()}`;
        await db.run(`
            INSERT INTO expenses (id, description, amount, expenseDate, paymentMethodId, supplierId, userId)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `,
        newId,
        data.description,
        data.amount,
        data.expenseDate,
        data.paymentMethodId,
        data.supplierId || null,
        userId
        );

        // 3. Update payment method balance
        await db.run('UPDATE payment_methods SET balance = balance - ? WHERE id = ?', data.amount, data.paymentMethodId);

        // 4. Update supplier balance if applicable
        // Paying a supplier reduces our debt to them, so we subtract from their balance (which represents money we owe them)
        if (data.supplierId) {
            await db.run('UPDATE suppliers SET balance = balance - ? WHERE id = ?', data.amount, data.supplierId);
        }

        await db.exec('COMMIT');

        revalidatePath('/expenses');
        revalidatePath('/payment-methods');
        revalidatePath('/suppliers');
        revalidatePath('/'); // For dashboard stats if they include expenses later
        return { success: true, message: 'تم تسجيل المصروف بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to add expense:', e);
        return { success: false, message: e.message || 'فشل تسجيل المصروف.' };
    }
}


export async function deleteExpense(id: string) {
    const db = await getDbInstance();
    try {
        await db.exec('BEGIN');
        const expense = await db.get('SELECT * FROM expenses WHERE id = ?', id) as Expense;
        if (!expense) {
            throw new Error('المصروف غير موجود.');
        }

        // Revert payment method balance
        await db.run('UPDATE payment_methods SET balance = balance + ? WHERE id = ?', expense.amount, expense.paymentMethodId);

        // Revert supplier balance
        if (expense.supplierId) {
            await db.run('UPDATE suppliers SET balance = balance + ? WHERE id = ?', expense.amount, expense.supplierId);
        }

        // Delete the expense record
        await db.run('DELETE FROM expenses WHERE id = ?', id);

        await db.exec('COMMIT');

        revalidatePath('/expenses');
        revalidatePath('/payment-methods');
        revalidatePath('/suppliers');
        revalidatePath('/');
        return { success: true, message: 'تم حذف المصروف بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to delete expense:', e);
        return { success: false, message: e.message || 'فشل حذف المصروف.' };
    }
}
