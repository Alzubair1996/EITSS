
'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MoreHorizontal, Trash2, ReceiptText, TrendingDown } from 'lucide-react';
import type { ExpenseDetails } from '@/lib/types';
import { format } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import * as React from 'react';

interface ExpensesTableProps {
  expenses: ExpenseDetails[];
  onDelete: (expenseId: string) => void;
}

export function ExpensesTable({ expenses, onDelete }: ExpensesTableProps) {
  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);

  return (
    <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
      <CardHeader className="pb-4 border-b border-border/40 bg-secondary/10 flex flex-row justify-between items-center">
        <div>
          <CardTitle className="text-base font-bold text-foreground">سجل المصروفات</CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">تتبع النفقات التشغيلية ومصادرها</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-red-600 bg-red-50 dark:bg-red-500/10 px-3 py-1.5 rounded-full border border-red-200 dark:border-red-500/20">
            <TrendingDown className="h-3 w-3" />
            الإجمالي: {formatCurrency(totalExpenses)}
          </div>
          <div className="text-xs font-semibold text-muted-foreground bg-background px-3 py-1.5 rounded-full border border-border/40 shadow-sm">
            {expenses.length} مصروف
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>التاريخ</TableHead>
              <TableHead>الوصف</TableHead>
              <TableHead>الحساب المدفوع منه</TableHead>
              <TableHead>المورد</TableHead>
              <TableHead className="text-right">المبلغ</TableHead>
              <TableHead className="text-center">الإجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {expenses.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-40 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-4 rounded-2xl bg-muted/50">
                      <ReceiptText className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">لا توجد مصروفات</p>
                      <p className="text-sm text-muted-foreground mt-1">قم بتسجيل أول مصروف</p>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              expenses.map((expense) => (
                <TableRow key={expense.id} className="group">
                  <TableCell className="text-muted-foreground text-sm">
                    {format(new Date(expense.expenseDate), 'dd/MM/yyyy HH:mm')}
                  </TableCell>
                  <TableCell className="font-semibold">{expense.description}</TableCell>
                  <TableCell>
                    <Badge variant="info">{expense.paymentMethodName}</Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {expense.supplierName || '—'}
                  </TableCell>
                  <TableCell className="text-right">
                    <span className="font-mono font-bold text-red-600">
                      -{formatCurrency(expense.amount)}
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <AlertDialog>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            aria-haspopup="true"
                            size="icon"
                            variant="ghost"
                            className="rounded-full h-8 w-8 hover:bg-primary/5 hover:text-primary opacity-100 transition-all"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">فتح القائمة</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="rounded-xl shadow-lg border-border/50">
                          <AlertDialogTrigger asChild>
                            <DropdownMenuItem
                              onSelect={(e) => e.preventDefault()}
                              className="rounded-lg cursor-pointer text-destructive focus:text-destructive"
                            >
                              <Trash2 className="me-2 h-4 w-4" />
                              حذف المصروف
                            </DropdownMenuItem>
                          </AlertDialogTrigger>
                        </DropdownMenuContent>
                      </DropdownMenu>
                      <AlertDialogContent className="rounded-3xl">
                        <AlertDialogHeader>
                          <AlertDialogTitle>هل أنت متأكد؟</AlertDialogTitle>
                          <AlertDialogDescription>
                            سيتم حذف هذا المصروف نهائياً وإعادة المبلغ إلى الحساب الذي تم الخصم منه. لا يمكن التراجع عن هذا الإجراء.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="rounded-xl">إلغاء</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => onDelete(expense.id)}
                            className="rounded-xl bg-destructive hover:bg-destructive/90"
                          >
                            نعم، قم بالحذف
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
