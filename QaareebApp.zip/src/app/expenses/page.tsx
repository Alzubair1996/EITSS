import ExpensesClientPage from './expenses-client-page';
import { getExpenses, getPaymentMethods, getSuppliers } from '@/lib/queries';
import { getSession } from '@/lib/server-auth';

export default async function ExpensesPage() {
  const session = await getSession();
  // Determine if the current user is admin
  const isAdmin = session?.username === 'admin';
  const initialExpenses = await getExpenses();
  const paymentMethods = await getPaymentMethods();
  const suppliers = await getSuppliers();

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <ExpensesClientPage 
            initialExpenses={initialExpenses}
            paymentMethods={paymentMethods}
            suppliers={suppliers}
            isAdmin={isAdmin}
        />
      </div>
  );
}
