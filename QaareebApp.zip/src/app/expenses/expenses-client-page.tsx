'use client';

import * as React from 'react';
import { PlusCircle, Search, Coins, Wallet, Receipt, Filter, CalendarDays } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/page-header';
import { ExpensesTable } from './expenses-table';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { ExpenseForm } from './expense-form';
import type { ExpenseDetails, PaymentMethod, Supplier } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { addExpense, deleteExpense } from './actions';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface ExpensesClientPageProps {
  initialExpenses: ExpenseDetails[];
  paymentMethods: PaymentMethod[];
  suppliers: Supplier[];
  isAdmin: boolean;
}

export default function ExpensesClientPage({
  initialExpenses,
  paymentMethods,
  suppliers,
  isAdmin,
}: ExpensesClientPageProps) {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [paymentMethodFilter, setPaymentMethodFilter] = React.useState<string>('all');
  const [supplierFilter, setSupplierFilter] = React.useState<string>('all');
  const [dateFilter, setDateFilter] = React.useState<string>('all');
  
  const { toast } = useToast();
  const router = useRouter();

  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  const handleDelete = async (expenseId: string) => {
    const result = await deleteExpense(expenseId);
    if (result.success) {
      toast({ title: 'تم الحذف بنجاح', description: result.message });
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'خطأ في الحذف', description: result.message });
    }
  };

  const handleFormSubmit = async (values: any) => {
    const result = await addExpense(values);
    if (result.success) {
      toast({ title: 'تمت الإضافة بنجاح', description: result.message });
      setIsDialogOpen(false);
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }
  };

  const filteredExpenses = React.useMemo(() => {
    return initialExpenses.filter((expense) => {
      const matchSearch = expense.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchPM = paymentMethodFilter === 'all' || expense.paymentMethodId === paymentMethodFilter;
      const matchSupplier = supplierFilter === 'all' || expense.supplierId === supplierFilter;
      
      let matchDate = true;
      if (dateFilter !== 'all') {
        const expDate = new Date(expense.expenseDate);
        const now = new Date();
        const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        if (dateFilter === 'today') matchDate = expDate >= startOfToday;
        else if (dateFilter === 'week') {
          const oneWeekAgo = new Date(startOfToday.getTime() - 7 * 24 * 60 * 60 * 1000);
          matchDate = expDate >= oneWeekAgo;
        } else if (dateFilter === 'month') {
          const oneMonthAgo = new Date(startOfToday.getFullYear(), startOfToday.getMonth() - 1, startOfToday.getDate());
          matchDate = expDate >= oneMonthAgo;
        }
      }
      return matchSearch && matchPM && matchSupplier && matchDate;
    });
  }, [initialExpenses, searchTerm, paymentMethodFilter, supplierFilter, dateFilter]);

  const stats = React.useMemo(() => {
    const total = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
    const count = filteredExpenses.length;
    const methodBreakdown = filteredExpenses.reduce((acc: Record<string, number>, e) => {
      const name = e.paymentMethodName || 'أخرى';
      acc[name] = (acc[name] || 0) + e.amount;
      return acc;
    }, {});
    const mainMethod = Object.entries(methodBreakdown).sort((a, b) => b[1] - a[1])[0];
    const topMethodText = mainMethod ? `${mainMethod[0]}: ${formatCurrency(mainMethod[1])}` : '—';
    return { total, count, topMethodText };
  }, [filteredExpenses]);

  const statCards = [
    { label: 'إجمالي المصروفات', value: formatCurrency(stats.total), icon: Coins, color: 'text-red-600', bg: 'bg-red-500/8', border: 'border-red-500/20' },
    { label: 'عدد المعاملات', value: stats.count, icon: Receipt, color: 'text-primary', bg: 'bg-primary/8', border: 'border-primary/20' },
    { label: 'أعلى طريقة دفع', value: stats.topMethodText, icon: Wallet, color: 'text-emerald-600', bg: 'bg-emerald-500/8', border: 'border-emerald-500/20' },
  ];

  const hasFilters = paymentMethodFilter !== 'all' || supplierFilter !== 'all' || dateFilter !== 'all';

  return (
    <>
      <PageHeader title="إدارة المصروفات">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
            <Input
              type="search"
              placeholder="بحث بوصف المصروف..."
              className="pr-9 w-[180px] lg:w-[240px] h-9 rounded-xl bg-background border-border/60 text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button onClick={() => setIsDialogOpen(true)} size="sm" className="h-9 rounded-xl gap-1.5 px-4 shadow-sm">
            <PlusCircle className="h-3.5 w-3.5" />
            إضافة مصروف
          </Button>
        </div>
      </PageHeader>

      <div className="flex flex-col gap-4 p-4 md:p-6 max-w-screen-xl mx-auto w-full">

        {/* Compact Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {statCards.map((card, idx) => (
            <div key={idx} className={cn('rounded-xl border px-3 py-2.5 flex items-center gap-2.5 bg-card', card.border)}>
              <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center shrink-0', card.bg, card.color)}>
                <card.icon className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-muted-foreground font-medium leading-none mb-0.5 truncate">{card.label}</p>
                <p className="text-sm font-extrabold text-foreground leading-none truncate">{card.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Filter Strip */}
        <div className="flex flex-wrap items-center gap-2 bg-muted/20 px-4 py-2.5 rounded-xl border border-border/40">
          <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
          <span className="text-[11px] font-bold text-muted-foreground">تصفية:</span>

          <Select value={paymentMethodFilter} onValueChange={setPaymentMethodFilter}>
            <SelectTrigger className="w-[140px] bg-background border-border/60 rounded-lg text-[11px] h-7 font-medium">
              <SelectValue placeholder="طريقة الدفع" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل طرق الدفع</SelectItem>
              {paymentMethods.map(pm => (
                <SelectItem key={pm.id} value={pm.id}>{pm.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={supplierFilter} onValueChange={setSupplierFilter}>
            <SelectTrigger className="w-[140px] bg-background border-border/60 rounded-lg text-[11px] h-7 font-medium">
              <SelectValue placeholder="المورد" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الموردين</SelectItem>
              {suppliers.map(s => (
                <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex items-center gap-1">
            <CalendarDays className="h-3 w-3 text-muted-foreground" />
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger className="w-[120px] bg-background border-border/60 rounded-lg text-[11px] h-7 font-medium">
                <SelectValue placeholder="التاريخ" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل التواريخ</SelectItem>
                <SelectItem value="today">اليوم</SelectItem>
                <SelectItem value="week">آخر 7 أيام</SelectItem>
                <SelectItem value="month">آخر 30 يوم</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {hasFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => { setPaymentMethodFilter('all'); setSupplierFilter('all'); setDateFilter('all'); }}
              className="h-7 text-[11px] font-medium text-red-600 hover:text-red-700 rounded-lg px-2"
            >
              تصفير
            </Button>
          )}

          <span className="text-[10px] text-muted-foreground bg-background px-2 py-0.5 rounded-full font-medium border border-border/40 ml-auto">
            {filteredExpenses.length} نتيجة
          </span>
        </div>

        <ExpensesTable
          expenses={filteredExpenses}
          onDelete={handleDelete}
        />
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl">
          <ExpenseForm
            paymentMethods={paymentMethods}
            suppliers={suppliers}
            onSubmit={handleFormSubmit}
            onCancel={() => setIsDialogOpen(false)}
            isAdmin={isAdmin}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}
