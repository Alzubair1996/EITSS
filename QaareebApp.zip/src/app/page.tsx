import Link from 'next/link';
import {
  DollarSign,
  Users,
  AlertTriangle,
  BarChart2,
  Clock,
  ShoppingBag,
} from 'lucide-react';
import { PageHeader } from '@/components/page-header';
import { SalesChart } from './sales-chart';
import { getDashboardStats, getSalesForChart } from '@/lib/queries';

export default async function Dashboard() {
  const stats = await getDashboardStats();
  const salesData = await getSalesForChart();

  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  const maxSold =
    stats.topProducts?.length > 0
      ? Math.max(...stats.topProducts.map((p: any) => p.totalSold))
      : 1;

  const today = new Date().toLocaleDateString('ar-EG', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const statCards = [
    {
      href: '/transactions',
      label: 'إجمالي الإيرادات',
      value: formatCurrency(stats.totalRevenue),
      sub: 'إيرادات هذا الشهر ↑',
      Icon: DollarSign,
      iconBg: 'bg-emerald-500/12',
      iconColor: 'text-emerald-600 dark:text-emerald-400',
      hoverBorder: 'hover:border-emerald-400/30',
    },
    {
      href: '/reports',
      label: 'إجمالي الأرباح',
      value: formatCurrency(stats.totalProfit),
      sub: 'صافي الأرباح',
      Icon: BarChart2,
      iconBg: 'bg-primary/10',
      iconColor: 'text-primary',
      hoverBorder: 'hover:border-primary/30',
    },
    {
      href: '/products',
      label: 'منخفضة المخزون',
      value: String(stats.lowStockCount),
      sub: '5 وحدات أو أقل',
      Icon: AlertTriangle,
      iconBg: 'bg-amber-500/12',
      iconColor: 'text-amber-600 dark:text-amber-400',
      hoverBorder: 'hover:border-amber-400/30',
    },
    {
      href: '/customers',
      label: 'إجمالي العملاء',
      value: String(stats.totalCustomers),
      sub: 'عملاء مسجلون',
      Icon: Users,
      iconBg: 'bg-cyan-500/12',
      iconColor: 'text-cyan-600 dark:text-cyan-400',
      hoverBorder: 'hover:border-cyan-400/30',
    },
  ];

  return (
    <div className="flex flex-1 flex-col gap-5 p-4 md:p-7 max-w-screen-xl mx-auto w-full">

      {/* Page Title */}
      <PageHeader title="لوحة التحكم" />

      {/* ── Welcome Banner ── */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-l from-[hsl(250,80%,46%)] via-[hsl(240,75%,50%)] to-[hsl(228,68%,44%)] px-6 py-5 md:px-8 md:py-6 text-white shadow-xl shadow-primary/20">
        <div className="pointer-events-none absolute -top-14 -left-14 h-52 w-52 rounded-full bg-white/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-12 -right-10 h-52 w-52 rounded-full bg-white/10 blur-3xl" />
        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl md:text-2xl font-extrabold font-headline mb-1 tracking-tight">
              مرحباً بك مجدداً 👋
            </h2>
            <p className="text-sm text-white/75 max-w-lg leading-relaxed">
              نظرة سريعة على أداء عملك اليوم. تحكم بالمبيعات والمخزون والحسابات.
            </p>
          </div>
          <div className="shrink-0 flex items-center gap-2 bg-white/15 backdrop-blur-sm px-4 py-2 rounded-xl border border-white/20 text-sm font-semibold self-start sm:self-auto">
            <Clock className="w-4 h-4 opacity-75" />
            <span>{today}</span>
          </div>
        </div>
      </div>

      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {statCards.map((c) => (
          <Link key={c.label} href={c.href} className="group block">
            <div className={`rounded-2xl border border-border/60 bg-card p-5 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md ${c.hoverBorder}`}>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-muted-foreground leading-snug">{c.label}</span>
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${c.iconBg} ${c.iconColor} transition-transform duration-200 group-hover:scale-110`}>
                  <c.Icon className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-extrabold tracking-tight text-foreground font-sans mb-1 leading-none">
                {c.value}
              </div>
              <div className={`text-[11px] font-semibold ${c.iconColor} opacity-80`}>{c.sub}</div>
            </div>
          </Link>
        ))}
      </div>

      {/* ── Analytics Grid ── */}
      <div className="grid gap-5 lg:grid-cols-3">

        {/* Sales Chart Card */}
        <div className="lg:col-span-2 rounded-2xl border border-border/60 bg-card shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-border/50">
            <div>
              <p className="font-bold text-sm text-foreground">تحليل أداء المبيعات</p>
              <p className="text-xs text-muted-foreground mt-0.5">رسم بياني لمبيعات آخر 12 شهر</p>
            </div>
            <span className="inline-flex items-center gap-1.5 text-xs font-bold text-primary bg-primary/10 px-3 py-1.5 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              مباشر
            </span>
          </div>
          <div className="p-5 h-72">
            <SalesChart data={salesData} />
          </div>
        </div>

        {/* Right Widgets Column */}
        <div className="flex flex-col gap-5">

          {/* Top Products */}
          <div className="rounded-2xl border border-border/60 bg-card shadow-sm flex-1 flex flex-col">
            <div className="px-5 py-4 border-b border-border/50">
              <p className="font-bold text-sm text-foreground">الأكثر مبيعاً</p>
              <p className="text-xs text-muted-foreground mt-0.5">الأصناف الأعلى طلباً</p>
            </div>
            <div className="p-5 flex-1">
              {stats.topProducts?.length > 0 ? (
                <ul className="space-y-4">
                  {stats.topProducts.map((product: any) => {
                    const pct = Math.round((product.totalSold / maxSold) * 100);
                    return (
                      <li key={product.productId} className="space-y-1.5">
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2 font-semibold text-foreground min-w-0">
                            <span className="w-2 h-2 rounded-full bg-primary shrink-0" />
                            <span className="truncate">{product.productName}</span>
                          </div>
                          <span className="text-xs font-bold text-muted-foreground shrink-0 ml-2">
                            {product.totalSold} وحدة
                          </span>
                        </div>
                        <div className="h-1.5 w-full bg-secondary rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full bg-gradient-to-l from-primary to-primary/50 transition-all duration-700"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center h-full">
                  <ShoppingBag className="w-8 h-8 text-muted-foreground/30 mb-2" />
                  <p className="text-sm text-muted-foreground">لا توجد بيانات مبيعات</p>
                </div>
              )}
            </div>
          </div>

          {/* Peak Hours */}
          <div className="rounded-2xl border border-border/60 bg-card shadow-sm">
            <div className="px-5 py-4 border-b border-border/50">
              <p className="font-bold text-sm text-foreground">أوقات الذروة</p>
              <p className="text-xs text-muted-foreground mt-0.5">الساعات الأعلى نشاطاً</p>
            </div>
            <div className="p-4">
              {stats.peakHours?.length > 0 ? (
                <div className="space-y-2">
                  {stats.peakHours.map((hourObj: any, idx: number) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between px-3 py-2.5 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors duration-150"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-7 h-7 rounded-lg bg-primary/10 text-primary text-xs font-bold flex items-center justify-center font-sans shrink-0">
                          {idx + 1}
                        </span>
                        <span className="text-sm font-semibold text-foreground font-sans">
                          {hourObj.hour}:00
                        </span>
                      </div>
                      <span className="text-sm font-bold text-foreground font-sans">
                        {formatCurrency(hourObj.total)}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <Clock className="w-8 h-8 text-muted-foreground/30 mb-2" />
                  <p className="text-sm text-muted-foreground">لا توجد بيانات كافية</p>
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
