'use server';

import { getPurchaseInvoiceDetails } from '@/lib/queries';
import { getDbInstance } from '@/lib/db';

export async function getInvoiceDetailsAction(invoiceId: string) {
    try {
        const invoice = await getPurchaseInvoiceDetails(invoiceId);
        if (!invoice) {
            return { success: false, message: 'فاتورة الشراء غير موجودة.' };
        }

        const db = await getDbInstance();

        // Get returned items for this invoice
        const returnedItems = await db.all(`
            SELECT pri.productId, pri.rawMaterialId, pri.quantity
            FROM purchase_return_items pri
            JOIN purchase_returns pr ON pri.purchaseReturnId = pr.id
            WHERE pr.purchaseInvoiceId = ?
        `, invoiceId) as { productId: string | null; rawMaterialId: string | null; quantity: number }[];

        // Calculate already returned quantities by item (productId or rawMaterialId)
        const returnedByItem: Record<string, number> = {};
        returnedItems.forEach(item => {
            const key = item.productId || item.rawMaterialId;
            if (key) {
                returnedByItem[key] = (returnedByItem[key] || 0) + item.quantity;
            }
        });

        // Add remaining quantity to each item in the invoice
        const updatedItems = invoice.items.map((item) => {
            const key = item.productId || item.rawMaterialId;
            const returnedQuantity = key ? (returnedByItem[key] || 0) : 0;
            const remainingQuantity = Math.max(0, item.quantity - returnedQuantity);
            return {
                ...item,
                returnedQuantity,
                remainingQuantity
            };
        });

        return { 
            success: true, 
            data: { 
                ...invoice, 
                items: updatedItems 
            } 
        };
    } catch (error) {
        console.error("Failed to fetch invoice details:", error);
        return { success: false, message: 'فشل جلب تفاصيل الفاتورة.' };
    }
}

