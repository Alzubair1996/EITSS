import PurchaseReturnsClientPage from './purchase-returns-client-page';
import { getPurchaseReturns, getPurchaseInvoices } from '@/lib/queries';

export default async function PurchaseReturnsPage() {
  const purchaseReturns = await getPurchaseReturns();
  const purchaseInvoices = await getPurchaseInvoices();

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <PurchaseReturnsClientPage 
            initialReturns={purchaseReturns}
            purchaseInvoices={purchaseInvoices}
        />
      </div>
  );
}

