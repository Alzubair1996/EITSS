'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { PurchaseReturnItem } from '@/lib/types';
import { randomUUID } from 'crypto';
import { getSession } from '@/lib/server-auth';
import { IS_RESTAURANT_APP } from '@/lib/types';

interface PurchaseReturnItemInput {
    productId?: string | null;
    rawMaterialId?: string | null;
    quantity: number;
    costPrice: number;
}

interface CreatePurchaseReturnInput {
    purchaseInvoiceId: string;
    returnDate: string;
    items: PurchaseReturnItemInput[];
    reason?: string;
}

export async function createPurchaseReturn(data: CreatePurchaseReturnInput) {
    const { purchaseInvoiceId, returnDate, items, reason } = data;

    if (!purchaseInvoiceId || items.length === 0) {
        return { success: false, message: 'يجب اختيار فاتورة الشراء وإضافة أصناف للإرجاع.' };
    }
    
    const db = await getDbInstance();
    const session = await getSession();
    const userId = session?.userId || null;

    try {
        await db.exec('BEGIN');

        // 1. Get the purchase invoice
        const purchaseInvoice = await db.get('SELECT * FROM purchase_invoices WHERE id = ?', purchaseInvoiceId) as any;
        if (!purchaseInvoice) {
            throw new Error('فاتورة الشراء غير موجودة.');
        }

        // 2. Calculate total amount
        const totalAmount = items.reduce((sum, item) => sum + item.quantity * item.costPrice, 0);
        if (totalAmount <= 0) {
            throw new Error('مبلغ المرتجع يجب أن يكون أكبر من صفر.');
        }

        // 3. Verify that all returned items exist in the purchase invoice
        const invoiceItems = await db.all('SELECT * FROM purchase_invoice_items WHERE purchaseInvoiceId = ?', purchaseInvoiceId) as any[];
        
        // Check if there are already returns for this invoice
        const existingReturns = await db.all('SELECT * FROM purchase_returns WHERE purchaseInvoiceId = ?', purchaseInvoiceId) as any[];
        const returnedItems = await db.all(`
            SELECT pri.* FROM purchase_return_items pri
            JOIN purchase_returns pr ON pri.purchaseReturnId = pr.id
            WHERE pr.purchaseInvoiceId = ?
        `, purchaseInvoiceId) as any[];

        // Calculate already returned quantities by item
        const returnedByItem: { [key: string]: number } = {};
        returnedItems.forEach(item => {
            const key = item.productId || item.rawMaterialId;
            if (key) {
                returnedByItem[key] = (returnedByItem[key] || 0) + item.quantity;
            }
        });

        // Verify new returns don't exceed purchased quantities
        for (const returnItem of items) {
            const invoiceItem = invoiceItems.find(item => 
                (returnItem.productId && item.productId === returnItem.productId) ||
                (returnItem.rawMaterialId && item.rawMaterialId === returnItem.rawMaterialId)
            );

            if (!invoiceItem) {
                throw new Error('أحد الأصناف المختارة للإرجاع غير موجود في فاتورة الشراء.');
            }

            const key = returnItem.productId || returnItem.rawMaterialId;
            const alreadyReturned = returnedByItem[key] || 0;
            const newReturnQty = returnItem.quantity;

            if (alreadyReturned + newReturnQty > invoiceItem.quantity) {
                throw new Error('الكمية المراد إرجاعها تتجاوز الكمية المتبقية من الشراء.');
            }
        }

        // 4. Generate return number
        const returnNumber = await getNextPurchaseReturnNumber(db);

        // 5. Insert into purchase_returns table
        const purchaseReturnId = `ret_${randomUUID()}`;
        await db.run(`
            INSERT INTO purchase_returns (id, purchaseInvoiceId, returnNumber, returnDate, totalAmount, reason, status, userId)
            VALUES (?, ?, ?, ?, ?, ?, 'completed', ?)
        `, purchaseReturnId, purchaseInvoiceId, returnNumber, returnDate, totalAmount, reason || null, userId);

        // 6. Insert items and update product stock (decrease it)
        for (const item of items) {
            await db.run('INSERT INTO purchase_return_items (id, purchaseReturnId, productId, rawMaterialId, quantity, costPrice) VALUES (?, ?, ?, ?, ?, ?)', 
            `ret_item_${randomUUID()}`, 
            purchaseReturnId, 
            item.productId || null,
            item.rawMaterialId || null,
            item.quantity, 
            item.costPrice
            );

            if (IS_RESTAURANT_APP && item.rawMaterialId) {
                await db.run('UPDATE raw_materials SET quantityInStock = quantityInStock - ? WHERE id = ?', item.quantity, item.rawMaterialId);
            } else if (!IS_RESTAURANT_APP && item.productId) {
                await db.run('UPDATE products SET quantity = quantity - ? WHERE id = ?', item.quantity, item.productId);
            }
        }
        
        // 7. Update supplier balance (reduce our debt to them)
        await db.run('UPDATE suppliers SET balance = balance - ? WHERE id = ?', totalAmount, purchaseInvoice.supplierId);

        await db.exec('COMMIT');

        revalidatePath('/purchase-returns');
        revalidatePath('/purchases');
        if(IS_RESTAURANT_APP) {
            revalidatePath('/materials');
        } else {
            revalidatePath('/products');
        }
        revalidatePath('/suppliers');
        revalidatePath('/');
        return { success: true, message: 'تم إرجاع المشتريات بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to create purchase return:', e);
        return { success: false, message: e.message || 'فشل إرجاع المشتريات.' };
    }
}

async function getNextPurchaseReturnNumber(db: any): Promise<string> {
    try {
        const lastReturn = await db.get('SELECT returnNumber FROM purchase_returns ORDER BY returnDate DESC, id DESC LIMIT 1') as { returnNumber: string } | undefined;
        
        if (!lastReturn || !lastReturn.returnNumber) {
            const year = new Date().getFullYear();
            return `RET-${year}-001`;
        }
        
        const match = lastReturn.returnNumber.match(/^RET-(\d{4})-(\d{3})$/);
        if (!match) {
            const year = new Date().getFullYear();
            return `RET-${year}-001`;
        }
        
        const [, year, num] = match;
        const currentYear = new Date().getFullYear().toString();
        const nextNum = year === currentYear ? String(parseInt(num) + 1).padStart(3, '0') : '001';
        
        return `RET-${currentYear}-${nextNum}`;
    } catch (error) {
        console.error("Failed to get next purchase return number:", error);
        const year = new Date().getFullYear();
        return `RET-${year}-001`;
    }
}

export async function deletePurchaseReturn(returnId: string) {
    const db = await getDbInstance();
    try {
        await db.exec('BEGIN');
        
        const purchaseReturn = await db.get('SELECT * FROM purchase_returns WHERE id = ?', returnId) as any;
        if (!purchaseReturn) {
            throw new Error('المرتجع غير موجود.');
        }

        // Get all items to revert stock changes
        const items = await db.all('SELECT * FROM purchase_return_items WHERE purchaseReturnId = ?', returnId) as any[];

        // Get purchase invoice to revert supplier balance
        const purchaseInvoice = await db.get('SELECT * FROM purchase_invoices WHERE id = ?', purchaseReturn.purchaseInvoiceId) as any;

        // Revert stock changes
        for (const item of items) {
            if (IS_RESTAURANT_APP && item.rawMaterialId) {
                await db.run('UPDATE raw_materials SET quantityInStock = quantityInStock + ? WHERE id = ?', item.quantity, item.rawMaterialId);
            } else if (!IS_RESTAURANT_APP && item.productId) {
                await db.run('UPDATE products SET quantity = quantity + ? WHERE id = ?', item.quantity, item.productId);
            }
        }

        // Revert supplier balance
        if (purchaseInvoice) {
            await db.run('UPDATE suppliers SET balance = balance + ? WHERE id = ?', purchaseReturn.totalAmount, purchaseInvoice.supplierId);
        }

        // Delete the return and its items (CASCADE will handle this)
        await db.run('DELETE FROM purchase_returns WHERE id = ?', returnId);

        await db.exec('COMMIT');

        revalidatePath('/purchase-returns');
        revalidatePath('/purchases');
        if(IS_RESTAURANT_APP) {
            revalidatePath('/materials');
        } else {
            revalidatePath('/products');
        }
        revalidatePath('/suppliers');
        revalidatePath('/');
        return { success: true, message: 'تم حذف المرتجع بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to delete purchase return:', e);
        return { success: false, message: e.message || 'فشل حذف المرتجع.' };
    }
}

