
'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MoreHorizontal, Trash2, RotateCcw } from 'lucide-react';
import type { PurchaseReturnDetails } from '@/lib/types';
import { format } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import * as React from 'react';

interface PurchaseReturnsTableProps {
  returns: PurchaseReturnDetails[];
  onDelete: (returnId: string) => void;
}

export function PurchaseReturnsTable({ returns, onDelete }: PurchaseReturnsTableProps) {
  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  const totalReturned = returns.reduce((sum, r) => sum + r.totalAmount, 0);

  const statusConfig: Record<string, { text: string; variant: 'success' | 'info' | 'warning' }> = {
    completed: { text: 'مكتمل', variant: 'success' },
    approved: { text: 'موافق عليه', variant: 'info' },
    pending: { text: 'قيد الانتظار', variant: 'warning' },
  };

  return (
    <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
      <CardHeader className="pb-4 border-b border-border/40 bg-secondary/10 flex flex-row justify-between items-center">
        <div>
          <CardTitle className="text-base font-bold text-foreground">سجل مرتجعات المشتريات</CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">تتبع البضاعة المرتجعة للموردين</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="text-xs font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-200 dark:border-emerald-500/20">
            الإجمالي المسترد: {formatCurrency(totalReturned)}
          </div>
          <div className="text-xs font-semibold text-muted-foreground bg-background px-3 py-1.5 rounded-full border border-border/40 shadow-sm">
            {returns.length} مرتجع
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>رقم المرتجع</TableHead>
              <TableHead>المورد</TableHead>
              <TableHead>رقم الفاتورة</TableHead>
              <TableHead>التاريخ</TableHead>
              <TableHead className="text-right">المبلغ</TableHead>
              <TableHead>الحالة</TableHead>
              <TableHead className="text-center">الإجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {returns.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-40 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-4 rounded-2xl bg-muted/50">
                      <RotateCcw className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">لا توجد مرتجعات</p>
                      <p className="text-sm text-muted-foreground mt-1">لم يتم تسجيل أي مرتجعات حتى الآن</p>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              returns.map((returnRecord) => {
                const status = statusConfig[returnRecord.status] || { text: returnRecord.status, variant: 'warning' as const };
                return (
                  <TableRow key={returnRecord.id} className="group">
                    <TableCell className="font-mono font-bold text-foreground">{returnRecord.returnNumber || '—'}</TableCell>
                    <TableCell className="font-semibold">{returnRecord.supplierName}</TableCell>
                    <TableCell className="font-mono text-sm text-muted-foreground">{returnRecord.invoiceNumber || '—'}</TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {format(new Date(returnRecord.returnDate), 'dd/MM/yyyy')}
                    </TableCell>
                    <TableCell className="text-right font-mono font-bold text-emerald-600">
                      {formatCurrency(returnRecord.totalAmount)}
                    </TableCell>
                    <TableCell>
                      <Badge variant={status.variant}>{status.text}</Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <AlertDialog>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              aria-haspopup="true"
                              size="icon"
                              variant="ghost"
                              className="rounded-full h-8 w-8 hover:bg-primary/5 hover:text-primary opacity-60 group-hover:opacity-100 transition-all"
                            >
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">فتح القائمة</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="rounded-xl shadow-lg border-border/50">
                            <AlertDialogTrigger asChild>
                              <DropdownMenuItem
                                onSelect={(e) => e.preventDefault()}
                                className="rounded-lg cursor-pointer text-destructive focus:text-destructive"
                              >
                                <Trash2 className="me-2 h-4 w-4" />
                                حذف المرتجع
                              </DropdownMenuItem>
                            </AlertDialogTrigger>
                          </DropdownMenuContent>
                        </DropdownMenu>
                        <AlertDialogContent className="rounded-3xl">
                          <AlertDialogHeader>
                            <AlertDialogTitle>هل أنت متأكد؟</AlertDialogTitle>
                            <AlertDialogDescription>
                              سيتم حذف المرتجع نهائياً وإعادة الكميات إلى المخزون وإعادة رصيد المورد. لا يمكن التراجع عن هذا الإجراء.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel className="rounded-xl">إلغاء</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => onDelete(returnRecord.id)}
                              className="rounded-xl bg-destructive hover:bg-destructive/90"
                            >
                              نعم، قم بالحذف
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
