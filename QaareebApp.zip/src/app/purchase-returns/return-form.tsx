
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { LoaderCircle, Trash2, ShoppingCart } from 'lucide-react';
import type { PurchaseInvoiceDetails } from '@/lib/types';
import { getInvoiceDetailsAction } from './actions-get-invoice';
import { cn } from '@/lib/utils';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

interface ReturnFormProps {
  purchaseInvoices: PurchaseInvoiceDetails[];
  onSubmit: (values: any) => void;
  onCancel: () => void;
}

type CartItem = {
    id: string;
    type: 'product' | 'material';
    productId?: string | null;
    rawMaterialId?: string | null;
    name: string;
    quantity: number | string;
    maxQuantity: number;
    costPrice: number;
    originalItemId: string;
};

export function ReturnForm({ purchaseInvoices, onSubmit, onCancel }: ReturnFormProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = React.useState(false);
  const [loadingInvoice, setLoadingInvoice] = React.useState(false);
  const [selectedInvoiceId, setSelectedInvoiceId] = React.useState<string>('');
  const [invoiceItems, setInvoiceItems] = React.useState<any[]>([]);
  const [cart, setCart] = React.useState<CartItem[]>([]);
  const [reason, setReason] = React.useState('');
  const [returnNumber, setReturnNumber] = React.useState('');
  const [invoiceSearchQuery, setInvoiceSearchQuery] = React.useState('');
  const [isInvoicePopoverOpen, setIsInvoicePopoverOpen] = React.useState(false);

  const filteredInvoices = React.useMemo(() => {
    if (!invoiceSearchQuery) return purchaseInvoices;
    const query = invoiceSearchQuery.toLowerCase();
    return purchaseInvoices.filter(invoice => 
      (invoice.invoiceNumber && invoice.invoiceNumber.toLowerCase().includes(query)) ||
      (invoice.supplierName && invoice.supplierName.toLowerCase().includes(query)) ||
      (invoice.id && invoice.id.toLowerCase().includes(query))
    );
  }, [purchaseInvoices, invoiceSearchQuery]);

  React.useEffect(() => {
    if (!selectedInvoiceId) {
      setInvoiceItems([]);
      setCart([]);
      return;
    }

    async function loadInvoiceDetails() {
      setLoadingInvoice(true);
      try {
        const result = await getInvoiceDetailsAction(selectedInvoiceId);
        if (result.success && result.data && result.data.items) {
          setInvoiceItems(result.data.items);
        } else {
          toast({
            variant: 'destructive',
            title: 'خطأ',
            description: result.message || 'فشل تحميل فاتورة الشراء.',
          });
        }
      } catch (error) {
        console.error('Failed to load invoice details:', error);
        toast({
          variant: 'destructive',
          title: 'خطأ',
          description: 'فشل تحميل فاتورة الشراء.',
        });
      }
      setLoadingInvoice(false);
    }

    loadInvoiceDetails();
  }, [selectedInvoiceId, toast]);

  const formatCurrency = (num: number) => {
    return Math.round(num).toLocaleString('en-US');
  };

  const totalAmount = React.useMemo(() => {
    return cart.reduce((sum, item) => sum + (Number(item.quantity) || 0) * item.costPrice, 0);
  }, [cart]);

  const handleAddItem = (item: any) => {
    // Check if already in cart
    const existingIndex = cart.findIndex(cartItem => cartItem.originalItemId === item.id);
    
    if (existingIndex >= 0) {
      // Already in cart, just update quantity if needed
      return;
    }

    // Add to cart with the name from the item
    const itemName = item.productName || item.rawMaterialName || (item.productId || item.rawMaterialId || '');
    setCart((prevCart) => [
      ...prevCart,
      {
        id: item.productId || item.rawMaterialId || '',
        type: item.productId ? 'product' : 'material',
        productId: item.productId || null,
        rawMaterialId: item.rawMaterialId || null,
        name: itemName,
        quantity: Math.min(1, item.remainingQuantity !== undefined ? item.remainingQuantity : item.quantity),
        maxQuantity: item.remainingQuantity !== undefined ? item.remainingQuantity : item.quantity,
        costPrice: item.costPrice,
        originalItemId: item.id,
      },
    ]);
  };

  const handleQuantityChange = (cartItemId: string, newQuantity: number | string) => {
    setCart((prevCart) =>
      prevCart.map((item) => {
        if (item.originalItemId === cartItemId) {
          let val = newQuantity;
          if (typeof val === 'string') {
            if (val === '') return { ...item, quantity: '' };
            const num = Number(val);
            if (!isNaN(num)) val = Math.max(0, Math.min(num, item.maxQuantity));
          } else if (typeof val === 'number') {
            val = Math.max(0, Math.min(val, item.maxQuantity));
          }
          return { ...item, quantity: val };
        }
        return item;
      })
    );
  };

  const handleRemoveItem = (cartItemId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.originalItemId !== cartItemId));
  };

  const handleSubmit = async () => {
    if (!selectedInvoiceId) {
      toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى اختيار فاتورة الشراء.' });
      return;
    }
    if (cart.length === 0) {
      toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى إضافة أصناف للإرجاع.' });
      return;
    }

    const hasValidQuantities = cart.some(item => Number(item.quantity) > 0);
    if (!hasValidQuantities) {
      toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى تحديد كميات للإرجاع.' });
      return;
    }

    setIsLoading(true);

    const itemsToReturn = cart.filter(item => Number(item.quantity) > 0).map(item => ({
      productId: item.productId || null,
      rawMaterialId: item.rawMaterialId || null,
      quantity: Number(item.quantity),
      costPrice: item.costPrice,
    }));

    onSubmit({
      purchaseInvoiceId: selectedInvoiceId,
      returnDate: new Date().toISOString(),
      items: itemsToReturn,
      reason,
    });

    setIsLoading(false);
  };

  return (
    <>
      <DialogHeader>
        <DialogTitle>إرجاع بضاعة لمورد</DialogTitle>
        <DialogDescription>
          اختر فاتورة الشراء وقم بإضافة الأصناف المراد إرجاعها
        </DialogDescription>
      </DialogHeader>

      <div className="py-4 space-y-4">
        <div className="grid grid-cols-1 gap-4">
          <div>
            <Label>فاتورة الشراء</Label>
            <Popover open={isInvoicePopoverOpen} onOpenChange={setIsInvoicePopoverOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={isInvoicePopoverOpen}
                  className="w-full justify-between text-right font-normal h-11 px-3 rounded-xl border-border/80"
                >
                  {selectedInvoiceId ? (
                    (() => {
                      const selectedInvoice = purchaseInvoices.find(invoice => invoice.id === selectedInvoiceId);
                      return selectedInvoice 
                        ? `${selectedInvoice.invoiceNumber || 'بدون رقم'} - ${selectedInvoice.supplierName} (${new Date(selectedInvoice.issueDate).toLocaleDateString('ar-SA')})` 
                        : 'اختر فاتورة الشراء';
                    })()
                  ) : (
                    <span className="text-muted-foreground">ابحث أو اختر فاتورة الشراء...</span>
                  )}
                  <span className="text-muted-foreground text-[10px]">▼</span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-0" align="start">
                <div className="flex flex-col min-h-0 max-h-[300px]">
                  <div className="p-2 border-b border-border/50 bg-secondary/20">
                    <Input
                      placeholder="ابحث برقم الفاتورة أو اسم المورد..."
                      value={invoiceSearchQuery}
                      onChange={(e) => setInvoiceSearchQuery(e.target.value)}
                      className="text-right h-9 rounded-lg"
                      autoFocus
                    />
                  </div>
                  <div className="flex-1 overflow-y-auto p-1 divide-y divide-border/20">
                    {filteredInvoices.length > 0 ? (
                      filteredInvoices.map((invoice) => (
                        <button
                          key={invoice.id}
                          type="button"
                          onClick={() => {
                            setSelectedInvoiceId(invoice.id);
                            setIsInvoicePopoverOpen(false);
                            setInvoiceSearchQuery('');
                          }}
                          className={cn(
                            "w-full text-right px-3 py-2 text-sm rounded-lg hover:bg-primary/5 hover:text-primary transition-all flex flex-col gap-0.5",
                            selectedInvoiceId === invoice.id && "bg-primary/10 text-primary font-bold"
                          )}
                        >
                          <div className="flex justify-between w-full">
                            <span className="font-semibold">{invoice.invoiceNumber || 'بدون رقم'}</span>
                            <span className="text-xs text-muted-foreground">{new Date(invoice.issueDate).toLocaleDateString('ar-SA')}</span>
                          </div>
                          <span className="text-xs text-muted-foreground">{invoice.supplierName}</span>
                        </button>
                      ))
                    ) : (
                      <div className="text-center py-6 text-sm text-muted-foreground font-semibold">
                        لم يتم العثور على فواتير شراء.
                      </div>
                    )}
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>

        {loadingInvoice && (
          <div className="flex items-center justify-center p-8">
            <LoaderCircle className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        )}

        {!loadingInvoice && invoiceItems.length > 0 && (
          <div className="space-y-4">
            <div>
              <Label>أصناف فاتورة الشراء</Label>
              <div className="rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>المنتج/المادة</TableHead>
                      <TableHead className="text-center">الكمية المشتراة</TableHead>
                      <TableHead className="text-center">سعر الشراء</TableHead>
                      <TableHead className="text-center">الإجراء</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {invoiceItems.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">
                          {item.productName || item.rawMaterialName || item.productId || item.rawMaterialId || '—'}
                        </TableCell>
                        <TableCell className="text-center">
                          <span className="font-semibold">{item.quantity}</span>
                          {item.returnedQuantity !== undefined && item.returnedQuantity > 0 && (
                            <div className="text-xs text-amber-600 dark:text-amber-500 font-medium mt-1">
                              (المتبقي: {item.remainingQuantity} | تم إرجاع: {item.returnedQuantity})
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="text-center">{formatCurrency(item.costPrice)} SDG</TableCell>
                        <TableCell className="text-center">
                          {cart.findIndex(cartItem => cartItem.originalItemId === item.id) < 0 ? (
                            item.remainingQuantity !== undefined && item.remainingQuantity <= 0 ? (
                              <span className="text-xs text-muted-foreground font-semibold">تم إرجاعها بالكامل</span>
                            ) : (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleAddItem(item)}
                              >
                                إضافة للإرجاع
                              </Button>
                            )
                          ) : (
                            <span className="text-green-600 font-semibold text-sm">أضيف للإرجاع</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        )}

        {cart.length > 0 && (
          <div className="space-y-4">
            <div>
              <Label>الأصناف المراد إرجاعها</Label>
              <div className="rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>المنتج/المادة</TableHead>
                      <TableHead className="text-center">الكمية المراد إرجاعها</TableHead>
                      <TableHead className="text-center">سعر الشراء</TableHead>
                      <TableHead className="text-center">الإجمالي</TableHead>
                      <TableHead className="text-center">الإجراء</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cart.map((item) => (
                      <TableRow key={item.originalItemId}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell className="text-center">
                          <Input
                            type="number"
                            min="0"
                            max={item.maxQuantity}
                            value={item.quantity}
                            onChange={(e) => handleQuantityChange(item.originalItemId, e.target.value)}
                            className="w-24 mx-auto text-center font-bold"
                          />
                        </TableCell>
                        <TableCell className="text-center">{formatCurrency(item.costPrice)} SDG</TableCell>
                        <TableCell className="text-center">{formatCurrency((Number(item.quantity) || 0) * item.costPrice)} SDG</TableCell>
                        <TableCell className="text-center">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleRemoveItem(item.originalItemId)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            <div className="flex justify-end items-center gap-4 p-4 bg-muted rounded-lg">
              <div className="text-lg font-semibold">
                الإجمالي: {formatCurrency(totalAmount)} SDG
              </div>
            </div>

            <div>
              <Label>سبب الإرجاع (اختياري)</Label>
              <Textarea
                placeholder="اذكر سبب الإرجاع..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                rows={3}
              />
            </div>
          </div>
        )}
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          إلغاء
        </Button>
        <Button onClick={handleSubmit} disabled={isLoading || cart.length === 0}>
          {isLoading && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
          تأكيد الإرجاع
        </Button>
      </DialogFooter>
    </>
  );
}

