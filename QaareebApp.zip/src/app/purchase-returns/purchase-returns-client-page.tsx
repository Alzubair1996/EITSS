'use client';

import * as React from 'react';
import { PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/page-header';
import { PurchaseReturnsTable } from './purchase-returns-table';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { ReturnForm } from './return-form';
import type { PurchaseReturnDetails, PurchaseInvoiceDetails } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { createPurchaseReturn, deletePurchaseReturn } from './actions';
import { useRouter } from 'next/navigation';

interface PurchaseReturnsClientPageProps {
  initialReturns: PurchaseReturnDetails[];
  purchaseInvoices: PurchaseInvoiceDetails[];
}

export default function PurchaseReturnsClientPage({ initialReturns, purchaseInvoices }: PurchaseReturnsClientPageProps) {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const { toast } = useToast();
  const router = useRouter();

  const handleDelete = async (returnId: string) => {
    const result = await deletePurchaseReturn(returnId);
    if (result.success) {
      toast({
        title: 'تم الحذف بنجاح',
        description: result.message,
      });
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ في الحذف',
        description: result.message,
      });
    }
  };

  const handleFormSubmit = async (values: any) => {
    const result = await createPurchaseReturn(values);

    if (result.success) {
      toast({
        title: 'تم الإرجاع بنجاح',
        description: result.message,
      });
      setIsDialogOpen(false);
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ',
        description: result.message,
      });
    }
  };

  return (
    <>
      <PageHeader title="مرتجعات المشتريات">
        <Button onClick={() => setIsDialogOpen(true)} className="shadow-md hover:shadow-lg transition-shadow">
          <PlusCircle className="me-2 h-4 w-4" />
          إرجاع بضاعة
        </Button>
      </PageHeader>
      <PurchaseReturnsTable
        returns={initialReturns}
        onDelete={handleDelete}
      />
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
          <ReturnForm
            purchaseInvoices={purchaseInvoices}
            onSubmit={handleFormSubmit}
            onCancel={() => setIsDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}

