
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import type { Category } from '@/lib/types';

const formSchema = z.object({
  name: z.string().min(2, { message: 'اسم الفئة مطلوب ويجب أن يكون حرفين على الأقل' }),
});

type CategoryFormValues = z.infer<typeof formSchema>;

interface CategoryFormProps {
  category: Category | null;
  onSubmit: (values: CategoryFormValues) => void;
  onCancel: () => void;
}

export function CategoryForm({ category, onSubmit, onCancel }: CategoryFormProps) {
  const form = useForm<CategoryFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: category?.name || '',
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <DialogHeader>
          <DialogTitle>
            {category ? 'تعديل الفئة' : 'إضافة فئة جديدة'}
          </DialogTitle>
          <DialogDescription>
            {category ? 'قم بتعديل اسم الفئة.' : 'أدخل اسم الفئة الجديدة.'}
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>اسم الفئة</FormLabel>
                <FormControl>
                  <Input placeholder="مثال: إلكترونيات" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onCancel}>
            إلغاء
          </Button>
          <Button type="submit">
            {category ? 'حفظ التغييرات' : 'إضافة فئة'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}
