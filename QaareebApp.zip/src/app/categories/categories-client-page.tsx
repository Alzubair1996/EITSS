'use client';

import * as React from 'react';
import { PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/page-header';
import { CategoriesTable } from './categories-table';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { CategoryForm } from './category-form';
import type { Category } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { deleteCategory, addCategory, updateCategory } from './actions';
import { useRouter } from 'next/navigation';

interface CategoriesClientPageProps {
  initialCategories: Category[];
}

export default function CategoriesClientPage({ initialCategories }: CategoriesClientPageProps) {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [editingCategory, setEditingCategory] = React.useState<Category | null>(null);
  const { toast } = useToast();
  const router = useRouter();

  const handleAdd = () => {
    setEditingCategory(null);
    setIsDialogOpen(true);
  };

  const handleEdit = (category: Category) => {
    setEditingCategory(category);
    setIsDialogOpen(true);
  };

  const handleDelete = async (categoryId: string) => {
    const result = await deleteCategory(categoryId);
    if (result.success) {
      toast({
        title: 'تم الحذف بنجاح',
        description: result.message,
      });
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ في الحذف',
        description: result.message,
      });
    }
  };

  const handleFormSubmit = async (values: { name: string }) => {
    const result = editingCategory
      ? await updateCategory({ ...values, id: editingCategory.id })
      : await addCategory(values.name);

    if (result.success) {
      toast({
        title: editingCategory ? 'تم التحديث بنجاح' : 'تمت الإضافة بنجاح',
        description: result.message,
      });
      setIsDialogOpen(false);
      setEditingCategory(null);
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ',
        description: result.message,
      });
    }
  };

  return (
    <>
      <PageHeader title="إدارة الفئات">
        <Button onClick={handleAdd} className="shadow-md hover:shadow-lg transition-shadow">
          <PlusCircle className="me-2 h-4 w-4" />
          إضافة فئة جديدة
        </Button>
      </PageHeader>
      <CategoriesTable
        categories={initialCategories}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <CategoryForm
            category={editingCategory}
            onSubmit={handleFormSubmit}
            onCancel={() => setIsDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}
