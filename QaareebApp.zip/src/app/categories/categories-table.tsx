'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MoreHorizontal, Pencil, Trash2, Boxes } from 'lucide-react';
import type { Category } from '@/lib/types';

interface CategoriesTableProps {
  categories: Category[];
  onEdit: (category: Category) => void;
  onDelete: (categoryId: string) => void;
}

export function CategoriesTable({ categories, onEdit, onDelete }: CategoriesTableProps) {
  return (
    <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
      <CardHeader className="pb-4 border-b border-border/40 bg-secondary/10 flex flex-row justify-between items-center">
        <div>
          <CardTitle className="text-base font-bold text-foreground">فئات المنتجات</CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">تصنيف وتنظيم المنتجات في مجموعات</p>
        </div>
        <div className="text-xs font-semibold text-muted-foreground bg-background px-3 py-1.5 rounded-full border border-border/40 shadow-sm">
          {categories.length} فئة
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>اسم الفئة</TableHead>
              <TableHead className="text-center">الإجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {categories.length === 0 ? (
              <TableRow>
                <TableCell colSpan={2} className="h-40 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-4 rounded-2xl bg-muted/50">
                      <Boxes className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">لا توجد فئات</p>
                      <p className="text-sm text-muted-foreground mt-1">قم بإضافة فئة جديدة للبدء</p>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              categories.map((category) => (
                <TableRow key={category.id} className="group">
                  <TableCell className="font-semibold">{category.name}</TableCell>
                  <TableCell className="text-center">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          aria-haspopup="true"
                          size="icon"
                          variant="ghost"
                          className="rounded-full h-8 w-8 hover:bg-primary/5 hover:text-primary opacity-60 group-hover:opacity-100 transition-all"
                        >
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">فتح القائمة</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl shadow-lg border-border/50">
                        <DropdownMenuItem
                          onSelect={() => onEdit(category)}
                          className="rounded-lg cursor-pointer"
                        >
                          <Pencil className="me-2 h-4 w-4 text-primary" />
                          تعديل
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onSelect={() => onDelete(category.id)}
                          className="rounded-lg cursor-pointer text-destructive focus:text-destructive"
                        >
                          <Trash2 className="me-2 h-4 w-4" />
                          حذف
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
