import CategoriesClientPage from './categories-client-page';
import { getCategories } from '@/lib/queries';

export default async function CategoriesPage() {
  const initialCategories = await getCategories();

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
      <CategoriesClientPage initialCategories={initialCategories} />
    </div>
  );
}
