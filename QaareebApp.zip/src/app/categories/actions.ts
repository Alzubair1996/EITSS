'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { Category } from '@/lib/types';
import { randomUUID } from 'crypto';

export async function addCategory(name: string) {
    try {
        const db = await getDbInstance();
        const existing = await db.get('SELECT id FROM categories WHERE name = ?', name);
        if (existing) {
            return { success: false, message: 'الفئة موجودة بالفعل.' };
        }
        const newId = `cat_${randomUUID()}`;
        await db.run('INSERT INTO categories (id, name) VALUES (?, ?)', newId, name);
        revalidatePath('/categories');
        revalidatePath('/products');
        return { success: true, message: 'تمت إضافة الفئة بنجاح.' };
    } catch (e: any) {
        console.error(e);
        if (e.code === 'SQLITE_CONSTRAINT') {
             return { success: false, message: 'الفئة موجودة بالفعل.' };
        }
        return { success: false, message: 'خطأ في قاعدة البيانات: فشلت إضافة الفئة.' };
    }
}

export async function updateCategory(category: Category) {
     try {
        const db = await getDbInstance();
        await db.run('UPDATE categories SET name = ? WHERE id = ?', category.name, category.id);
        revalidatePath('/categories');
        revalidatePath('/products');
        return { success: true, message: 'تم تحديث الفئة بنجاح.' };
    } catch (e: any) {
        console.error(e);
        if (e.code === 'SQLITE_CONSTRAINT') {
             return { success: false, message: 'الفئة موجودة بالفعل.' };
        }
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل تحديث الفئة.' };
    }
}

export async function deleteCategory(id: string) {
    try {
        const db = await getDbInstance();
        const product = await db.get('SELECT id FROM products WHERE categoryId = ?', id);
        if (product) {
            return { success: false, message: 'لا يمكن حذف الفئة لأنها مستخدمة في منتجات.' };
        }
        await db.run('DELETE FROM categories WHERE id = ?', id);
        revalidatePath('/categories');
        revalidatePath('/products');
        return { success: true, message: 'تم حذف الفئة بنجاح.' };
    } catch (e) {
        console.error(e);
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل حذف الفئة.' };
    }
}
