
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import type { Supplier } from '@/lib/types';

const formSchema = z.object({
  name: z.string().min(2, { message: 'اسم المورد مطلوب' }),
  phone: z.string().min(9, { message: 'رقم الهاتف مطلوب' }),
  address: z.string().optional(),
});

type SupplierFormValues = z.infer<typeof formSchema>;

interface SupplierFormProps {
  supplier: Supplier | null;
  onSubmit: (values: SupplierFormValues) => void;
  onCancel: () => void;
}

export function SupplierForm({ supplier, onSubmit, onCancel }: SupplierFormProps) {
  const form = useForm<SupplierFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: supplier?.name || '',
      phone: supplier?.phone || '',
      address: supplier?.address || '',
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <DialogHeader>
          <DialogTitle>
            {supplier ? 'تعديل بيانات المورد' : 'إضافة مورد جديد'}
          </DialogTitle>
          <DialogDescription>
            {supplier ? 'قم بتعديل بيانات المورد.' : 'أدخل بيانات المورد الجديد.'}
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem className="md:col-span-2">
                <FormLabel>اسم المورد</FormLabel>
                <FormControl>
                  <Input placeholder="مثال: شركة التوريدات الحديثة" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>رقم الهاتف</FormLabel>
                <FormControl>
                  <Input placeholder="مثال: 0912345678" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="address"
            render={({ field }) => (
              <FormItem>
                <FormLabel>العنوان (اختياري)</FormLabel>
                <FormControl>
                  <Input placeholder="المدينة، الحي، الشارع" {...field} value={field.value ?? ''} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <DialogFooter className="pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            إلغاء
          </Button>
          <Button type="submit">
            {supplier ? 'حفظ التغييرات' : 'إضافة مورد'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}
