import SuppliersClientPage from './suppliers-client-page';
import { getSuppliers } from '@/lib/queries';

export default async function SuppliersPage() {
  const initialSuppliers = await getSuppliers();

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <SuppliersClientPage initialSuppliers={initialSuppliers} />
      </div>
  );
}
