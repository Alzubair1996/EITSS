'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { Supplier } from '@/lib/types';
import { randomUUID } from 'crypto';

export async function addSupplier(supplierData: Omit<Supplier, 'id' | 'balance'>) {
    try {
        const db = await getDbInstance();
        const existing = await db.get('SELECT id FROM suppliers WHERE phone = ?', supplierData.phone);
        if (existing) {
            return { success: false, message: 'مورد بنفس رقم الهاتف موجود بالفعل.' };
        }

        const newId = `supp_${randomUUID()}`;
        await db.run(`
            INSERT INTO suppliers (id, name, phone, address, balance)
            VALUES (?, ?, ?, ?, 0)
        `, newId, supplierData.name, supplierData.phone, supplierData.address);
        revalidatePath('/suppliers');
        return { success: true, message: 'تمت إضافة المورد بنجاح' };
    } catch (e: any) {
        console.error(e);
        if (e.code === 'SQLITE_CONSTRAINT') {
             return { success: false, message: 'مورد بنفس رقم الهاتف موجود بالفعل.' };
        }
        return { success: false, message: 'خطأ في قاعدة البيانات: فشلت إضافة المورد' };
    }
}

export async function updateSupplier(supplierData: Omit<Supplier, 'balance'>) {
     try {
        const db = await getDbInstance();
        await db.run(`
            UPDATE suppliers
            SET name = ?, phone = ?, address = ?
            WHERE id = ?
        `, supplierData.name, supplierData.phone, supplierData.address, supplierData.id);
        revalidatePath('/suppliers');
        return { success: true, message: 'تم تحديث المورد بنجاح' };
    } catch (e: any) {
        console.error(e);
        if (e.code === 'SQLITE_CONSTRAINT') {
             return { success: false, message: 'مورد بنفس رقم الهاتف موجود بالفعل.' };
        }
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل تحديث المورد' };
    }
}

export async function deleteSupplier(id: string) {
    try {
        const db = await getDbInstance();
        // Here you might want to check if the supplier has any purchase invoices before deleting.
        // For now, we will delete directly.
        await db.run('DELETE FROM suppliers WHERE id = ?', id);
        revalidatePath('/suppliers');
        return { success: true, message: 'تم حذف المورد.' };
    } catch (e) {
        console.error(e);
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل حذف المورد.' };
    }
}
