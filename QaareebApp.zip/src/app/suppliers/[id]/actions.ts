'use server';
import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import { randomUUID } from 'crypto';
import { getSession } from '@/lib/server-auth';


export async function makeGeneralPayment(supplierId: string, amount: number, paymentMethodId: string) {
    if (!supplierId || !paymentMethodId || !amount || amount <= 0) {
        return { success: false, message: 'بيانات الدفعة غير صحيحة.' };
    }
    const db = await getDbInstance();
    // Determine which user is making this payment so it can be recorded for auditing
    const session = await getSession();
    const userId = session?.userId || null;
    try {
        await db.exec('BEGIN');

        // Check payment method balance
        const paymentMethod = await db.get('SELECT balance FROM payment_methods WHERE id = ?', paymentMethodId) as { balance: number } | undefined;
        if (!paymentMethod) {
            throw new Error('طريقة الدفع غير موجودة.');
        }
        if (paymentMethod.balance < amount) {
            throw new Error('الرصيد في طريقة الدفع غير كافٍ.');
        }

        // Check if supplier exists
        const supplier = await db.get('SELECT * FROM suppliers WHERE id = ?', supplierId);
        if (!supplier) {
            throw new Error('المورد غير موجود.');
        }

        const paymentDate = new Date().toISOString();

        // 1. Add to supplier_payments table with user attribution
        await db.run(
            'INSERT INTO supplier_payments (id, supplierId, paymentMethodId, amount, paymentDate, description, userId) VALUES (?, ?, ?, ?, ?, ?, ?)',
            `sup_pay_${randomUUID()}`,
            supplierId,
            paymentMethodId,
            amount,
            paymentDate,
            'دفعة عامة للمورد',
            userId
        );
        
        // 2. Update payment method balance (subtract as it's an expense)
        await db.run('UPDATE payment_methods SET balance = balance - ? WHERE id = ?', amount, paymentMethodId);

        // 3. Update supplier balance (reduce our debt to them)
        await db.run('UPDATE suppliers SET balance = balance - ? WHERE id = ?', amount, supplierId);

        await db.exec('COMMIT');

        revalidatePath('/suppliers');
        revalidatePath(`/suppliers/${supplierId}`);
        revalidatePath('/payment-methods');
        revalidatePath('/');
        return { success: true, message: 'تم تسجيل الدفعة بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to make payment:', e);
        return { success: false, message: e.message || 'فشل تسجيل الدفعة.' };
    }
}

export async function addDebtToSupplier(supplierId: string, amount: number, description: string | null, referenceNumber: string | null) {
    if (!supplierId || !amount || amount <= 0) {
        return { success: false, message: 'بيانات الدين غير صحيحة.' };
    }
    const db = await getDbInstance();
    const session = await getSession();
    const userId = session?.userId || null;
    
    try {
        await db.exec('BEGIN');

        // Check if supplier exists
        const supplier = await db.get('SELECT * FROM suppliers WHERE id = ?', supplierId);
        if (!supplier) {
            throw new Error('المورد غير موجود.');
        }

        // Add external debt
        const createdAt = new Date().toISOString();
        const externalDebtId = `ext_debt_${randomUUID()}`;
        
        await db.run(`
            INSERT INTO external_debts (id, supplierId, amount, description, referenceNumber, createdAt, userId)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `, externalDebtId, supplierId, amount, description, referenceNumber, createdAt, userId);

        // Update supplier balance (increase debt)
        await db.run('UPDATE suppliers SET balance = balance + ? WHERE id = ?', amount, supplierId);

        await db.exec('COMMIT');

        revalidatePath('/suppliers');
        revalidatePath(`/suppliers/${supplierId}`);
        revalidatePath('/');
        return { success: true, message: 'تم إضافة الدين بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to add debt:', e);
        return { success: false, message: e.message || 'فشل إضافة الدين.' };
    }
}

export async function makePaymentForPurchaseInvoice(purchaseInvoiceId: string, amount: number, paymentMethodId: string) {
    if (!purchaseInvoiceId || !paymentMethodId || !amount || amount <= 0) {
        return { success: false, message: 'بيانات الدفعة غير صحيحة.' };
    }
    const db = await getDbInstance();
    const session = await getSession();
    const userId = session?.userId || null;
    try {
        await db.exec('BEGIN');

        // Fetch purchase invoice
        const purchaseInvoice = await db.get('SELECT * FROM purchase_invoices WHERE id = ?', purchaseInvoiceId) as { id: string; supplierId: string; totalAmount: number; amountPaid: number; status: string; invoiceNumber: string | null } | undefined;
        if (!purchaseInvoice) {
            throw new Error('فاتورة الشراء غير موجودة.');
        }

        // Fetch total returns for this invoice
        const invoiceReturns = await db.all('SELECT totalAmount FROM purchase_returns WHERE purchaseInvoiceId = ?', purchaseInvoiceId) as { totalAmount: number }[];
        const totalReturned = invoiceReturns.reduce((sum, ret) => sum + ret.totalAmount, 0);

        const remainingBalance = Math.max(0, purchaseInvoice.totalAmount - purchaseInvoice.amountPaid - totalReturned);
        if (amount > remainingBalance + 0.001) {
             throw new Error('المبلغ المدفوع أكبر من المبلغ المتبقي للفاتورة.');
        }

        // Check payment method balance
        const paymentMethod = await db.get('SELECT balance FROM payment_methods WHERE id = ?', paymentMethodId) as { balance: number } | undefined;
        if (!paymentMethod) {
            throw new Error('طريقة الدفع غير موجودة.');
        }
        if (paymentMethod.balance < amount) {
            throw new Error('الرصيد في طريقة الدفع غير كافٍ.');
        }

        const paymentDate = new Date().toISOString();

        // 1. Add to supplier_payments table with user attribution and purchaseInvoiceId
        await db.run(
            'INSERT INTO supplier_payments (id, supplierId, paymentMethodId, amount, paymentDate, description, purchaseInvoiceId, userId) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            `sup_pay_${randomUUID()}`,
            purchaseInvoice.supplierId,
            paymentMethodId,
            amount,
            paymentDate,
            `سداد دفعة للفاتورة #${purchaseInvoice.invoiceNumber || 'بدون رقم'}`,
            purchaseInvoiceId,
            userId
        );
        
        // 2. Update payment method balance (subtract as it's an expense/outflow)
        await db.run('UPDATE payment_methods SET balance = balance - ? WHERE id = ?', amount, paymentMethodId);

        // 3. Update purchase invoice amount paid and status
        const newAmountPaid = purchaseInvoice.amountPaid + amount;
        let newStatus = purchaseInvoice.status;
        if (newAmountPaid + totalReturned >= purchaseInvoice.totalAmount - 0.001) {
            newStatus = 'paid';
        } else {
            newStatus = 'partial';
        }
        await db.run('UPDATE purchase_invoices SET amountPaid = ?, status = ? WHERE id = ?', newAmountPaid, newStatus, purchaseInvoiceId);

        // 4. Update supplier balance (reduce our debt to them)
        await db.run('UPDATE suppliers SET balance = balance - ? WHERE id = ?', amount, purchaseInvoice.supplierId);

        await db.exec('COMMIT');

        revalidatePath('/suppliers');
        revalidatePath(`/suppliers/${purchaseInvoice.supplierId}`);
        revalidatePath('/payment-methods');
        revalidatePath('/');
        return { success: true, message: 'تم تسجيل دفعة الفاتورة بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to make purchase invoice payment:', e);
        return { success: false, message: e.message || 'فشل تسجيل الدفعة.' };
    }
}
