'use client';

import * as React from 'react';
import type { SupplierDetails, PurchaseInvoice, PaymentMethod, SupplierPaymentDetails, ExternalDebt, PurchaseReturn, PurchaseInvoiceDetails } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { useToast } from '@/hooks/use-toast';
import { makeGeneralPayment, addDebtToSupplier, makePaymentForPurchaseInvoice } from './actions';
import { createPurchaseReturn } from '@/app/purchase-returns/actions';
import { getInvoiceDetailsAction } from '@/app/purchase-returns/actions-get-invoice';
import { format } from 'date-fns';
import { useRouter } from 'next/navigation';
import { Phone, MapPin, DollarSign, LoaderCircle, Plus, RotateCcw, Trash2 } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

interface SupplierDetailsClientPageProps {
  supplierDetails: SupplierDetails;
  paymentMethods: PaymentMethod[];
  purchaseInvoices: PurchaseInvoiceDetails[];
  isAdmin: boolean;
}

type DialogMode = 'payment' | 'addDebt' | 'returnItems' | 'invoicePayment';

type CartItem = {
    id: string;
    type: 'product' | 'material';
    productId?: string | null;
    rawMaterialId?: string | null;
    name: string;
    quantity: number | string;
    maxQuantity: number;
    costPrice: number;
    originalItemId: string;
};

function FormattedDate({ dateString }: { dateString: string }) {
    const [formattedDate, setFormattedDate] = React.useState('');
    React.useEffect(() => {
        setFormattedDate(format(new Date(dateString), 'dd/MM/yyyy HH:mm'));
    }, [dateString]);
    return <>{formattedDate}</>;
}

export default function SupplierDetailsClientPage({ supplierDetails, paymentMethods, purchaseInvoices, isAdmin }: SupplierDetailsClientPageProps) {
  const { toast } = useToast();
  const router = useRouter();

  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [dialogMode, setDialogMode] = React.useState<DialogMode | null>(null);

  const [paymentAmount, setPaymentAmount] = React.useState<number | string>('');
  const [debtAmount, setDebtAmount] = React.useState<number | string>('');
  const [debtDescription, setDebtDescription] = React.useState('');
  const [debtReference, setDebtReference] = React.useState('');
  
  const [selectedPaymentMethodId, setSelectedPaymentMethodId] = React.useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [selectedInvoice, setSelectedInvoice] = React.useState<any | null>(null);
  const [searchQuery, setSearchQuery] = React.useState('');

  // Return dialog state
  const [selectedInvoiceId, setSelectedInvoiceId] = React.useState<string>('');
  const [invoiceItems, setInvoiceItems] = React.useState<any[]>([]);
  const [cart, setCart] = React.useState<CartItem[]>([]);
  const [reason, setReason] = React.useState('');
  const [loadingInvoice, setLoadingInvoice] = React.useState(false);

  const formatCurrency = (amount: number) => {
    return `${Math.round(amount).toLocaleString('en-US')} SDG`;
  };

  const getInvoiceRemainingAmount = React.useCallback((invoice: any) => {
    if (!invoice) return 0;
    const invoiceReturns = supplierDetails.purchaseReturns.filter(ret => ret.purchaseInvoiceId === invoice.id);
    const totalReturnedForInvoice = invoiceReturns.reduce((sum, ret) => sum + ret.totalAmount, 0);
    return Math.max(0, invoice.totalAmount - invoice.amountPaid - totalReturnedForInvoice);
  }, [supplierDetails.purchaseReturns]);

  const handleMakePaymentClick = () => {
    setSelectedInvoice(null);
    setPaymentAmount('');
    setSearchQuery('');
    setSelectedPaymentMethodId(paymentMethods[0]?.id || null);
    setDialogMode('payment');
    setDialogOpen(true);
  }

  const handleMakeInvoicePaymentClick = (invoice: any) => {
    setSelectedInvoice(invoice);
    const invoiceReturns = supplierDetails.purchaseReturns.filter(ret => ret.purchaseInvoiceId === invoice.id);
    const totalReturnedForInvoice = invoiceReturns.reduce((sum, ret) => sum + ret.totalAmount, 0);
    const remaining = Math.max(0, invoice.totalAmount - invoice.amountPaid - totalReturnedForInvoice);
    setPaymentAmount(remaining);
    setSelectedPaymentMethodId(paymentMethods[0]?.id || null);
    setDialogMode('invoicePayment');
    setDialogOpen(true);
  }

  const handleAddDebtClick = () => {
    setDebtAmount('');
    setDebtDescription('');
    setDebtReference('');
    setDialogMode('addDebt');
    setDialogOpen(true);
  }

  const handleReturnItemsClick = () => {
    setSelectedInvoiceId('');
    setInvoiceItems([]);
    setCart([]);
    setReason('');
    setDialogMode('returnItems');
    setDialogOpen(true);
  }

  const handleMakeInvoiceReturnClick = (invoice: any) => {
    setSelectedInvoiceId(invoice.id);
    setInvoiceItems([]);
    setCart([]);
    setReason('');
    setDialogMode('returnItems');
    setDialogOpen(true);
  }

  React.useEffect(() => {
    if (dialogMode === 'returnItems' && selectedInvoiceId) {
      async function loadInvoiceDetails() {
        setLoadingInvoice(true);
        try {
          const result = await getInvoiceDetailsAction(selectedInvoiceId);
          if (result.success && result.data && result.data.items) {
            setInvoiceItems(result.data.items);
          } else {
            toast({
              variant: 'destructive',
              title: 'خطأ',
              description: result.message || 'فشل تحميل فاتورة الشراء.',
            });
          }
        } catch (error) {
          console.error('Failed to load invoice details:', error);
          toast({
            variant: 'destructive',
            title: 'خطأ',
            description: 'فشل تحميل فاتورة الشراء.',
          });
        }
        setLoadingInvoice(false);
      }
      loadInvoiceDetails();
    }
  }, [dialogMode, selectedInvoiceId, toast]);

  React.useEffect(() => {
    if (!dialogOpen) {
      setDialogMode(null);
      setSelectedInvoiceId('');
      setInvoiceItems([]);
      setCart([]);
      setReason('');
      setSelectedInvoice(null);
      setPaymentAmount('');
      setSearchQuery('');
    }
  }, [dialogOpen]);

  const handleConfirmPayment = async () => {
    if (dialogMode === 'payment') {
      if (!selectedPaymentMethodId) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى اختيار طريقة الدفع.' });
        return;
      }
      const numericPaymentAmount = Number(paymentAmount);
      if (isNaN(numericPaymentAmount) || numericPaymentAmount <= 0) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'مبلغ الدفع يجب أن يكون أكبر من صفر.' });
        return;
      }
      setIsSubmitting(true);
      let result;
      if (selectedInvoice) {
        const remaining = getInvoiceRemainingAmount(selectedInvoice);
        if (numericPaymentAmount > remaining + 0.001) {
          toast({ variant: 'destructive', title: 'خطأ', description: 'المبلغ المدفوع أكبر من المبلغ المتبقي للفاتورة.' });
          setIsSubmitting(false);
          return;
        }
        result = await makePaymentForPurchaseInvoice(selectedInvoice.id, numericPaymentAmount, selectedPaymentMethodId);
      } else {
        result = await makeGeneralPayment(supplierDetails.id, numericPaymentAmount, selectedPaymentMethodId);
      }
      setIsSubmitting(false);
      if (result.success) {
        toast({ title: 'نجاح', description: result.message });
        setDialogOpen(false);
        setPaymentAmount('');
        setSelectedInvoice(null);
        router.refresh();
      } else {
        toast({ variant: 'destructive', title: 'فشل', description: result.message });
      }
    } else if (dialogMode === 'invoicePayment') {
      if (!selectedPaymentMethodId) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى اختيار طريقة الدفع.' });
        return;
      }
      const numericPaymentAmount = Number(paymentAmount);
      if (isNaN(numericPaymentAmount) || numericPaymentAmount <= 0) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'مبلغ الدفع يجب أن يكون أكبر من صفر.' });
        return;
      }
      if (selectedInvoice) {
        const remaining = getInvoiceRemainingAmount(selectedInvoice);
        if (numericPaymentAmount > remaining + 0.001) {
          toast({ variant: 'destructive', title: 'خطأ', description: 'المبلغ المدفوع أكبر من المبلغ المتبقي للفاتورة.' });
          return;
        }
        setIsSubmitting(true);
        const result = await makePaymentForPurchaseInvoice(selectedInvoice.id, numericPaymentAmount, selectedPaymentMethodId);
        setIsSubmitting(false);
        if (result.success) {
          toast({ title: 'نجاح', description: result.message });
          setDialogOpen(false);
          setPaymentAmount('');
          setSelectedInvoice(null);
          router.refresh();
        } else {
          toast({ variant: 'destructive', title: 'فشل', description: result.message });
        }
      }
    } else if (dialogMode === 'addDebt') {
      const numericDebtAmount = Number(debtAmount);
      if (isNaN(numericDebtAmount) || numericDebtAmount <= 0) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'مبلغ المستحقات يجب أن يكون أكبر من صفر.' });
        return;
      }
      setIsSubmitting(true);
      const result = await addDebtToSupplier(supplierDetails.id, numericDebtAmount, debtDescription, debtReference);
      setIsSubmitting(false);
      if (result.success) {
        toast({ title: 'نجاح', description: result.message });
        setDialogOpen(false);
        setDebtAmount('');
        setDebtDescription('');
        setDebtReference('');
        router.refresh();
      } else {
        toast({ variant: 'destructive', title: 'فشل', description: result.message });
      }
    } else if (dialogMode === 'returnItems') {
      if (!selectedInvoiceId) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى اختيار فاتورة الشراء.' });
        return;
      }
      if (cart.length === 0) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى إضافة أصناف للإرجاع.' });
        return;
      }
      const hasValidQuantities = cart.some(item => Number(item.quantity) > 0);
      if (!hasValidQuantities) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى تحديد كميات للإرجاع.' });
        return;
      }
      setIsSubmitting(true);
      const itemsToReturn = cart.filter(item => Number(item.quantity) > 0).map(item => ({
        productId: item.productId || null,
        rawMaterialId: item.rawMaterialId || null,
        quantity: Number(item.quantity),
        costPrice: item.costPrice,
      }));
      const result = await createPurchaseReturn({
        purchaseInvoiceId: selectedInvoiceId,
        returnDate: new Date().toISOString(),
        items: itemsToReturn,
        reason,
      });
      setIsSubmitting(false);
      if (result.success) {
        toast({ title: 'نجاح', description: result.message });
        setDialogOpen(false);
        setSelectedInvoiceId('');
        setInvoiceItems([]);
        setCart([]);
        setReason('');
        router.refresh();
      } else {
        toast({ variant: 'destructive', title: 'فشل', description: result.message });
      }
    }
  };

  const handleAddItem = (item: any) => {
    const existingIndex = cart.findIndex(cartItem => cartItem.originalItemId === item.id);
    if (existingIndex >= 0) {
      return;
    }
    const itemName = item.productName || item.rawMaterialName || (item.productId || item.rawMaterialId || '');
    setCart((prevCart) => [
      ...prevCart,
      {
        id: item.productId || item.rawMaterialId || '',
        type: item.productId ? 'product' : 'material',
        productId: item.productId || null,
        rawMaterialId: item.rawMaterialId || null,
        name: itemName,
        quantity: Math.min(1, item.remainingQuantity !== undefined ? item.remainingQuantity : item.quantity),
        maxQuantity: item.remainingQuantity !== undefined ? item.remainingQuantity : item.quantity,
        costPrice: item.costPrice,
        originalItemId: item.id,
      },
    ]);
  };

  const handleQuantityChange = (cartItemId: string, newQuantity: number | string) => {
    setCart((prevCart) =>
      prevCart.map((item) => {
        if (item.originalItemId === cartItemId) {
          let val = newQuantity;
          if (typeof val === 'string') {
            if (val === '') return { ...item, quantity: '' };
            const num = Number(val);
            if (!isNaN(num)) val = Math.max(0, Math.min(num, item.maxQuantity));
          } else if (typeof val === 'number') {
            val = Math.max(0, Math.min(val, item.maxQuantity));
          }
          return { ...item, quantity: val };
        }
        return item;
      })
    );
  };

  const handleRemoveItem = (cartItemId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.originalItemId !== cartItemId));
  };

  const invoiceStatusMap: { [key: string]: { text: string; variant: 'default' | 'outline' | 'secondary' | 'destructive' } } = {
    paid: { text: 'مدفوعة', variant: 'secondary' },
    partial: { text: 'مدفوعة جزئياً', variant: 'outline' },
    unpaid: { text: 'غير مدفوعة', variant: 'destructive' },
  };

  const renderDialogContent = () => {
    if (dialogMode === 'payment') {
        return (
         <>
          <DialogHeader>
            <DialogTitle>تسجيل سداد للمورد</DialogTitle>
            <DialogDescription>
              تسجيل سداد عام للمورد: {supplierDetails.name}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div>
              <Label htmlFor="searchInvoice">بحث عن فاتورة شراء بالرقم</Label>
              <Input
                id="searchInvoice"
                type="text"
                placeholder="اكتب رقم الفاتورة للبحث..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="mb-2"
              />
              <Label htmlFor="linkInvoice">ربط بفاتورة شراء (اختياري)</Label>
              <Select 
                onValueChange={(val) => {
                  if (val === 'none') {
                    setSelectedInvoice(null);
                    setPaymentAmount('');
                  } else {
                    const inv = supplierDetails.purchaseInvoices.find(i => i.id === val);
                    if (inv) {
                      setSelectedInvoice(inv);
                      setPaymentAmount(getInvoiceRemainingAmount(inv));
                    }
                  }
                }} 
                value={selectedInvoice?.id || 'none'}
              >
                <SelectTrigger id="linkInvoice">
                  <SelectValue placeholder="اختر فاتورة للربط..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">دفعة عامة (بدون ربط بفاتورة)</SelectItem>
                  {supplierDetails.purchaseInvoices
                    .filter(inv => inv.status !== 'paid')
                    .filter(inv => {
                      if (!searchQuery) return true;
                      return inv.invoiceNumber?.toLowerCase().includes(searchQuery.toLowerCase());
                    })
                    .map(inv => (
                      <SelectItem key={inv.id} value={inv.id}>
                        فاتورة #{inv.invoiceNumber || 'بدون رقم'} (المتبقي: {formatCurrency(getInvoiceRemainingAmount(inv))})
                      </SelectItem>
                    ))
                  }
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="paymentAmount">المبلغ المدفوع</Label>
              <Input
                id="paymentAmount"
                type="number"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                max={selectedInvoice ? getInvoiceRemainingAmount(selectedInvoice) : undefined}
              />
            </div>
            <div>
              <Label htmlFor="paymentMethodPay">اختر طريقة الدفع</Label>
              <Select onValueChange={setSelectedPaymentMethodId} value={selectedPaymentMethodId || undefined}>
                <SelectTrigger id="paymentMethodPay">
                  <SelectValue placeholder="اختر الحساب..." />
                </SelectTrigger>
                <SelectContent>
                  {paymentMethods.map(pm => (
                    <SelectItem key={pm.id} value={pm.id}>{pm.name}{isAdmin && ` (الرصيد: ${formatCurrency(pm.balance)})`}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
         </>
      )
    } else if (dialogMode === 'invoicePayment' && selectedInvoice) {
        const remainingBalance = getInvoiceRemainingAmount(selectedInvoice);
        return (
         <>
          <DialogHeader>
            <DialogTitle>تسديد دفعة لفاتورة شراء</DialogTitle>
            <DialogDescription>
              الفاتورة رقم #{selectedInvoice.invoiceNumber || 'بدون رقم'}. المبلغ المتبقي: {formatCurrency(remainingBalance)}.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div>
              <Label htmlFor="paymentAmount">المبلغ المدفوع</Label>
              <Input
                id="paymentAmount"
                type="number"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                max={remainingBalance}
              />
            </div>
            <div>
              <Label htmlFor="paymentMethodPay">اختر طريقة الدفع</Label>
              <Select onValueChange={setSelectedPaymentMethodId} value={selectedPaymentMethodId || undefined}>
                <SelectTrigger id="paymentMethodPay">
                  <SelectValue placeholder="اختر الحساب..." />
                </SelectTrigger>
                <SelectContent>
                  {paymentMethods.map(pm => (
                    <SelectItem key={pm.id} value={pm.id}>{pm.name}{isAdmin && ` (الرصيد: ${formatCurrency(pm.balance)})`}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
         </>
      )
    } else if (dialogMode === 'addDebt') {
        return (
         <>
          <DialogHeader>
            <DialogTitle>إضافة مستحقات للمورد</DialogTitle>
            <DialogDescription>
              إضافة مستحقات خارجية للمورد: {supplierDetails.name}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div>
              <Label htmlFor="debtAmount">المبلغ المستحق</Label>
              <Input
                id="debtAmount"
                type="number"
                value={debtAmount}
                onChange={(e) => setDebtAmount(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="debtDescription">الوصف (اختياري)</Label>
              <Textarea
                id="debtDescription"
                value={debtDescription}
                onChange={(e) => setDebtDescription(e.target.value)}
                placeholder="مثال: دين مقابل خدمات إصلاح..."
              />
            </div>
            <div>
              <Label htmlFor="debtReference">رقم المرجع (اختياري)</Label>
              <Input
                id="debtReference"
                type="text"
                value={debtReference}
                onChange={(e) => setDebtReference(e.target.value)}
                placeholder="مثال: رقم الفاتورة الخارجية..."
              />
            </div>
          </div>
         </>
      )
    } else if (dialogMode === 'returnItems') {
      const totalAmount = cart.reduce((sum, item) => sum + (Number(item.quantity) || 0) * item.costPrice, 0);
      
      return (
        <>
          <DialogHeader>
            <DialogTitle>إرجاع بضاعة لمورد</DialogTitle>
            <DialogDescription>
              اختر فاتورة الشراء وقم بإضافة الأصناف المراد إرجاعها
            </DialogDescription>
          </DialogHeader>

          <div className="py-4 space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label>فاتورة الشراء</Label>
                <Select value={selectedInvoiceId} onValueChange={setSelectedInvoiceId}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر فاتورة الشراء" />
                  </SelectTrigger>
                  <SelectContent>
                    {purchaseInvoices
                      .filter(inv => inv.supplierId === supplierDetails.id)
                      .map((invoice) => (
                      <SelectItem key={invoice.id} value={invoice.id}>
                        {invoice.invoiceNumber || 'بدون رقم'} ({new Date(invoice.issueDate).toLocaleDateString('ar-SA')})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {loadingInvoice && (
              <div className="flex items-center justify-center p-8">
                <LoaderCircle className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            )}

            {!loadingInvoice && invoiceItems.length > 0 && (
              <div className="space-y-4">
                <div>
                  <Label>أصناف فاتورة الشراء</Label>
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>المنتج/المادة</TableHead>
                          <TableHead className="text-center">الكمية المشتراة</TableHead>
                          <TableHead className="text-center">سعر الشراء</TableHead>
                          <TableHead className="text-center">الإجراء</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {invoiceItems.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">
                              {item.productName || item.rawMaterialName || item.productId || item.rawMaterialId || '—'}
                            </TableCell>
                            <TableCell className="text-center">
                              <span className="font-semibold">{item.quantity}</span>
                              {item.returnedQuantity !== undefined && item.returnedQuantity > 0 && (
                                <div className="text-xs text-amber-600 dark:text-amber-500 font-medium mt-1">
                                  (المتبقي: {item.remainingQuantity} | تم إرجاع: {item.returnedQuantity})
                                </div>
                              )}
                            </TableCell>
                            <TableCell className="text-center">{Math.round(item.costPrice).toLocaleString('en-US')} SDG</TableCell>
                            <TableCell className="text-center">
                              {cart.findIndex(cartItem => cartItem.originalItemId === item.id) < 0 ? (
                                item.remainingQuantity !== undefined && item.remainingQuantity <= 0 ? (
                                  <span className="text-xs text-muted-foreground font-semibold">تم إرجاعها بالكامل</span>
                                ) : (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleAddItem(item)}
                                  >
                                    إضافة للإرجاع
                                  </Button>
                                )
                              ) : (
                                <span className="text-green-600 font-semibold text-sm">أضيف للإرجاع</span>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
            )}

            {cart.length > 0 && (
              <div className="space-y-4">
                <div>
                  <Label>الأصناف المراد إرجاعها</Label>
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>المنتج/المادة</TableHead>
                          <TableHead className="text-center">الكمية المراد إرجاعها</TableHead>
                          <TableHead className="text-center">سعر الشراء</TableHead>
                          <TableHead className="text-center">الإجمالي</TableHead>
                          <TableHead className="text-center">الإجراء</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {cart.map((item) => (
                          <TableRow key={item.originalItemId}>
                            <TableCell className="font-medium">{item.name}</TableCell>
                            <TableCell className="text-center">
                              <Input
                                type="number"
                                min="0"
                                max={item.maxQuantity}
                                value={item.quantity}
                                onChange={(e) => handleQuantityChange(item.originalItemId, e.target.value)}
                                className="w-24 mx-auto text-center font-bold"
                              />
                            </TableCell>
                            <TableCell className="text-center">{Math.round(item.costPrice).toLocaleString('en-US')} SDG</TableCell>
                            <TableCell className="text-center">{Math.round((Number(item.quantity) || 0) * item.costPrice).toLocaleString('en-US')} SDG</TableCell>
                            <TableCell className="text-center">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleRemoveItem(item.originalItemId)}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>

                <div className="flex justify-end items-center gap-4 p-4 bg-muted rounded-lg">
                  <div className="text-lg font-semibold">
                    الإجمالي: {Math.round(totalAmount).toLocaleString('en-US')} SDG
                  </div>
                </div>

                <div>
                  <Label>سبب الإرجاع (اختياري)</Label>
                  <Textarea
                    placeholder="اذكر سبب الإرجاع..."
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    rows={3}
                  />
                </div>
              </div>
            )}
          </div>
        </>
      );
    }
    return null;
  }

  const InvoicePaymentsTable = ({ payments }: { payments: SupplierPaymentDetails[] }) => (
    <div className="my-4">
        <h4 className="font-semibold text-xs mb-2">سجل دفعات الفاتورة</h4>
        <Table>
            <TableHeader>
                <TableRow>
                    <TableHead className="py-2 text-xs">التاريخ</TableHead>
                    <TableHead className="py-2 text-xs">طريقة الدفع</TableHead>
                    <TableHead className="py-2 text-xs text-right">المبلغ</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {payments && payments.length > 0 ? (
                    payments.map(payment => (
                        <TableRow key={payment.id} className="text-xs">
                            <TableCell className="py-2"><FormattedDate dateString={payment.paymentDate} /></TableCell>
                            <TableCell className="py-2">{payment.paymentMethodName}</TableCell>
                            <TableCell className="py-2 text-right font-semibold">{formatCurrency(payment.amount)}</TableCell>
                        </TableRow>
                    ))
                ) : (
                    <TableRow>
                        <TableCell colSpan={3} className="text-center text-muted-foreground py-4 text-xs">
                            لا توجد دفعات مسجلة لهذه الفاتورة.
                        </TableCell>
                    </TableRow>
                )}
            </TableBody>
        </Table>
    </div>
  );

  const PaymentsHistoryTable = ({ payments }: { payments: SupplierPaymentDetails[] }) => (
    <div className="my-4">
        <h4 className="font-semibold text-sm mb-2">جميع الدفعات</h4>
        <Table>
            <TableHeader>
                <TableRow>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الوصف</TableHead>
                    <TableHead>طريقة الدفع</TableHead>
                    <TableHead className="text-right">المبلغ</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {payments.length > 0 ? (
                    payments.map(payment => (
                        <TableRow key={payment.id}>
                            <TableCell><FormattedDate dateString={payment.paymentDate} /></TableCell>
                            <TableCell>
                              <div className="text-sm flex flex-col gap-1">
                                {payment.purchaseInvoiceNumber ? (
                                  <div className="flex items-center gap-1.5 flex-wrap">
                                    <span>سداد للفاتورة</span>
                                    <Badge variant="outline" className="font-mono text-xs px-1.5 py-0.5 bg-primary/5 text-primary border-primary/20">
                                      #{payment.purchaseInvoiceNumber}
                                    </Badge>
                                  </div>
                                ) : (
                                  payment.description || '-'
                                )}
                                {payment.referenceNumber && (
                                  <div className="text-xs text-muted-foreground mt-1">
                                    مرجع: {payment.referenceNumber}
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>{payment.paymentMethodName}</TableCell>
                            <TableCell className="text-right">{formatCurrency(payment.amount)}</TableCell>
                        </TableRow>
                    ))
                ) : (
                    <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground">
                            لا توجد دفعات مسجلة لهذا المورد.
                        </TableCell>
                    </TableRow>
                )}
            </TableBody>
        </Table>
    </div>
);


  const totalDebt = supplierDetails.balance;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>معلومات المورد</CardTitle>
          <CardDescription>البيانات الأساسية للاتصال والرصيد الجاري المستحق للمورد.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-2"><strong>الاسم:</strong> {supplierDetails.name}</div>
            <div className="flex items-center gap-2"><Phone className="w-4 h-4 text-muted-foreground" /><strong>الهاتف:</strong> {supplierDetails.phone}</div>
            <div className="flex items-center gap-2"><MapPin className="w-4 h-4 text-muted-foreground" /><strong>العنوان:</strong> {supplierDetails.address || 'غير محدد'}</div>
            <div className="flex items-center gap-2"><DollarSign className="w-4 h-4 text-muted-foreground" /><strong>المستحقات المطلوبة للمورد:</strong> <span className={supplierDetails.balance > 0 ? 'text-destructive font-bold' : 'font-bold'}>{formatCurrency(supplierDetails.balance)}</span></div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>كشف حساب الفواتير والالتزامات</CardTitle>
              <CardDescription>يستعرض فواتير الشراء والالتزامات غير المسددة وتفاصيل دفعات كل منها.</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleMakePaymentClick} variant="default" size="sm">
                <DollarSign className="me-2 h-4 w-4" />
                سداد للمورد
              </Button>
              <Button onClick={handleAddDebtClick} variant="outline" size="sm">
                <Plus className="me-2 h-4 w-4" />
                إضافة مستحقات خارجية
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {(supplierDetails.purchaseInvoices.length > 0 || supplierDetails.externalDebts.length > 0) ? (
            <div className="space-y-2">
            <Accordion type="multiple" className="w-full">
              {supplierDetails.purchaseInvoices.map((invoice) => {
                const invoiceReturns = supplierDetails.purchaseReturns.filter(ret => ret.purchaseInvoiceId === invoice.id);
                const totalReturnedForInvoice = invoiceReturns.reduce((sum, ret) => sum + ret.totalAmount, 0);
                const remaining = Math.max(0, invoice.totalAmount - invoice.amountPaid - totalReturnedForInvoice);
                return (
                  <AccordionItem value={invoice.id} key={invoice.id}>
                    <AccordionTrigger>
                      <div className="flex justify-between items-center w-full pe-4">
                        <div className="flex flex-col text-right items-start">
                          <span>فاتورة #{invoice.invoiceNumber || 'بدون رقم'} - بتاريخ <FormattedDate dateString={invoice.issueDate} /></span>
                          <Badge variant={invoiceStatusMap[invoice.status]?.variant || 'default'} className="mt-1">
                            {invoiceStatusMap[invoice.status]?.text || invoice.status}
                          </Badge>
                        </div>
                        <div className="flex flex-col text-left items-end">
                          <span className="font-semibold">{formatCurrency(invoice.totalAmount)}</span>
                          {invoice.status !== 'paid' && (
                            <span className="text-xs text-destructive">المتبقي: {formatCurrency(remaining)}</span>
                          )}
                        </div>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="text-center py-4 px-2 border-t mt-2">
                        <p className="text-muted-foreground text-sm mb-4">فاتورة شراء بضاعة.</p>
                        <div className="flex gap-2 justify-center mb-4">
                          {invoice.status !== 'paid' && (
                            <Button onClick={() => handleMakeInvoicePaymentClick(invoice)} size="sm">
                              <DollarSign className="w-4 h-4 me-1" />
                              تسديد دفعة
                            </Button>
                          )}
                          <Button onClick={() => handleMakeInvoiceReturnClick(invoice)} variant="outline" size="sm">
                            <RotateCcw className="w-4 h-4 me-1 text-destructive" />
                            إرجاع أصناف
                          </Button>
                        </div>
                        <InvoicePaymentsTable payments={invoice.payments} />
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
              {supplierDetails.externalDebts.map((debt) => (
                <div key={debt.id} className="flex justify-between items-center p-3 border rounded-lg bg-muted/50">
                  <div className="flex flex-col">
                    <span className="font-medium">
                      {debt.description || 'مستحقات خارجية'} - بتاريخ <FormattedDate dateString={debt.createdAt} />
                    </span>
                    {debt.referenceNumber && (
                      <span className="text-xs text-muted-foreground mt-1">مرجع: {debt.referenceNumber}</span>
                    )}
                  </div>
                  <div className="flex flex-col text-left items-end">
                    <span className="font-semibold">{formatCurrency(debt.amount)}</span>
                  </div>
                </div>
              ))}
              <div className="mt-4 pt-4 border-t">
                <div className="flex justify-between items-center">
                  <span className="font-bold">إجمالي المستحقات المطلوبة:</span>
                  <span className="font-bold text-destructive">{formatCurrency(totalDebt)}</span>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">لا توجد مستحقات مسجلة لهذا المورد.</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>سجل الدفعات الصادرة</CardTitle>
              <CardDescription>عرض شامل وتاريخي لكافة عمليات السداد الصادرة للمورد (سواء كانت عامة أو مرتبطة بفواتير محددة) لتدقيق الحركات المالية.</CardDescription>
            </div>
            <Button onClick={handleMakePaymentClick} variant="outline" size="sm">
              <DollarSign className="me-2 h-4 w-4" />
              سداد للمورد
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <PaymentsHistoryTable payments={supplierDetails.payments} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>مرتجعات المشتريات</CardTitle>
              <CardDescription>سجل عمليات إرجاع البضائع المخصومة من إجمالي مستحقات المورد.</CardDescription>
            </div>
            <Button onClick={handleReturnItemsClick} variant="outline" size="sm">
              <RotateCcw className="me-2 h-4 w-4" />
              إرجاع بضاعة
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {supplierDetails.purchaseReturns.length > 0 ? (
            <div className="space-y-3">
              {supplierDetails.purchaseReturns.map((return_) => (
                <div key={return_.id} className="border rounded-lg overflow-hidden">
                  <div className="flex justify-between items-center p-3 bg-muted/50">
                    <div className="flex flex-col">
                      <span className="font-medium">
                        {return_.returnNumber || 'بدون رقم'} - بتاريخ <FormattedDate dateString={return_.returnDate} />
                      </span>
                      {return_.invoiceNumber && (
                        <span className="text-xs text-muted-foreground mt-1">فاتورة: {return_.invoiceNumber}</span>
                      )}
                    </div>
                    <div className="flex flex-col text-left items-end">
                      <span className="font-semibold">{formatCurrency(return_.totalAmount)}</span>
                    </div>
                  </div>
                  {return_.items && return_.items.length > 0 && (
                    <div className="p-3 border-t">
                      <div className="space-y-2">
                        {return_.items.map((item, idx) => (
                          <div key={item.id || idx} className="flex justify-between items-center text-sm">
                            <span className="text-muted-foreground">
                              {item.productName || item.rawMaterialName || 'مادة غير محددة'}
                            </span>
                            <span className="font-medium">
                              {item.quantity} × {Math.round(item.costPrice).toLocaleString('en-US')} SDG
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {return_.reason && (
                    <div className="px-3 pb-3 pt-2 border-t">
                      <span className="text-xs text-muted-foreground">سبب الإرجاع: {return_.reason}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">لا توجد مرتجعات مسجلة لهذا المورد.</p>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className={`max-h-[90vh] overflow-y-auto ${dialogMode === 'returnItems' ? 'max-w-3xl' : 'max-w-lg'}`}>
          {renderDialogContent()}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={handleConfirmPayment} disabled={isSubmitting}>
              {isSubmitting && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
              تأكيد
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
