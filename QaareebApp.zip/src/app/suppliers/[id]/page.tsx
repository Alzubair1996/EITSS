import { getSupplierDetails, getPaymentMethods, getPurchaseInvoices } from '@/lib/queries';
import { notFound } from 'next/navigation';
import SupplierDetailsClientPage from './supplier-details-client';
import { PageHeader } from '@/components/page-header';
import { getSession } from '@/lib/server-auth';

export default async function SupplierDetailsPage({ params }: { params: { id: string } }) {
  const supplierDetails = await getSupplierDetails(params.id);
  const paymentMethods = await getPaymentMethods();
  const purchaseInvoices = await getPurchaseInvoices();
  const session = await getSession();
  const isAdmin = session?.username === 'admin';

  if (!supplierDetails) {
    notFound();
  }

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <PageHeader title={supplierDetails.name} />
        <SupplierDetailsClientPage 
            supplierDetails={supplierDetails} 
            paymentMethods={paymentMethods} 
            purchaseInvoices={purchaseInvoices}
            isAdmin={isAdmin}
        />
      </div>
  );
}

