'use client';

import * as React from 'react';
import { PlusCircle, Search, Truck, AlertCircle, Coins, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/page-header';
import { SuppliersTable } from './suppliers-table';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { SupplierForm } from './supplier-form';
import type { Supplier } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { deleteSupplier, addSupplier, updateSupplier } from './actions';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface SuppliersClientPageProps {
  initialSuppliers: Supplier[];
}

export default function SuppliersClientPage({ initialSuppliers }: SuppliersClientPageProps) {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [editingSupplier, setEditingSupplier] = React.useState<Supplier | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');
  
  const [debtFilter, setDebtFilter] = React.useState<string>('all');

  const { toast } = useToast();
  const router = useRouter();

  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  const stats = React.useMemo(() => {
    const total = initialSuppliers.length;
    const dainin = initialSuppliers.filter(s => (s.balance || 0) > 0).length;
    const totalOwed = initialSuppliers.reduce((sum, s) => sum + Math.max(0, s.balance || 0), 0);
    return { total, dainin, totalOwed };
  }, [initialSuppliers]);

  const handleAdd = () => { setEditingSupplier(null); setIsDialogOpen(true); };
  const handleEdit = (supplier: Supplier) => { setEditingSupplier(supplier); setIsDialogOpen(true); };

  const handleDelete = async (supplierId: string) => {
    const result = await deleteSupplier(supplierId);
    if (result.success) {
      toast({ title: 'تم الحذف بنجاح', description: result.message });
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'خطأ في الحذف', description: result.message });
    }
  };

  const handleFormSubmit = async (values: Omit<Supplier, 'id' | 'balance'>) => {
    const action = editingSupplier
      ? updateSupplier({ ...values, id: editingSupplier.id })
      : addSupplier(values);

    const result = await action;

    if (result.success) {
      toast({ title: editingSupplier ? 'تم التحديث بنجاح' : 'تمت الإضافة بنجاح', description: result.message });
      setIsDialogOpen(false);
      setEditingSupplier(null);
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }
  };

  const filteredSuppliers = React.useMemo(() => {
    return initialSuppliers.filter((supplier) => {
      const matchSearch =
        supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        supplier.phone.includes(searchTerm);
      
      let matchDebt = true;
      const bal = supplier.balance || 0;
      if (debtFilter === 'debt') matchDebt = bal > 0;
      else if (debtFilter === 'zero') matchDebt = bal === 0;

      return matchSearch && matchDebt;
    });
  }, [initialSuppliers, searchTerm, debtFilter]);

  const statCards = [
    { label: 'إجمالي الموردين', value: stats.total, icon: Truck, color: 'text-primary', bg: 'bg-primary/8', border: 'border-primary/20' },
    { label: 'موردين دائنون', value: stats.dainin, icon: AlertCircle, color: 'text-red-600', bg: 'bg-red-500/8', border: 'border-red-500/20' },
    { label: 'إجمالي المستحقات', value: formatCurrency(stats.totalOwed), icon: Coins, color: 'text-amber-600', bg: 'bg-amber-500/8', border: 'border-amber-500/20' },
  ];

  return (
    <>
      <PageHeader title="إدارة الموردين">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
            <Input
              type="search"
              placeholder="بحث بالاسم أو الهاتف..."
              className="pr-9 w-[180px] lg:w-[240px] h-9 rounded-xl bg-background border-border/60 text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button onClick={handleAdd} size="sm" className="h-9 rounded-xl gap-1.5 px-4 shadow-sm">
            <PlusCircle className="h-3.5 w-3.5" />
            إضافة مورد
          </Button>
        </div>
      </PageHeader>

      <div className="flex flex-col gap-4 p-4 md:p-6 max-w-screen-xl mx-auto w-full">

        {/* Compact Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {statCards.map((card, idx) => (
            <div key={idx} className={cn('rounded-xl border px-3 py-2.5 flex items-center gap-2.5 bg-card', card.border)}>
              <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center shrink-0', card.bg, card.color)}>
                <card.icon className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-muted-foreground font-medium leading-none mb-0.5 truncate">{card.label}</p>
                <p className="text-sm font-extrabold text-foreground leading-none truncate">{card.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Filter Strip */}
        <div className="flex flex-wrap items-center gap-2 bg-muted/20 px-4 py-2.5 rounded-xl border border-border/40">
          <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
          <span className="text-[11px] font-bold text-muted-foreground">تصفية:</span>

          <Select value={debtFilter} onValueChange={setDebtFilter}>
            <SelectTrigger className="w-[160px] bg-background border-border/60 rounded-lg text-[11px] h-7 font-medium">
              <SelectValue placeholder="حالة الحساب المالي" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الموردين</SelectItem>
              <SelectItem value="debt">عليهم مستحقات دائن</SelectItem>
              <SelectItem value="zero">حساب صفر</SelectItem>
            </SelectContent>
          </Select>

          {debtFilter !== 'all' && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDebtFilter('all')}
              className="h-7 text-[11px] font-medium text-red-600 hover:text-red-700 rounded-lg px-2"
            >
              تصفير
            </Button>
          )}

          <span className="text-[10px] text-muted-foreground bg-background px-2 py-0.5 rounded-full font-medium border border-border/40 ml-auto">
            {filteredSuppliers.length} مورد
          </span>
        </div>

        <SuppliersTable
          suppliers={filteredSuppliers}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl">
          <SupplierForm
            supplier={editingSupplier}
            onSubmit={handleFormSubmit}
            onCancel={() => setIsDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}
