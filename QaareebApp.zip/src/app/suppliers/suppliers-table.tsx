
'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MoreHorizontal, Pencil, Trash2, Truck, TrendingDown, MapPin } from 'lucide-react';
import type { Supplier } from '@/lib/types';
import Link from 'next/link';

interface SuppliersTableProps {
  suppliers: Supplier[];
  onEdit: (supplier: Supplier) => void;
  onDelete: (supplierId: string) => void;
}

export function SuppliersTable({ suppliers, onEdit, onDelete }: SuppliersTableProps) {
  const formatCurrency = (amount: number) =>
    `${Math.round(Math.abs(amount)).toLocaleString('en-US')} SDG`;

  const totalOwed = suppliers.reduce((sum, s) => sum + Math.max(0, s.balance || 0), 0);

  return (
    <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
      <CardHeader className="pb-4 border-b border-border/40 bg-secondary/10 flex flex-row justify-between items-center">
        <div>
          <CardTitle className="text-base font-bold text-foreground">قائمة الموردين</CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">إدارة بيانات الموردين وأرصدتهم</p>
        </div>
        <div className="flex items-center gap-2">
          {totalOwed > 0 && (
            <div className="flex items-center gap-1.5 text-xs font-semibold text-red-600 bg-red-50 dark:bg-red-500/10 px-3 py-1.5 rounded-full border border-red-200 dark:border-red-500/20">
              <TrendingDown className="h-3 w-3" />
              مستحق: {formatCurrency(totalOwed)}
            </div>
          )}
          <div className="text-xs font-semibold text-muted-foreground bg-background px-3 py-1.5 rounded-full border border-border/40 shadow-sm">
            الإجمالي: {suppliers.length}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>اسم المورد</TableHead>
              <TableHead>رقم الهاتف</TableHead>
              <TableHead>العنوان</TableHead>
              <TableHead className="text-right">الرصيد المستحق</TableHead>
              <TableHead className="text-center">الإجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {suppliers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-40 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-4 rounded-2xl bg-muted/50">
                      <Truck className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">لا يوجد موردون</p>
                      <p className="text-sm text-muted-foreground mt-1">قم بإضافة مورد جديد للبدء</p>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              suppliers.map((supplier) => {
                const balance = supplier.balance || 0;
                return (
                  <TableRow key={supplier.id} className="group">
                    <TableCell className="font-semibold">
                      <Link
                        href={`/suppliers/${supplier.id}`}
                        className="text-primary hover:text-primary/80 hover:underline transition-colors"
                      >
                        {supplier.name}
                      </Link>
                    </TableCell>
                    <TableCell className="text-muted-foreground font-mono text-sm">
                      {supplier.phone || '—'}
                    </TableCell>
                    <TableCell>
                      {supplier.address ? (
                        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                          <MapPin className="h-3 w-3 flex-shrink-0" />
                          {supplier.address}
                        </div>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <span className={`font-mono font-bold text-sm ${balance > 0 ? 'text-red-600' : balance < 0 ? 'text-emerald-600' : 'text-muted-foreground'}`}>
                        {balance !== 0 ? formatCurrency(balance) : '—'}
                      </span>
                    </TableCell>
                    <TableCell className="text-center">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            aria-haspopup="true"
                            size="icon"
                            variant="ghost"
                            className="rounded-full h-8 w-8 hover:bg-primary/5 hover:text-primary opacity-100 transition-all"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">فتح القائمة</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="rounded-xl shadow-lg border-border/50">
                          <DropdownMenuItem
                            onSelect={() => onEdit(supplier)}
                            className="rounded-lg cursor-pointer"
                          >
                            <Pencil className="me-2 h-4 w-4 text-primary" />
                            تعديل البيانات
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onSelect={() => onDelete(supplier.id)}
                            className="rounded-lg cursor-pointer text-destructive focus:text-destructive"
                          >
                            <Trash2 className="me-2 h-4 w-4" />
                            حذف المورد
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
