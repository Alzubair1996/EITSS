'use client';

import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PageHeader } from '@/components/page-header';
import { DollarSign, TrendingUp, TrendingDown, Building2, Calculator, Wallet, Calendar, Sparkles } from 'lucide-react';
import { getFinancialAccountSummary } from './actions';
import type { FixedAssetDetails } from '@/lib/types';
import { format } from 'date-fns';

interface FinancialAccountsClientPageProps {
  initialFixedAssets: FixedAssetDetails[];
}

export default function FinancialAccountsClientPage({ initialFixedAssets }: FinancialAccountsClientPageProps) {
  const [loading, setLoading] = React.useState(false);
  const [summary, setSummary] = React.useState<any>(null);

  React.useEffect(() => {
    async function fetchSummary() {
      setLoading(true);
      const result = await getFinancialAccountSummary();
      if (result.success && result.data) {
        setSummary(result.data);
      }
      setLoading(false);
    }
    fetchSummary();
  }, []);

  const formatCurrency = (amount: number) => {
    return `${Math.round(amount).toLocaleString('en-US')} SDG`;
  };

  if (loading || !summary) {
    return (
      <div className="flex flex-1 flex-col gap-6 p-4 md:gap-8 md:p-8 max-w-7xl mx-auto w-full">
        <PageHeader title="الحسابات المالية" subtitle="تحميل الإحصاءات والملخص المالي..." />
        <div className="flex flex-col items-center justify-center h-64 gap-3 bg-card border border-border/40 rounded-3xl">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <div className="text-muted-foreground text-sm">جاري جلب البيانات المالية...</div>
        </div>
      </div>
    );
  }

  const activeAssets = initialFixedAssets.filter(a => a.status === 'active');

  return (
    <div className="flex flex-1 flex-col gap-6 p-4 md:gap-8 md:p-8 max-w-7xl mx-auto w-full">
      <PageHeader 
        title="الحسابات المالية" 
        subtitle="ملخص شامل للإيرادات والمصروفات والأصول الثابتة الخاصة بالمؤسسة"
      />
      
      {/* Financial Metrics Cards (Material Design 3 Pastel theme) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Total Revenue */}
        <Card className="hover-lift rounded-3xl border border-emerald-500/10 bg-emerald-500/[0.03] hover:bg-emerald-500/[0.06] transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-semibold text-muted-foreground">إجمالي الإيرادات</CardTitle>
            <div className="p-2 bg-emerald-500/10 text-emerald-600 rounded-xl">
              <DollarSign className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent className="pt-2">
            <div className="text-2xl font-bold tracking-tight text-emerald-600 font-mono">
              {formatCurrency(summary.totalRevenue)}
            </div>
            <p className="text-[11px] text-muted-foreground mt-1">
              مجموع العمليات والخدمات المباعة بالنظام
            </p>
          </CardContent>
        </Card>

        {/* Total Expenses */}
        <Card className="hover-lift rounded-3xl border border-red-500/10 bg-red-500/[0.03] hover:bg-red-500/[0.06] transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-semibold text-muted-foreground">إجمالي المصروفات</CardTitle>
            <div className="p-2 bg-red-500/10 text-red-600 rounded-xl">
              <TrendingDown className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent className="pt-2">
            <div className="text-2xl font-bold tracking-tight text-red-600 font-mono">
              {formatCurrency(summary.totalExpenses)}
            </div>
            <p className="text-[11px] text-muted-foreground mt-1">
              إجمالي نفقات التشغيل والمشتريات
            </p>
          </CardContent>
        </Card>

        {/* Net Profit */}
        <Card className="hover-lift rounded-3xl border border-primary/10 bg-primary/[0.03] hover:bg-primary/[0.06] transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-semibold text-muted-foreground">صافي الربح التشغيلي</CardTitle>
            <div className="p-2 bg-primary/10 text-primary rounded-xl">
              <TrendingUp className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent className="pt-2">
            <div className={`text-2xl font-bold tracking-tight font-mono ${summary.netProfit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              {summary.netProfit >= 0 ? '+' : ''}{formatCurrency(summary.netProfit)}
            </div>
            <p className="text-[11px] text-muted-foreground mt-1">
              الفارق المالي المباشر (الإيرادات - المصروفات)
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Financial Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Fixed Assets Section */}
        <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
          <CardHeader className="pb-4 border-b border-border/40 bg-secondary/15">
            <CardTitle className="text-base font-bold text-foreground flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              الأصول الثابتة
            </CardTitle>
            <CardDescription className="text-xs">الملخص والأرصدة المتعلقة بالأصول غير المتداولة</CardDescription>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="flex justify-between items-center bg-secondary/10 px-4 py-3 rounded-2xl border border-border/30">
              <span className="text-sm font-semibold text-muted-foreground">القيمة الدفترية الحالية</span>
              <span className="text-base font-bold text-primary font-mono">{formatCurrency(summary.totalFixedAssetsValue)}</span>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm py-1.5 border-b border-border/40">
                <span className="text-muted-foreground font-medium">عدد الأصول النشطة</span>
                <span className="font-bold text-foreground">{summary.activeFixedAssetsCount} أصول</span>
              </div>
              <div className="flex justify-between items-center text-sm py-1.5 border-b border-border/40">
                <span className="text-muted-foreground font-medium">عدد الأصول المباعة</span>
                <span className="font-bold text-foreground">{summary.soldFixedAssetsCount} أصول</span>
              </div>
              <div className="flex justify-between items-center text-sm py-1.5 border-b border-border/40">
                <span className="text-muted-foreground font-medium">عائدات بيع الأصول</span>
                <span className="font-bold text-emerald-600 font-mono">{formatCurrency(summary.totalAssetsFromSales)}</span>
              </div>
              <div className="flex justify-between items-center text-sm py-1.5">
                <span className="text-muted-foreground font-medium">تكاليف شراء الأصول</span>
                <span className="font-bold text-red-600 font-mono">{formatCurrency(summary.totalAssetsExpenses)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Global Financial Summary */}
        <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
          <CardHeader className="pb-4 border-b border-border/40 bg-secondary/15">
            <CardTitle className="text-base font-bold text-foreground flex items-center gap-2">
              <Calculator className="h-5 w-5 text-primary" />
              الملخص المالي الشامل
            </CardTitle>
            <CardDescription className="text-xs">تجميع الحسابات الشاملة (التشغيلية والأصول)</CardDescription>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center text-sm py-1">
                <span className="text-muted-foreground font-medium">إجمالي الإيرادات الكلية (مع الأصول)</span>
                <span className="font-bold text-emerald-600 font-mono">{formatCurrency(summary.totalRevenueWithAssets)}</span>
              </div>
              <div className="flex justify-between items-center text-sm py-1">
                <span className="text-muted-foreground font-medium">إجمالي المصروفات الكلية (مع الأصول)</span>
                <span className="font-bold text-red-600 font-mono">{formatCurrency(summary.totalExpensesWithAssets)}</span>
              </div>
            </div>

            <div className="flex flex-col bg-primary/10 p-4 rounded-2xl border border-primary/20 mt-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-extrabold text-primary flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-primary" />
                  صافي الربح الشامل للمؤسسة
                </span>
                <span className={`text-xl font-extrabold font-mono ${summary.netProfitWithAssets >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {summary.netProfitWithAssets >= 0 ? '+' : ''}{formatCurrency(summary.netProfitWithAssets)}
                </span>
              </div>
              <p className="text-[10px] text-muted-foreground/80 mt-1.5 leading-relaxed">
                هذا المقياس يمثل النتيجة المالية النهائية بعد حساب نفقات وإيرادات التشغيل، مضافاً إليها نفقات ومبيعات الأصول الثابتة المقتناة.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Fixed Assets List */}
      {activeAssets.length > 0 && (
        <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
          <CardHeader className="pb-4 border-b border-border/40 bg-secondary/15">
            <CardTitle className="text-base font-bold text-foreground flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              الأصول الثابتة النشطة حالياً
            </CardTitle>
            <CardDescription className="text-xs">قائمة الأصول غير المتداولة التي تحتفظ بها المؤسسة حالياً</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {activeAssets.map((asset) => (
                <div key={asset.id} className="flex flex-col justify-between p-4 bg-secondary/15 rounded-2xl border border-border/40 hover:bg-secondary/20 transition-colors">
                  <div className="space-y-1">
                    <div className="font-bold text-foreground text-sm">{asset.name}</div>
                    <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                      <Calendar className="w-3.5 h-3.5" />
                      شراء: {format(new Date(asset.purchaseDate), 'dd/MM/yyyy')}
                    </div>
                  </div>
                  <div className="flex justify-between items-end border-t border-border/30 pt-3 mt-3">
                    <div>
                      <div className="text-[10px] text-muted-foreground font-medium">سعر الشراء</div>
                      <div className="text-xs font-bold text-muted-foreground font-mono">{formatCurrency(asset.purchasePrice)}</div>
                    </div>
                    <div className="text-left">
                      <div className="text-[10px] text-primary font-bold">القيمة الحالية</div>
                      <div className="text-sm font-extrabold text-primary font-mono">{formatCurrency(asset.bookValue)}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
