'use server';

import { getFixedAssets, getReportStats } from '@/lib/queries';

export async function getFinancialAccountSummary() {
    try {
        // Get overall stats without date range
        const stats = await getReportStats();
        
        // Get all fixed assets
        const fixedAssets = await getFixedAssets();
        
        // Calculate total fixed assets value
        const totalFixedAssetsValue = fixedAssets
            .filter(asset => asset.status === 'active')
            .reduce((sum, asset) => sum + asset.bookValue, 0);
        
        // Calculate total assets from sales
        const totalAssetsFromSales = fixedAssets
            .filter(asset => asset.status === 'sold')
            .reduce((sum, asset) => sum + (asset.salePrice || 0), 0);
        
        // Calculate total assets expenses (purchases)
        const totalAssetsExpenses = fixedAssets.reduce((sum, asset) => sum + asset.purchasePrice, 0);

        // Net profit includes revenue minus expenses
        const netProfit = stats.totalRevenue - stats.totalExpenses;
        
        // Include fixed assets in calculations
        const totalRevenueWithAssets = stats.totalRevenue + totalAssetsFromSales;
        const totalExpensesWithAssets = stats.totalExpenses + totalAssetsExpenses;
        const netProfitWithAssets = totalRevenueWithAssets - totalExpensesWithAssets;

        return {
            success: true,
            data: {
                totalRevenue: stats.totalRevenue,
                totalExpenses: stats.totalExpenses,
                netProfit,
                totalFixedAssetsValue,
                totalAssetsFromSales,
                totalAssetsExpenses,
                totalRevenueWithAssets,
                totalExpensesWithAssets,
                netProfitWithAssets,
                activeFixedAssetsCount: fixedAssets.filter(a => a.status === 'active').length,
                soldFixedAssetsCount: fixedAssets.filter(a => a.status === 'sold').length,
            }
        };
    } catch (error) {
        console.error("Failed to fetch financial account summary:", error);
        return { 
            success: false, 
            message: 'فشل جلب الملخص المالي',
            data: {
                totalRevenue: 0,
                totalExpenses: 0,
                netProfit: 0,
                totalFixedAssetsValue: 0,
                totalAssetsFromSales: 0,
                totalAssetsExpenses: 0,
                totalRevenueWithAssets: 0,
                totalExpensesWithAssets: 0,
                netProfitWithAssets: 0,
                activeFixedAssetsCount: 0,
                soldFixedAssetsCount: 0,
            }
        };
    }
}

