import FinancialAccountsClientPage from './financial-accounts-client-page';
import { getFixedAssets } from '@/lib/queries';

export default async function FinancialAccountsPage() {
  const fixedAssets = await getFixedAssets();

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <FinancialAccountsClientPage 
            initialFixedAssets={fixedAssets}
        />
      </div>
  );
}

