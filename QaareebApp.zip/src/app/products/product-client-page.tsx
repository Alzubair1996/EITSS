
'use client';

import * as React from 'react';
import { PlusCircle, Search, Upload, Download, DollarSign, Printer, Package, AlertTriangle, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/page-header';
import { ProductTable } from './product-table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import type { Product, Category, Unit, CompanyInfo } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { deleteProduct, handleProductImport, applyUSDRateToCategories } from './actions';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { IS_RESTAURANT_APP } from '@/lib/types';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import Link from 'next/link';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface ProductClientPageProps {
  initialProducts: Product[];
  categories: Category[];
  units: Unit[];
  currentUSDRate: number;
  companyInfo: CompanyInfo;
}

export default function ProductClientPage({
  initialProducts,
  categories,
  units,
  currentUSDRate,
  companyInfo,
}: ProductClientPageProps) {
  const [isImportDialogOpen, setIsImportDialogOpen] = React.useState(false);
  const [isRateDialogOpen, setIsRateDialogOpen] = React.useState(false);

  const [searchTerm, setSearchTerm] = React.useState('');
  
  const [usdRate, setUsdRate] = React.useState(currentUSDRate);
  const [selectedCategories, setSelectedCategories] = React.useState<string[]>([]);
  
  const { toast } = useToast();
  const router = useRouter();

  const [stockFilter, setStockFilter] = React.useState<'all' | 'instock' | 'low' | 'out'>('all');

  const stats = React.useMemo(() => {
    const total = initialProducts.length;
    const lowStock = initialProducts.filter(p => !IS_RESTAURANT_APP && (p.quantity || 0) <= 5 && (p.quantity || 0) > 0).length;
    const outOfStock = initialProducts.filter(p => !IS_RESTAURANT_APP && (p.quantity || 0) <= 0).length;
    const activeCats = new Set(initialProducts.map(p => p.categoryId)).size;
    return { total, lowStock, outOfStock, activeCats };
  }, [initialProducts]);


  const handleDeleteProduct = async (productId: string) => {
    const result = await deleteProduct(productId);
    if (result.success) {
        toast({ title: 'تم الحذف بنجاح', description: result.message });
        router.refresh(); 
    } else {
        toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }
  };

  
  const handleImport = async (event: React.MouseEvent<HTMLButtonElement>) => {
    const fileInput = document.getElementById('import-file') as HTMLInputElement;
    const file = fileInput?.files?.[0];
    if (!file) {
      toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى اختيار ملف Excel أولاً.' });
      return;
    }
    
    const XLSX = await import('xlsx');
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);

        const result = await handleProductImport(json);
        
        if (result.success) {
          toast({ title: 'نجاح الاستيراد', description: result.message });
          setIsImportDialogOpen(false);
          router.refresh();
        } else {
          toast({ variant: 'destructive', title: 'فشل الاستيراد', description: result.message, duration: 7000 });
        }
      } catch (error) {
        console.error(error);
        toast({ variant: 'destructive', title: 'خطأ', description: 'فشل قراءة ملف Excel. تأكد من أن التنسيق صحيح.' });
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleDownloadTemplate = async () => {
    const XLSX = await import('xlsx');
    const headers = ["الاسم", "الرمز", "اسم الفئة", "اسم الوحدة", "الكمية", "سعر البيع", "الضمان", "سعر صرف الدولار", "تاريخ الانتهاء"];
    const ws = XLSX.utils.aoa_to_sheet([headers]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Products");
    XLSX.writeFile(wb, "MatjarakStore_Product_Template.xlsx");
    toast({ title: 'تم التحميل', description: 'تم تنزيل قالب Excel بالعربية بنجاح.' });
  };

  const handleExport = async () => {
    const XLSX = await import('xlsx');
    const dataToExport = filteredProducts.map(product => {
      const category = categories.find(c => c.id === product.categoryId);
      const unit = units.find(u => u.id === product.unitId);
      return {
        'الاسم': product.name,
        'الكود': product.code,
        'الفئة': category ? category.name : '',
        'الوحدة': unit ? unit.name : '',
        'الكمية': product.quantity,
        'سعر البيع': product.price,
        'الضمان': product.warranty,
        'سعر البيع بالدولار': product.priceUSD,
        'سعر الصرف الأولي': product.initialUSDRate,
        'تاريخ الانتهاء': (product as any).expiryDate ?? '',
      };
    });

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "المنتجات");
    XLSX.writeFile(wb, `Products_Export_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast({ title: 'تم التصدير بنجاح', description: 'تم إنشاء ملف Excel يحتوي على المنتجات.' });
  };

  const handleRateUpdate = async () => {
    const result = await applyUSDRateToCategories(usdRate, selectedCategories);
    if(result.success) {
      toast({ title: 'تم التحديث بنجاح', description: result.message });
      setIsRateDialogOpen(false);
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }
  };

  const handleCategorySelection = (categoryId: string) => {
    setSelectedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId) 
        : [...prev, categoryId]
    );
  };

  const handleSelectAllCategories = (checked: boolean) => {
    if (checked) {
      setSelectedCategories(categories.map(c => c.id));
    } else {
      setSelectedCategories([]);
    }
  }

  const filteredProducts = React.useMemo(() => {
    return initialProducts.filter((product) => {
      const matchSearch =
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (product.code || '').toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchCategory =
        selectedCategories.length === 0 ||
        selectedCategories.includes(product.categoryId);
      
      let matchStock = true;
      const qty = product.quantity || 0;
      if (stockFilter === 'instock') {
        matchStock = qty > 5;
      } else if (stockFilter === 'low') {
        matchStock = qty <= 5 && qty > 0;
      } else if (stockFilter === 'out') {
        matchStock = qty <= 0;
      }

      return matchSearch && matchCategory && matchStock;
    });
  }, [initialProducts, searchTerm, selectedCategories, stockFilter]);

  const handlePrint = () => window.print();

  const statCards = [
    {
      label: IS_RESTAURANT_APP ? 'إجمالي الأصناف' : 'إجمالي المنتجات',
      value: stats.total,
      color: 'text-primary',
      bg: 'bg-primary/8',
      border: 'border-primary/20',
    },
    {
      label: 'الفئات النشطة',
      value: stats.activeCats,
      color: 'text-cyan-600',
      bg: 'bg-cyan-500/8',
      border: 'border-cyan-500/20',
    },
    ...(!IS_RESTAURANT_APP ? [
      {
        label: 'منخفضة المخزون',
        value: stats.lowStock,
        color: 'text-amber-600',
        bg: 'bg-amber-500/8',
        border: 'border-amber-500/20',
      },
      {
        label: 'نافدة من المخزون',
        value: stats.outOfStock,
        color: 'text-red-600',
        bg: 'bg-red-500/8',
        border: 'border-red-500/20',
      },
    ] : []),
  ];

  return (
    <>
      <PageHeader title={IS_RESTAURANT_APP ? "إدارة الأصناف" : "إدارة المنتجات"}>
        <div className="flex items-center gap-2 no-print">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
            <Input
              type="search"
              placeholder="بحث بالاسم أو الكود..."
              className="pr-9 w-[180px] lg:w-[240px] h-9 rounded-xl bg-background border-border/60 text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button onClick={handlePrint} variant="outline" size="sm" className="h-9 rounded-xl gap-1.5">
            <Printer className="h-3.5 w-3.5" />
            طباعة
          </Button>
          {!IS_RESTAURANT_APP && (
            <>
              <Button onClick={handleExport} variant="outline" size="sm" className="h-9 rounded-xl gap-1.5">
                <Download className="h-3.5 w-3.5" />
                تصدير
              </Button>
              <Button onClick={() => setIsImportDialogOpen(true)} variant="outline" size="sm" className="h-9 rounded-xl gap-1.5">
                <Upload className="h-3.5 w-3.5" />
                استيراد
              </Button>
              <Button onClick={() => setIsRateDialogOpen(true)} variant="outline" size="sm" className="h-9 rounded-xl gap-1.5">
                <DollarSign className="h-3.5 w-3.5" />
                تحديث الأسعار
              </Button>
            </>
          )}
          <Button asChild size="sm" className="h-9 rounded-xl gap-1.5 px-4 shadow-sm">
            <Link href="/products/new">
              <PlusCircle className="h-3.5 w-3.5" />
              إضافة {IS_RESTAURANT_APP ? "صنف" : "منتج"}
            </Link>
          </Button>
        </div>
      </PageHeader>

      <div className="flex flex-col gap-4 p-4 md:p-6 max-w-screen-xl mx-auto w-full">

        {/* Compact Stats */}
        <div className={cn("grid gap-2 no-print", IS_RESTAURANT_APP ? "grid-cols-2" : "grid-cols-2 sm:grid-cols-4")}>
          {statCards.map((card, idx) => (
            <div
              key={idx}
              className={cn('rounded-xl border px-3 py-2.5 flex items-center gap-2.5 bg-card', card.border)}
            >
              <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center shrink-0', card.bg, card.color)}>
                <Package className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-muted-foreground font-medium leading-none mb-0.5 truncate">{card.label}</p>
                <p className="text-base font-extrabold text-foreground leading-none">{card.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Low Stock Warning */}
        {!IS_RESTAURANT_APP && (stats.outOfStock > 0 || stats.lowStock > 0) && (
          <div className="flex items-center gap-2 rounded-xl border border-amber-500/20 bg-amber-50 dark:bg-amber-500/5 px-4 py-2.5 no-print">
            <AlertTriangle className="h-3.5 w-3.5 text-amber-600 shrink-0" />
            <p className="text-xs text-amber-700 dark:text-amber-400">
              {stats.outOfStock > 0 && <span className="font-bold">{stats.outOfStock} منتج نافد • </span>}
              {stats.lowStock > 0 && <span>{stats.lowStock} منتج على وشك النفاد</span>}
            </p>
          </div>
        )}

        {/* Filter Strip */}
        <div className="flex flex-wrap items-center gap-2 bg-muted/20 px-4 py-2.5 rounded-xl border border-border/40 no-print">
          <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
          <span className="text-[11px] font-bold text-muted-foreground">تصفية:</span>

          {/* Category */}
          <Select
            value={selectedCategories.length === 0 ? 'all' : selectedCategories[0]}
            onValueChange={(val) => {
              if (val === 'all') setSelectedCategories([]);
              else setSelectedCategories([val]);
            }}
          >
            <SelectTrigger className="w-[150px] bg-background border-border/60 rounded-lg text-[11px] h-7 font-medium">
              <SelectValue placeholder="كل الفئات" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الفئات</SelectItem>
              {categories.map(c => (
                <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Stock Filter (non-restaurant) */}
          {!IS_RESTAURANT_APP && (
            <Select value={stockFilter} onValueChange={(val: any) => setStockFilter(val)}>
              <SelectTrigger className="w-[150px] bg-background border-border/60 rounded-lg text-[11px] h-7 font-medium">
                <SelectValue placeholder="حالة المخزون" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل الكميات</SelectItem>
                <SelectItem value="instock">متوفر</SelectItem>
                <SelectItem value="low">منخفض المخزون</SelectItem>
                <SelectItem value="out">نافد</SelectItem>
              </SelectContent>
            </Select>
          )}

          {(selectedCategories.length > 0 || stockFilter !== 'all') && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => { setSelectedCategories([]); setStockFilter('all'); }}
              className="h-7 text-[11px] font-medium text-red-600 hover:text-red-700 rounded-lg px-2"
            >
              تصفير
            </Button>
          )}

          <span className="text-[10px] text-muted-foreground bg-background px-2 py-0.5 rounded-full font-medium border border-border/40 ml-auto">
            {filteredProducts.length} نتيجة
          </span>
        </div>

        <ProductTable
          products={filteredProducts}
          categories={categories}
          units={units}
          onDelete={handleDeleteProduct}
          isRestaurant={IS_RESTAURANT_APP}
        />
      </div>

      {/* Import Dialog */}
      <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
        <DialogContent className="sm:max-w-[800px] rounded-2xl">
          <DialogHeader>
            <DialogTitle>استيراد وتحديث المنتجات</DialogTitle>
            <DialogDescription>
              قم برفع ملف Excel لإضافة منتجات جديدة أو تحديث المنتجات الحالية. سيتم التحديث بناءً على تطابق `code`.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <p className="font-semibold text-sm">الأعمدة المطلوبة:</p>
            <div className="rounded-xl border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/30">
                    <TableHead className="text-xs">الاسم (مطلوب)</TableHead>
                    <TableHead className="text-xs">الرمز (مطلوب)</TableHead>
                    <TableHead className="text-xs">اسم الفئة (مطلوب)</TableHead>
                    <TableHead className="text-xs">اسم الوحدة (مطلوب)</TableHead>
                    <TableHead className="text-xs">الكمية</TableHead>
                    <TableHead className="text-xs">سعر البيع</TableHead>
                    <TableHead className="text-xs">الضمان</TableHead>
                    <TableHead className="text-xs">سعر الدولار</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="text-xs">لابتوب ديل</TableCell>
                    <TableCell className="text-xs">LP-DELL-01</TableCell>
                    <TableCell className="text-xs">إلكترونيات</TableCell>
                    <TableCell className="text-xs">قطعة</TableCell>
                    <TableCell className="text-xs">15</TableCell>
                    <TableCell className="text-xs">250000</TableCell>
                    <TableCell className="text-xs">سنة</TableCell>
                    <TableCell className="text-xs">2600</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
            <p className="text-xs text-muted-foreground">
              ملاحظة: يجب أن تكون أسماء الفئات والوحدات موجودة مسبقًا في النظام.
            </p>
            <div className="flex gap-3 items-center">
              <Label htmlFor="import-file" className="sr-only">اختر ملف</Label>
              <Input id="import-file" type="file" accept=".xlsx, .xls" className="flex-grow rounded-xl text-sm" />
              <Button type="button" variant="secondary" size="sm" onClick={handleDownloadTemplate} className="rounded-xl">
                <Download className="me-1.5 h-3.5 w-3.5" />
                قالب
              </Button>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" className="rounded-xl" onClick={() => setIsImportDialogOpen(false)}>إلغاء</Button>
            <Button className="rounded-xl" onClick={handleImport}>بدء الاستيراد</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* USD Rate Dialog */}
      <Dialog open={isRateDialogOpen} onOpenChange={setIsRateDialogOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl">
          <DialogHeader>
            <DialogTitle>تحديث الأسعار حسب سعر الصرف</DialogTitle>
            <DialogDescription>
              أدخل سعر الصرف الجديد للدولار واختر الفئات التي تريد تحديث أسعارها.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div>
              <Label htmlFor="usdRate" className="text-sm font-semibold">سعر صرف الدولار (SDG)</Label>
              <Input
                id="usdRate"
                type="number"
                value={usdRate}
                onChange={(e) => setUsdRate(parseFloat(e.target.value) || 0)}
                className="mt-1.5 rounded-xl text-right"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-semibold">اختر الفئات للتحديث</Label>
              <div className="flex items-center gap-2 px-1">
                <Checkbox
                  id="select-all"
                  onCheckedChange={(checked) => handleSelectAllCategories(checked as boolean)}
                  checked={selectedCategories.length === categories.length}
                />
                <Label htmlFor="select-all" className="text-sm font-normal cursor-pointer">تحديد الكل</Label>
              </div>
              <ScrollArea className="h-40 rounded-xl border p-2">
                <div className="space-y-2">
                  {categories.map(category => (
                    <div key={category.id} className="flex items-center gap-2 px-1">
                      <Checkbox
                        id={`cat-${category.id}`}
                        checked={selectedCategories.includes(category.id)}
                        onCheckedChange={() => handleCategorySelection(category.id)}
                      />
                      <Label htmlFor={`cat-${category.id}`} className="text-sm font-normal cursor-pointer">{category.name}</Label>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" className="rounded-xl" onClick={() => setIsRateDialogOpen(false)}>إلغاء</Button>
            <Button className="rounded-xl" onClick={handleRateUpdate} disabled={selectedCategories.length === 0}>
              تحديث الأسعار المختارة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
