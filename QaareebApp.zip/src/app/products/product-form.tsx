'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { Product, Category, Unit, CompanyInfo, ProductIngredientDetails } from '@/lib/types';
import { IS_RESTAURANT_APP } from '@/lib/types';
import Image from 'next/image';
import { ScrollArea } from '@/components/ui/scroll-area';
import { LoaderCircle, PlusCircle, Trash2 } from 'lucide-react';
import { addProductIngredients, deleteProductIngredient, getRawMaterialsAction } from './ingredients/actions';
import { useToast } from '@/hooks/use-toast';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { useRouter } from 'next/navigation';

const formSchema = z.object({
  name: z.string().min(2, { message: 'الاسم مطلوب' }),
  code: z.string().optional().nullable(),
  categoryId: z.string().min(1, { message: 'الفئة مطلوبة' }),
  unitId: z.string().min(1, { message: 'الوحدة مطلوبة' }),
  quantity: z.coerce.number().min(0, { message: 'الكمية يجب أن تكون موجبة' }),
  costPrice: z.coerce.number().optional().default(0),
  price: z.coerce.number().min(0.01, { message: 'السعر مطلوب' }),
  initialUSDRate: z.coerce.number().optional(),
  warranty: z.string().optional(),
  image: z.string().optional().nullable(),
  priceUSD: z.coerce.number().optional(), // This will be calculated
  isDynamicPrice: z.boolean(),
  expiryDate: z.string().optional().nullable(),
});

export type ProductFormValues = z.infer<typeof formSchema>;

interface ProductFormProps {
  product: Product & { ingredients?: ProductIngredientDetails[] } | null;
  categories: Category[];
  units: Unit[];
  onSubmit: (data: ProductFormValues) => Promise<any>;
  currentUSDRate: number;
  companyInfo: CompanyInfo;
}

export function ProductForm({
  product,
  categories,
  units,
  onSubmit,
  currentUSDRate,
  companyInfo,
}: ProductFormProps) {
  const router = useRouter();
  const [imagePreview, setImagePreview] = React.useState<string | null>(product?.image || null);
  
  const [rawMaterials, setRawMaterials] = React.useState<(import('@/lib/types').RawMaterialDetails)[]>([]);
  const [ingredients, setIngredients] = React.useState(product?.ingredients || []);
  const [isLoading, setIsLoading] = React.useState(false);
  const { toast } = useToast();

  React.useEffect(() => {
    if(IS_RESTAURANT_APP) {
        getRawMaterialsAction().then(setRawMaterials);
    }
  }, []);

  const form = useForm<ProductFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: product?.name || '',
      code: product?.code || '',
      categoryId: product?.categoryId || '',
      unitId: product?.unitId || '',
      quantity: (IS_RESTAURANT_APP ? 99999 : (product ? product.quantity : '')) as any,
      costPrice: (product ? product.costPrice : 0) as any,
      price: (product ? product.price : '') as any,
      initialUSDRate: (product ? product.initialUSDRate : (currentUSDRate || '')) as any,
      warranty: product?.warranty || '',
      image: product?.image || null,
      priceUSD: (product ? product.priceUSD : '') as any,
      isDynamicPrice: product?.isDynamicPrice ?? true,
      expiryDate: (product as any)?.expiryDate || '',
    },
  });

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        form.setValue('image', base64String);
        setImagePreview(base64String);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const priceInSDG = form.watch('price');
  const usdRate = form.watch('initialUSDRate');

  const calculatedUSDPrice = React.useMemo(() => {
    if (priceInSDG > 0 && usdRate && usdRate > 0) {
      return priceInSDG / usdRate;
    }
    return 0;
  }, [priceInSDG, usdRate]);

  const handleFormSubmit = async (data: ProductFormValues) => {
    setIsLoading(true);
    // Compute USD equivalents for selling and cost prices.
    const costPriceUSD = data.costPrice && data.initialUSDRate && data.initialUSDRate > 0
        ? data.costPrice / data.initialUSDRate
        : 0;
    const finalData = {
        ...data,
        // Override the computed selling price in USD
        priceUSD: calculatedUSDPrice,
        costPriceUSD,
        // If expiryDate is empty string, set to null
        expiryDate: data.expiryDate && data.expiryDate.trim() !== '' ? data.expiryDate : null,
    };
    const result = await onSubmit(finalData);

    if (result.success) {
        if (IS_RESTAURANT_APP && product && ingredients) {
            const ingredientsToSubmit = ingredients.map(ing => ({
                ...ing,
                quantityRequired: Number(ing.quantityRequired) || 0,
            }));
            const ingResult = await addProductIngredients(product.id, ingredientsToSubmit);
            if (ingResult.success) {
                toast({ title: 'تم حفظ المكونات' });
            } else {
                toast({ variant: 'destructive', title: 'خطأ في حفظ المكونات', description: ingResult.message });
            }
        }
        router.push('/products');
    } else {
        toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }

    setIsLoading(false);
  }

  const handleAddIngredient = () => {
    setIngredients([...ingredients, { id: `new_${Date.now()}`, productId: product?.id || '', rawMaterialId: '', quantityRequired: 0, rawMaterialName: '', unitName: '' }]);
  }

  const handleIngredientChange = (index: number, field: keyof ProductIngredientDetails, value: any) => {
    const newIngredients = [...ingredients];
    const ingredient = newIngredients[index];
    (ingredient[field] as any) = value;

    if(field === 'rawMaterialId') {
        const material = rawMaterials.find(rm => rm.id === value);
        if(material) {
            ingredient.rawMaterialName = material.name;
            ingredient.unitName = material.unitName;
        }
    }
    setIngredients(newIngredients);
  }

  const handleRemoveIngredient = async (index: number, ingredientId: string) => {
    if(ingredientId.startsWith('new_')) {
      setIngredients(ingredients.filter((_, i) => i !== index));
    } else {
        const result = await deleteProductIngredient(ingredientId);
        if(result.success){
            setIngredients(ingredients.filter(ing => ing.id !== ingredientId));
            toast({description: 'تم حذف المكون.'})
        } else {
            toast({variant: 'destructive', title: 'خطأ', description: result.message});
        }
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFormSubmit)} className="flex flex-col h-full space-y-6">
        <Card>
            <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-right">
                <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                    <FormItem className="md:col-span-2">
                        <FormLabel>اسم {IS_RESTAURANT_APP ? 'الصنف' : 'المنتج'}</FormLabel>
                        <FormControl>
                        <Input className="text-right" placeholder={IS_RESTAURANT_APP ? 'مثال: طبق دجاج مشوي' : 'مثال: هاتف ذكي'} {...field} />
                        </FormControl>
                        <FormMessage />
                    </FormItem>
                    )}
                />
                 <FormField
                    control={form.control}
                    name="code"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>الباركود (اختياري)</FormLabel>
                        <FormControl>
                        <Input placeholder="امسح الباركود هنا" {...field} value={field.value ?? ''} className="text-right"/>
                        </FormControl>
                        <FormMessage />
                    </FormItem>
                    )}
                />

                {!IS_RESTAURANT_APP && (
                    <>
                    <FormField
                        control={form.control}
                        name="quantity"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>الكمية</FormLabel>
                            <FormControl>
                            <Input type="number" placeholder="0" className="text-right" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="warranty"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>الضمان (اختياري)</FormLabel>
                            <FormControl>
                            <Input className="text-right" placeholder="مثال: سنة واحدة" {...field} value={field.value ?? ''}/>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    {/* Expiry date field */}
                    <FormField
                        control={form.control}
                        name="expiryDate"
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>تاريخ انتهاء الصلاحية (اختياري)</FormLabel>
                            <FormControl>
                            <Input type="date" className="text-right" {...field} value={field.value ?? ''} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                    </>
                )}
                <FormField
                    control={form.control}
                    name="categoryId"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>الفئة</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                            <SelectTrigger>
                            <SelectValue placeholder="اختر فئة" />
                            </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                            {categories.map((cat) => (
                            <SelectItem key={cat.id} value={cat.id}>
                                {cat.name}
                            </SelectItem>
                            ))}
                        </SelectContent>
                        </Select>
                        <FormMessage />
                    </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="unitId"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>الوحدة</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                            <SelectTrigger>
                            <SelectValue placeholder="اختر وحدة" />
                            </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                            {units.map((unit) => (
                            <SelectItem key={unit.id} value={unit.id}>
                                {unit.name}
                            </SelectItem>
                            ))}
                        </SelectContent>
                        </Select>
                        <FormMessage />
                    </FormItem>
                    )}
                />
                
                {IS_RESTAURANT_APP ? (
                    <FormField
                        control={form.control}
                        name="price"
                        render={({ field }) => (
                        <FormItem className="md:col-span-2">
                            <FormLabel>السعر</FormLabel>
                            <FormControl>
                            <Input type="number" step="0.01" placeholder="0.00" className="text-right" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                        )}
                    />
                ) : (
                    <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-4 p-4 border rounded-md bg-muted/50">
                        {/* Selling price input */}
                        <FormField
                            control={form.control}
                            name="price"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>سعر البيع (بالجنيه)</FormLabel>
                                    <FormControl>
                                        <Input type="number" step="0.01" placeholder="0.00" className="text-right" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        {/* Initial USD rate */}
                        <FormField
                            control={form.control}
                            name="initialUSDRate"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>سعر الصرف الأولي</FormLabel>
                                    <FormControl>
                                        <Input type="number" step="0.01" placeholder="سعر الدولار عند الإضافة" className="text-right" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        {/* Computed selling price in USD */}
                        <div>
                            <FormLabel>سعر البيع بالدولار (محسوب)</FormLabel>
                            <Input type="text" readOnly disabled value={`${calculatedUSDPrice.toFixed(2)} $`} className="mt-2 font-bold text-right" />
                        </div>
                        {/* Dynamic price toggle spanning full row */}
                        <FormField
                            control={form.control}
                            name="isDynamicPrice"
                            render={({ field }) => (
                                <FormItem className="flex flex-row items-center justify-end gap-2 pt-5 md:col-span-3">
                                    <FormLabel className="m-0">يتأثر بسعر الصرف</FormLabel>
                                    <FormControl>
                                        <Switch
                                            checked={field.value}
                                            onCheckedChange={field.onChange}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                    </div>
                )}
                
                <div className="md:col-span-1">
                    <FormLabel>صورة {IS_RESTAURANT_APP ? 'الصنف' : 'المنتج'} (اختياري)</FormLabel>
                    <FormControl>
                        <Input type="file" accept="image/*" onChange={handleImageChange} className="mt-2"/>
                    </FormControl>
                    {imagePreview && (
                        <div className="mt-2">
                            <Image src={imagePreview} alt="معاينة الصورة" width={100} height={100} className="rounded-md object-cover" />
                        </div>
                    )}
                </div>
                
                {IS_RESTAURANT_APP && product && (
                    <div className="md:col-span-2 space-y-4 pt-4 border-t">
                    <div className='flex justify-between items-center'>
                        <h3 className="text-lg font-semibold">مكونات الصنف (الوصفة)</h3>
                        <Button type="button" size="sm" variant="outline" onClick={handleAddIngredient}><PlusCircle className="me-2 h-4 w-4" />إضافة مكون</Button>
                    </div>
                    <div className='space-y-2'>
                        {ingredients.map((ing, index) => (
                            <div key={ing.id} className="grid grid-cols-12 gap-2 items-center">
                                <div className="col-span-6">
                                    <Select value={ing.rawMaterialId} onValueChange={(value) => handleIngredientChange(index, 'rawMaterialId', value)}>
                                        <SelectTrigger><SelectValue placeholder="اختر المكون..." /></SelectTrigger>
                                        <SelectContent>
                                            {rawMaterials.map(rm => <SelectItem key={rm.id} value={rm.id}>{rm.name}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="col-span-4">
                                    <Input 
                                        type="number"
                                        placeholder='الكمية'
                                        value={ing.quantityRequired}
                                        onChange={(e) => handleIngredientChange(index, 'quantityRequired', e.target.value)}
                                        className="text-right w-full font-bold"
                                        min="0"
                                        step="0.001"
                                    />
                                </div>
                                <div className="col-span-1 text-xs text-muted-foreground self-center pt-2">
                                    {ing.unitName}
                                </div>
                                <div className="col-span-1">
                                    <Button type="button" variant="ghost" size="icon" onClick={() => handleRemoveIngredient(index, ing.id)}>
                                        <Trash2 className='h-4 w-4 text-destructive' />
                                    </Button>
                                </div>
                            </div>
                        ))}
                    </div>
                    </div>
                )}
                </div>
            </CardContent>
        </Card>
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={() => router.back()}>
            إلغاء
          </Button>
          <Button type="submit" disabled={isLoading}>
             {isLoading && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
            {product ? 'حفظ التغييرات' : `إضافة ${IS_RESTAURANT_APP ? 'الصنف' : 'المنتج'}`}
          </Button>
        </div>
      </form>
    </Form>
  );
}
