'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { ProductIngredientDetails, RawMaterialDetails } from '@/lib/types';
import { randomUUID } from 'crypto';
import { getRawMaterialsWithUnits } from '@/lib/queries';

export async function getRawMaterialsAction(): Promise<RawMaterialDetails[]> {
    return getRawMaterialsWithUnits();
}

export async function addProductIngredients(productId: string, ingredients: ProductIngredientDetails[]) {
    const db = await getDbInstance();
    try {
        await db.exec('BEGIN TRANSACTION');

        // First, delete existing ingredients for the product
        await db.run('DELETE FROM product_ingredients WHERE productId = ?', productId);

        // Then, insert the new ones
        for (const ing of ingredients) {
            if (ing.rawMaterialId && ing.quantityRequired > 0) {
                await db.run(
                    'INSERT INTO product_ingredients (id, productId, rawMaterialId, quantityRequired) VALUES (?, ?, ?, ?)',
                    `ing_${randomUUID()}`,
                    productId,
                    ing.rawMaterialId,
                    ing.quantityRequired
                );
            }
        }
        
        await db.exec('COMMIT');
        revalidatePath(`/products`);
        return { success: true, message: 'تم حفظ مكونات المنتج بنجاح.' };
    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to add product ingredients:', e);
        return { success: false, message: 'فشل حفظ مكونات المنتج.' };
    }
}

export async function deleteProductIngredient(ingredientId: string) {
    const db = await getDbInstance();
    try {
        await db.run('DELETE FROM product_ingredients WHERE id = ?', ingredientId);
        revalidatePath('/products');
        return { success: true, message: 'تم حذف المكون.' };
    } catch (e: any) {
        console.error('Failed to delete product ingredient:', e);
        return { success: false, message: 'فشل حذف المكون.' };
    }
}
