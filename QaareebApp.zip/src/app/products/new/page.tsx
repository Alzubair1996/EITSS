
import { PageHeader } from '@/components/page-header';
import { getCategories, getUnits, getCurrentUSDRate, getCompanyInfo } from '@/lib/queries';
import { ProductForm, type ProductFormValues } from '../product-form';
import { addProduct } from '../actions';
import { IS_RESTAURANT_APP } from '@/lib/types';
import { redirect } from 'next/navigation';

export default async function NewProductPage() {
    
  const categories = await getCategories();
  const units = await getUnits();
  const currentUSDRate = await getCurrentUSDRate();
  const companyInfo = await getCompanyInfo();

  async function handleSubmit(data: Omit<ProductFormValues, 'hasSubUnits'>) {
    'use server';
    return await addProduct(data);
  }

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <PageHeader title={IS_RESTAURANT_APP ? "إضافة صنف جديد" : "إضافة منتج جديد"} />
        <ProductForm
            product={null}
            categories={categories}
            units={units}
            onSubmit={handleSubmit}
            currentUSDRate={currentUSDRate}
            companyInfo={companyInfo}
        />
    </div>
  );
}
