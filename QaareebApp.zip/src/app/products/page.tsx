import ProductClientPage from './product-client-page';
import { getProducts, getCategories, getUnits, getCurrentUSDRate, getCompanyInfo } from '@/lib/queries';
import { redirect } from 'next/navigation';
import { BUSINESS_TYPE } from '@/lib/types';

export default async function ProductsPage() {
    
  if (BUSINESS_TYPE === null) {
      redirect('/setup');
  }

  const initialProducts = await getProducts();
  const initialCategories = await getCategories();
  const initialUnits = await getUnits();
  const currentUSDRate = await getCurrentUSDRate();
  const companyInfo = await getCompanyInfo();

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <ProductClientPage
          initialProducts={initialProducts}
          categories={initialCategories}
          units={initialUnits}
          currentUSDRate={currentUSDRate}
          companyInfo={companyInfo}
        />
      </div>
  );
}
