
'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MoreHorizontal, Pencil, Trash2, Package, AlertTriangle, TrendingDown } from 'lucide-react';
import type { Product, Category, Unit } from '@/lib/types';
import Image from 'next/image';
import Link from 'next/link';

interface ProductTableProps {
  products: Product[];
  categories: Category[];
  units: Unit[];
  onDelete: (productId: string) => void;
  isRestaurant: boolean;
}

export function ProductTable({
  products,
  categories,
  units,
  onDelete,
  isRestaurant,
}: ProductTableProps) {
  const getCategoryName = (id: string) =>
    categories.find((c) => c.id === id)?.name || 'غير محدد';
  const getUnitName = (id: string) =>
    units.find((u) => u.id === id)?.name || 'غير محدد';

  const lowStockCount = products.filter(p => (p.quantity || 0) <= 5 && (p.quantity || 0) > 0).length;
  const outOfStockCount = products.filter(p => (p.quantity || 0) <= 0).length;

  const getStockBadge = (quantity: number) => {
    if (quantity <= 0) return <Badge variant="destructive">نافد</Badge>;
    if (quantity <= 5) return <Badge variant="warning">قليل</Badge>;
    return <Badge variant="success">وافر</Badge>;
  };

  return (
    <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
      {/* Low stock warning bar */}
      {(lowStockCount > 0 || outOfStockCount > 0) && (
        <div className="border-b border-amber-500/20 bg-amber-50 dark:bg-amber-500/5 px-6 py-3 flex items-center gap-3">
          <AlertTriangle className="h-4 w-4 text-amber-600 flex-shrink-0" />
          <p className="text-sm text-amber-700 dark:text-amber-400">
            {outOfStockCount > 0 && (
              <span className="font-bold">{outOfStockCount} {isRestaurant ? 'صنف' : 'منتج'} نافد من المخزون</span>
            )}
            {outOfStockCount > 0 && lowStockCount > 0 && ' • '}
            {lowStockCount > 0 && (
              <span>{lowStockCount} {isRestaurant ? 'صنف' : 'منتج'} على وشك النفاد</span>
            )}
          </p>
        </div>
      )}

      <CardHeader className="pb-4 border-b border-border/40 bg-secondary/10 flex flex-row justify-between items-center">
        <div>
          <CardTitle className="text-base font-bold text-foreground">
            {isRestaurant ? 'قائمة الأصناف' : 'قائمة المنتجات'}
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">
            إدارة المنتجات والأسعار ومستويات المخزون
          </p>
        </div>
        <div className="flex items-center gap-2">
          {outOfStockCount > 0 && (
            <span className="flex items-center gap-1.5 text-xs font-semibold text-red-600 bg-red-50 dark:bg-red-500/10 px-3 py-1.5 rounded-full border border-red-200 dark:border-red-500/20">
              <TrendingDown className="h-3 w-3" /> {outOfStockCount} نافد
            </span>
          )}
          <span className="text-xs font-semibold text-muted-foreground bg-background px-3 py-1.5 rounded-full border border-border/40 shadow-sm">
            الإجمالي: {products.length}
          </span>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16">صورة</TableHead>
              <TableHead>اسم {isRestaurant ? 'الصنف' : 'المنتج'}</TableHead>
              <TableHead>الفئة</TableHead>
              {!isRestaurant && (
                <>
                  <TableHead>الكود</TableHead>
                  <TableHead>الضمان</TableHead>
                  <TableHead>المخزون</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead>انتهاء الصلاحية</TableHead>
                </>
              )}
              <TableHead className="text-right">السعر</TableHead>
              <TableHead className="text-center no-print">الإجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {products.length === 0 ? (
              <TableRow>
                <TableCell colSpan={isRestaurant ? 5 : 10} className="h-40 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-4 rounded-2xl bg-muted/50">
                      <Package className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">لا توجد {isRestaurant ? 'أصناف' : 'منتجات'}</p>
                      <p className="text-sm text-muted-foreground mt-1">قم بإضافة {isRestaurant ? 'صنف' : 'منتج'} جديد للبدء</p>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              products.map((product) => (
                <TableRow key={product.id} className="group">
                  <TableCell>
                    {product.image ? (
                      <div className="w-10 h-10 rounded-xl overflow-hidden border border-border/50 shadow-sm">
                        <Image src={product.image} alt={product.name} width={40} height={40} className="object-cover w-full h-full" />
                      </div>
                    ) : (
                      <div className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center border border-border/30">
                        <Package className="h-4 w-4 text-muted-foreground" />
                      </div>
                    )}
                  </TableCell>
                  <TableCell className="font-semibold text-foreground">{product.name}</TableCell>
                  <TableCell>
                    <span className="text-xs font-medium text-muted-foreground bg-secondary px-2.5 py-1 rounded-full">
                      {getCategoryName(product.categoryId)}
                    </span>
                  </TableCell>
                  {!isRestaurant && (
                    <>
                      <TableCell className="font-mono text-sm text-muted-foreground">
                        {product.code && product.code.trim() !== '' ? product.code : '—'}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {product.warranty || '—'}
                      </TableCell>
                      <TableCell>
                        <span className="font-mono font-bold text-sm">
                          {product.quantity} {getUnitName(product.unitId)}
                        </span>
                      </TableCell>
                      <TableCell>
                        {getStockBadge(product.quantity || 0)}
                      </TableCell>
                      <TableCell>
                        {(() => {
                          const exp = (product as any).expiryDate as string | null | undefined;
                          if (!exp) return <span className="text-muted-foreground">—</span>;
                          try {
                            const expDate = new Date(exp);
                            if (isNaN(expDate.getTime())) return exp;
                            const now = new Date();
                            const diffDays = Math.floor((expDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
                            const formatted = expDate.toISOString().split('T')[0];
                            return (
                              <span className={`text-sm font-medium ${diffDays <= 30 ? 'text-red-600' : 'text-foreground'}`}>
                                {formatted}
                                {diffDays <= 30 && diffDays > 0 && <span className="text-xs text-red-500 mr-1">({diffDays}يوم)</span>}
                              </span>
                            );
                          } catch {
                            return exp;
                          }
                        })()}
                      </TableCell>
                    </>
                  )}
                  <TableCell className="text-right">
                    <span className="font-mono font-bold text-foreground">
                      {Math.round(product.price).toLocaleString('en-US')} SDG
                    </span>
                  </TableCell>
                  <TableCell className="text-center no-print">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          aria-haspopup="true"
                          size="icon"
                          variant="ghost"
                          className="rounded-full h-8 w-8 hover:bg-primary/5 hover:text-primary opacity-100 transition-all"
                        >
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">فتح القائمة</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl shadow-lg border-border/50">
                        <DropdownMenuItem asChild className="rounded-lg cursor-pointer">
                          <Link href={`/products/${product.id}/edit`}>
                            <Pencil className="me-2 h-4 w-4 text-primary" />
                            تعديل
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onSelect={() => onDelete(product.id)}
                          className="rounded-lg cursor-pointer text-destructive focus:text-destructive"
                        >
                          <Trash2 className="me-2 h-4 w-4" />
                          حذف
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
