

'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { Product, Category, Unit } from '@/lib/types';
import { randomUUID } from 'crypto';

export async function addProduct(productData: Omit<Product, 'id'>) {
    try {
        const db = await getDbInstance();
        
        const code = productData.code?.trim() || null;

        await db.run(
            `INSERT INTO products (id, name, code, categoryId, unitId, quantity, costPrice, price, image, warranty, priceUSD, costPriceUSD, initialUSDRate, expiryDate, isDynamicPrice)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            `prod_${randomUUID()}`,
            productData.name,
            code,
            productData.categoryId,
            productData.unitId,
            productData.quantity,
            productData.costPrice,
            productData.price,
            productData.image || null,
            productData.warranty || null,
            productData.priceUSD,
            productData.costPriceUSD ?? null,
            productData.initialUSDRate,
            // expiry date may be undefined or null
            (productData as any).expiryDate || null,
            productData.isDynamicPrice
        );
        
        revalidatePath('/products');
        revalidatePath('/');
        return { success: true, message: 'تمت إضافة المنتج بنجاح' };
    } catch (e: any) {
        console.error('Error adding product:', e);
        if (e.code === 'SQLITE_CONSTRAINT') {
            return { success: false, message: 'منتج بنفس الكود موجود بالفعل.' };
        }
        return { success: false, message: `خطأ في قاعدة البيانات: ${e.message}` };
    }
}

export async function updateProduct(productData: Product) {
     try {
        const db = await getDbInstance();

        const code = productData.code?.trim() || null;

        await db.run(
            `UPDATE products
            SET name = ?, code = ?, categoryId = ?, unitId = ?, quantity = ?, costPrice = ?, price = ?, image = ?, warranty = ?, priceUSD = ?, costPriceUSD = ?, initialUSDRate = ?, expiryDate = ?, isDynamicPrice = ?
            WHERE id = ?`,
            productData.name,
            code,
            productData.categoryId,
            productData.unitId,
            productData.quantity,
            productData.costPrice,
            productData.price,
            productData.image || null,
            productData.warranty || null,
            productData.priceUSD,
            productData.costPriceUSD ?? null,
            productData.initialUSDRate,
            // expiry date may be undefined or null
            (productData as any).expiryDate || null,
            productData.isDynamicPrice,
            productData.id
        );
        
        revalidatePath('/products');
        revalidatePath('/');
        return { success: true, message: 'تم تحديث المنتج بنجاح' };
    } catch (e: any) {
        console.error('Error updating product:', e);
        if (e.code === 'SQLITE_CONSTRAINT') {
            return { success: false, message: 'منتج آخر بنفس الكود موجود بالفعل.' };
        }
        return { success: false, message: `خطأ في قاعدة البيانات: ${e.message}` };
    }
}

export async function deleteProduct(id: string) {
    try {
        const db = await getDbInstance();
        await db.run('DELETE FROM products WHERE id = ?', id);
        revalidatePath('/products');
        revalidatePath('/');
        return { success: true, message: 'تم حذف المنتج.' };
    } catch (e) {
        console.error(e);
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل حذف المنتج.' };
    }
}

export async function handleProductImport(productsData: any[]) {
    const db = await getDbInstance();
    try {
        let addedCount = 0;
        let updatedCount = 0;
        let errorCount = 0;
        const errors: string[] = [];

        const categories = await db.all('SELECT * FROM categories') as Category[];
        const units = await db.all('SELECT * FROM units') as Unit[];

        await db.exec('BEGIN TRANSACTION');

        for (const row of productsData) {
            // Support both English and Arabic column names for more user-friendly imports.
            // Fallback to undefined if not provided.
            const name: string | undefined = row.name ?? row['الاسم'];
            const code: string | undefined = row.code ?? row['الرمز'];
            const categoryName: string | undefined = row.categoryName ?? row['اسم الفئة'] ?? row['الفئة'];
            const unitName: string | undefined = row.unitName ?? row['اسم الوحدة'] ?? row['الوحدة'];
            const quantity: any = row.quantity ?? row['الكمية'];
            const salePrice: any = row.price ?? row['السعر'] ?? row['سعر البيع'];
            const costPrice: any = row.costPrice ?? row['سعر التكلفة'];
            const warranty: any = row.warranty ?? row['الضمان'];
            // Expiry date. Supports both English and Arabic column names.
            const expiryDate: any = row.expiryDate ?? row['تاريخ الانتهاء'];
            const initialUSDRate: any = row.initialUSDRate ?? row['سعر صرف الدولار'];

            if (!name || !code || !categoryName || !unitName) {
                errorCount++;
                errors.push(`صف يحتوي بيانات ناقصة (الاسم, الكود, الفئة, الوحدة مطلوبة): ${JSON.stringify(row)}`);
                continue;
            }

            const category = categories.find(c => c.name === categoryName);
            const unit = units.find(u => u.name === unitName);

            if (!category) {
                errorCount++;
                errors.push(`الفئة '${categoryName}' غير موجودة للمنتج بكود '${code}'.`);
                continue;
            }
            if (!unit) {
                errorCount++;
                errors.push(`الوحدة '${unitName}' غير موجودة للمنتج بكود '${code}'.`);
                continue;
            }

            const existingProduct = await db.get('SELECT * FROM products WHERE code = ?', code) as Product | undefined;

            // Ensure numeric parsing with fallbacks to existing values for both selling and cost prices.
            const finalCostPrice = costPrice !== undefined && costPrice !== null && !isNaN(parseFloat(costPrice))
                ? parseFloat(costPrice)
                : (existingProduct ? existingProduct.costPrice : 0);
            const finalPrice = salePrice !== undefined && salePrice !== null && !isNaN(parseFloat(salePrice))
                ? parseFloat(salePrice)
                : (existingProduct ? existingProduct.price : 0);
            const finalRate = initialUSDRate !== undefined && initialUSDRate !== null && !isNaN(parseFloat(initialUSDRate))
                ? parseFloat(initialUSDRate)
                : (existingProduct ? (existingProduct.initialUSDRate ?? 0) : 0);

            // Calculate USD equivalents for selling and cost prices
            const priceUSD = (finalPrice > 0 && finalRate > 0) ? finalPrice / finalRate : 0;
            const costPriceUSD = (finalCostPrice > 0 && finalRate > 0) ? finalCostPrice / finalRate : 0;

            if (existingProduct) {
                // Update existing product including cost price and its USD equivalent.
                await db.run(
                    `UPDATE products
                    SET name = ?, categoryId = ?, unitId = ?, quantity = ?, costPrice = ?, price = ?, warranty = ?, priceUSD = ?, costPriceUSD = ?, initialUSDRate = ?, expiryDate = ?, isDynamicPrice = ?
                    WHERE id = ?`,
                    name || existingProduct.name,
                    category.id,
                    unit.id,
                    quantity !== undefined && quantity !== null ? parseInt(quantity) : existingProduct.quantity,
                    finalCostPrice,
                    finalPrice,
                    warranty !== undefined ? warranty : existingProduct.warranty,
                    priceUSD || existingProduct.priceUSD,
                    costPriceUSD || existingProduct.costPriceUSD,
                    initialUSDRate !== undefined && initialUSDRate !== null ? parseFloat(initialUSDRate) : existingProduct.initialUSDRate,
                    // Update expiryDate; if provided, use it, else keep existing
                    expiryDate || (existingProduct as any).expiryDate || null,
                    existingProduct.isDynamicPrice,
                    existingProduct.id
                );
                updatedCount++;
            } else {
                // Add new product including cost price and its USD equivalent.
                await db.run(
                    `INSERT INTO products (id, name, code, categoryId, unitId, quantity, costPrice, price, image, warranty, priceUSD, costPriceUSD, initialUSDRate, expiryDate, isDynamicPrice)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    `prod_${randomUUID()}`,
                    name,
                    code,
                    category.id,
                    unit.id,
                    quantity || 0,
                    finalCostPrice,
                    finalPrice,
                    null,
                    warranty || null,
                    priceUSD || 0,
                    costPriceUSD || 0,
                    initialUSDRate || 0,
                    expiryDate || null,
                    true
                );
                addedCount++;
            }
        }

        await db.exec('COMMIT');

        revalidatePath('/products');
        
        let message = `تمت العملية بنجاح. ${addedCount} منتج تمت إضافته، ${updatedCount} منتج تم تحديثه.`;
        if (errorCount > 0) {
            message += `\nفشلت ${errorCount} صفوف. الأسباب: ${errors.slice(0, 3).join(', ')}`;
        }
        return { success: true, message };

    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Product import failed:', e);
        return { success: false, message: e.message || 'فشل استيراد المنتجات.' };
    }
}

/**
 * Generate a random numeric barcode for a product that currently lacks one.
 * The barcode will be a string of 12 digits (EAN-13 style without check digit) and
 * will be unique among existing product codes. If the product already has a code,
 * this function returns the existing code without modifying it.
 */
export async function generateBarcode(productId: string) {
    const db = await getDbInstance();
    const product = await db.get('SELECT * FROM products WHERE id = ?', productId) as Product | undefined;
    if (!product) {
        return { success: false, message: 'المنتج غير موجود.' };
    }
    if (product.code && product.code.trim() !== '') {
        return { success: true, code: product.code };
    }
    // Generate a 12-digit numeric code. Retry if conflict.
    let newCode: string = '';
    let exists: any;
    do {
        newCode = Math.floor(100000000000 + Math.random() * 900000000000).toString().slice(0, 12);
        exists = await db.get('SELECT id FROM products WHERE code = ?', newCode);
    } while (exists);
    await db.run('UPDATE products SET code = ? WHERE id = ?', newCode, productId);
    revalidatePath('/products');
    return { success: true, code: newCode };
}


export async function applyUSDRateToCategories(rate: number, categoryIds: string[]) {
    if (!rate || rate <= 0) {
        return { success: false, message: 'سعر الصرف يجب أن يكون رقماً موجباً.' };
    }
    if (!categoryIds || categoryIds.length === 0) {
        return { success: false, message: 'يجب اختيار فئة واحدة على الأقل.' };
    }
    
    const db = await getDbInstance();
    
    try {
        await db.exec('BEGIN');

        // Save the new rate in settings for future use
        await db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'usd_rate', rate.toString());

        // Construct the placeholder string for the IN clause
        const placeholders = categoryIds.map(() => '?').join(',');
        
        // Get all products that need updating
        const productsToUpdate = await db.all<Product[]>(`
            SELECT * FROM products 
            WHERE categoryId IN (${placeholders}) 
            AND isDynamicPrice = 1 
            AND priceUSD IS NOT NULL 
            AND priceUSD > 0
        `, ...categoryIds);

        let updatedCount = 0;
        // Recalculate and update price for each product
        for (const product of productsToUpdate) {
            const newPriceSDG = (product.priceUSD ?? 0) * rate;
            const roundedPrice = Math.round(newPriceSDG); 
            
            await db.run('UPDATE products SET price = ? WHERE id = ?', roundedPrice, product.id);
            updatedCount++;
        }
        
        await db.exec('COMMIT');

        revalidatePath('/products');
        revalidatePath('/invoices/new');
        revalidatePath('/settings');
        
        return { success: true, message: `تم تحديث أسعار ${updatedCount} منتج بنجاح.` };

    } catch (e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to update prices by category:', e);
        return { success: false, message: 'فشل تحديث أسعار المنتجات.' };
    }
}
