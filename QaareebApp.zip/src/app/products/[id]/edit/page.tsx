
import { PageHeader } from '@/components/page-header';
import { getCategories, getUnits, getCurrentUSDRate, getCompanyInfo, getProducts } from '@/lib/queries';
import { ProductForm, type ProductFormValues } from '../../product-form';
import { updateProduct } from '../../actions';
import { IS_RESTAURANT_APP } from '@/lib/types';
import { notFound } from 'next/navigation';

async function getProductById(id: string) {
    const products = await getProducts();
    return products.find(p => p.id === id);
}

export default async function EditProductPage({ params }: { params: { id: string } }) {
  
  const product = await getProductById(params.id);

  if (!product) {
    notFound();
  }
    
  const categories = await getCategories();
  const units = await getUnits();
  const currentUSDRate = await getCurrentUSDRate();
  const companyInfo = await getCompanyInfo();

  async function handleSubmit(data: Omit<ProductFormValues, 'hasSubUnits'>) {
    'use server';
    return await updateProduct({ ...data, id: params.id });
  }

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <PageHeader title={`تعديل: ${product.name}`} />
        <ProductForm
            product={product}
            categories={categories}
            units={units}
            onSubmit={handleSubmit}
            currentUSDRate={currentUSDRate}
            companyInfo={companyInfo}
        />
    </div>
  );
}
