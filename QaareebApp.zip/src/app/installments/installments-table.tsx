
'use client';
export function InstallmentsTable() {
  return null;
}
