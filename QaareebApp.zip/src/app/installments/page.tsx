
export default function InstallmentsPage() {
  return null;
}
