
'use client';
export function InstallmentPlanForm() {
  return null;
}
