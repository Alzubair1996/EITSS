
'use client';
export default function InstallmentsClientPage() {
  return null;
}
