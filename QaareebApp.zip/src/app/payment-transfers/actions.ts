"use server";

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import { getSession } from '@/lib/server-auth';

/**
 * Create a new transfer between two payment methods. This deducts the amount from the source
 * payment method and adds it to the destination method, then records the transfer in the
 * payment_method_transfers table. The currently logged-in user's ID is attached to the record.
 */
export async function createPaymentMethodTransfer({
    fromMethodId,
    toMethodId,
    amount,
    transferDate,
    description,
}: {
    fromMethodId: string;
    toMethodId: string;
    amount: number;
    transferDate: string;
    description?: string;
}) {
    try {
        const db = await getDbInstance();
        const session = await getSession();
        if (!session) {
            return { success: false, message: 'ليس لديك إذن بإجراء هذه العملية.' };
        }
        const userId = session.userId;
        // Validate that the payment methods exist and the source has sufficient balance.
        const fromMethod = await db.get('SELECT balance FROM payment_methods WHERE id = ?', fromMethodId) as { balance: number } | undefined;
        const toMethod = await db.get('SELECT balance FROM payment_methods WHERE id = ?', toMethodId) as { balance: number } | undefined;
        if (!fromMethod || !toMethod) {
            return { success: false, message: 'إحدى طرق الدفع المحددة غير موجودة.' };
        }
        if (amount <= 0 || isNaN(amount)) {
            return { success: false, message: 'يجب أن يكون المبلغ رقماً أكبر من الصفر.' };
        }
        if (fromMethod.balance < amount) {
            return { success: false, message: 'الرصيد في طريقة الدفع المصدر لا يكفي للتحويل.' };
        }
        // Perform the transfer within a transaction
        await db.exec('BEGIN');
        const transferId = `tr_${Date.now()}`;
        await db.run(
            'INSERT INTO payment_method_transfers (id, fromMethodId, toMethodId, amount, transferDate, description, userId) VALUES (?, ?, ?, ?, ?, ?, ?)',
            transferId,
            fromMethodId,
            toMethodId,
            amount,
            transferDate,
            description || null,
            userId
        );
        // Deduct from source and add to destination
        await db.run('UPDATE payment_methods SET balance = balance - ? WHERE id = ?', amount, fromMethodId);
        await db.run('UPDATE payment_methods SET balance = balance + ? WHERE id = ?', amount, toMethodId);
        await db.exec('COMMIT');
        // Revalidate relevant pages
        revalidatePath('/payment-transfers');
        revalidatePath('/transactions');
        revalidatePath('/payment-methods');
        return { success: true, message: 'تم التحويل بين طرق الدفع بنجاح.' };
    } catch (e: any) {
        // Attempt to roll back if an error occurs
        try {
            const db = await getDbInstance();
            await db.exec('ROLLBACK');
        } catch {}
        console.error('Payment method transfer failed:', e);
        return { success: false, message: 'فشل التحويل بين طرق الدفع. يرجى المحاولة مرة أخرى.' };
    }
}