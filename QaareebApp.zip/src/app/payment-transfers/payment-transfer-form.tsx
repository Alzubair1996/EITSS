"use client";

import * as React from 'react';
import { useWatch } from 'react-hook-form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { CalendarIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { PaymentMethod } from '@/lib/types';
import { format } from 'date-fns';

// Schema for payment transfer form
const formSchema = z.object({
  fromMethodId: z.string({ required_error: 'طريقة الدفع المصدر مطلوبة' }),
  toMethodId: z.string({ required_error: 'طريقة الدفع الوجهة مطلوبة' }),
  amount: z
    .string()
    .refine((val) => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
      message: 'يجب أن يكون المبلغ رقماً أكبر من صفر',
    }),
  transferDate: z.date({ required_error: 'تاريخ التحويل مطلوب' }),
  description: z.string().optional(),
}).refine((data) => data.fromMethodId !== data.toMethodId, {
  message: 'يجب اختيار طرق دفع مختلفة',
  path: ['toMethodId'],
});

type PaymentTransferFormValues = z.infer<typeof formSchema>;

interface PaymentTransferFormProps {
  paymentMethods: PaymentMethod[];
  onSubmit: (values: {
    fromMethodId: string;
    toMethodId: string;
    amount: number;
    transferDate: string;
    description?: string;
  }) => void;
  onCancel: () => void;
  /**
   * Indicates whether the current user is the admin. If true, show available balances.
   */
  isAdmin: boolean;
}

export function PaymentTransferForm({ paymentMethods, onSubmit, onCancel, isAdmin }: PaymentTransferFormProps) {
  const form = useForm<PaymentTransferFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fromMethodId: '',
      toMethodId: '',
      amount: '',
      transferDate: new Date(),
      description: '',
    },
  });

  // Watch selected payment methods to display their current balances.
  // useWatch triggers re-renders when the form values change.
  const selectedFromMethodId = useWatch({ control: form.control, name: 'fromMethodId' });
  const selectedToMethodId = useWatch({ control: form.control, name: 'toMethodId' });
  const selectedFromMethod = React.useMemo(() => {
    return paymentMethods.find((pm) => pm.id === selectedFromMethodId);
  }, [selectedFromMethodId, paymentMethods]);
  const selectedToMethod = React.useMemo(() => {
    return paymentMethods.find((pm) => pm.id === selectedToMethodId);
  }, [selectedToMethodId, paymentMethods]);
  const handleSubmit = (values: PaymentTransferFormValues) => {
    onSubmit({
      fromMethodId: values.fromMethodId,
      toMethodId: values.toMethodId,
      amount: parseFloat(values.amount),
      transferDate: values.transferDate.toISOString(),
      description: values.description || undefined,
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)}>
        <DialogHeader>
          <DialogTitle>إجراء تحويل جديد</DialogTitle>
          <DialogDescription>اختر طرق الدفع، أدخل المبلغ، وحدد تاريخ التحويل.</DialogDescription>
        </DialogHeader>
        <div className="py-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="fromMethodId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>من حساب</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر الحساب المصدر" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {paymentMethods.map((pm) => (
                      <SelectItem key={pm.id} value={pm.id}>
                        {pm.name}
                        {isAdmin && ` (الرصيد: ${pm.balance.toFixed(2)})`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
                {/* Display the current balance for the selected source account */}
                {isAdmin && selectedFromMethod && (
                  <p className="mt-1 text-xs text-muted-foreground">
                    الرصيد المتاح: {selectedFromMethod.balance.toFixed(2)}
                  </p>
                )}
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="toMethodId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>إلى حساب</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر الحساب الوجهة" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                     {paymentMethods.map((pm) => (
                       <SelectItem key={pm.id} value={pm.id}>
                        {pm.name}
                        {isAdmin && ` (الرصيد: ${pm.balance.toFixed(2)})`}
                       </SelectItem>
                     ))}
                  </SelectContent>
                </Select>
                <FormMessage />
                {/* Display the current balance for the selected destination account */}
                {isAdmin && selectedToMethod && (
                  <p className="mt-1 text-xs text-muted-foreground">
                    الرصيد المتاح: {selectedToMethod.balance.toFixed(2)}
                  </p>
                )}
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="amount"
            render={({ field }) => (
              <FormItem>
                <FormLabel>المبلغ</FormLabel>
                <FormControl>
                  <Input type="number" step="0.01" placeholder="0.00" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="transferDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>تاريخ التحويل</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        className={cn(
                          'w-full justify-start text-left font-normal',
                          !field.value && 'text-muted-foreground'
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {field.value ? format(field.value, 'PPP') : <span>اختر تاريخاً</span>}
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem className="md:col-span-2">
                <FormLabel>وصف (اختياري)</FormLabel>
                <FormControl>
                  <Input placeholder="سبب التحويل أو ملاحظات إضافية" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <DialogFooter className="pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            إلغاء
          </Button>
          <Button type="submit">إجراء التحويل</Button>
        </DialogFooter>
      </form>
    </Form>
  );
}