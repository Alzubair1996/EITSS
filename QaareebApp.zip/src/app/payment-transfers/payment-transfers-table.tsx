"use client";

import * as React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { PaymentMethodTransfer } from '@/lib/types';
import { format } from 'date-fns';
import { ArrowRightLeft, Calendar, User, ArrowRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface PaymentTransfersTableProps {
  transfers: PaymentMethodTransfer[];
}

export function PaymentTransfersTable({ transfers }: PaymentTransfersTableProps) {
  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  return (
    <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
      <CardHeader className="pb-4 border-b border-border/40 bg-secondary/10 flex flex-row justify-between items-center">
        <div>
          <CardTitle className="text-base font-bold text-foreground flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-primary" />
            سجل تحويلات الخزينة
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">سجل حركة الأموال المنقولة بين الحسابات والخزائن المالية</p>
        </div>
        <span className="text-xs font-semibold text-muted-foreground bg-background px-3 py-1.5 rounded-full border border-border/40 shadow-sm">
          {transfers.length} تحويل مسجل
        </span>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>التاريخ</TableHead>
              <TableHead>مسار التحويل (من ← إلى)</TableHead>
              <TableHead className="text-right">المبلغ المحول</TableHead>
              <TableHead>بواسطة الموظف</TableHead>
              <TableHead>البيان / الوصف</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transfers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-40 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-4 rounded-2xl bg-muted/50">
                      <ArrowRightLeft className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">لا توجد عمليات تحويل</p>
                      <p className="text-sm text-muted-foreground mt-1">لم يتم تسجيل أي عمليات تحويل للأموال بعد</p>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              transfers.map((tr) => (
                <TableRow key={tr.id} className="group">
                  <TableCell className="text-muted-foreground text-xs font-medium">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                      {format(new Date(tr.transferDate), 'dd/MM/yyyy')}
                    </div>
                  </TableCell>
                  <TableCell className="font-semibold text-foreground">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="px-2 py-0.5 bg-red-500/5 text-red-600 border-red-500/10">
                        {tr.fromMethodName}
                      </Badge>
                      <ArrowRight className="w-3.5 h-3.5 text-muted-foreground" />
                      <Badge variant="success" className="px-2 py-0.5">
                        {tr.toMethodName}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-mono font-bold text-foreground">
                    {formatCurrency(tr.amount)}
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    <div className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-muted-foreground" />
                      {tr.userName || '—'}
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground max-w-xs truncate" title={tr.description || ''}>
                    {tr.description || '—'}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}