import PaymentTransfersClientPage from './payment-transfers-client-page';
import { getPaymentMethodTransfers, getPaymentMethods } from '@/lib/queries';
import { getSession } from '@/lib/server-auth';
import { hasPermission } from '@/lib/permissions';
import { redirect } from 'next/navigation';

export default async function PaymentTransfersPage() {
  // Ensure the user is authenticated
  const session = await getSession();
  if (!session) {
    redirect('/login');
  }
  // Check if the user has permission to view the payment transfer page
  const allowed = await hasPermission(session.userId, 'transfer_payment_methods');
  if (!allowed) {
    // Redirect unauthorized users to the home page or show 404
    redirect('/');
  }
  // Determine if the current user is the admin based on username
  const isAdmin = session.username === 'admin';
  // Fetch existing transfers and payment methods
  const transfers = await getPaymentMethodTransfers();
  const paymentMethods = await getPaymentMethods();
  return (
    <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
      <PaymentTransfersClientPage transfers={transfers} paymentMethods={paymentMethods} isAdmin={isAdmin} />
    </div>
  );
}