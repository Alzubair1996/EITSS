"use client";

import * as React from 'react';
import { PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/page-header';
import { PaymentTransfersTable } from './payment-transfers-table';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { PaymentTransferForm } from './payment-transfer-form';
import type { PaymentMethodTransfer, PaymentMethod } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { createPaymentMethodTransfer } from './actions';
import { useRouter } from 'next/navigation';

interface PaymentTransfersClientPageProps {
  transfers: PaymentMethodTransfer[];
  paymentMethods: PaymentMethod[];
  isAdmin: boolean;
}

export default function PaymentTransfersClientPage({ transfers, paymentMethods, isAdmin }: PaymentTransfersClientPageProps) {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const { toast } = useToast();
  const router = useRouter();

  const handleCreateTransfer = async (values: { fromMethodId: string; toMethodId: string; amount: number; transferDate: string; description?: string; }) => {
    const result = await createPaymentMethodTransfer(values);
    if (result.success) {
      toast({ title: 'نجاح', description: result.message });
      setIsDialogOpen(false);
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }
  };

  return (
    <>
      <PageHeader title="تحويل بين طرق الدفع">
        <Button onClick={() => setIsDialogOpen(true)} className="shadow-md hover:shadow-lg transition-all rounded-full">
          <PlusCircle className="me-2 h-4 w-4" />
          إجراء تحويل جديد
        </Button>
      </PageHeader>
      <PaymentTransfersTable transfers={transfers} />
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <PaymentTransferForm
            paymentMethods={paymentMethods}
            onSubmit={handleCreateTransfer}
            onCancel={() => setIsDialogOpen(false)}
            isAdmin={isAdmin}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}