'use server';

import { getReportStats, getInvoices, getExpenses } from '@/lib/queries';
import { startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfYear, endOfYear } from 'date-fns';
import type { Invoice, ExpenseDetails } from '@/lib/types';


function getDatesForFilter(filter: 'today' | 'week' | 'month' | 'year') {
    let startDate: Date;
    let endDate: Date = new Date();

    switch(filter) {
        case 'today':
            startDate = startOfDay(endDate);
            endDate = endOfDay(endDate);
            break;
        case 'week':
            startDate = startOfWeek(endDate);
            endDate = endOfWeek(endDate);
            break;
        case 'month':
            startDate = startOfMonth(endDate);
            endDate = endOfMonth(endDate);
            break;
        case 'year':
            startDate = startOfYear(endDate);
            endDate = endOfYear(endDate);
            break;
    }

    return { startDate: startDate.toISOString(), endDate: endDate.toISOString() };
}

export async function getFilteredReportStats(filter: 'today' | 'week' | 'month' | 'year') {
    const dateRange = getDatesForFilter(filter);
    
    try {
        const stats = await getReportStats(dateRange);
        return { success: true, stats };
    } catch (error) {
        console.error("Failed to fetch filtered report stats:", error);
        return { success: false, message: 'فشل جلب الإحصائيات المفلترة.' };
    }
}


export async function getDetailedRevenue(filter: 'today' | 'week' | 'month' | 'year'): Promise<{ success: boolean, data?: Invoice[], message?: string}> {
    const dateRange = getDatesForFilter(filter);
    try {
        const allInvoices = await getInvoices(); // Fetch all first
        const filteredInvoices = allInvoices.filter(inv => {
            const issueDate = new Date(inv.issueDate);
            return issueDate >= new Date(dateRange.startDate) && issueDate <= new Date(dateRange.endDate) && inv.status !== 'cancelled';
        });
        return { success: true, data: filteredInvoices };
    } catch (error) {
        console.error("Failed to fetch detailed revenue:", error);
        return { success: false, message: 'فشل جلب تفاصيل الإيرادات' };
    }
}

export async function getDetailedExpenses(filter: 'today' | 'week' | 'month' | 'year'): Promise<{ success: boolean, data?: ExpenseDetails[], message?: string}> {
    const dateRange = getDatesForFilter(filter);
    try {
        const allExpenses = await getExpenses();
        const filteredExpenses = allExpenses.filter(exp => {
            const expenseDate = new Date(exp.expenseDate);
            return expenseDate >= new Date(dateRange.startDate) && expenseDate <= new Date(dateRange.endDate);
        });
        return { success: true, data: filteredExpenses };
    } catch (error) {
        console.error("Failed to fetch detailed expenses:", error);
        return { success: false, message: 'فشل جلب تفاصيل المصروفات' };
    }
}
