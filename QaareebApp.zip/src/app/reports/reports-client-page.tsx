'use client';

import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { DollarSign, FileText, BarChart, ArrowUp, ArrowDown, Banknote, LoaderCircle, TrendingUp, Sparkles, Calendar, ShoppingBag, Eye } from 'lucide-react';
import { format } from 'date-fns';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { getFilteredReportStats, getDetailedRevenue, getDetailedExpenses } from './actions';
import type { Invoice, TopSellingProduct, ReportStats, ExpenseDetails } from '@/lib/types';
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';

interface ReportsClientPageProps {
  initialTopProducts: TopSellingProduct[];
  initialRecentInvoices: Invoice[];
}

type DetailsType = 'revenue' | 'expenses' | 'profit';

function FormattedDate({ dateString }: { dateString: string }) {
    const [formattedDate, setFormattedDate] = React.useState('');
    React.useEffect(() => {
        setFormattedDate(format(new Date(dateString), 'dd/MM/yyyy HH:mm'));
    }, [dateString]);
    return <>{formattedDate}</>;
}

export default function ReportsClientPage({ initialTopProducts, initialRecentInvoices }: ReportsClientPageProps) {
  const [loading, setLoading] = React.useState(true);
  const [stats, setStats] = React.useState<ReportStats | null>(null);
  const [filter, setFilter] = React.useState<'today' | 'week' | 'month' | 'year'>('month');

  const [detailsOpen, setDetailsOpen] = React.useState(false);
  const [detailsType, setDetailsType] = React.useState<DetailsType | null>(null);
  const [detailsData, setDetailsData] = React.useState<Invoice[] | ExpenseDetails[]>([]);
  const [detailsLoading, setDetailsLoading] = React.useState(false);

  React.useEffect(() => {
    async function fetchStats() {
      setLoading(true);
      const result = await getFilteredReportStats(filter);
      if (result.success && result.stats) {
        setStats(result.stats);
      } else {
        console.error(result.message);
      }
      setLoading(false);
    }
    fetchStats();
  }, [filter]);

  const formatCurrency = (amount: number) => {
    return `${Math.round(amount).toLocaleString('en-US')} SDG`;
  };
  
  const handleDetailsClick = async (type: DetailsType) => {
    setDetailsType(type);
    setDetailsOpen(true);
    setDetailsLoading(true);
    setDetailsData([]);

    let result;
    if (type === 'revenue' || type === 'profit') {
      result = await getDetailedRevenue(filter);
    } else if (type === 'expenses') {
      result = await getDetailedExpenses(filter);
    }
    
    if (result?.success && result.data) {
      setDetailsData(result.data);
    } else {
      console.error(result?.message);
    }
    setDetailsLoading(false);
  };

  const statusMap: { [key: string]: { text: string; variant: 'default' | 'outline' | 'secondary' | 'destructive' | 'success' | 'warning' | 'info' } } = {
    paid: { text: 'مدفوعة', variant: 'success' },
    partial: { text: 'مدفوعة جزئياً', variant: 'warning' },
    unpaid: { text: 'غير مدفوعة', variant: 'destructive' },
    cancelled: { text: 'ملغاة', variant: 'secondary' },
    proforma: { text: 'مبدئية', variant: 'info' },
  };
  
  const getDialogTitle = () => {
    switch (detailsType) {
        case 'revenue': return 'تفاصيل الإيرادات الكلية';
        case 'expenses': return 'تفاصيل المصروفات الكلية';
        case 'profit': return 'تفاصيل الأرباح النقدية';
        default: return 'تفاصيل العمليات';
    }
  };

  const netProfit = (stats?.totalRevenue ?? 0) - (stats?.totalExpenses ?? 0);
  
  const maxSold = initialTopProducts.length > 0 
    ? Math.max(...initialTopProducts.map(p => p.totalSold)) 
    : 1;

  return (
    <div className="space-y-6">
      {/* Premium Filter Toggle Group */}
      <div className="flex items-center justify-between bg-card border border-border/40 p-2.5 rounded-2xl shadow-sm">
        <span className="text-xs font-bold text-muted-foreground mr-2 flex items-center gap-1.5">
          <Calendar className="w-4 h-4 text-primary" />
          تصفية فترة التقرير:
        </span>
        <ToggleGroup type="single" value={filter} onValueChange={(value) => { if(value) setFilter(value as any)}} className="bg-secondary/40 rounded-xl p-0.5 border border-border/10">
          <ToggleGroupItem value="today" className="rounded-lg text-xs font-semibold px-3 py-1.5 data-[state=on]:bg-background data-[state=on]:shadow-sm data-[state=on]:text-primary transition-all">اليوم</ToggleGroupItem>
          <ToggleGroupItem value="week" className="rounded-lg text-xs font-semibold px-3 py-1.5 data-[state=on]:bg-background data-[state=on]:shadow-sm data-[state=on]:text-primary transition-all">الأسبوع</ToggleGroupItem>
          <ToggleGroupItem value="month" className="rounded-lg text-xs font-semibold px-3 py-1.5 data-[state=on]:bg-background data-[state=on]:shadow-sm data-[state=on]:text-primary transition-all">الشهر</ToggleGroupItem>
          <ToggleGroupItem value="year" className="rounded-lg text-xs font-semibold px-3 py-1.5 data-[state=on]:bg-background data-[state=on]:shadow-sm data-[state=on]:text-primary transition-all">السنة</ToggleGroupItem>
        </ToggleGroup>
      </div>
      
      {loading ? (
        <div className="flex flex-col justify-center items-center h-48 gap-3 bg-card border border-border/40 rounded-3xl">
          <LoaderCircle className="w-8 h-8 animate-spin text-primary" />
          <span className="text-xs text-muted-foreground">جاري احتساب المؤشرات المالية...</span>
        </div>
      ) : stats ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          
          {/* Revenue */}
          <Card className="hover-lift cursor-pointer rounded-3xl border border-emerald-500/10 bg-emerald-500/[0.03] hover:bg-emerald-500/[0.06] transition-all duration-300" onClick={() => handleDetailsClick('revenue')}>
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-xs font-semibold text-muted-foreground">إجمالي الإيرادات</CardTitle>
              <div className="p-1.5 bg-emerald-500/10 text-emerald-600 rounded-lg">
                <ArrowUp className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent className="pt-1.5">
              <div className="text-2xl font-bold tracking-tight text-emerald-600 font-mono">{formatCurrency(stats.totalRevenue)}</div>
              <p className="text-[10px] text-muted-foreground mt-1">مجموع فواتير المبيعات • اضغط للتفاصيل</p>
            </CardContent>
          </Card>

          {/* Expenses */}
          <Card className="hover-lift cursor-pointer rounded-3xl border border-red-500/10 bg-red-500/[0.03] hover:bg-red-500/[0.06] transition-all duration-300" onClick={() => handleDetailsClick('expenses')}>
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-xs font-semibold text-muted-foreground">إجمالي المصروفات</CardTitle>
              <div className="p-1.5 bg-red-500/10 text-red-600 rounded-lg">
                <ArrowDown className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent className="pt-1.5">
              <div className="text-2xl font-bold tracking-tight text-red-600 font-mono">{formatCurrency(stats.totalExpenses)}</div>
              <p className="text-[10px] text-muted-foreground mt-1">المصاريف الكلية المسجلة • اضغط للتفاصيل</p>
            </CardContent>
          </Card>

          {/* Net Profit */}
          <Card className="hover-lift cursor-pointer rounded-3xl border border-primary/10 bg-primary/[0.03] hover:bg-primary/[0.06] transition-all duration-300" onClick={() => handleDetailsClick('profit')}>
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-xs font-semibold text-muted-foreground">صافي الأرباح</CardTitle>
              <div className="p-1.5 bg-primary/10 text-primary rounded-lg">
                <Banknote className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent className="pt-1.5">
              <div className={`text-2xl font-bold tracking-tight font-mono ${netProfit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                {netProfit >= 0 ? '+' : ''}{formatCurrency(netProfit)}
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">المبيعات ناقصاً المصروفات • اضغط للتفاصيل</p>
            </CardContent>
          </Card>

          {/* Installment Profit */}
          <Card className="rounded-3xl border border-border/50 bg-card shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-xs font-semibold text-muted-foreground">أرباح التقسيط المجدولة</CardTitle>
              <div className="p-1.5 bg-secondary text-muted-foreground rounded-lg">
                <BarChart className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent className="pt-1.5">
              <div className="text-2xl font-bold tracking-tight text-foreground font-mono">{formatCurrency(stats.totalProfit)}</div>
              <p className="text-[10px] text-muted-foreground mt-1">الربح المتوقع الإضافي من فوائد الأقساط</p>
            </CardContent>
          </Card>
        </div>
      ) : (
         <div className="text-center py-12 text-muted-foreground bg-card border border-dashed rounded-3xl">
             فشل في تحميل التحليلات المالية. يرجى تحديث الصفحة.
        </div>
      )}

      {/* Analytics Lists Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7 pt-2">
          
          {/* Recent Sales Card */}
          <Card className="lg:col-span-4 rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
              <CardHeader className="pb-4 border-b border-border/40 bg-secondary/15 flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-sm font-bold text-foreground">أحدث 5 عمليات بيع</CardTitle>
                  <CardDescription className="text-xs">المبيعات الأخيرة المسجلة للعملاء</CardDescription>
                </div>
                <Button variant="ghost" size="sm" asChild className="rounded-full hover:bg-primary/5 text-primary text-xs">
                  <Link href="/invoices">عرض الكل</Link>
                </Button>
              </CardHeader>
              <CardContent className="p-0">
                  <Table>
                      <TableHeader>
                          <TableRow>
                              <TableHead>العميل / الفاتورة</TableHead>
                              <TableHead className="hidden sm:table-cell">الحالة</TableHead>
                              <TableHead className="hidden sm:table-cell">التاريخ</TableHead>
                              <TableHead className="text-right">المبلغ الكلي</TableHead>
                          </TableRow>
                      </TableHeader>
                      <TableBody>
                          {initialRecentInvoices.map((invoice) => (
                              <TableRow key={invoice.id} className="group">
                                  <TableCell className="font-semibold text-foreground">
                                      <div className="font-bold">{invoice.customerName}</div>
                                      <div className="text-[10px] text-muted-foreground mt-0.5">
                                          <Link href={`/invoices/${invoice.id}/print`} className="text-primary hover:underline flex items-center gap-1">
                                            #{invoice.invoiceNumber}
                                            <Eye className="w-3 h-3 inline opacity-0 group-hover:opacity-100 transition-opacity" />
                                          </Link>
                                      </div>
                                  </TableCell>
                                  <TableCell className="hidden sm:table-cell">
                                      <Badge variant={statusMap[invoice.status]?.variant || 'default'}>
                                          {statusMap[invoice.status]?.text || invoice.status}
                                      </Badge>
                                  </TableCell>
                                  <TableCell className="hidden sm:table-cell text-xs text-muted-foreground">
                                      <FormattedDate dateString={invoice.issueDate} />
                                  </TableCell>
                                  <TableCell className="text-right font-mono font-bold text-foreground">{formatCurrency(invoice.totalAmount)}</TableCell>
                              </TableRow>
                          ))}
                      </TableBody>
                  </Table>
              </CardContent>
          </Card>

          {/* Top Selling Products Card */}
          <Card className="lg:col-span-3 rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
              <CardHeader className="pb-4 border-b border-border/40 bg-secondary/15">
                  <CardTitle className="text-sm font-bold text-foreground">المنتجات الأكثر طلباً</CardTitle>
                  <CardDescription className="text-xs">أفضل 5 أصناف تم بيعها كميةً</CardDescription>
              </CardHeader>
              <CardContent className="p-4 space-y-4">
                  {initialTopProducts.length > 0 ? initialTopProducts.map((product) => {
                      const percent = (product.totalSold / maxSold) * 100;
                      return (
                        <div key={product.productId} className="space-y-1 p-2 rounded-xl hover:bg-secondary/10 transition-colors">
                          <div className="flex justify-between items-center text-xs font-semibold text-foreground">
                            <span className="flex items-center gap-1.5">
                              <ShoppingBag className="w-3.5 h-3.5 text-primary" />
                              {product.productName}
                            </span>
                            <span className="font-mono bg-primary/10 text-primary px-2 py-0.5 rounded-full text-[10px]">{product.totalSold} وحدة</span>
                          </div>
                          {/* Animated progress bar indicator */}
                          <div className="w-full bg-secondary rounded-full h-1.5 overflow-hidden">
                            <div className="bg-primary h-full rounded-full transition-all duration-500" style={{ width: `${percent}%` }} />
                          </div>
                        </div>
                      );
                  }) : (
                      <div className="text-center py-10 text-muted-foreground text-xs">
                          لا توجد إحصائيات للمبيعات بعد.
                      </div>
                  )}
              </CardContent>
          </Card>
      </div>

      {/* Details Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="sm:max-w-4xl rounded-3xl border border-border/50 shadow-2xl p-0 overflow-hidden">
          <DialogHeader className="p-6 pb-4 border-b border-border/40 bg-secondary/15">
            <DialogTitle className="text-base font-bold text-foreground flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              {getDialogTitle()}
            </DialogTitle>
            <DialogDescription className="text-xs mt-1">
              جدول التحليل التفصيلي للعمليات المالية المطابقة للفلترة والمدة الزمنية المحددة.
            </DialogDescription>
          </DialogHeader>
          <div className="p-0">
            <ScrollArea className="h-[60vh] max-h-[60vh]">
              {detailsLoading ? (
                <div className="flex flex-col justify-center items-center h-64 gap-2">
                  <LoaderCircle className="w-8 h-8 animate-spin text-primary" />
                  <span className="text-xs text-muted-foreground font-medium">جاري جلب القائمة التفصيلية...</span>
                </div>
              ) : (
                <Table>
                  {detailsType === 'revenue' || detailsType === 'profit' ? (
                     <>
                      <TableHeader>
                        <TableRow>
                          <TableHead>رقم الفاتورة</TableHead>
                          <TableHead>العميل</TableHead>
                          <TableHead>التاريخ</TableHead>
                          <TableHead>الحالة</TableHead>
                          <TableHead className="text-right">المبلغ الكلي</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(detailsData as Invoice[]).length > 0 ? (detailsData as Invoice[]).map((inv: Invoice) => (
                          <TableRow key={inv.id}>
                            <TableCell className="font-mono font-bold text-primary">#{inv.invoiceNumber}</TableCell>
                            <TableCell className="font-semibold text-foreground">{inv.customerName}</TableCell>
                            <TableCell className="text-muted-foreground text-xs"><FormattedDate dateString={inv.issueDate} /></TableCell>
                            <TableCell>
                              <Badge variant={statusMap[inv.status]?.variant || 'default'}>
                                {statusMap[inv.status]?.text || inv.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right font-mono font-bold text-foreground">{formatCurrency(inv.totalAmount)}</TableCell>
                          </TableRow>
                        )) : (
                            <TableRow><TableCell colSpan={5} className="text-center h-32 text-muted-foreground text-xs">لا توجد مبيعات مسجلة في هذه الفترة.</TableCell></TableRow>
                        )}
                      </TableBody>
                    </>
                  ) : (
                    <>
                      <TableHeader>
                        <TableRow>
                          <TableHead>التاريخ</TableHead>
                          <TableHead>الوصف</TableHead>
                          <TableHead>الحساب المدفوع منه</TableHead>
                          <TableHead className="text-right">المبلغ الكلي</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                         {(detailsData as ExpenseDetails[]).length > 0 ? (detailsData as ExpenseDetails[]).map((exp: ExpenseDetails) => (
                          <TableRow key={exp.id}>
                            <TableCell className="text-muted-foreground text-xs"><FormattedDate dateString={exp.expenseDate} /></TableCell>
                            <TableCell className="font-semibold text-foreground">{exp.description}</TableCell>
                            <TableCell><Badge variant="secondary">{exp.paymentMethodName}</Badge></TableCell>
                            <TableCell className="text-right font-mono font-bold text-red-600">-{formatCurrency(exp.amount)}</TableCell>
                          </TableRow>
                        )): (
                            <TableRow><TableCell colSpan={4} className="text-center h-32 text-muted-foreground text-xs">لا توجد مصاريف مسجلة في هذه الفترة.</TableCell></TableRow>
                        )}
                      </TableBody>
                    </>
                  )}
                </Table>
              )}
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
