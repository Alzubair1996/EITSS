import { PageHeader } from '@/components/page-header';
import { getTopSellingProducts, getInvoices } from '@/lib/queries';
import ReportsClientPage from './reports-client-page';

export default async function ReportsPage() {
  const topProducts = await getTopSellingProducts(5);
  const recentInvoices = (await getInvoices()).slice(0, 5);

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <PageHeader title="التقارير" />
        <ReportsClientPage 
          initialTopProducts={topProducts}
          initialRecentInvoices={recentInvoices}
        />
      </div>
  );
}
