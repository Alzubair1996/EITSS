// The users administration page. This is a server component that displays all users and allows
// the admin to create new users, change roles, and delete users. It requires the MANAGE_USERS permission.

import { getUsersAndRoles, createUser, deleteUser } from './actions';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { User, Shield, UserMinus, PlusCircle } from 'lucide-react';

export const dynamic = 'force-dynamic';

export default async function AdminUsersPage() {
  const { users } = await getUsersAndRoles();

  const moduleOptions = [
    { key: 'view_dashboard', label: 'لوحة التحكم' },
    { key: 'manage_invoices', label: 'الفواتير' },
    { key: 'manage_purchases', label: 'المشتريات' },
    { key: 'manage_inventory', label: 'المخزون' },
    { key: 'manage_customers', label: 'العملاء' },
    { key: 'manage_suppliers', label: 'الموردين' },
    { key: 'view_reports', label: 'التقارير' },
    { key: 'manage_finance', label: 'المالية' },
    { key: 'manage_settings', label: 'الإعدادات' },
    { key: 'transfer_payment_methods', label: 'تحويل طرق الدفع' },
    { key: 'manage_payment_methods', label: 'إدارة طرق الدفع' },
  ];

  return (
    <div className="flex flex-1 flex-col gap-6 p-4 md:gap-8 md:p-8 max-w-7xl mx-auto w-full">
      <PageHeader 
        title="إدارة الموظفين" 
        subtitle="إضافة وتعديل حسابات الموظفين وتخصيص صلاحيات الوصول للنظام"
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Form to add a new user */}
        <Card className="lg:col-span-4 rounded-3xl border border-border/50 bg-card shadow-lg shadow-black/[0.02]">
          <CardHeader className="pb-4 border-b border-border/40 bg-secondary/15">
            <CardTitle className="text-base font-bold text-foreground flex items-center gap-2">
              <PlusCircle className="w-5 h-5 text-primary" />
              إضافة مستخدم جديد
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <form action={createUser} className="space-y-5">
              <div className="space-y-1.5">
                <Label htmlFor="new-fullname" className="text-sm font-semibold">اسم الموظف</Label>
                <Input
                  type="text"
                  id="new-fullname"
                  name="fullName"
                  required
                  placeholder="الاسم الكامل للموظف (مثال: محمد أحمد)"
                  className="rounded-xl border-border/60"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="new-username" className="text-sm font-semibold">اسم المستخدم (تسجيل الدخول)</Label>
                <Input
                  type="text"
                  id="new-username"
                  name="username"
                  required
                  placeholder="اسم المستخدم بالأحرف الإنجليزية"
                  className="rounded-xl border-border/60"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="new-password" className="text-sm font-semibold">كلمة المرور</Label>
                <Input
                  type="password"
                  id="new-password"
                  name="password"
                  required
                  placeholder="كلمة مرور حساب الموظف"
                  className="rounded-xl border-border/60"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-semibold block mb-1">
                  الصلاحيات الممنوحة
                </Label>
                <div className="grid grid-cols-1 gap-2 bg-secondary/10 p-3 rounded-2xl border border-border/40 max-h-[220px] overflow-y-auto">
                  {moduleOptions.map((opt) => (
                    <label key={opt.key} className="flex items-center gap-2.5 p-1.5 rounded-lg hover:bg-background transition-colors cursor-pointer select-none">
                      <input
                        type="checkbox"
                        name="permissions"
                        value={opt.key}
                        className="rounded border-border text-primary focus:ring-primary/20 h-4 w-4"
                      />
                      <span className="text-xs font-medium text-foreground">{opt.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <Button type="submit" className="w-full rounded-xl shadow-md hover:shadow-lg transition-all gap-2 h-11">
                <PlusCircle className="w-4 h-4" />
                إنشاء حساب الموظف
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* List of existing users */}
        <Card className="lg:col-span-8 rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
          <CardHeader className="pb-4 border-b border-border/40 bg-secondary/15 flex flex-row justify-between items-center">
            <div>
              <CardTitle className="text-base font-bold text-foreground flex items-center gap-2">
                <User className="w-5 h-5 text-primary" />
                قائمة الحسابات المسجلة
              </CardTitle>
            </div>
            <span className="text-xs font-semibold text-muted-foreground bg-background px-3 py-1.5 rounded-full border border-border/40 shadow-sm">
              إجمالي المستخدمين: {users.length}
            </span>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المستخدم</TableHead>
                  <TableHead>الصلاحيات الممنوحة</TableHead>
                  <TableHead className="text-center w-24">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                 {users.map((user: any) => (
                  <TableRow key={user.id} className="group">
                    <TableCell className="font-semibold flex items-center gap-3 text-foreground py-3">
                      <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <User className="w-4.5 h-4.5 text-primary" />
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-sm font-bold text-foreground">
                          {user.fullName || (user.username === 'admin' ? 'مدير النظام' : 'غير محدد')}
                        </span>
                        <span className="text-xs text-muted-foreground font-mono">
                          @{user.username}
                        </span>
                      </div>
                      {user.username === 'admin' && (
                        <Badge variant="success" className="text-[10px] px-2 py-0.5 mr-2 font-bold bg-emerald-500/10 text-emerald-600 border-emerald-500/20">المدير العام</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {user.permissions && user.permissions.length > 0 ? (
                          user.permissions.map((perm: string) => {
                            const match = moduleOptions.find((opt) => opt.key === perm);
                            return (
                              <Badge key={perm} variant="secondary" className="text-[10px] px-2 py-0.5 bg-secondary/50 border-border/30">
                                {match ? match.label : perm}
                              </Badge>
                            );
                          })
                        ) : (
                          <span className="text-xs text-muted-foreground">بدون صلاحيات</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      {user.username !== 'admin' ? (
                        <form action={deleteUser}>
                          <input type="hidden" name="userId" value={user.id} />
                          <Button 
                            type="submit" 
                            variant="ghost" 
                            size="sm" 
                            className="rounded-full h-8 px-2.5 text-destructive hover:text-destructive hover:bg-destructive/5 gap-1"
                          >
                            <UserMinus className="h-3.5 w-3.5" />
                            حذف الحساب
                          </Button>
                        </form>
                      ) : (
                        <span className="text-muted-foreground text-xs font-semibold">—</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}