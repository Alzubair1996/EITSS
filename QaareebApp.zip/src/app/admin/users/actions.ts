// Server actions for managing users. These actions require the caller to have the MANAGE_USERS permission.
'use server';

import { getDbInstance } from '@/lib/db';
import { hashPassword } from '@/lib/server-auth';
import { getSession } from '@/lib/server-auth';
import { redirect } from 'next/navigation';
import { hasPermission } from '@/lib/permissions';

const MANAGE_USERS_KEY = 'manage_users';

// Ensure the current user has permission to manage users. If not authenticated, redirect to login.
async function assertCanManage() {
  const session = await getSession();
  if (!session) {
    redirect('/login');
  }
  const allowed = await hasPermission(session.userId, MANAGE_USERS_KEY);
  if (!allowed) {
    throw new Error('ليست لديك الصلاحية لإدارة المستخدمين.');
  }
}

// Fetch a list of all users with their roles and all roles available.
export async function getUsersAndRoles() {
  await assertCanManage();
  const db = await getDbInstance();
  // Fetch all users and their role IDs
  const users = await db.all(`
    SELECT u.id, u.username, u.roleId, u.fullName
    FROM users u
  `);
  // For each user, fetch the associated permissions from role_permissions
  const usersWithPermissions = await Promise.all(
    users.map(async (user: any) => {
      const perms = await db.all(
        'SELECT permission FROM role_permissions WHERE roleId = ?',
        user.roleId
      );
      return {
        ...user,
        permissions: perms.map((p: any) => p.permission as string),
      };
    })
  );
  return { users: usersWithPermissions };
}

// Create a new user.
export async function createUser(formData: FormData) {
  await assertCanManage();
  const username = (formData.get('username') as string)?.trim();
  const password = (formData.get('password') as string) || '';
  const fullName = (formData.get('fullName') as string)?.trim() || '';
  const permissions = formData.getAll('permissions') as string[];
  if (!username || !password || !fullName || permissions.length === 0) {
    return { error: 'يجب ملء جميع الحقول واختيار الصلاحيات.' };
  }
  const db = await getDbInstance();
  const existing = await db.get('SELECT id FROM users WHERE username = ?', username);
  if (existing) {
    return { error: 'اسم المستخدم موجود بالفعل.' };
  }
  // Create a new role for this user with the selected permissions
  const roleId = `role_${Date.now()}`;
  const roleName = `Role for ${username}`;
  await db.run('INSERT INTO roles (id, name, is_default) VALUES (?, ?, ?)', roleId, roleName, 0);
  // Insert permissions for this role
  for (const perm of permissions) {
    await db.run('INSERT INTO role_permissions (roleId, permission) VALUES (?, ?)', roleId, perm);
  }
  // Insert the user with the new role and fullName
  const userId = `user_${Date.now()}`;
  const hashed = await hashPassword(password);
  await db.run('INSERT INTO users (id, username, password, roleId, fullName) VALUES (?, ?, ?, ?, ?)', userId, username, hashed, roleId, fullName);
  // Redirect back to the users page after creation
  redirect('/admin/users');
}

// Delete a user by id.
export async function deleteUser(formData: FormData) {
  await assertCanManage();
  const userId = formData.get('userId') as string;
  if (!userId) {
    return { error: 'معرّف المستخدم غير صالح.' };
  }
  const db = await getDbInstance();
  // Prevent deletion of the admin user (username: 'admin')
  try {
    const user = await db.get('SELECT username FROM users WHERE id = ?', userId) as { username?: string } | undefined;
    if (user && user.username === 'admin') {
      // Do not delete the admin user. Simply return or redirect back.
      return { error: 'لا يمكن حذف المستخدم المدير.' };
    }
    await db.run('DELETE FROM users WHERE id = ?', userId);
    redirect('/admin/users');
  } catch (e: any) {
    console.error('Failed to delete user:', e);
    return { error: e.message || 'خطأ في قاعدة البيانات: فشل حذف المستخدم.' };
  }
}