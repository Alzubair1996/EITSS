
// This is a temporary administrative page to trigger the database migration.
// It should be deleted after use.
'use client';
import { Button } from '@/components/ui/button';
import { hardRebuildInvoicesTable } from './actions';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import { LoaderCircle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';

export default function HardMigratePage() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleMigration = async () => {
    setIsLoading(true);
    toast({
        title: 'بدء عملية الإصلاح',
        description: 'جاري إعادة بناء جدول الفواتير. يرجى مراجعة الـ console لمتابعة التقدم.',
    });

    const result = await hardRebuildInvoicesTable();
    
    setIsLoading(false);
    if (result.success) {
      toast({
        title: 'نجاح!',
        description: result.message,
        duration: 7000,
      });
    } else {
      toast({
        variant: 'destructive',
        title: 'فشل الإصلاح',
        description: result.message,
        duration: 10000,
      });
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-muted">
      <Card className="max-w-xl">
        <CardHeader>
          <CardTitle>إصلاح قاعدة البيانات (Hard Migration)</CardTitle>
          <CardDescription>
            استخدم هذه الأداة لإصلاح جدول الفواتير بشكل قسري وتطبيق المخطط الصحيح.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>تحذير خطير</AlertTitle>
            <AlertDescription>
              هذا الإجراء مخصص للمطورين فقط. لا تستخدمه إلا إذا كنت تعرف ما تفعله.
              سيقوم بإعادة بناء جدول الفواتير مع الحفاظ على البيانات. يوصى بأخذ نسخة احتياطية أولاً.
            </AlertDescription>
          </Alert>
        </CardContent>
        <CardFooter>
          <Button onClick={handleMigration} disabled={isLoading} variant="destructive">
            {isLoading && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
            Execute Hard Rebuild
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
