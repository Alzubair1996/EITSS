
'use server';
import 'server-only';

import { hardRebuildInvoicesTable as _hardRebuild } from '@/lib/db';

export async function hardRebuildInvoicesTable() {
  // This will run on the server because the file is marked with 'use server'
  return _hardRebuild();
}
