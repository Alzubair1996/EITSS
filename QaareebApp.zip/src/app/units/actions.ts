'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { Unit } from '@/lib/types';
import { randomUUID } from 'crypto';

export async function addUnit(name: string) {
    try {
        const db = await getDbInstance();
        const existing = await db.get('SELECT id FROM units WHERE name = ?', name);
        if (existing) {
            return { success: false, message: 'الوحدة موجودة بالفعل.' };
        }
        const newId = `unit_${randomUUID()}`;
        await db.run('INSERT INTO units (id, name) VALUES (?, ?)', newId, name);
        revalidatePath('/units');
        revalidatePath('/products');
        return { success: true, message: 'تمت إضافة الوحدة بنجاح.' };
    } catch (e: any) {
        console.error(e);
        if (e.code === 'SQLITE_CONSTRAINT') {
             return { success: false, message: 'الوحدة موجودة بالفعل.' };
        }
        return { success: false, message: 'خطأ في قاعدة البيانات: فشلت إضافة الوحدة.' };
    }
}

export async function updateUnit(unit: Unit) {
     try {
        const db = await getDbInstance();
        await db.run('UPDATE units SET name = ? WHERE id = ?', unit.name, unit.id);
        revalidatePath('/units');
        revalidatePath('/products');
        return { success: true, message: 'تم تحديث الوحدة بنجاح.' };
    } catch (e: any) {
        console.error(e);
         if (e.code === 'SQLITE_CONSTRAINT') {
             return { success: false, message: 'الوحدة موجودة بالفعل.' };
        }
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل تحديث الوحدة.' };
    }
}

export async function deleteUnit(id: string) {
    try {
        const db = await getDbInstance();
        const product = await db.get('SELECT id FROM products WHERE unitId = ?', id);
        if (product) {
            return { success: false, message: 'لا يمكن حذف الوحدة لأنها مستخدمة في منتجات.' };
        }
        await db.run('DELETE FROM units WHERE id = ?', id);
        revalidatePath('/units');
        revalidatePath('/products');
        return { success: true, message: 'تم حذف الوحدة بنجاح.' };
    } catch (e) {
        console.error(e);
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل حذف الوحدة.' };
    }
}
