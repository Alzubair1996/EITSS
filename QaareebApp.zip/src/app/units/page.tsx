import UnitsClientPage from './units-client-page';
import { getUnits } from '@/lib/queries';

export default async function UnitsPage() {
  const initialUnits = await getUnits();

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <UnitsClientPage initialUnits={initialUnits} />
      </div>
  );
}
