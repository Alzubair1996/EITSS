'use client';

import * as React from 'react';
import { PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/page-header';
import { UnitsTable } from './units-table';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { UnitForm } from './unit-form';
import type { Unit } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { deleteUnit, addUnit, updateUnit } from './actions';
import { useRouter } from 'next/navigation';

interface UnitsClientPageProps {
  initialUnits: Unit[];
}

export default function UnitsClientPage({ initialUnits }: UnitsClientPageProps) {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [editingUnit, setEditingUnit] = React.useState<Unit | null>(null);
  const { toast } = useToast();
  const router = useRouter();

  const handleAdd = () => {
    setEditingUnit(null);
    setIsDialogOpen(true);
  };

  const handleEdit = (unit: Unit) => {
    setEditingUnit(unit);
    setIsDialogOpen(true);
  };

  const handleDelete = async (unitId: string) => {
    const result = await deleteUnit(unitId);
    if (result.success) {
      toast({
        title: 'تم الحذف بنجاح',
        description: result.message,
      });
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ في الحذف',
        description: result.message,
      });
    }
  };

  const handleFormSubmit = async (values: { name: string }) => {
    const result = editingUnit
      ? await updateUnit({ ...values, id: editingUnit.id })
      : await addUnit(values.name);

    if (result.success) {
      toast({
        title: editingUnit ? 'تم التحديث بنجاح' : 'تمت الإضافة بنجاح',
        description: result.message,
      });
      setIsDialogOpen(false);
      setEditingUnit(null);
      router.refresh();
    } else {
      toast({
        variant: 'destructive',
        title: 'خطأ',
        description: result.message,
      });
    }
  };

  return (
    <>
      <PageHeader title="إدارة الوحدات">
        <Button onClick={handleAdd} className="shadow-md hover:shadow-lg transition-shadow">
          <PlusCircle className="me-2 h-4 w-4" />
          إضافة وحدة جديدة
        </Button>
      </PageHeader>
      <UnitsTable
        units={initialUnits}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <UnitForm
            unit={editingUnit}
            onSubmit={handleFormSubmit}
            onCancel={() => setIsDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}
