
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import type { Unit } from '@/lib/types';

const formSchema = z.object({
  name: z.string().min(1, { message: 'اسم الوحدة مطلوب' }),
});

type UnitFormValues = z.infer<typeof formSchema>;

interface UnitFormProps {
  unit: Unit | null;
  onSubmit: (values: UnitFormValues) => void;
  onCancel: () => void;
}

export function UnitForm({ unit, onSubmit, onCancel }: UnitFormProps) {
  const form = useForm<UnitFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: unit?.name || '',
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <DialogHeader>
          <DialogTitle>
            {unit ? 'تعديل الوحدة' : 'إضافة وحدة جديدة'}
          </DialogTitle>
          <DialogDescription>
            {unit ? 'قم بتعديل اسم الوحدة.' : 'أدخل اسم الوحدة الجديدة.'}
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>اسم الوحدة</FormLabel>
                <FormControl>
                  <Input placeholder="مثال: قطعة" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onCancel}>
            إلغاء
          </Button>
          <Button type="submit">
            {unit ? 'حفظ التغييرات' : 'إضافة وحدة'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}
