'use client';
import * as React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { checkOnlineActivation } from './actions';
import { LoaderCircle, ShieldCheck, QrCode, Clock } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

interface ActivationClientPageProps {
  serverId: string;
  activationStatus: {
    isActivated: boolean;
    isSetupComplete: boolean;
    isClockTampered?: boolean;
  }
}

export default function ActivationClientPage({ serverId, activationStatus }: ActivationClientPageProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [isOnlineChecking, setIsOnlineChecking] = React.useState(false);
  const [successDetails, setSuccessDetails] = React.useState<{ expiry: string; daysRemaining?: number | null; destination: string } | null>(null);

  React.useEffect(() => {
    // Prevent immediate redirect if we are currently performing an online activation check
    // or if we have already successfully completed the check (successDetails is populated)
    if (activationStatus.isActivated && !isOnlineChecking && !successDetails) {
      window.location.href = activationStatus.isSetupComplete ? '/' : '/setup';
    }
  }, [activationStatus, isOnlineChecking, successDetails]);

  const handleOnlineCheck = async () => {
    setIsOnlineChecking(true);
    const result = await checkOnlineActivation();
    setIsOnlineChecking(false);

    if (result?.success) {
      const destination = result.isSetupComplete ? '/' : '/setup';
      
      setSuccessDetails({
        expiry: result.expiry || '',
        daysRemaining: result.daysRemaining,
        destination
      });
    } else {
      toast({ variant: 'destructive', title: 'فشل التفعيل أونلاين', description: result?.message || 'حدث خطأ غير متوقع أو لم يتم التفعيل بعد.' });
    }
  };

  return (
    <>


      {successDetails && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background/95 backdrop-blur-md animate-in fade-in duration-300">
          <div className="max-w-md w-full p-8 mx-4 text-center bg-card border border-border rounded-3xl shadow-2xl space-y-6 animate-in zoom-in-95 duration-300">
            <div className="flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur-xl animate-pulse"></div>
                <div className="relative bg-emerald-500/10 text-emerald-500 p-5 rounded-full border border-emerald-500/20">
                  <ShieldCheck className="w-16 h-16 stroke-[1.5]" />
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h1 className="text-3xl font-extrabold font-headline text-emerald-600 dark:text-emerald-400 tracking-tight">
                تهانينا! تم التفعيل بنجاح 🎉
              </h1>
              <p className="text-xl font-bold text-foreground leading-relaxed">
                {successDetails.expiry === 'lifetime' 
                  ? 'تم تفعيل الجهاز بنجاح مدى الحياة!' 
                  : `تم تفعيل الجهاز بنجاح ولديك ${successDetails.daysRemaining} يوم صلاحية لتشغيل البرنامج!`}
              </p>
              <p className="text-muted-foreground text-xs">تم ربط ترخيص جهازك بنجاح وحفظ كاش التفعيل محلياً</p>
            </div>

            <div className="p-5 bg-muted/50 rounded-2xl border border-border/80 space-y-3">
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground font-medium">حالة الترخيص:</span>
                <span className="text-emerald-500 font-bold bg-emerald-500/10 px-3 py-1 rounded-full text-xs border border-emerald-500/20">
                  نشط ومفعّل
                </span>
              </div>
              <div className="h-px bg-border/60"></div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground font-medium">صلاحية التفعيل:</span>
                <span className="font-bold text-foreground">
                  {successDetails.expiry === 'lifetime' ? 'مدى الحياة (Lifetime)' : `حتى تاريخ ${successDetails.expiry}`}
                </span>
              </div>
              {successDetails.daysRemaining !== null && successDetails.daysRemaining !== undefined && (
                <>
                  <div className="h-px bg-border/60"></div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground font-medium">المدة المتبقية:</span>
                    <span className="font-bold text-foreground">
                      {successDetails.daysRemaining} يوم
                    </span>
                  </div>
                </>
              )}
            </div>

            <div className="pt-4 w-full">
              <Button
                onClick={() => {
                  window.location.href = successDetails.destination;
                }}
                className="w-full font-bold h-12 text-sm bg-emerald-600 hover:bg-emerald-700 text-white transition-all duration-200 shadow-lg shadow-emerald-600/15 rounded-2xl flex items-center justify-center gap-2"
              >
                الدخول للنظام ومتابعة العمل
              </Button>
            </div>
          </div>
        </div>
      )}
    <Card className="shadow-lg border border-border/80">
      <CardHeader className="text-center pb-2">
        <CardTitle className="text-2xl font-bold font-headline">تفعيل البرنامج أونلاين</CardTitle>
        <CardDescription className="text-xs">
          امسح رمز الاستجابة السريعة بالهاتف من شاشة المسؤول لتفعيل هذا الجهاز.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {activationStatus.isClockTampered && (
          <Alert variant="destructive" className="bg-destructive/5 border-destructive/20 text-destructive">
            <Clock className="h-4 w-4 animate-pulse text-destructive" />
            <AlertTitle className="font-bold text-xs">تم اكتشاف تلاعب في تاريخ الجهاز!</AlertTitle>
            <AlertDescription className="text-[11px] leading-relaxed mt-1">
              لقد تم اكتشاف تغيير في تاريخ أو وقت نظام التشغيل للوراء. يرجى ضبط تاريخ ووقت الجهاز الحاليين للوقت الفعلي والصحيح لتتمكن من استخدام البرنامج.
            </AlertDescription>
          </Alert>
        )}

        {/* QR Code Section */}
        <div className="flex flex-col items-center justify-center p-5 bg-muted/40 rounded-2xl border border-dashed border-muted-foreground/20 space-y-4 shadow-inner">
          <div className="relative p-3.5 bg-white rounded-2xl shadow-md border border-border/60">
            <img 
              src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(serverId)}`} 
              alt="Server ID QR Code" 
              className="w-[180px] h-[180px] object-contain" 
            />
          </div>
          <div className="text-center space-y-1">
            <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-primary">
              <QrCode className="w-4 h-4" />
              <span>رمز التفعيل السريع للادمن</span>
            </div>
            <p className="text-[10px] text-muted-foreground max-w-xs leading-relaxed">
              امسح الرمز أعلاه باستخدام تطبيق تفعيل الإدارة الخاص بك لتحديد مدة الترخيص وتفعيل هذا الجهاز عن بعد.
            </p>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pb-6">
        <Button 
          onClick={handleOnlineCheck} 
          disabled={isOnlineChecking} 
          className="w-full font-bold h-11 text-sm bg-primary hover:bg-primary/95 transition-all duration-200"
        >
          {isOnlineChecking ? (
            <LoaderCircle className="me-2 h-4 w-4 animate-spin" />
          ) : (
            <ShieldCheck className="me-2 h-4 w-4 text-emerald-400" />
          )}
          التحقق من التفعيل أونلاين
        </Button>
      </CardFooter>
    </Card>
    </>
  );
}
