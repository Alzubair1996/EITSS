'use server';
import { getDbInstance } from '@/lib/db';
import { getServerId } from '@/lib/server-id';
import { revalidatePath } from 'next/cache';
import * as crypto from 'crypto';
import { performActivationCheck } from '@/app/api/auth/queries';
import { getOnlineLicense } from '@/lib/firebase';

// Server action to verify activation online via Firebase Realtime Database
export async function checkOnlineActivation() {
  try {
    const serverId = await getServerId();
    const onlineData = await getOnlineLicense(serverId);

    if (!onlineData) {
      return { success: false, message: 'لم يتم العثور على تفعيل مسجل لهذا الجهاز في قاعدة البيانات أونلاين. يرجى تفعيل الجهاز أولاً من شاشة الإدارة.' };
    }

    const { expiry, signature, activated } = onlineData;

    if (!activated) {
      return { success: false, message: 'حالة التفعيل غير نشطة حالياً لهذا الجهاز في قاعدة البيانات أونلاين.' };
    }

    // Verify signature to prevent tampering/spoofing of Firebase records
    const sha256Hash = crypto.createHash('sha256').update(serverId + ":" + expiry).digest('hex');
    const expectedSignature = crypto.createHash('sha512').update(sha256Hash).digest('hex');

    if (signature !== expectedSignature) {
      return { success: false, message: 'توقيع التفعيل المسترجع غير صالح أو معدل. يرجى التواصل مع الدعم الفني.' };
    }

    // Check expiry
    if (expiry !== 'lifetime') {
      const expiryDate = new Date(expiry);
      if (!isNaN(expiryDate.getTime())) {
        const now = new Date();
        now.setHours(0, 0, 0, 0);
        expiryDate.setHours(23, 59, 59, 999);
        if (now > expiryDate) {
          return { success: false, message: `تفعيل هذا الجهاز منتهي الصلاحية منذ تاريخ ${expiry}.` };
        }
      }
    }

    // Save key locally for offline caching (stores as YYYY-MM-DD-signature or lifetime-signature)
    const localKey = `${expiry}-${signature}`;
    const db = await getDbInstance();
    await db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'license_key', localKey);

    const status = await performActivationCheck();
    
    // Get the parsed license details to ensure we return the exact parsed expiry info
    const { getLicenseDetails } = await import('@/app/api/auth/queries');
    const licenseDetails = await getLicenseDetails();
    
    // Removed revalidatePath here to prevent Next.js from resetting client-side React state.
    // The hard reload/redirect (window.location.href) on client success will fetch the fresh database state.

    return { 
      success: true, 
      message: 'تم تفعيل البرنامج عبر الإنترنت بنجاح وحفظ رخصة الاستخدام محلياً.', 
      isSetupComplete: status.isSetupComplete,
      expiry: licenseDetails.expiry,
      daysRemaining: licenseDetails.daysRemaining
    };

  } catch (error: any) {
    console.error('Online activation check error:', error);
    return { success: false, message: error.message || 'حدث خطأ أثناء فحص التفعيل أونلاين.' };
  }
}

export async function continueWithTrial() {
    revalidatePath('/', 'layout');
    return { success: true };
}
