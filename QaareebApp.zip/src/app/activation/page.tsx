
import ActivationClientPage from './activation-client-page';
import { getServerId } from '@/lib/server-id';
import { KeyRound } from 'lucide-react';
import { performActivationCheck } from '@/app/api/auth/queries';
import { redirect } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default async function ActivationPage() {
    const serverId = await getServerId();
    const activationStatus = await performActivationCheck();
    
    // We will let the client page handle redirection to avoid race conditions with the success modal.

    return (
        <div className="flex flex-col items-center w-full h-screen overflow-y-auto bg-muted p-4 md:py-12">
            <div className="w-full max-w-lg space-y-6">
                <div className="flex flex-col items-center justify-center">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src="/logoEITSS.png" alt="EITSS Logo" className="h-24 w-auto object-contain mb-2" />
                    <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">شريك تقني EITSS</span>
                </div>
                <ActivationClientPage serverId={serverId} activationStatus={activationStatus} />
            </div>
        </div>
    );
}
