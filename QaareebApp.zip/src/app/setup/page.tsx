import { getCompanyInfo } from '@/lib/queries';
import SetupClientPage from '@/app/setup/setup-client-page';
import { Landmark } from 'lucide-react';
import { redirect } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default async function SetupPage() {
  const companyInfo = await getCompanyInfo();

  // If setup is already complete, redirect to home page.
  // We check for business_type as a proxy for setup completion.
  if (companyInfo.businessType) {
    redirect('/');
  }

  return (
      <div className="flex flex-col items-center w-full h-screen overflow-y-auto bg-gradient-to-br from-[#f8fafc] via-[#f1f5f9] to-[#e2e8f0] p-4 relative" dir="rtl">
        
        {/* Soft colorful background glowing orbs */}
        <div className="absolute top-[-10%] right-[-10%] w-[550px] h-[550px] bg-primary/8 rounded-full blur-[100px] pointer-events-none animate-pulse" style={{ animationDuration: '9s' }} />
        <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-indigo-400/8 rounded-full blur-[110px] pointer-events-none animate-pulse" style={{ animationDuration: '11s' }} />
        
        {/* Floating grid pattern background overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000002_1px,transparent_1px),linear-gradient(to_bottom,#00000002_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none" />

        <div className="w-full max-w-2xl relative z-10 my-8">
            <div className="flex flex-col items-center justify-center mb-8">
                <div className="p-3.5 bg-primary/10 border border-primary/20 rounded-2xl mb-4 shadow-md shadow-primary/5">
                   <Landmark className="w-8 h-8 text-primary animate-pulse" />
                </div>
                <h1 className="text-3xl font-extrabold font-headline text-slate-900 tracking-tight">إعداد المتجر الجديد</h1>
                <p className="text-slate-500 text-sm text-center mt-2 max-w-md leading-relaxed">
                    أدخل بيانات شركتك الأساسية للبدء، أو قم باستعادة بياناتك من نسخة احتياطية سابقة.
                </p>
            </div>
            
            {/* The main client page container - prominent frosted white glass */}
            <div className="bg-white/45 backdrop-blur-xl border border-white/60 p-6 md:p-8 rounded-2xl shadow-xl shadow-black/[0.03]">
               <SetupClientPage initialData={companyInfo} />
            </div>

            {/* Corporate branding tag */}
            <div className="text-center text-[10px] text-slate-400 mt-8">
              تم تطوير هذا النظام محلياً بواسطة EITSS الباقرة لتقنية المعلومات • جميع الحقوق محفوظة © 2026
            </div>
        </div>
      </div>
  );
}
