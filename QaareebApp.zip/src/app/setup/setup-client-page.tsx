'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { saveCompanyInfo } from '@/app/settings/company/actions';
import { restoreDatabaseAction } from '@/app/settings/actions';
import Image from 'next/image';
import { LoaderCircle, Building, UploadCloud, AlertTriangle, ShoppingCart, Store, Package, Pill, UtensilsCrossed } from 'lucide-react';
import type { CompanyInfo } from '@/lib/types';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

const businessTypes = [
  { id: 'general_store', name: 'متجر عام', label: 'المتجر', icon: Package },
  { id: 'grocery', name: 'بقالة', label: 'البقالة', icon: ShoppingCart },
  { id: 'supermarket', name: 'سوبر ماركت', label: 'السوبر ماركت', icon: Store },
  { id: 'pharmacy', name: 'صيدلية', label: 'الصيدلية', icon: Pill },
  { id: 'restaurant', name: 'مطعم', label: 'المطعم', icon: UtensilsCrossed },
];

interface SetupClientPageProps {
  initialData: CompanyInfo;
}

export default function SetupClientPage({ initialData }: SetupClientPageProps) {
  const { toast } = useToast();
  
  const [isLoading, setIsLoading] = React.useState(false);
  const [formData, setFormData] = React.useState<CompanyInfo>(initialData);
  const [logoPreview, setLogoPreview] = React.useState<string | null>(initialData.logo);

  const [isRestoreLoading, setIsRestoreLoading] = React.useState(false);
  const restoreFileInputRef = React.useRef<HTMLInputElement>(null);

  const [step, setStep] = React.useState(1);
  const [selectedBusinessType, setSelectedBusinessType] = React.useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: parseFloat(value) || 0 }));
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
        toast({
          variant: 'destructive',
          title: 'الملف كبير جدًا',
          description: 'يرجى اختيار صورة بحجم أقل من 2 ميجابايت.',
        });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData(prev => ({ ...prev, logo: base64String }));
        setLogoPreview(base64String);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleSubmit = async () => {
    if (!formData.name || !formData.address || !formData.phones) {
      toast({
        variant: 'destructive',
        title: 'بيانات ناقصة',
        description: 'اسم الشركة، العنوان، والهواتف حقول مطلوبة للبدء.',
      });
      return;
    }

    setIsLoading(true);
    const result = await saveCompanyInfo({...formData, businessType: selectedBusinessType});
    setIsLoading(false);

    if (result.success) {
      toast({ title: 'تم الحفظ بنجاح', description: 'تم إعداد متجرك بنجاح. جاري التوجيه...' });
      window.location.href = '/';
    } else {
      toast({ variant: 'destructive', title: 'فشل الحفظ', description: result.message });
    }
  };

  const handleRestoreFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
        toast({ variant: 'default', title: 'تم إلغاء التحديد' });
        return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
        const base64Data = event.target?.result as string;
        setIsRestoreLoading(true);
        const result = await restoreDatabaseAction(base64Data);
        setIsRestoreLoading(false);

        if (result.success) {
            toast({
                title: 'نجاح استعادة البيانات',
                description: result.message,
                duration: 5000,
            });
            setTimeout(() => window.location.reload(), 1500);
        } else {
             toast({
                variant: 'destructive',
                title: 'فشل استعادة البيانات',
                description: result.message,
                duration: 7000,
            });
        }
    };
    reader.readAsDataURL(file);
  };

  const renderStepOne = () => (
    <div className="space-y-6 text-right">
      <div>
        <h2 className="text-xl font-bold text-slate-800">الخطوة 1 من 2: اختر نوع نشاطك التجاري</h2>
        <p className="text-slate-500 text-xs mt-1">
          سيساعدنا هذا في تخصيص بعض الميزات والتقارير لتناسب احتياجاتك. هذا الإعداد لا يمكن تغييره لاحقًا.
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5 pt-2">
        {businessTypes.map(type => {
          const isSelected = selectedBusinessType === type.id;
          return (
            <button 
              key={type.id}
              onClick={() => setSelectedBusinessType(type.id)}
              className={cn(
                "flex flex-col items-center justify-center p-6 border rounded-xl text-center transition-all duration-300 relative overflow-hidden",
                isSelected 
                  ? "border-primary bg-primary/10 text-primary shadow-[0_0_15px_rgba(99,102,241,0.15)] scale-[1.03]" 
                  : "border-slate-200/60 bg-white/40 text-slate-700 hover:border-primary/50 hover:bg-white/80 hover:text-primary"
              )}
            >
              <type.icon className={cn("w-9 h-9 mb-3 transition-colors", isSelected ? "text-primary" : "text-slate-400")} />
              <span className="font-bold text-xs">{type.name}</span>
            </button>
          );
        })}
      </div>

      <div className="mt-8 pt-5 border-t border-slate-200/60">
        <Button 
          onClick={() => setStep(2)} 
          disabled={!selectedBusinessType} 
          className="w-full py-6 text-sm font-extrabold rounded-xl shadow-md shadow-primary/10" 
          size="lg"
        >
          متابعة الخطوة التالية
        </Button>
      </div>
    </div>
  );

  const renderStepTwo = () => {
    const businessNameLabel = businessTypes.find(b => b.id === selectedBusinessType)?.label || 'النشاط';

    return (
      <div className="space-y-6 text-right">
        <div>
          <h2 className="text-xl font-bold text-slate-800">الخطوة 2 من 2: بيانات النشاط التجاري</h2>
          <p className="text-slate-500 text-xs mt-1">
            هذه البيانات ستظهر في الفواتير المطبوعة. يمكنك تعديلها لاحقاً في أي وقت من الإعدادات.
          </p>
        </div>

        <div className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-1.5">
              <Label htmlFor="name" className="text-slate-700 font-bold text-xs">اسم {businessNameLabel} (عربي) *</Label>
              <Input id="name" value={formData.name} onChange={handleInputChange} className="text-right" placeholder="أدخل اسم النشاط بالعربية" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="nameEn" className="text-slate-700 font-bold text-xs">اسم {businessNameLabel} (إنجليزي)</Label>
              <Input id="nameEn" value={formData.nameEn} onChange={handleInputChange} className="text-right" placeholder="Business Name (English)" />
            </div>
          </div>
          
          <div className="space-y-1.5">
            <Label htmlFor="address" className="text-slate-700 font-bold text-xs">العنوان الجغرافي بالتفصيل *</Label>
            <Input id="address" value={formData.address} onChange={handleInputChange} className="text-right" placeholder="مثال: الخرطوم، شارع الستين" />
          </div>
          
          <div className="space-y-1.5">
            <Label htmlFor="phones" className="text-slate-700 font-bold text-xs">أرقام هواتف التواصل *</Label>
            <Input id="phones" value={formData.phones} onChange={handleInputChange} className="text-right" placeholder="مثال: 0912345678 - 0123456789" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
            <div className="space-y-1.5">
              <Label htmlFor="vatPercentage" className="text-slate-700 font-bold text-xs">نسبة ضريبة القيمة المضافة (%)</Label>
              <Input id="vatPercentage" type="number" value={formData.vatPercentage} onChange={handleNumberChange} className="text-right" placeholder="0" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="logo-upload" className="text-slate-700 font-bold text-xs">شعار النشاط / اللوجو (اختياري)</Label>
              <Input id="logo-upload" type="file" accept="image/png, image/jpeg, image/svg+xml" onChange={handleLogoChange} className="cursor-pointer text-xs" />
              <div className="mt-2 w-20 h-20 p-2.5 border border-slate-200 rounded-xl flex items-center justify-center bg-white/30 shadow-inner">
                {logoPreview ? (
                  <Image src={logoPreview} alt="شعار النشاط" width={64} height={64} className="object-contain" />
                ) : (
                  <Building className="w-10 h-10 text-slate-300" />
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-5 border-t border-slate-200 flex justify-between gap-4">
          <Button 
            onClick={() => setStep(1)} 
            variant="outline" 
            className="px-6 rounded-xl border-slate-200 text-slate-700 hover:bg-slate-100 bg-transparent text-xs"
          >
            السابق
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={isLoading} 
            className="px-8 rounded-xl font-bold text-xs" 
            size="lg"
          >
            {isLoading && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
            حفظ وإنهاء الإعداد
          </Button>
        </div>
      </div>
    );
  };

  return (
    <Tabs defaultValue="new_setup" className="w-full">
      <TabsList className="grid w-full grid-cols-2 p-1.5 bg-slate-100 border border-slate-200/50 rounded-xl mb-7">
        <TabsTrigger value="new_setup" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white text-slate-600 py-2.5 text-xs font-bold transition-all">إعداد جديد</TabsTrigger>
        <TabsTrigger value="restore" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white text-slate-600 py-2.5 text-xs font-bold transition-all">استعادة من نسخة احتياطية</TabsTrigger>
      </TabsList>
      
      <TabsContent value="new_setup">
        {step === 1 ? renderStepOne() : renderStepTwo()}
      </TabsContent>
      
      <TabsContent value="restore">
        <div className="space-y-6 text-right">
          <div>
            <h2 className="text-xl font-bold text-slate-800">استعادة البيانات من نسخة احتياطية</h2>
            <p className="text-slate-500 text-xs mt-1">
              استخدم هذه الميزة إذا قمت بترحيل بياناتك أو كان لديك نسخة احتياطية سابقة من قاعدة بيانات النظام.
            </p>
          </div>

          <div className="border border-red-200 bg-red-50/70 p-4 rounded-xl flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="font-bold text-red-800 text-sm">تحذير مسح واستبدال البيانات</h4>
              <p className="text-red-700/80 text-xs leading-relaxed">
                هذا الإجراء سيقوم بمسح كافة حركات البيع، الشراء، المنتجات، وأرصدة الحسابات الحالية بشكل نهائي واستبدالها بالبيانات المخزنة في ملف النسخة الاحتياطية المختار.
              </p>
            </div>
          </div>

          <div className="text-center pt-8 pb-4">
            <input 
              type="file"
              accept=".sqlite"
              ref={restoreFileInputRef}
              onChange={handleRestoreFileSelect}
              className="hidden"
            />
            <Button 
              onClick={() => restoreFileInputRef.current?.click()} 
              disabled={isRestoreLoading} 
              className="py-6 px-8 rounded-xl font-bold text-sm shadow-md shadow-primary/10" 
              size="lg"
            >
              {isRestoreLoading ? (
                 <LoaderCircle className="me-2 h-5 w-5 animate-spin" />
              ) : (
                 <UploadCloud className="me-2 h-5 w-5" />
              )}
              اختيار ملف قاعدة البيانات (.sqlite)
            </Button>
          </div>
        </div>
      </TabsContent>
    </Tabs>
  );
}
