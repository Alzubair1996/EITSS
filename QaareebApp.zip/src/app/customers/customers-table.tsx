
'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MoreHorizontal, Pencil, Trash2, Users, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import type { Customer } from '@/lib/types';
import Link from 'next/link';

interface CustomersTableProps {
  customers: Customer[];
  onEdit: (customer: Customer) => void;
  onDelete: (customerId: string) => void;
}

export function CustomersTable({ customers, onEdit, onDelete }: CustomersTableProps) {
  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  // Summary stats
  const totalBalance = customers.reduce((sum, c) => sum + (c.balance || 0), 0);
  const debtors = customers.filter(c => (c.balance || 0) < 0).length;
  const creditCustomers = customers.filter(c => (c.balance || 0) > 0).length;

  return (
    <Card className="rounded-3xl border border-border/50 bg-card overflow-hidden shadow-lg shadow-black/[0.02]">
      {/* Summary Bar */}
      <div className="grid grid-cols-3 divide-x divide-x-reverse divide-border/40 border-b border-border/40 bg-secondary/20">
        <div className="px-6 py-4 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-primary/10">
            <Users className="h-4 w-4 text-primary" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground font-medium">إجمالي العملاء</p>
            <p className="text-lg font-bold text-foreground">{customers.length}</p>
          </div>
        </div>
        <div className="px-6 py-4 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-emerald-500/10">
            <TrendingUp className="h-4 w-4 text-emerald-600" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground font-medium">عملاء بأرصدة دائنة</p>
            <p className="text-lg font-bold text-emerald-600">{creditCustomers}</p>
          </div>
        </div>
        <div className="px-6 py-4 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-red-500/10">
            <TrendingDown className="h-4 w-4 text-red-600" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground font-medium">عملاء بديون</p>
            <p className="text-lg font-bold text-red-600">{debtors}</p>
          </div>
        </div>
      </div>

      <CardHeader className="pb-4 border-b border-border/40 bg-secondary/10 flex flex-row justify-between items-center">
        <div>
          <CardTitle className="text-base font-bold text-foreground">قائمة العملاء</CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">إدارة بيانات العملاء والأرصدة</p>
        </div>
        <div className="text-xs font-semibold text-muted-foreground bg-background px-3 py-1.5 rounded-full border border-border/40 shadow-sm">
          صافي الأرصدة:{' '}
          <span className={totalBalance < 0 ? 'text-red-600' : totalBalance > 0 ? 'text-emerald-600' : ''}>
            {formatCurrency(totalBalance)}
          </span>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>الاسم الكامل</TableHead>
              <TableHead>رقم الهاتف</TableHead>
              <TableHead>النوع</TableHead>
              <TableHead>الحالة</TableHead>
              <TableHead className="text-right">الرصيد</TableHead>
              <TableHead className="text-center">الإجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {customers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-40 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-4 rounded-2xl bg-muted/50">
                      <Users className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">لا يوجد عملاء</p>
                      <p className="text-sm text-muted-foreground mt-1">قم بإضافة عميل جديد للبدء</p>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              customers.map((customer) => {
                const balance = customer.balance || 0;
                return (
                  <TableRow key={customer.id} className="group">
                    <TableCell className="font-semibold">
                      <Link
                        href={`/customers/${customer.id}`}
                        className="text-primary hover:text-primary/80 hover:underline transition-colors"
                      >
                        {customer.fullName}
                      </Link>
                    </TableCell>
                    <TableCell className="text-muted-foreground font-mono text-sm">{customer.phone}</TableCell>
                    <TableCell>
                      <Badge variant={customer.type === 'company' ? 'info' : 'secondary'}>
                        {customer.type === 'company' ? 'شركة' : 'فرد'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={customer.status === 'active' ? 'success' : 'destructive'}>
                        {customer.status === 'active' ? 'نشط' : 'غير نشط'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {balance < 0 ? (
                          <TrendingDown className="h-3.5 w-3.5 text-red-500" />
                        ) : balance > 0 ? (
                          <TrendingUp className="h-3.5 w-3.5 text-emerald-500" />
                        ) : (
                          <Minus className="h-3.5 w-3.5 text-muted-foreground" />
                        )}
                        <span className={`font-mono font-bold text-sm ${balance < 0 ? 'text-red-600' : balance > 0 ? 'text-emerald-600' : 'text-muted-foreground'}`}>
                          {formatCurrency(Math.abs(balance))}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            aria-haspopup="true"
                            size="icon"
                            variant="ghost"
                            className="rounded-full h-8 w-8 hover:bg-primary/5 hover:text-primary opacity-100 transition-all"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">فتح القائمة</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="rounded-xl shadow-lg border-border/50">
                          <DropdownMenuItem
                            onSelect={() => onEdit(customer)}
                            className="rounded-lg cursor-pointer"
                          >
                            <Pencil className="me-2 h-4 w-4 text-primary" />
                            تعديل البيانات
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onSelect={() => onDelete(customer.id)}
                            className="rounded-lg cursor-pointer text-destructive focus:text-destructive"
                          >
                            <Trash2 className="me-2 h-4 w-4" />
                            حذف العميل
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
