'use client';

import * as React from 'react';
import { PlusCircle, Search, Upload, Users, UserCheck, ShieldAlert, DollarSign, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/page-header';
import { CustomersTable } from './customers-table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { CustomerForm, type CustomerFormValues } from './customer-form';
import type { Customer } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { deleteCustomer, addCustomer, updateCustomer } from './actions';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableHead, TableHeader, TableRow, TableCell, TableBody } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface CustomersClientPageProps {
  initialCustomers: Customer[];
}

export default function CustomersClientPage({ initialCustomers }: CustomersClientPageProps) {
  const [isFormDialogOpen, setIsFormDialogOpen] = React.useState(false);
  const [isImportDialogOpen, setIsImportDialogOpen] = React.useState(false);
  const [editingCustomer, setEditingCustomer] = React.useState<Customer | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');
  
  const [typeFilter, setTypeFilter] = React.useState<string>('all');
  const [statusFilter, setStatusFilter] = React.useState<string>('all');
  const [debtFilter, setDebtFilter] = React.useState<string>('all');

  const { toast } = useToast();
  const router = useRouter();

  const formatCurrency = (amount: number) =>
    `${Math.round(amount).toLocaleString('en-US')} SDG`;

  const stats = React.useMemo(() => {
    const total = initialCustomers.length;
    const active = initialCustomers.filter(c => c.status === 'active').length;
    const debtors = initialCustomers.filter(c => (c.balance || 0) < 0).length;
    const totalDebt = initialCustomers.reduce((sum, c) => sum + (c.balance < 0 ? Math.abs(c.balance) : 0), 0);
    return { total, active, debtors, totalDebt };
  }, [initialCustomers]);

  const handleAdd = () => { setEditingCustomer(null); setIsFormDialogOpen(true); };
  const handleEdit = (customer: Customer) => { setEditingCustomer(customer); setIsFormDialogOpen(true); };

  const handleDelete = async (customerId: string) => {
    const result = await deleteCustomer(customerId);
    if (result.success) {
      toast({ title: 'تم الحذف بنجاح', description: result.message });
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'خطأ في الحذف', description: result.message });
    }
  };

  const handleFormSubmit = async (values: CustomerFormValues) => {
    const finalValues = { ...values, phone: values.phone ?? '' };
    const action = editingCustomer
      ? updateCustomer({ ...finalValues, id: editingCustomer.id, balance: editingCustomer.balance })
      : addCustomer(finalValues);

    const result = await action;

    if (result.success) {
      toast({ title: editingCustomer ? 'تم التحديث بنجاح' : 'تمت الإضافة بنجاح', description: result.message });
      setIsFormDialogOpen(false);
      setEditingCustomer(null);
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }
  };
  
  const handleImport = () => {
    toast({ title: 'قيد التطوير', description: 'سيتم إضافة ميزة الاستيراد قريبًا.' });
  };

  const filteredCustomers = React.useMemo(() => {
    return initialCustomers.filter((customer) => {
      const matchSearch =
        customer.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.phone.includes(searchTerm);
      
      const matchType = typeFilter === 'all' || customer.type === typeFilter;
      const matchStatus = statusFilter === 'all' || customer.status === statusFilter;
      
      let matchDebt = true;
      const bal = customer.balance || 0;
      if (debtFilter === 'debt') matchDebt = bal < 0;
      else if (debtFilter === 'credit') matchDebt = bal > 0;
      else if (debtFilter === 'zero') matchDebt = bal === 0;

      return matchSearch && matchType && matchStatus && matchDebt;
    });
  }, [initialCustomers, searchTerm, typeFilter, statusFilter, debtFilter]);

  const statCards = [
    { label: 'إجمالي العملاء', value: stats.total, icon: Users, color: 'text-primary', bg: 'bg-primary/8', border: 'border-primary/20' },
    { label: 'نشطون', value: stats.active, icon: UserCheck, color: 'text-emerald-600', bg: 'bg-emerald-500/8', border: 'border-emerald-500/20' },
    { label: 'عليهم مديونية', value: stats.debtors, icon: ShieldAlert, color: 'text-red-600', bg: 'bg-red-500/8', border: 'border-red-500/20' },
    { label: 'إجمالي المديونية', value: formatCurrency(stats.totalDebt), icon: DollarSign, color: 'text-amber-600', bg: 'bg-amber-500/8', border: 'border-amber-500/20' },
  ];

  const hasFilters = typeFilter !== 'all' || statusFilter !== 'all' || debtFilter !== 'all';

  return (
    <>
      <PageHeader title="إدارة العملاء">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
            <Input
              type="search"
              placeholder="بحث بالاسم أو الهاتف..."
              className="pr-9 w-[180px] lg:w-[240px] h-9 rounded-xl bg-background border-border/60 text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button onClick={() => setIsImportDialogOpen(true)} variant="outline" size="sm" className="h-9 rounded-xl gap-1.5">
            <Upload className="h-3.5 w-3.5" />
            استيراد
          </Button>
          <Button onClick={handleAdd} size="sm" className="h-9 rounded-xl gap-1.5 px-4 shadow-sm">
            <PlusCircle className="h-3.5 w-3.5" />
            إضافة عميل
          </Button>
        </div>
      </PageHeader>

      <div className="flex flex-col gap-4 p-4 md:p-6 max-w-screen-xl mx-auto w-full">

        {/* Compact Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {statCards.map((card, idx) => (
            <div key={idx} className={cn('rounded-xl border px-3 py-2.5 flex items-center gap-2.5 bg-card', card.border)}>
              <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center shrink-0', card.bg, card.color)}>
                <card.icon className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-muted-foreground font-medium leading-none mb-0.5 truncate">{card.label}</p>
                <p className="text-sm font-extrabold text-foreground leading-none truncate">{card.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Filter Strip */}
        <div className="flex flex-wrap items-center gap-2 bg-muted/20 px-4 py-2.5 rounded-xl border border-border/40">
          <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
          <span className="text-[11px] font-bold text-muted-foreground">تصفية:</span>

          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[130px] bg-background border-border/60 rounded-lg text-[11px] h-7 font-medium">
              <SelectValue placeholder="نوع العميل" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الأنواع</SelectItem>
              <SelectItem value="individual">أفراد</SelectItem>
              <SelectItem value="company">شركات</SelectItem>
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[130px] bg-background border-border/60 rounded-lg text-[11px] h-7 font-medium">
              <SelectValue placeholder="الحالة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الحالات</SelectItem>
              <SelectItem value="active">نشط</SelectItem>
              <SelectItem value="inactive">غير نشط</SelectItem>
            </SelectContent>
          </Select>

          <Select value={debtFilter} onValueChange={setDebtFilter}>
            <SelectTrigger className="w-[140px] bg-background border-border/60 rounded-lg text-[11px] h-7 font-medium">
              <SelectValue placeholder="حالة الرصيد" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الأرصدة</SelectItem>
              <SelectItem value="debt">عليهم مديونية</SelectItem>
              <SelectItem value="credit">رصيد دائن</SelectItem>
              <SelectItem value="zero">رصيد صفر</SelectItem>
            </SelectContent>
          </Select>

          {hasFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => { setTypeFilter('all'); setStatusFilter('all'); setDebtFilter('all'); }}
              className="h-7 text-[11px] font-medium text-red-600 hover:text-red-700 rounded-lg px-2"
            >
              تصفير
            </Button>
          )}

          <span className="text-[10px] text-muted-foreground bg-background px-2 py-0.5 rounded-full font-medium border border-border/40 ml-auto">
            {filteredCustomers.length} عميل
          </span>
        </div>

        <CustomersTable
          customers={filteredCustomers}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      </div>

      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl">
          <CustomerForm
            customer={editingCustomer}
            onSubmit={handleFormSubmit}
            onCancel={() => setIsFormDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
        <DialogContent className="sm:max-w-[700px] rounded-2xl">
          <DialogHeader>
            <DialogTitle>استيراد العملاء من ملف Excel</DialogTitle>
            <DialogDescription>
              قم بإعداد ملف Excel الخاص بك بالتنسيق المطلوب ثم قم برفعه هنا.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="rounded-xl border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/30">
                    <TableHead className="text-xs">fullName (مطلوب)</TableHead>
                    <TableHead className="text-xs">phone (مطلوب)</TableHead>
                    <TableHead className="text-xs">address</TableHead>
                    <TableHead className="text-xs">idNumber</TableHead>
                    <TableHead className="text-xs">type (مطلوب)</TableHead>
                    <TableHead className="text-xs">status (مطلوب)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="text-xs">أحمد محمد علي</TableCell>
                    <TableCell className="text-xs">0912345678</TableCell>
                    <TableCell className="text-xs">الخرطوم</TableCell>
                    <TableCell className="text-xs">123456789</TableCell>
                    <TableCell className="text-xs">individual</TableCell>
                    <TableCell className="text-xs">active</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
            <p className="text-xs text-muted-foreground">
              ملاحظة: `type` = individual أو company · `status` = active أو inactive
            </p>
            <div>
              <Label htmlFor="import-file" className="sr-only">اختر ملف</Label>
              <Input id="import-file" type="file" accept=".xlsx, .xls" className="rounded-xl text-sm" />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" className="rounded-xl" onClick={() => setIsImportDialogOpen(false)}>إلغاء</Button>
            <Button className="rounded-xl" onClick={handleImport}>بدء الاستيراد</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
