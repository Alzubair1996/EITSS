
'use server';

import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import type { Customer } from '@/lib/types';
import { randomUUID } from 'crypto';

export async function addCustomer(customerData: Omit<Customer, 'id' | 'balance'>) {
    try {
        const db = await getDbInstance();
        
        if (customerData.phone) {
            const existing = await db.get('SELECT id FROM customers WHERE phone = ?', customerData.phone);
            if (existing) {
                return { success: false, message: 'عميل بنفس رقم الهاتف موجود بالفعل.' };
            }
        }

        const newId = `cust_${randomUUID()}`;
        await db.run(`
            INSERT INTO customers (id, fullName, phone, address, idNumber, type, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `, newId, customerData.fullName, customerData.phone || null, customerData.address, customerData.idNumber, customerData.type, customerData.status);
        
        revalidatePath('/customers');
        return { success: true, message: 'تمت إضافة العميل بنجاح' };
    } catch (e: any) {
        console.error(e);
        if (e.code === 'SQLITE_CONSTRAINT') {
             return { success: false, message: 'عميل بنفس رقم الهاتف أو الرقم التعريفي موجود بالفعل.' };
        }
        return { success: false, message: 'خطأ في قاعدة البيانات: فشلت إضافة العميل' };
    }
}

export async function updateCustomer(customerData: Customer) {
     try {
        const db = await getDbInstance();
         if (customerData.phone) {
            const existing = await db.get('SELECT id FROM customers WHERE phone = ? AND id != ?', customerData.phone, customerData.id);
            if (existing) {
                return { success: false, message: 'عميل آخر بنفس رقم الهاتف موجود بالفعل.' };
            }
        }

        await db.run(`
            UPDATE customers
            SET fullName = ?, phone = ?, address = ?, idNumber = ?, type = ?, status = ?
            WHERE id = ?
        `, customerData.fullName, customerData.phone || null, customerData.address, customerData.idNumber, customerData.type, customerData.status, customerData.id);
        
        revalidatePath('/customers');
        return { success: true, message: 'تم تحديث العميل بنجاح' };
    } catch (e: any) {
        console.error(e);
        if (e.code === 'SQLITE_CONSTRAINT') {
             return { success: false, message: 'عميل بنفس رقم الهاتف أو الرقم التعريفي موجود بالفعل.' };
        }
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل تحديث العميل' };
    }
}

export async function deleteCustomer(id: string) {
    try {
        const db = await getDbInstance();
        // Here you might want to check if the customer has any invoices before deleting.
        // For now, we will delete directly.
        await db.run('DELETE FROM customers WHERE id = ?', id);
        revalidatePath('/customers');
        return { success: true, message: 'تم حذف العميل.' };
    } catch (e) {
        console.error(e);
        return { success: false, message: 'خطأ في قاعدة البيانات: فشل حذف العميل.' };
    }
}

