'use server';
import { revalidatePath } from 'next/cache';
import { getDbInstance } from '@/lib/db';
import { randomUUID } from 'crypto';
import { getSession } from '@/lib/server-auth';
import type { Invoice } from '@/lib/types';


export async function makePaymentForInvoice(invoiceId: string, amount: number, paymentMethodId: string) {
    if (!invoiceId || !paymentMethodId || !amount || amount <= 0) {
        return { success: false, message: 'بيانات الدفعة غير صحيحة.' };
    }
    const db = await getDbInstance();
    // Determine which user is making this payment so it can be recorded for auditing
    const session = await getSession();
    const userId = session?.userId || null;
    try {
        await db.exec('BEGIN');

        const invoice = await db.get('SELECT * FROM invoices WHERE id = ?', invoiceId) as Invoice;
        if (!invoice) {
            throw new Error('الفاتورة غير موجودة.');
        }

        const remainingBalance = invoice.totalAmount - invoice.amountPaid;
        if (amount > remainingBalance + 0.001) {
             throw new Error('المبلغ المدفوع أكبر من المبلغ المتبقي.');
        }
        
        if (!invoice.customerId) {
            throw new Error('لا يمكن تسديد دفعة لفاتورة غير مرتبطة بعميل.');
        }

        const paymentDate = new Date().toISOString();

        // 1. Add to payments table with user attribution
        await db.run(
            'INSERT INTO payments (id, invoiceId, paymentMethodId, amount, paymentDate, userId) VALUES (?, ?, ?, ?, ?, ?)',
            `paym_${randomUUID()}`,
            invoiceId,
            paymentMethodId,
            amount,
            paymentDate,
            userId
        );
        
        // 2. Update payment method balance
        await db.run('UPDATE payment_methods SET balance = balance + ? WHERE id = ?', amount, paymentMethodId);

        // 3. Update invoice amount paid and status
        const newAmountPaid = invoice.amountPaid + amount;
        let newStatus = invoice.status;
        if (newAmountPaid >= invoice.totalAmount - 0.001) {
            newStatus = 'paid';
        } else {
            newStatus = 'partial';
        }
        await db.run('UPDATE invoices SET amountPaid = ?, status = ? WHERE id = ?', newAmountPaid, newStatus, invoiceId);
        
        // 4. Update customer balance (reduce debt)
        await db.run('UPDATE customers SET balance = balance + ? WHERE id = ?', amount, invoice.customerId);

        await db.exec('COMMIT');
        
        revalidatePath(`/customers/${invoice.customerId}`);
        revalidatePath('/customers');
        revalidatePath('/invoices');
        revalidatePath('/reports');
        revalidatePath('/transactions');
        revalidatePath('/');

        return { success: true, message: 'تم تسجيل الدفعة بنجاح.' };

    } catch(e: any) {
        await db.exec('ROLLBACK');
        console.error('Failed to make payment for invoice:', e);
        return { success: false, message: e.message || 'فشل تسجيل الدفعة.' };
    }
}
