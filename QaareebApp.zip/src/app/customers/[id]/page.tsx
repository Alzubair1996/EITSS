import { getCustomerDetails, getPaymentMethods } from '@/lib/queries';
import { notFound } from 'next/navigation';
import CustomerDetailsClientPage from './customer-details-client';
import { PageHeader } from '@/components/page-header';
import { getSession } from '@/lib/server-auth';

export default async function CustomerDetailsPage({ params }: { params: { id: string } }) {
  const customerDetails = await getCustomerDetails(params.id);
  const paymentMethods = await getPaymentMethods();
  const session = await getSession();
  const isAdmin = session?.username === 'admin';

  if (!customerDetails) {
    notFound();
  }

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <PageHeader title={customerDetails.fullName} />
        <CustomerDetailsClientPage 
            customerDetails={customerDetails} 
            paymentMethods={paymentMethods} 
            isAdmin={isAdmin}
        />
      </div>
  );
}
