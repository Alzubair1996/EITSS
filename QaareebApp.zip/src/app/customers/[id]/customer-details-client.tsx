'use client';

import * as React from 'react';
import type { CustomerDetails, Invoice, PaymentMethod, PaymentDetails } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { useToast } from '@/hooks/use-toast';
import { makePaymentForInvoice } from './actions';
import { createSalesReturn, deleteSalesReturn, getInvoiceDetailsAction } from '@/app/sales-returns/actions';
import { format } from 'date-fns';
import { useRouter } from 'next/navigation';
import { User, Phone, MapPin, Hash, DollarSign, LoaderCircle, HandCoins, RotateCcw, Trash2 } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

interface CustomerDetailsClientPageProps {
  customerDetails: CustomerDetails;
  paymentMethods: PaymentMethod[];
  isAdmin: boolean;
}

type DialogMode = 'payment' | 'returnItems';

type CartItem = {
  id: string;
  productId: string;
  name: string;
  quantity: number | string;
  maxQuantity: number;
  price: number;
  originalItemId: string;
};

function FormattedDate({ dateString }: { dateString: string }) {
    const [formattedDate, setFormattedDate] = React.useState('');
    React.useEffect(() => {
        setFormattedDate(format(new Date(dateString), 'dd/MM/yyyy HH:mm'));
    }, [dateString]);
    return <>{formattedDate}</>;
}

export default function CustomerDetailsClientPage({ customerDetails, paymentMethods, isAdmin }: CustomerDetailsClientPageProps) {
  const { toast } = useToast();
  const router = useRouter();

  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [dialogMode, setDialogMode] = React.useState<DialogMode | null>(null);

  const [selectedInvoice, setSelectedInvoice] = React.useState<Invoice | null>(null);
  const [paymentAmount, setPaymentAmount] = React.useState<number | string>('');
  
  const [selectedPaymentMethodId, setSelectedPaymentMethodId] = React.useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  // Return dialog state
  const [selectedInvoiceId, setSelectedInvoiceId] = React.useState<string>('');
  const [invoiceItems, setInvoiceItems] = React.useState<any[]>([]);
  const [cart, setCart] = React.useState<CartItem[]>([]);
  const [reason, setReason] = React.useState('');
  const [loadingInvoice, setLoadingInvoice] = React.useState(false);

  const formatCurrency = (amount: number) => {
    return `${Math.round(amount).toLocaleString('en-US')} SDG`;
  };

  const getInvoiceRemainingAmount = React.useCallback((invoice: Invoice) => {
    if (!invoice) return 0;
    const invoiceReturns = customerDetails.salesReturns?.filter(ret => ret.invoiceId === invoice.id) || [];
    const totalReturnedForInvoice = invoiceReturns.reduce((sum, ret) => sum + ret.totalAmount, 0);
    return Math.max(0, invoice.totalAmount - invoice.amountPaid - totalReturnedForInvoice);
  }, [customerDetails.salesReturns]);

  const handleMakePaymentClick = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    const remaining = getInvoiceRemainingAmount(invoice);
    setPaymentAmount(remaining);
    setSelectedPaymentMethodId(paymentMethods[0]?.id || null);
    setDialogMode('payment');
    setDialogOpen(true);
  }

  const handleMakeInvoiceReturnClick = (invoice: Invoice) => {
    setSelectedInvoiceId(invoice.id);
    setInvoiceItems([]);
    setCart([]);
    setReason('');
    setDialogMode('returnItems');
    setDialogOpen(true);
  }

  React.useEffect(() => {
    if (dialogMode === 'returnItems' && selectedInvoiceId) {
      async function loadInvoiceDetails() {
        setLoadingInvoice(true);
        try {
          const result = await getInvoiceDetailsAction(selectedInvoiceId);
          if (result.success && result.items) {
            setInvoiceItems(result.items);
          } else {
            toast({
              variant: 'destructive',
              title: 'خطأ',
              description: result.message || 'فشل تحميل فاتورة المبيعات.',
            });
          }
        } catch (error) {
          console.error('Failed to load invoice details:', error);
          toast({
            variant: 'destructive',
            title: 'خطأ',
            description: 'فشل تحميل فاتورة المبيعات.',
          });
        }
        setLoadingInvoice(false);
      }
      loadInvoiceDetails();
    }
  }, [dialogMode, selectedInvoiceId, toast]);

  React.useEffect(() => {
    if (!dialogOpen) {
      setDialogMode(null);
      setSelectedInvoiceId('');
      setInvoiceItems([]);
      setCart([]);
      setReason('');
      setSelectedInvoice(null);
      setPaymentAmount('');
    }
  }, [dialogOpen]);

  const handleAddItem = (item: any) => {
    setCart(prev => [
      ...prev,
      {
        id: item.productId,
        productId: item.productId,
        name: item.productName || '—',
        quantity: item.remainingQuantity || 1,
        maxQuantity: item.remainingQuantity || 1,
        price: item.unitPrice,
        originalItemId: item.id
      }
    ]);
  };

  const handleRemoveItem = (originalItemId: string) => {
    setCart(prev => prev.filter(item => item.originalItemId !== originalItemId));
  };

  const handleQuantityChange = (originalItemId: string, value: string) => {
    setCart(prev => prev.map(item => {
      if (item.originalItemId === originalItemId) {
        const numVal = Number(value);
        if (isNaN(numVal) || numVal < 0) return { ...item, quantity: '' };
        return { ...item, quantity: Math.min(item.maxQuantity, numVal) };
      }
      return item;
    }));
  };

  const handleConfirmPayment = async () => {
    if (dialogMode === 'payment' && selectedInvoice) {
      if (!selectedPaymentMethodId) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى اختيار طريقة الدفع.' });
        return;
      }
      
      const numericPaymentAmount = Number(paymentAmount);
      if (isNaN(numericPaymentAmount) || numericPaymentAmount <= 0) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'مبلغ الدفع يجب أن يكون أكبر من صفر.' });
        return;
      }

      const remaining = getInvoiceRemainingAmount(selectedInvoice);
      if (numericPaymentAmount > remaining + 0.001) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'المبلغ المدفوع أكبر من المبلغ المتبقي للفاتورة.' });
        return;
      }

      setIsSubmitting(true);
      const result = await makePaymentForInvoice(selectedInvoice.id, numericPaymentAmount, selectedPaymentMethodId);
      setIsSubmitting(false);

      if (result.success) {
        toast({ title: 'نجاح', description: result.message });
        setDialogOpen(false);
        setSelectedInvoice(null);
        router.refresh();
      } else {
        toast({ variant: 'destructive', title: 'فشل', description: result.message });
      }
    } else if (dialogMode === 'returnItems') {
      const returnItems = cart.map(item => ({
        productId: item.productId,
        quantity: Number(item.quantity) || 0,
        price: item.price
      })).filter(item => item.quantity > 0);

      if (returnItems.length === 0) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'يرجى إدخال كمية صحيحة لأصناف المرتجع.' });
        return;
      }

      if (!reason.trim()) {
        toast({ variant: 'destructive', title: 'خطأ', description: 'سبب الإرجاع مطلوب.' });
        return;
      }

      setIsSubmitting(true);
      const result = await createSalesReturn({
        invoiceId: selectedInvoiceId,
        reason,
        items: returnItems
      });
      setIsSubmitting(false);

      if (result.success) {
        toast({ title: 'نجاح', description: result.message });
        setDialogOpen(false);
        router.refresh();
      } else {
        toast({ variant: 'destructive', title: 'خطأ', description: result.message });
      }
    }
  };

  const handleDeleteReturn = async (returnId: string) => {
    if (!confirm('هل أنت متأكد من رغبتك في حذف هذا المرتجع؟ سيتم استرجاع كميات المخزون وتعديل حساب العميل.')) {
      return;
    }
    
    setIsSubmitting(true);
    const result = await deleteSalesReturn(returnId);
    setIsSubmitting(false);
    
    if (result.success) {
      toast({ title: 'نجاح', description: result.message });
      router.refresh();
    } else {
      toast({ variant: 'destructive', title: 'خطأ', description: result.message });
    }
  };

  const invoiceStatusMap: { [key: string]: { text: string; variant: 'default' | 'outline' | 'secondary' | 'destructive' } } = {
    paid: { text: 'مدفوعة', variant: 'secondary' },
    partial: { text: 'مدفوعة جزئياً', variant: 'outline' },
    unpaid: { text: 'غير مدفوعة', variant: 'destructive' },
    cancelled: { text: 'ملغاة', variant: 'outline' },
  };

  const renderDialogContent = () => {
    if (dialogMode === 'payment' && selectedInvoice) {
       const remainingBalance = getInvoiceRemainingAmount(selectedInvoice);
        return (
         <>
          <DialogHeader>
            <DialogTitle>تسديد دفعة لفاتورة</DialogTitle>
            <DialogDescription>
              الفاتورة رقم #{selectedInvoice.invoiceNumber}. المبلغ المتبقي: {formatCurrency(remainingBalance)}.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div>
              <Label htmlFor="paymentAmount">المبلغ المدفوع</Label>
              <Input
                id="paymentAmount"
                type="number"
                value={paymentAmount}
                onChange={(e) => {
                  const value = e.target.value;
                  setPaymentAmount(value);
                }}
                max={remainingBalance}
              />
            </div>
            <div>
              <Label htmlFor="paymentMethodPay">اختر طريقة الدفع</Label>
              <Select onValueChange={setSelectedPaymentMethodId} value={selectedPaymentMethodId || undefined}>
                <SelectTrigger id="paymentMethodPay">
                  <SelectValue placeholder="اختر الحساب..." />
                </SelectTrigger>
                <SelectContent>
                  {paymentMethods.map(pm => (
                    <SelectItem key={pm.id} value={pm.id}>{pm.name}{isAdmin && ` (الرصيد: ${formatCurrency(pm.balance)})`}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
         </>
      )
    }

    if (dialogMode === 'returnItems') {
      const totalAmount = cart.reduce((sum, item) => sum + (Number(item.quantity) || 0) * item.price, 0);

      return (
        <>
          <DialogHeader>
            <DialogTitle>إرجاع بضاعة من عميل</DialogTitle>
            <DialogDescription>
              قم بإرجاع أصناف وكميات محددة من الفاتورة إلى المخزن.
            </DialogDescription>
          </DialogHeader>

          <div className="py-4 space-y-4">
            {loadingInvoice && (
              <div className="flex items-center justify-center p-8">
                <LoaderCircle className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            )}

            {!loadingInvoice && invoiceItems.length > 0 && (
              <div className="space-y-4">
                <div>
                  <Label>أصناف الفاتورة</Label>
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>المنتج</TableHead>
                          <TableHead className="text-center">الكمية المباعة</TableHead>
                          <TableHead className="text-center">سعر البيع</TableHead>
                          <TableHead className="text-center">الإجراء</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {invoiceItems.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">
                              {item.productName || item.productId || '—'}
                            </TableCell>
                            <TableCell className="text-center">
                              <span className="font-semibold">{item.quantity}</span>
                              {item.returnedQuantity !== undefined && item.returnedQuantity > 0 && (
                                <div className="text-xs text-amber-600 dark:text-amber-500 font-medium mt-1">
                                  (المتبقي: {item.remainingQuantity} | تم إرجاع: {item.returnedQuantity})
                                </div>
                              )}
                            </TableCell>
                            <TableCell className="text-center">{Math.round(item.unitPrice).toLocaleString('en-US')} SDG</TableCell>
                            <TableCell className="text-center">
                              {cart.findIndex(cartItem => cartItem.originalItemId === item.id) < 0 ? (
                                item.remainingQuantity !== undefined && item.remainingQuantity <= 0 ? (
                                  <span className="text-xs text-muted-foreground font-semibold">تم إرجاعها بالكامل</span>
                                ) : (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleAddItem(item)}
                                  >
                                    إضافة للإرجاع
                                  </Button>
                                )
                              ) : (
                                <span className="text-green-600 font-semibold text-sm">أضيف للإرجاع</span>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
            )}

            {cart.length > 0 && (
              <div className="space-y-4">
                <div>
                  <Label>الأصناف المراد إرجاعها</Label>
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>المنتج</TableHead>
                          <TableHead className="text-center">الكمية المرتجعة</TableHead>
                          <TableHead className="text-center">سعر البيع</TableHead>
                          <TableHead className="text-center">الإجمالي</TableHead>
                          <TableHead className="text-center">الإجراء</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {cart.map((item) => (
                          <TableRow key={item.originalItemId}>
                            <TableCell className="font-medium">{item.name}</TableCell>
                            <TableCell className="text-center">
                              <Input
                                type="number"
                                min="0"
                                max={item.maxQuantity}
                                value={item.quantity}
                                onChange={(e) => handleQuantityChange(item.originalItemId, e.target.value)}
                                className="w-24 mx-auto text-center font-bold"
                              />
                            </TableCell>
                            <TableCell className="text-center">{Math.round(item.price).toLocaleString('en-US')} SDG</TableCell>
                            <TableCell className="text-center">{Math.round((Number(item.quantity) || 0) * item.price).toLocaleString('en-US')} SDG</TableCell>
                            <TableCell className="text-center">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleRemoveItem(item.originalItemId)}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>

                <div className="flex justify-end items-center gap-4 p-4 bg-muted rounded-lg">
                  <div className="text-lg font-semibold">
                    إجمالي قيمة المرتجع: {Math.round(totalAmount).toLocaleString('en-US')} SDG
                  </div>
                </div>

                <div>
                  <Label>سبب الإرجاع <span className="text-destructive">*</span></Label>
                  <Textarea
                    placeholder="اذكر سبب الإرجاع..."
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    rows={3}
                  />
                </div>
              </div>
            )}
          </div>
        </>
      );
    }

    return null;
  };

  const PaymentsHistoryTable = ({ payments }: { payments: PaymentDetails[] }) => (
    <div className="my-4">
        <h4 className="font-semibold text-sm mb-2">سجل الدفعات</h4>
        <Table>
            <TableHeader>
                <TableRow>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>طريقة الدفع</TableHead>
                    <TableHead className="text-right">المبلغ</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {payments.length > 0 ? (
                    payments.map(payment => (
                        <TableRow key={payment.id}>
                            <TableCell><FormattedDate dateString={payment.paymentDate} /></TableCell>
                            <TableCell>{payment.paymentMethodName}</TableCell>
                            <TableCell className="text-right font-semibold">{formatCurrency(payment.amount)}</TableCell>
                        </TableRow>
                    ))
                ) : (
                    <TableRow>
                        <TableCell colSpan={3} className="text-center text-muted-foreground">
                            لا توجد دفعات مسجلة لهذه الفاتورة.
                        </TableCell>
                    </TableRow>
                )}
            </TableBody>
        </Table>
    </div>
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>معلومات العميل</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-2"><User className="w-4 h-4 text-muted-foreground" /><strong>الاسم:</strong> {customerDetails.fullName}</div>
            <div className="flex items-center gap-2"><Phone className="w-4 h-4 text-muted-foreground" /><strong>الهاتف:</strong> {customerDetails.phone}</div>
            <div className="flex items-center gap-2"><MapPin className="w-4 h-4 text-muted-foreground" /><strong>العنوان:</strong> {customerDetails.address || 'غير محدد'}</div>
            <div className="flex items-center gap-2"><Hash className="w-4 h-4 text-muted-foreground" /><strong>الرقم التعريفي:</strong> {customerDetails.idNumber || 'غير محدد'}</div>
            <div className="flex items-center gap-2"><DollarSign className="w-4 h-4 text-muted-foreground" /><strong>الرصيد (الدين):</strong> <span className={customerDetails.balance < 0 ? 'text-destructive font-bold' : 'font-bold'}>{formatCurrency(customerDetails.balance)}</span></div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>كشف حساب الفواتير</CardTitle>
        </CardHeader>
        <CardContent>
          {customerDetails.invoices.length > 0 ? (
            <Accordion type="multiple" className="w-full">
              {customerDetails.invoices.map((invoice) => {
                const remaining = getInvoiceRemainingAmount(invoice);
                return (
                  <AccordionItem value={invoice.id} key={invoice.id}>
                    <AccordionTrigger>
                      <div className="flex justify-between items-center w-full pe-4">
                        <div className="flex flex-col text-right items-start">
                          <span>فاتورة #{invoice.invoiceNumber} - بتاريخ <FormattedDate dateString={invoice.issueDate} /></span>
                           <Badge variant={invoiceStatusMap[invoice.status]?.variant || 'default'} className="mt-1">
                            {invoiceStatusMap[invoice.status]?.text || invoice.status}
                          </Badge>
                        </div>
                        <div className="flex flex-col text-left items-end">
                          <span className="font-semibold">{formatCurrency(invoice.totalAmount)}</span>
                          {invoice.status !== 'paid' && (
                            <span className="text-xs text-destructive">المتبقي: {formatCurrency(remaining)}</span>
                          )}
                        </div>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                        <div className="text-center py-4 px-2">
                           <p className="text-muted-foreground font-semibold text-xs mb-3">فاتورة بيع مباشر.</p>
                           <div className="flex gap-2 justify-center mb-4">
                             {invoice.status !== 'paid' && invoice.status !== 'cancelled' && (
                               <Button onClick={() => handleMakePaymentClick(invoice)} size="sm">
                                 <HandCoins className="w-4 h-4 me-1" />
                                 تسديد دفعة
                               </Button>
                             )}
                             {invoice.status !== 'cancelled' && (
                               <Button onClick={() => handleMakeInvoiceReturnClick(invoice)} variant="outline" size="sm">
                                 <RotateCcw className="w-4 h-4 me-1 text-destructive" />
                                 إرجاع أصناف
                               </Button>
                             )}
                           </div>
                           <PaymentsHistoryTable payments={invoice.payments} />
                        </div>
                    </AccordionContent>
                  </AccordionItem>
                )
              })}
            </Accordion>
          ) : (
            <p className="text-muted-foreground text-center py-8">لا توجد فواتير لهذا العميل.</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>مرتجعات المبيعات</CardTitle>
              <CardDescription>سجل عمليات إرجاع البضائع المخصومة من مستحقات العميل.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {customerDetails.salesReturns && customerDetails.salesReturns.length > 0 ? (
            <div className="space-y-3">
              {customerDetails.salesReturns.map((return_) => (
                <div key={return_.id} className="border rounded-lg overflow-hidden">
                  <div className="flex justify-between items-center p-3 bg-muted/50">
                    <div className="flex flex-col">
                      <span className="font-medium">
                        {return_.returnNumber || 'بدون رقم'} - بتاريخ <FormattedDate dateString={return_.returnDate} />
                      </span>
                      {return_.invoiceNumber && (
                        <span className="text-xs text-muted-foreground mt-1">فاتورة: {return_.invoiceNumber}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-semibold">{formatCurrency(return_.totalAmount)}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDeleteReturn(return_.id)}
                        disabled={isSubmitting}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                  {return_.items && return_.items.length > 0 && (
                    <div className="p-3 border-t">
                      <div className="space-y-2">
                        {return_.items.map((item, idx) => (
                          <div key={item.id || idx} className="flex justify-between items-center text-sm">
                            <span className="text-muted-foreground">
                              {item.productName || 'منتج غير محدد'}
                            </span>
                            <span className="font-medium">
                              {item.quantity} × {Math.round(item.price).toLocaleString('en-US')} SDG
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {return_.reason && (
                    <div className="px-3 pb-3 pt-2 border-t">
                      <span className="text-xs text-muted-foreground">سبب الإرجاع: {return_.reason}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">لا توجد مرتجعات مسجلة لهذا العميل.</p>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className={`max-h-[90vh] overflow-y-auto ${dialogMode === 'returnItems' ? 'max-w-3xl' : 'max-w-lg'}`}>
          {renderDialogContent()}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button 
              onClick={handleConfirmPayment} 
              disabled={isSubmitting || (dialogMode === 'returnItems' && (!reason.trim() || cart.length === 0))}
            >
              {isSubmitting && <LoaderCircle className="me-2 h-4 w-4 animate-spin" />}
              تأكيد
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
