import CustomersClientPage from './customers-client-page';
import { getCustomers } from '@/lib/queries';

export default async function CustomersPage() {
  const initialCustomers = await getCustomers();

  return (
      <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <CustomersClientPage initialCustomers={initialCustomers} />
      </div>
  );
}
