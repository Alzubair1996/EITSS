
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import type { Customer } from '@/lib/types';

const formSchema = z.object({
  fullName: z.string().min(2, { message: 'الاسم الكامل مطلوب' }),
  phone: z.string().optional(),
  address: z.string().optional(),
  idNumber: z.string().optional(),
  type: z.enum(['individual', 'company'], {
    required_error: 'نوع العميل مطلوب',
  }),
  status: z.enum(['active', 'inactive'], {
    required_error: 'حالة العميل مطلوبة',
  }),
});

export type CustomerFormValues = z.infer<typeof formSchema>;

interface CustomerFormProps {
  customer: Customer | null;
  onSubmit: (values: CustomerFormValues) => void;
  onCancel: () => void;
}

export function CustomerForm({ customer, onSubmit, onCancel }: CustomerFormProps) {
  const form = useForm<CustomerFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: customer?.fullName || '',
      phone: customer?.phone || '',
      address: customer?.address || '',
      idNumber: customer?.idNumber || '',
      type: customer?.type || 'individual',
      status: customer?.status || 'active',
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <DialogHeader>
          <DialogTitle>
            {customer ? 'تعديل بيانات العميل' : 'إضافة عميل جديد'}
          </DialogTitle>
          <DialogDescription>
            {customer ? 'قم بتعديل بيانات العميل.' : 'أدخل بيانات العميل الجديد.'}
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[70vh] overflow-y-auto pr-2">
          <FormField
            control={form.control}
            name="fullName"
            render={({ field }) => (
              <FormItem className="md:col-span-2">
                <FormLabel>الاسم الكامل</FormLabel>
                <FormControl>
                  <Input placeholder="مثال: أحمد محمد" {...field} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>رقم الهاتف (اختياري)</FormLabel>
                <FormControl>
                  <Input placeholder="مثال: 0912345678" {...field} value={field.value ?? ''} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="idNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>الرقم التعريفي (اختياري)</FormLabel>
                <FormControl>
                  <Input placeholder="رقم الهوية / جواز السفر" {...field} value={field.value ?? ''} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="address"
            render={({ field }) => (
              <FormItem className="md:col-span-2">
                <FormLabel>العنوان (اختياري)</FormLabel>
                <FormControl>
                  <Input placeholder="المدينة، الحي، الشارع" {...field} value={field.value ?? ''} className="text-right" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem className="space-y-3">
                <FormLabel>نوع العميل</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="flex space-x-4 space-x-reverse"
                  >
                    <FormItem className="flex items-center space-x-2 space-x-reverse">
                      <FormControl>
                        <RadioGroupItem value="individual" id="individual" />
                      </FormControl>
                      <FormLabel htmlFor="individual" className="font-normal">
                        فرد
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-2 space-x-reverse">
                      <FormControl>
                        <RadioGroupItem value="company" id="company" />
                      </FormControl>
                      <FormLabel htmlFor="company" className="font-normal">
                        شركة
                      </FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem className="space-y-3">
                <FormLabel>حالة العميل</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="flex space-x-4 space-x-reverse"
                  >
                    <FormItem className="flex items-center space-x-2 space-x-reverse">
                      <FormControl>
                        <RadioGroupItem value="active" id="active" />
                      </FormControl>
                      <FormLabel htmlFor="active" className="font-normal">
                        نشط
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-2 space-x-reverse">
                      <FormControl>
                        <RadioGroupItem value="inactive" id="inactive" />
                      </FormControl>
                      <FormLabel htmlFor="inactive" className="font-normal">
                        غير نشط
                      </FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <DialogFooter className="pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            إلغاء
          </Button>
          <Button type="submit">
            {customer ? 'حفظ التغييرات' : 'إضافة عميل'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}
