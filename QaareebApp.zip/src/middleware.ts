
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { jwtVerify } from 'jose';

// Secret used to decrypt/verify session cookies. This must match the secret used in auth.ts.
const secretKey = process.env.SESSION_SECRET || 'your-fallback-secret-key-that-is-long-and-secure';
const key = new TextEncoder().encode(secretKey);

// The middleware is now simplified to its core responsibility:
// protecting routes and handling basic path management, NOT database access.
export async function middleware(request: NextRequest) {
    const { pathname } = request.nextUrl;

    const requestHeaders = new Headers(request.headers);
    requestHeaders.set('x-pathname', pathname);

    // Public pages that are always allowed.
    // Added /login here so unauthenticated users can access the login page
    const publicPaths = ['/activation', '/setup', '/login'];

    // Allow all API routes, static files, and image optimization routes.
    if (pathname.startsWith('/api') || pathname.startsWith('/_next') || pathname.match(/\.(woff|woff2|ttf|eot|svg|png|jpg|jpeg|ico)$/)) {
        return NextResponse.next({
            request: {
                headers: requestHeaders,
            }
        });
    }

    // Allow any public paths without further checks
    if (publicPaths.some(p => pathname.startsWith(p))) {
        return NextResponse.next({
            request: {
                headers: requestHeaders,
            }
        });
    }

    // Validate the session cookie. If it's missing or invalid/expired, redirect to login.
    const sessionCookie = request.cookies.get('session')?.value;
    if (!sessionCookie) {
        return NextResponse.redirect(new URL('/login', request.url));
    }
    try {
        // Attempt to verify and decode the JWT. jwtVerify will throw if the signature is invalid or expired.
        await jwtVerify(sessionCookie, key, { algorithms: ['HS256'] });
    } catch (e) {
        return NextResponse.redirect(new URL('/login', request.url));
    }
    
    // If the database has been restored via Tauri, the app needs to restart.
    // The frontend will set a cookie or query param that we can check here.
    // This is a placeholder for that logic if needed in the future.

    // All other logic (activation, setup checks) is now handled in the RootLayout's AuthWrapper
    // This is safer because it runs within the React render cycle and can be caught by error boundaries.
    return NextResponse.next({
        request: {
            headers: requestHeaders,
        }
    });
}

export const config = {
  matcher: [
    // This matcher ensures the middleware runs on all paths except for a few Next.js specific ones.
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
}
