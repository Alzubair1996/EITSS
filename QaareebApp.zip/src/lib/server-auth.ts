

'use server'

import { randomBytes, pbkdf2Sync } from 'crypto';
import { cookies } from 'next/headers';
import { decrypt } from './auth';
import type { NextRequest } from 'next/server';

export async function hashPassword(password: string): Promise<string> {
    const salt = randomBytes(16).toString('hex');
    const hash = pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
    return `${salt}:${hash}`;
}

export async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
    if (!storedHash.includes(':')) {
        if (password === storedHash) {
            console.warn("Warning: Plaintext password matched. Please ensure all passwords are migrated to a hashed format.");
            return true;
        }
        return false;
    }
    const [salt, hash] = storedHash.split(':');
    const hashToVerify = pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
    return hash === hashToVerify;
}


// This function is for SERVER COMPONENTS
export async function getSession(req?: NextRequest) {
  let sessionCookie;
  if (req) {
    // For middleware
    sessionCookie = req.cookies.get('session')?.value;
  } else {
    // For Server Components
    sessionCookie = cookies().get('session')?.value
  }

  if (!sessionCookie) return null

  try {
    const session = await decrypt(sessionCookie);
    if (!session || new Date(session.expires) < new Date()) {
      return null;
    }
    return session;
  } catch (e) {
    console.error("Failed to decrypt session in getSession:", e);
    return null;
  }
}
