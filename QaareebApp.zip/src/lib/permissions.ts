
import { getDbInstance } from './db';

export const PERMISSIONS = {
    VIEW_DASHBOARD: { key: 'view_dashboard', label: 'عرض لوحة التحكم' },
    MANAGE_INVOICES: { key: 'manage_invoices', label: 'إدارة الفواتير' },
    MANAGE_PURCHASES: { key: 'manage_purchases', label: 'إدارة المشتريات' },
    MANAGE_INVENTORY: { key: 'manage_inventory', label: 'إدارة المخزون' },
    MANAGE_CUSTOMERS: { key: 'manage_customers', label: 'إدارة العملاء' },
    MANAGE_SUPPLIERS: { key: 'manage_suppliers', label: 'إدارة الموردين' },
    VIEW_REPORTS: { key: 'view_reports', label: 'عرض التقارير' },
    MANAGE_FINANCE: { key: 'manage_finance', label: 'إدارة المالية' },
    MANAGE_SETTINGS: { key: 'manage_settings', label: 'إدارة الإعدادات' },
    MANAGE_USERS: { key: 'manage_users', label: 'إدارة المستخدمين والصلاحيات' },
    // Permission for transferring funds between payment methods.
    TRANSFER_PAYMENT_METHODS: { key: 'transfer_payment_methods', label: 'تحويل طرق الدفع' },
    // Permission for managing payment methods.  Splits payment methods off from the finance module.
    MANAGE_PAYMENT_METHODS: { key: 'manage_payment_methods', label: 'إدارة طرق الدفع' },
} as const;

export type PermissionKey = typeof PERMISSIONS[keyof typeof PERMISSIONS]['key'];

export const ALL_PERMISSIONS = Object.values(PERMISSIONS);

/**
 * Check whether a user has a given permission.
 * This function performs a join across users, roles and role_permissions to determine if the specified
 * user has the given permission key. Returns a boolean.
 */
export async function hasPermission(userId: string, permissionKey: string): Promise<boolean> {
    const db = await getDbInstance();
    // Using a parameterized query protects against SQL injection.
    const row = await db.get(
        `
        SELECT 1
        FROM users u
        JOIN roles r ON r.id = u.roleId
        JOIN role_permissions rp ON rp.roleId = r.id
        WHERE u.id = ? AND rp.permission = ?
        `,
        userId,
        permissionKey
    );
    return !!row;
}

/**
 * Fetch all permission keys for a given user by joining the users, roles, and role_permissions tables.
 * Returns an array of permission key strings (e.g. 'manage_invoices', 'view_dashboard').
 */
export async function getUserPermissions(userId: string): Promise<string[]> {
    const db = await getDbInstance();
    const rows = await db.all(
        `
        SELECT rp.permission
        FROM users u
        JOIN roles r ON r.id = u.roleId
        JOIN role_permissions rp ON rp.roleId = r.id
        WHERE u.id = ?
        `,
        userId
    );
    return rows.map((row: any) => row.permission as string);
}
