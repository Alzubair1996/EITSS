
import { getDbInstance } from './db';
import type { 
    Product, 
    Category, 
    Unit, 
    Customer, 
    PaymentMethod, 
    Invoice, 
    InvoiceDetails, 
    InvoiceItem, 
    PaymentDetails, 
    ReportStats, 
    TopSellingProduct, 
    Supplier,
    SupplierDetails,
    CustomerDetails,
    InvoiceWithPayments,
    SupplierPaymentDetails,
    ExternalDebt,
    ExpenseDetails,
    PurchaseInvoiceDetails,
    PurchaseInvoiceDetailsWithItems,
    PurchaseInvoice,
    PurchaseInvoiceWithPayments,
    PurchaseReturn,
    CompanyInfo,
    RawMaterial,
    RawMaterialDetails,
    ProductIngredientDetails,
    FinancialTransaction,
    PaymentMethodTransfer,
    FixedAsset,
    FixedAssetDetails,
    FixedAssetTransactionDetails,
    PurchaseReturnDetails,
    PurchaseReturnItemDetails,
    SalesReturnDetails
} from './types';
import { format, startOfDay, endOfDay } from 'date-fns';

// New type import
import type { User } from './types';

export async function getCompanyInfo(): Promise<CompanyInfo> {
    const fallbackInfo: CompanyInfo = {
        name: '',
        nameEn: '',
        logo: null,
        address: '',
        phones: '',
        vatPercentage: 0,
        invoiceTemplate: 'modern',
        businessType: null,
        isWeightBarcodeEnabled: false,
        autoPrintInvoice: false,
    };

    try {
        const db = await getDbInstance();
        const results = await db.all('SELECT key, value FROM settings WHERE key IN (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', 'app_name', 'app_name_en', 'app_logo', 'company_address', 'company_phones', 'vat_percentage', 'invoice_template', 'business_type', 'weight_barcode_enabled', 'invoice_template_html', 'auto_print_invoice') as {key: string, value: string}[];
        const info = { ...fallbackInfo };

        results.forEach(row => {
            switch(row.key) {
                case 'app_name': info.name = row.value; break;
                case 'app_name_en': info.nameEn = row.value; break;
                case 'app_logo': info.logo = row.value; break;
                case 'company_address': info.address = row.value; break;
                case 'company_phones': info.phones = row.value; break;
                case 'vat_percentage': info.vatPercentage = parseFloat(row.value) || 0; break;
                case 'invoice_template': info.invoiceTemplate = row.value || 'modern'; break;
                case 'business_type': info.businessType = row.value; break;
                case 'weight_barcode_enabled': info.isWeightBarcodeEnabled = row.value === 'true'; break;
                case 'auto_print_invoice': info.autoPrintInvoice = row.value === 'true'; break;
            }
        });
        return info;
    } catch (error) {
        console.error("Failed to fetch company info, returning fallback. Error:", error);
        // This is critical. If the DB doesn't exist, we must not crash the app.
        // The middleware will handle redirection to setup.
        return fallbackInfo;
    }
}


export async function getAppName(): Promise<string> {
    const info = await getCompanyInfo();
    return info.name;
}

export async function getAppLogo(): Promise<string | null> {
    const info = await getCompanyInfo();
    return info.logo;
}


export async function getCurrentUSDRate(): Promise<number> {
    try {
        const db = await getDbInstance();
        const result = await db.get('SELECT value FROM settings WHERE key = ?', 'usd_rate') as { value: string } | undefined;
        return result ? parseFloat(result.value) : 0;
    } catch (error) {
        console.error("Failed to fetch USD rate:", error);
        return 0;
    }
}

/**
 * Fetch all users with their IDs and usernames. Useful for filtering transactions by user.
 */
export async function getUsers(): Promise<User[]> {
    try {
        const db = await getDbInstance();
        return await db.all('SELECT id, username, fullName FROM users ORDER BY username ASC');
    } catch (error) {
        console.error("Failed to fetch users:", error);
        return [];
    }
}

export async function getPrintType(): Promise<'a4' | 'thermal'> {
    try {
        const db = await getDbInstance();
        const result = await db.get('SELECT value FROM settings WHERE key = ?', 'print_type') as { value: 'a4' | 'thermal' } | undefined;
        return result?.value || 'a4';
    } catch (error) {
        console.error("Failed to fetch print type:", error);
        return 'a4';
    }
}

export async function getFontSize(): Promise<'sm' | 'md' | 'lg'> {
    try {
        const db = await getDbInstance();
        const result = await db.get('SELECT value FROM settings WHERE key = ?', 'font_size') as { value: 'sm' | 'md' | 'lg' } | undefined;
        return result?.value || 'md';
    } catch (error) {
        console.error("Failed to fetch font size:", error);
        return 'md';
    }
}

/**
 * Fetch all payment method transfers, joined with the names of the payment methods and the user who made the transfer.
 * Results are ordered by the transfer date descending.
 */
export async function getPaymentMethodTransfers(): Promise<PaymentMethodTransfer[]> {
    try {
        const db = await getDbInstance();
        const transfers = await db.all<PaymentMethodTransfer[]>(
            `SELECT t.id, t.fromMethodId, pmFrom.name AS fromMethodName, t.toMethodId, pmTo.name AS toMethodName, t.amount, t.transferDate, t.description, t.userId, u.username AS userName
             FROM payment_method_transfers t
             JOIN payment_methods pmFrom ON pmFrom.id = t.fromMethodId
             JOIN payment_methods pmTo ON pmTo.id = t.toMethodId
             LEFT JOIN users u ON u.id = t.userId
             ORDER BY datetime(t.transferDate) DESC`
        );
        return transfers;
    } catch (error) {
        console.error("Failed to fetch payment method transfers:", error);
        return [];
    }
}


export async function getCategories(): Promise<Category[]> {
    try {
        const db = await getDbInstance();
        return await db.all('SELECT * FROM categories ORDER BY name ASC');
    } catch (error) {
        console.error("Failed to fetch categories:", error)
        return [];
    }
}

export async function getUnits(): Promise<Unit[]> {
    try {
        const db = await getDbInstance();
        return await db.all('SELECT * FROM units ORDER BY name ASC');
    } catch (error) {
        console.error("Failed to fetch units:", error)
        return [];
    }
}

export async function getProducts(): Promise<(Product & { ingredients?: ProductIngredientDetails[] })[]> {
    try {
        const db = await getDbInstance();
        const products = await db.all('SELECT * FROM products ORDER BY name ASC');
        const companyInfo = await getCompanyInfo();
        if (companyInfo.businessType !== 'restaurant') {
            return products;
        }
        
        const productsWithIngredients = await Promise.all(products.map(async (p) => {
            const ingredients = await db.all(`
                SELECT pi.*, rm.name as rawMaterialName, u.name as unitName
                FROM product_ingredients pi
                JOIN raw_materials rm ON pi.rawMaterialId = rm.id
                JOIN units u ON rm.unitId = u.id
                WHERE pi.productId = ?
            `, p.id);
            return { ...p, ingredients };
        }));

        return productsWithIngredients;

    } catch (error) {
        console.error("Failed to fetch products:", error)
        return [];
    }
}

export async function getRawMaterials(): Promise<RawMaterial[]> {
    try {
        const db = await getDbInstance();
        return await db.all('SELECT * FROM raw_materials ORDER BY name ASC');
    } catch (error) {
        console.error("Failed to fetch raw materials:", error)
        return [];
    }
}

export async function getRawMaterialsWithUnits(): Promise<RawMaterialDetails[]> {
    try {
        const db = await getDbInstance();
        return await db.all(`
            SELECT rm.*, u.name as unitName 
            FROM raw_materials rm
            JOIN units u ON rm.unitId = u.id
            ORDER BY rm.name ASC
        `);
    } catch (error) {
        console.error("Failed to fetch raw materials with units:", error)
        return [];
    }
}

export async function getProductCount(): Promise<number> {
    try {
        const db = await getDbInstance();
        const result = await db.get('SELECT SUM(quantity) as count FROM products') as { count: number | null } | undefined;
        return result?.count || 0;
    } catch (error) {
        console.error("Failed to fetch product count:", error)
        return 0;
    }
}

export async function getCustomers(): Promise<Customer[]> {
    try {
        const db = await getDbInstance();
        return await db.all('SELECT * FROM customers ORDER BY fullName ASC');
    } catch (error) {
        console.error("Failed to fetch customers:", error);
        return [];
    }
}

export async function getCustomerDetails(id: string): Promise<CustomerDetails | null> {
    try {
        const db = await getDbInstance();
        const customer = await db.get('SELECT * FROM customers WHERE id = ?', id) as Customer;
        if (!customer) {
            return null;
        }

        const invoices = await db.all('SELECT * FROM invoices WHERE customerId = ? ORDER BY issueDate DESC', id) as Invoice[];

        const invoicesWithPayments: InvoiceWithPayments[] = await Promise.all(invoices.map(async (invoice) => {
            const payments = await db.all(`
                SELECT p.*, pm.name as paymentMethodName, i.invoiceNumber, i.customerName
                FROM payments p
                JOIN payment_methods pm ON p.paymentMethodId = pm.id
                JOIN invoices i ON p.invoiceId = i.id
                WHERE p.invoiceId = ?
                ORDER BY p.paymentDate DESC
            `, invoice.id) as PaymentDetails[];

            return { ...invoice, payments };
        }));

        // Get all sales returns for this customer
        const salesReturns = await db.all(`
            SELECT sr.*, i.invoiceNumber, c.fullName as customerName
            FROM sales_returns sr
            JOIN invoices i ON sr.invoiceId = i.id
            JOIN customers c ON i.customerId = c.id
            WHERE i.customerId = ?
            ORDER BY sr.returnDate DESC
        `, id) as any[];

        const salesReturnsWithItems = await Promise.all(salesReturns.map(async (sr) => {
            const items = await db.all(`
                SELECT sri.*, p.name as productName
                FROM sales_return_items sri
                LEFT JOIN products p ON sri.productId = p.id
                WHERE sri.salesReturnId = ?
            `, sr.id) as any[];
            return { ...sr, items };
        }));

        return { ...customer, invoices: invoicesWithPayments, salesReturns: salesReturnsWithItems };
    } catch (error) {
        console.error("Failed to fetch customer details:", error);
        return null;
    }
}


export async function getSuppliers(): Promise<Supplier[]> {
    try {
        const db = await getDbInstance();
        return await db.all('SELECT * FROM suppliers ORDER BY name ASC');
    } catch (error) {
        console.error("Failed to fetch suppliers:", error);
        return [];
    }
}

export async function getSupplierDetails(id: string): Promise<SupplierDetails | null> {
    try {
        const db = await getDbInstance();
        const cols = await db.all("PRAGMA table_info(supplier_payments)");
        console.log("Next.js sees columns for supplier_payments:", cols.map(c => c.name));
        const supplier = await db.get('SELECT * FROM suppliers WHERE id = ?', id) as Supplier;
        if (!supplier) {
            return null;
        }

        // Get all payments for this supplier, joining purchase_invoices to get invoice number if present
        const payments = await db.all(`
            SELECT sp.*, pm.name as paymentMethodName, u.username as userName, pi.invoiceNumber as purchaseInvoiceNumber
            FROM supplier_payments sp
            JOIN payment_methods pm ON sp.paymentMethodId = pm.id
            LEFT JOIN users u ON sp.userId = u.id
            LEFT JOIN purchase_invoices pi ON sp.purchaseInvoiceId = pi.id
            WHERE sp.supplierId = ?
            ORDER BY sp.paymentDate DESC
        `, id) as SupplierPaymentDetails[];

        // Get all purchase invoices for this supplier
        const purchaseInvoices = await db.all('SELECT * FROM purchase_invoices WHERE supplierId = ? ORDER BY issueDate DESC', id) as any[];

        // Fetch payments for each purchase invoice
        const purchaseInvoicesWithPayments: PurchaseInvoiceWithPayments[] = await Promise.all(purchaseInvoices.map(async (invoice) => {
            const invoicePayments = await db.all(`
                SELECT sp.*, pm.name as paymentMethodName, u.username as userName
                FROM supplier_payments sp
                JOIN payment_methods pm ON sp.paymentMethodId = pm.id
                LEFT JOIN users u ON sp.userId = u.id
                WHERE sp.purchaseInvoiceId = ?
                ORDER BY sp.paymentDate DESC
            `, invoice.id) as SupplierPaymentDetails[];

            return { ...invoice, payments: invoicePayments };
        }));

        // Get all external debts for this supplier
        const externalDebts = await db.all(`
            SELECT ed.*, u.username as userName
            FROM external_debts ed
            LEFT JOIN users u ON ed.userId = u.id
            WHERE ed.supplierId = ?
            ORDER BY ed.createdAt DESC
        `, id) as any[];

        // Get all purchase returns for this supplier
        const purchaseReturns = await db.all(`
            SELECT pr.*, pi.invoiceNumber
            FROM purchase_returns pr
            JOIN purchase_invoices pi ON pr.purchaseInvoiceId = pi.id
            WHERE pi.supplierId = ?
            ORDER BY pr.returnDate DESC
        `, id) as any[];
        
        // Fetch items for each purchase return
        const purchaseReturnsWithItems = await Promise.all(purchaseReturns.map(async (pr) => {
            const items = await db.all(`
                SELECT 
                    pri.*,
                    p.name as productName,
                    rm.name as rawMaterialName
                FROM purchase_return_items pri
                LEFT JOIN products p ON pri.productId = p.id
                LEFT JOIN raw_materials rm ON pri.rawMaterialId = rm.id
                WHERE pri.purchaseReturnId = ?
            `, pr.id) as any[];
            return { ...pr, items };
        }));

        return { ...supplier, payments, purchaseInvoices: purchaseInvoicesWithPayments, externalDebts, purchaseReturns: purchaseReturnsWithItems };
    } catch (error) {
        console.error("Failed to fetch supplier details:", error);
        return null;
    }
}

export async function getPaymentMethods(): Promise<PaymentMethod[]> {
    try {
        const db = await getDbInstance();
        return await db.all('SELECT * FROM payment_methods ORDER BY name ASC');
    } catch (error) {
        console.error("Failed to fetch payment methods:", error);
        return [];
    }
}


export async function getInvoices(): Promise<Invoice[]> {
    try {
        const db = await getDbInstance();
        const stmt = `
            SELECT *
            FROM invoices
            ORDER BY invoiceNumber DESC
        `;
        return await db.all(stmt);
    } catch (error) {
        console.error("Failed to fetch invoices:", error);
        return [];
    }
}

export async function getInvoiceByNumber(invoiceNumber: string): Promise<InvoiceDetails | null> {
    try {
        const db = await getDbInstance();
        const invoice = await db.get<Invoice & { userName?: string | null }>(
            `SELECT i.*, u.username as userName
             FROM invoices i
             LEFT JOIN users u ON u.id = i.userId
             WHERE i.invoiceNumber = ? AND i.status != 'cancelled'`, 
            invoiceNumber
        );

        if (!invoice) {
            return null;
        }
        
        const items = await db.all<InvoiceItem[]>('SELECT * FROM invoice_items WHERE invoiceId = ?', invoice.id);
        
        return { ...invoice, items };

    } catch (error) {
        console.error(`Failed to fetch invoice by number ${invoiceNumber}:`, error);
        return null;
    }
}


export async function getInvoiceDetails(id: string): Promise<InvoiceDetails | null> {
    try {
        const db = await getDbInstance();
        // Fetch invoice with associated user name, if available
        const invoice = await db.get(
            `SELECT i.*, u.username as userName FROM invoices i
             LEFT JOIN users u ON u.id = i.userId
             WHERE i.id = ?`,
            id
        ) as (Invoice & { userName?: string | null }) | undefined;

        if (!invoice) {
            return null;
        }

        const items = await db.all('SELECT * FROM invoice_items WHERE invoiceId = ?', id) as InvoiceItem[];
        
        return { ...invoice, items } as InvoiceDetails;

    } catch (error) {
        console.error("Failed to fetch invoice details:", error);
        return null;
    }
}


export async function getNextInvoiceNumber(): Promise<string> {
    try {
        const db = await getDbInstance();
        const now = new Date();
        const year = format(now, 'yy');
        const month = format(now, 'MM');
        const prefix = `INV${year}${month}`;

        const lastInvoice = await db.get(
            "SELECT invoiceNumber FROM invoices WHERE invoiceNumber LIKE ? ORDER BY invoiceNumber DESC LIMIT 1",
            `${prefix}%`
        ) as { invoiceNumber: string } | undefined;
    
        let sequence = 1;
        if (lastInvoice) {
            const lastSequence = parseInt(lastInvoice.invoiceNumber.slice(prefix.length), 10);
            sequence = lastSequence + 1;
        }
    
        return `${prefix}${String(sequence).padStart(5, '0')}`;
    } catch (error) {
        console.error("Failed to fetch next invoice number:", error);
        const now = new Date();
        const year = format(now, 'yy');
        const month = format(now, 'MM');
        return `INV${year}${month}00001`;
    }
}

export async function getNextDailyOrderNumber(): Promise<number> {
    try {
        const db = await getDbInstance();
        const todayStart = startOfDay(new Date()).toISOString();
        const todayEnd = endOfDay(new Date()).toISOString();
        
        const lastOrder = await db.get(
            "SELECT dailyOrderNumber FROM invoices WHERE issueDate >= ? AND issueDate <= ? ORDER BY dailyOrderNumber DESC LIMIT 1",
            [todayStart, todayEnd]
        ) as { dailyOrderNumber: number } | undefined;

        return (lastOrder?.dailyOrderNumber || 0) + 1;
    } catch (error) {
        console.error("Failed to fetch next daily order number:", error);
        return 1;
    }
}

export async function getReportStats(dateRange?: { startDate: string, endDate: string }): Promise<ReportStats> {
    try {
        const db = await getDbInstance();
        
        let revenueWhereClause = "status != 'cancelled'";
        let expensesWhereClause = "1 = 1";
        const params: any[] = [];

        if (dateRange) {
            revenueWhereClause += ' AND issueDate >= ? AND issueDate <= ?';
            expensesWhereClause += ' AND expenseDate >= ? AND expenseDate <= ?';
            params.push(dateRange.startDate, dateRange.endDate);
        }

        const revenueStats = await db.get(`
            SELECT
                SUM(totalAmount) as totalRevenue,
                0 as totalProfit,
                COUNT(id) as invoiceCount
            FROM invoices
            WHERE ${revenueWhereClause}
        `, ...(dateRange ? [dateRange.startDate, dateRange.endDate] : [])) as { totalRevenue: number | null, totalProfit: number | null, invoiceCount: number | null };
        
        const expenseStats = await db.get(`
            SELECT SUM(amount) as totalExpenses
            FROM expenses
            WHERE ${expensesWhereClause}
        `, ...(dateRange ? [dateRange.startDate, dateRange.endDate] : [])) as { totalExpenses: number | null };

        const returnsStats = await db.get(`
            SELECT SUM(totalAmount) as totalReturns
            FROM sales_returns
            WHERE ${dateRange ? 'returnDate >= ? AND returnDate <= ?' : '1 = 1'}
        `, ...(dateRange ? [dateRange.startDate, dateRange.endDate] : [])) as { totalReturns: number | null };

        const totalRevenue = Math.max(0, (revenueStats?.totalRevenue || 0) - (returnsStats?.totalReturns || 0));
        const invoiceCount = revenueStats?.invoiceCount || 0;

        // Get fixed assets stats (always include overall, not filtered by date)
        const fixedAssetsStats = await db.get(`
            SELECT 
                SUM(CASE WHEN status = 'active' THEN bookValue ELSE 0 END) as totalFixedAssetsValue,
                COUNT(CASE WHEN status = 'active' THEN 1 END) as fixedAssetsCount
            FROM fixed_assets
        `) as { totalFixedAssetsValue: number | null, fixedAssetsCount: number | null };

        return {
            totalRevenue,
            totalProfit: revenueStats?.totalProfit || 0,
            invoiceCount,
            avgInvoiceValue: invoiceCount > 0 ? totalRevenue / invoiceCount : 0,
            totalExpenses: expenseStats?.totalExpenses || 0,
            totalFixedAssetsValue: fixedAssetsStats?.totalFixedAssetsValue || 0,
            fixedAssetsCount: fixedAssetsStats?.fixedAssetsCount || 0,
        };
    } catch (error) {
        console.error("Failed to fetch report stats:", error);
        return {
            totalRevenue: 0,
            totalProfit: 0,
            invoiceCount: 0,
            avgInvoiceValue: 0,
            totalExpenses: 0,
            totalFixedAssetsValue: 0,
            fixedAssetsCount: 0,
        };
    }
}

export async function getDashboardStats() {
    try {
        const db = await getDbInstance();
        // Get overall revenue without date range
        const reportStats = await getReportStats();
        // Count of customers
        const totalCustomersResult = await db.get('SELECT COUNT(id) as count FROM customers') as { count: number };
        // Count of active invoices (partial or unpaid)
        const activeInvoicesResult = await db.get("SELECT COUNT(id) as count FROM invoices WHERE status IN ('partial', 'unpaid')") as { count: number };
        // Count of products
        const productCount = await getProductCount();
        // Count products nearing expiry within 30 days (expiryDate not null and not empty)
        const nearExpiryResult = await db.get(`
            SELECT COUNT(id) as count
            FROM products
            WHERE expiryDate IS NOT NULL
              AND expiryDate != ''
              AND date(expiryDate) <= date('now', '+30 days')
        `) as { count: number };
        // Count products with low stock (quantity <= 5)
        const lowStockResult = await db.get(`
            SELECT COUNT(id) as count
            FROM products
            WHERE quantity <= 5
        `) as { count: number };
        // Calculate total profit from invoice items (unitPrice - costPrice) * quantity, ignoring cancelled invoices
        const profitRow = await db.get(`
            SELECT SUM((ii.unitPrice - p.costPrice) * ii.quantity) as profit
            FROM invoice_items ii
            JOIN invoices i ON ii.invoiceId = i.id
            JOIN products p ON ii.productId = p.id
            WHERE i.status != 'cancelled'
        `) as { profit: number | null };
        
        // Calculate returned items cost/profit to deduct from totalProfit
        const returnedProfitRow = await db.get(`
            SELECT SUM((sri.price - p.costPrice) * sri.quantity) as returnedProfit
            FROM sales_return_items sri
            JOIN sales_returns sr ON sri.salesReturnId = sr.id
            JOIN products p ON sri.productId = p.id
            WHERE sr.status = 'completed'
        `) as { returnedProfit: number | null };
        const returnedProfit = returnedProfitRow?.returnedProfit ? Number(returnedProfitRow.returnedProfit) : 0;
        const totalProfit = Math.max(0, (profitRow?.profit ? Number(profitRow.profit) : 0) - returnedProfit);
        // Get top 5 selling products
        const topProducts = await getTopSellingProducts(5);
        // Get top 3 peak sales hours by payment amount
        const peakHourRows = await db.all(`
            SELECT strftime('%H', paymentDate) as hour, SUM(amount) as total
            FROM payments
            GROUP BY hour
            ORDER BY total DESC
            LIMIT 3
        `) as { hour: string; total: number }[];
        const peakHours = peakHourRows.map((row) => ({
            hour: row.hour,
            total: Number(row.total),
        }));
        return {
            totalRevenue: reportStats.totalRevenue,
            totalCustomers: totalCustomersResult?.count || 0,
            activeInvoices: activeInvoicesResult?.count || 0,
            productCount,
            nearExpiryCount: nearExpiryResult?.count || 0,
            lowStockCount: lowStockResult?.count || 0,
            totalProfit,
            topProducts,
            peakHours,
        };

    } catch (error) {
        console.error("Failed to fetch dashboard stats:", error);
        return {
            totalRevenue: 0,
            totalCustomers: 0,
            activeInvoices: 0,
            productCount: 0,
            nearExpiryCount: 0,
            lowStockCount: 0,
            totalProfit: 0,
            topProducts: [],
            peakHours: [],
        };
    }
}

export async function getSalesForChart() {
    try {
        const db = await getDbInstance();
        
        const arabicMonths = [
            'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
            'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
        ];
        
        const chartData: { month: string; sales: number; yearMonth: string }[] = [];
        const today = new Date();
        
        // Generate the last 12 months in chronological order
        for (let i = 11; i >= 0; i--) {
            const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
            const yearMonth = format(d, 'yyyy-MM');
            const monthIndex = d.getMonth();
            const monthArabic = arabicMonths[monthIndex];
            chartData.push({
                month: monthArabic,
                sales: 0,
                yearMonth
            });
        }
        
        // Query payments starting from the first day of the oldest month in the list
        const oldestYearMonth = chartData[0].yearMonth;
        const startDate = `${oldestYearMonth}-01T00:00:00.000Z`;
        
        const payments = await db.all(`
            SELECT amount, paymentDate 
            FROM payments 
            WHERE paymentDate >= ?
        `, startDate) as {amount: number, paymentDate: string}[];

        // Aggregate payments by yearMonth
        payments.forEach(p => {
            const pDate = new Date(p.paymentDate);
            if (!isNaN(pDate.getTime())) {
                const pYearMonth = format(pDate, 'yyyy-MM');
                const matchingBucket = chartData.find(item => item.yearMonth === pYearMonth);
                if (matchingBucket) {
                    matchingBucket.sales += p.amount;
                }
            }
        });

        // Return clean data containing only month name and sales
        return chartData.map(({ month, sales }) => ({ month, sales }));

    } catch (error) {
        console.error("Failed to fetch sales for chart:", error);
        return [];
    }
}



export async function getTopSellingProducts(limit: number = 5): Promise<TopSellingProduct[]> {
    try {
        const db = await getDbInstance();
        return await db.all(`
            SELECT 
                ii.productId, 
                ii.productName, 
                SUM(ii.quantity) as totalSold 
            FROM invoice_items ii
            JOIN invoices i ON ii.invoiceId = i.id
            WHERE i.status != 'cancelled'
            GROUP BY ii.productId, ii.productName 
            ORDER BY totalSold DESC 
            LIMIT ?
        `, limit);
    } catch (error) {
        console.error("Failed to fetch top selling products:", error);
        return [];
    }
}

export async function getPayments(): Promise<PaymentDetails[]> {
    try {
        const db = await getDbInstance();
        return await db.all(`
            SELECT
                p.*,
                i.invoiceNumber,
                i.customerName,
                i.id as invoiceId,
                pm.name as paymentMethodName
            FROM payments p
            JOIN invoices i ON p.invoiceId = i.id
            JOIN payment_methods pm ON p.paymentMethodId = pm.id
            ORDER BY p.paymentDate DESC
        `);
    } catch (error) {
        console.error("Failed to fetch payments:", error);
        return [];
    }
}

export async function getExpenses(): Promise<ExpenseDetails[]> {
    try {
        const db = await getDbInstance();
        return await db.all(`
            SELECT
                e.*,
                pm.name as paymentMethodName,
                s.name as supplierName
            FROM expenses e
            JOIN payment_methods pm ON e.paymentMethodId = pm.id
            LEFT JOIN suppliers s ON e.supplierId = s.id
            ORDER BY e.expenseDate DESC
        `);
    } catch (error) {
        console.error("Failed to fetch expenses:", error);
        return [];
    }
}

export async function getFinancialTransactions(): Promise<FinancialTransaction[]> {
  try {
    const db = await getDbInstance();

    const revenues = await db.all(`
      SELECT
        p.id,
        p.paymentDate as date,
        'revenue' as type,
        'دفعة من العميل ' || i.customerName || ' للفاتورة #' || i.invoiceNumber as description,
        p.amount,
        p.paymentMethodId,
        pm.name as paymentMethodName,
        i.id as relatedId,
        p.userId as userId,
        u.username as userName
      FROM payments p
      JOIN invoices i ON p.invoiceId = i.id
      JOIN payment_methods pm ON p.paymentMethodId = pm.id
      LEFT JOIN users u ON u.id = p.userId
      -- لا نستبعد فواتير ملغاة من الإيرادات؛ نحتفظ بجميع السجلات
    `);

    const expenses = await db.all(`
      SELECT
        e.id,
        e.expenseDate as date,
        'expense' as type,
        e.description,
        e.amount,
        e.paymentMethodId,
        pm.name as paymentMethodName,
        e.supplierId as relatedId,
        e.userId as userId,
        u.username as userName
      FROM expenses e
      JOIN payment_methods pm ON e.paymentMethodId = pm.id
      LEFT JOIN users u ON u.id = e.userId
    `);

    const purchasePayments = await db.all(`
      SELECT
        sp.id,
        sp.paymentDate as date,
        'expense' as type,
        COALESCE(sp.description, 'دفعة للمورد ' || s.name) as description,
        sp.amount,
        sp.paymentMethodId,
        pm.name as paymentMethodName,
        sp.supplierId as relatedId,
        sp.userId as userId,
        u.username as userName
      FROM supplier_payments sp
      JOIN suppliers s ON sp.supplierId = s.id
      JOIN payment_methods pm ON sp.paymentMethodId = pm.id
      LEFT JOIN users u ON u.id = sp.userId
    `);

    const salesReturnsRaw = await db.all(`
      SELECT
        sr.id,
        sr.returnDate as date,
        'expense' as type,
        'مرتجع مبيعات للفاتورة #' || i.invoiceNumber as description,
        sr.totalAmount as amount,
        COALESCE((SELECT p.paymentMethodId FROM payments p WHERE p.invoiceId = i.id LIMIT 1), 'credit') as paymentMethodId,
        COALESCE((SELECT pm.name FROM payment_methods pm WHERE pm.id = (SELECT p2.paymentMethodId FROM payments p2 WHERE p2.invoiceId = i.id LIMIT 1)), 'حساب العميل/آجل') as paymentMethodName,
        sr.invoiceId as relatedId,
        sr.userId as userId,
        u.username as userName
      FROM sales_returns sr
      JOIN invoices i ON sr.invoiceId = i.id
      LEFT JOIN users u ON u.id = sr.userId
    `) as FinancialTransaction[];

    // ------------------------------------------------------------------
    // Additional transaction types: Payment transfers and invoice events
    // ------------------------------------------------------------------
    // 1. Payment method transfers: each transfer yields two transactions (outgoing and incoming)
    const transfersRaw = await db.all<{
      id: string;
      fromMethodId: string;
      fromMethodName: string;
      toMethodId: string;
      toMethodName: string;
      amount: number;
      transferDate: string;
      description: string | null;
      userId: string | null;
      userName: string | null;
    }[]>(
      `SELECT t.id, t.fromMethodId, pmFrom.name AS fromMethodName, t.toMethodId, pmTo.name AS toMethodName, t.amount, t.transferDate, t.description, t.userId, u.username AS userName
         FROM payment_method_transfers t
         JOIN payment_methods pmFrom ON pmFrom.id = t.fromMethodId
         JOIN payment_methods pmTo ON pmTo.id = t.toMethodId
         LEFT JOIN users u ON u.id = t.userId`
    );
    const transferTransactions: FinancialTransaction[] = [];
    for (const t of transfersRaw) {
      // Outgoing from the source method
      transferTransactions.push({
        id: `${t.id}-out`,
        date: t.transferDate,
        type: 'transfer',
        description: t.description || `تحويل إلى ${t.toMethodName}`,
        amount: t.amount,
        paymentMethodId: t.fromMethodId,
        paymentMethodName: t.fromMethodName,
        relatedId: t.id,
        userId: t.userId || undefined,
        userName: t.userName || undefined,
        transferDirection: 'out',
      });
      // Incoming to the destination method
      transferTransactions.push({
        id: `${t.id}-in`,
        date: t.transferDate,
        type: 'transfer',
        description: t.description || `تحويل من ${t.fromMethodName}`,
        amount: t.amount,
        paymentMethodId: t.toMethodId,
        paymentMethodName: t.toMethodName,
        relatedId: t.id,
        userId: t.userId || undefined,
        userName: t.userName || undefined,
        transferDirection: 'in',
      });
    }

    // 2. Invoice creation and cancellation events
    const invoicesRaw = await db.all<{
      id: string;
      issueDate: string;
      totalAmount: number;
      status: string;
      cancellationDate: string | null;
      cancellationReason: string | null;
      invoiceNumber: string;
      customerName: string;
      userId: string | null;
      userName: string | null;
      paymentMethodId: string | null;
      paymentMethodName: string | null;
      amountPaid: number;
    }[]>(
      `SELECT i.id,
              i.issueDate,
              i.totalAmount,
              i.status,
              i.cancellationDate,
              i.cancellationReason,
              i.invoiceNumber,
              i.customerName,
              i.userId,
              u.username AS userName,
              -- Find the payment method used for the invoice by taking the first payment record (if any)
              (SELECT p.paymentMethodId FROM payments p WHERE p.invoiceId = i.id LIMIT 1) AS paymentMethodId,
              (SELECT pm.name FROM payment_methods pm WHERE pm.id = (SELECT p2.paymentMethodId FROM payments p2 WHERE p2.invoiceId = i.id LIMIT 1)) AS paymentMethodName
              , i.amountPaid
         FROM invoices i
         LEFT JOIN users u ON u.id = i.userId`
    );
    const invoiceTransactions: FinancialTransaction[] = [];
    for (const inv of invoicesRaw) {
      // Skip invoice creation events. We only record the payment transactions separately via the payments table.
      // For cancellation events, record the deduction as an expense using the payment method used for the invoice (if any).
      if (inv.status === 'cancelled' && inv.cancellationDate) {
        // Check if there is already an expense record for this cancellation to prevent double counting
        const hasExpense = expenses.some(e => e.description && e.description.includes(`إلغاء فاتورة #${inv.invoiceNumber}`));
        if (hasExpense) {
          continue;
        }

        const reasonPart = inv.cancellationReason ? ` - ${inv.cancellationReason}` : '';
        // Determine payment method for the cancellation. If no payment method exists, mark as 'none'.
        const pmId = inv.paymentMethodId || 'none';
        const pmName = inv.paymentMethodName || 'غير محدد';
        invoiceTransactions.push({
          id: `${inv.id}-cancel`,
          date: inv.cancellationDate,
          type: 'expense',
          description: `إلغاء فاتورة #${inv.invoiceNumber}${reasonPart}`,
          // Use the amount actually paid for the invoice as the deduction
          amount: inv.amountPaid,
          paymentMethodId: pmId,
          paymentMethodName: pmName,
          relatedId: inv.id,
          userId: inv.userId || undefined,
          userName: inv.userName || undefined,
        });
      }
    }

    const allTransactions = [
      ...revenues,
      ...expenses,
      ...purchasePayments,
      ...transferTransactions,
      ...invoiceTransactions,
      ...salesReturnsRaw,
    ];

    allTransactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return allTransactions as FinancialTransaction[];
  } catch (error) {
    console.error("Failed to fetch financial transactions:", error);
    return [];
  }
}


export async function getPurchaseInvoices(): Promise<PurchaseInvoiceDetails[]> {
    try {
        const db = await getDbInstance();
        return await db.all(`
            SELECT
                pi.*,
                s.name as supplierName
            FROM purchase_invoices pi
            JOIN suppliers s ON pi.supplierId = s.id
            ORDER BY pi.issueDate DESC
        `);
    } catch (error) {
        console.error("Failed to fetch purchase invoices:", error);
        return [];
    }
}

export async function getInvoiceTemplate(): Promise<string> {
  try {
    const db = await getDbInstance();
    const result = await db.get('SELECT value FROM settings WHERE key = ?', 'invoice_template_html');
    return result?.value || '';
  } catch (e) {
    console.error('Error fetching invoice template', e);
    return '';
  }
}

export async function getFixedAssets(): Promise<FixedAssetDetails[]> {
    try {
        const db = await getDbInstance();
        return await db.all(`
            SELECT
                fa.*,
                pm.name as paymentMethodName
            FROM fixed_assets fa
            LEFT JOIN payment_methods pm ON fa.paymentMethodId = pm.id
            ORDER BY fa.purchaseDate DESC
        `);
    } catch (error) {
        console.error("Failed to fetch fixed assets:", error);
        return [];
    }
}

export async function getFixedAssetTransactions(): Promise<FixedAssetTransactionDetails[]> {
    try {
        const db = await getDbInstance();
        return await db.all(`
            SELECT
                fat.*,
                fa.name as assetName,
                pm.name as paymentMethodName,
                u.username as userName
            FROM fixed_asset_transactions fat
            JOIN fixed_assets fa ON fat.assetId = fa.id
            LEFT JOIN payment_methods pm ON fat.paymentMethodId = pm.id
            LEFT JOIN users u ON fat.userId = u.id
            ORDER BY fat.transactionDate DESC
        `);
    } catch (error) {
        console.error("Failed to fetch fixed asset transactions:", error);
        return [];
    }
}

export async function getActiveFixedAssets(): Promise<FixedAssetDetails[]> {
    try {
        const db = await getDbInstance();
        return await db.all(`
            SELECT
                fa.*,
                pm.name as paymentMethodName
            FROM fixed_assets fa
            LEFT JOIN payment_methods pm ON fa.paymentMethodId = pm.id
            WHERE fa.status = 'active'
            ORDER BY fa.purchaseDate DESC
        `);
    } catch (error) {
        console.error("Failed to fetch active fixed assets:", error);
        return [];
    }
}

export async function getPurchaseInvoiceDetails(id: string): Promise<PurchaseInvoiceDetailsWithItems | null> {
    try {
        const db = await getDbInstance();
        const invoice = await db.get(`
            SELECT pi.*, s.name as supplierName, u.username as userName
            FROM purchase_invoices pi
            JOIN suppliers s ON pi.supplierId = s.id
            LEFT JOIN users u ON pi.userId = u.id
            WHERE pi.id = ?
        `, id) as (PurchaseInvoiceDetails & { userName?: string | null }) | undefined;

        if (!invoice) {
            return null;
        }

        const items = await db.all(`
            SELECT 
                pii.*,
                p.name as productName,
                rm.name as rawMaterialName
            FROM purchase_invoice_items pii
            LEFT JOIN products p ON pii.productId = p.id
            LEFT JOIN raw_materials rm ON pii.rawMaterialId = rm.id
            WHERE pii.purchaseInvoiceId = ?
        `, id) as any[];
        
        return { ...invoice, items } as PurchaseInvoiceDetailsWithItems;
    } catch (error) {
        console.error("Failed to fetch purchase invoice details:", error);
        return null;
    }
}

export async function getPurchaseReturns(): Promise<PurchaseReturnDetails[]> {
    try {
        const db = await getDbInstance();
        return await db.all(`
            SELECT
                pr.*,
                pi.invoiceNumber,
                s.name as supplierName,
                u.username as userName
            FROM purchase_returns pr
            JOIN purchase_invoices pi ON pr.purchaseInvoiceId = pi.id
            JOIN suppliers s ON pi.supplierId = s.id
            LEFT JOIN users u ON pr.userId = u.id
            ORDER BY pr.returnDate DESC
        `);
    } catch (error) {
        console.error("Failed to fetch purchase returns:", error);
        return [];
    }
}

export async function getSalesReturns(): Promise<SalesReturnDetails[]> {
    try {
        const db = await getDbInstance();
        return await db.all(`
            SELECT
                sr.*,
                i.invoiceNumber,
                COALESCE(c.fullName, 'عميل نقدي') as customerName,
                u.username as userName
            FROM sales_returns sr
            JOIN invoices i ON sr.invoiceId = i.id
            LEFT JOIN customers c ON i.customerId = c.id
            LEFT JOIN users u ON sr.userId = u.id
            ORDER BY sr.returnDate DESC
        `) as any[];
    } catch (error) {
        console.error("Failed to fetch sales returns:", error);
        return [];
    }
}

export async function getNextSalesReturnNumber(dbIn?: any): Promise<string> {
    try {
        const db = dbIn || await getDbInstance();
        const lastReturn = await db.get('SELECT returnNumber FROM sales_returns ORDER BY returnDate DESC, id DESC LIMIT 1') as { returnNumber: string } | undefined;
        
        if (!lastReturn || !lastReturn.returnNumber) {
            const year = new Date().getFullYear();
            return `SRET-${year}-001`;
        }
        
        const match = lastReturn.returnNumber.match(/^SRET-(\d{4})-(\d{3})$/);
        if (!match) {
            const year = new Date().getFullYear();
            return `SRET-${year}-001`;
        }
        
        const [, year, num] = match;
        const currentYear = new Date().getFullYear().toString();
        const nextNum = year === currentYear ? String(parseInt(num) + 1).padStart(3, '0') : '001';
        
        return `SRET-${currentYear}-${nextNum}`;
    } catch (error) {
        console.error("Failed to get next sales return number:", error);
        const year = new Date().getFullYear();
        return `SRET-${year}-001`;
    }
}

export async function getNextPurchaseReturnNumber(): Promise<string> {
    try {
        const db = await getDbInstance();
        const lastReturn = await db.get('SELECT returnNumber FROM purchase_returns ORDER BY returnDate DESC, id DESC LIMIT 1') as { returnNumber: string } | undefined;
        
        if (!lastReturn || !lastReturn.returnNumber) {
            const year = new Date().getFullYear();
            return `RET-${year}-001`;
        }
        
        const match = lastReturn.returnNumber.match(/^RET-(\d{4})-(\d{3})$/);
        if (!match) {
            const year = new Date().getFullYear();
            return `RET-${year}-001`;
        }
        
        const [, year, num] = match;
        const currentYear = new Date().getFullYear().toString();
        const nextNum = year === currentYear ? String(parseInt(num) + 1).padStart(3, '0') : '001';
        
        return `RET-${currentYear}-${nextNum}`;
    } catch (error) {
        console.error("Failed to get next purchase return number:", error);
        const year = new Date().getFullYear();
        return `RET-${year}-001`;
    }
}
