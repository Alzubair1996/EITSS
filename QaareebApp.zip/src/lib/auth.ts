
import { SignJWT, jwtVerify } from 'jose'
import { cookies } from 'next/headers'

const secretKey = process.env.SESSION_SECRET || 'your-fallback-secret-key-that-is-long-and-secure';
const key = new TextEncoder().encode(secretKey)

export async function encrypt(payload: any) {
  return await new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('24h')
    .sign(key)
}

export async function decrypt(input: string): Promise<any> {
  try {
    const { payload } = await jwtVerify(input, key, {
      algorithms: ['HS256'],
    })
    return payload
  } catch (e) {
    console.warn('Session decryption failed. It might be expired or tampered.');
    return null;
  }
}

export async function createSession(userId: string, username: string, role: string) {
    'use server'
    const expires = new Date(Date.now() + 24 * 60 * 60 * 1000)
    const session = await encrypt({ userId, username, role, expires })

    cookies().set('session', session, {
        expires,
        httpOnly: true,
        path: '/',
    })
}

export async function deleteSession() {
    'use server'
    cookies().set('session', '', { expires: new Date(0) })
}
