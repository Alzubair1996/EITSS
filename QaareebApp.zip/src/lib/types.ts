

// THIS IS A PERMANENT SETTING.
// It is configured once during the initial setup of the application.
// Do not change this value manually. It is managed by the setup process.
export const BUSINESS_TYPE = 'general_store'; // null | 'restaurant' | 'general_store' | etc.

// This boolean is derived from the permanent setting above.
// Use this constant throughout the application to conditionally render UI elements
// or apply specific business logic for restaurants.
export const IS_RESTAURANT_APP = BUSINESS_TYPE === 'restaurant';


export interface Category {
  id: string;
  name: string;
}

export interface Unit {
  id: string;
  name: string;
}

export interface Product {
  id: string;
  name: string;
  code: string | null;
  categoryId: string;
  unitId: string;
  quantity: number;
  /**
   * Cost price (سعر التكلفة) of the product in local currency (SDG).
   * This is used to calculate profit margins on sales.
   */
  costPrice: number;
  /**
   * Selling price (سعر البيع) of the product in local currency (SDG).
   */
  price: number;
  /**
   * Selling price converted to USD based on the initialUSDRate.
   */
  priceUSD?: number | null;
  /**
   * Optional cost price in USD. Currently unused but reserved for future use.
   */
  costPriceUSD?: number | null;
  initialUSDRate?: number | null;
  image?: string | null;
  warranty?: string | null;
  isDynamicPrice: boolean;

  /**
   * Expiry date (تاريخ انتهاء الصلاحية) of the product. Nullable. ISO date string.
   */
  expiryDate?: string | null;
}

export interface RawMaterial {
  id: string;
  name: string;
  unitId: string;
  quantityInStock: number;
}

export interface RawMaterialDetails extends RawMaterial {
  unitName: string;
}

export interface ProductIngredient {
  id: string;
  productId: string;
  rawMaterialId: string;
  quantityRequired: number;
}

export interface ProductIngredientDetails extends ProductIngredient {
  rawMaterialName: string;
  unitName: string;
}

export interface Customer {
    id: string;
    fullName: string;
    phone: string;
    address?: string | null;
    idNumber?: string | null;
    type: 'individual' | 'company';
    status: 'active' | 'inactive';
    balance: number;
}

export interface Supplier {
    id: string;
    name: string;
    phone: string;
    address?: string | null;
    balance: number;
}

export interface PaymentMethod {
    id: string;
    name: string;
    type: 'cash' | 'bank';
    bankName?: string | null;
    accountNumber?: string | null;
    branch?: string | null;
    balance: number;
}

/**
 * Basic user information used for permission checks and attribution.
 */
export interface User {
    id: string;
    username: string;
    fullName?: string | null;
}


export type InvoiceStatus = 'paid' | 'unpaid' | 'partial' | 'cancelled' | 'proforma';
export type OrderType = 'dine-in' | 'takeaway';
export type PaymentType = 'full' | 'partial' | 'proforma';


export interface Invoice {
    id: string;
    invoiceNumber: string;
    dailyOrderNumber?: number | null;
    customerId: string | null;
    customerName: string;
    customerPhone?: string | null;
    subject?: string | null;
    issueDate: string; // ISO date string
    totalAmount: number;
    amountPaid: number;
    status: InvoiceStatus;
    orderType?: OrderType | null;
    cancellationReason?: string | null;

    /**
     * ID of the user who created this invoice. Optional because older records may not have it.
     */
    userId?: string | null;
}

export interface InvoiceItem {
    id: string;
    invoiceId: string;
    productId: string;
    productName: string;
    quantity: number;
    unitPrice: number;
    warranty?: string | null;
    // For local state management in the form
    stock?: number;
}

export interface Payment {
    id: string;
    invoiceId: string;
    paymentMethodId: string;
    amount: number;
    paymentDate: string; // ISO date string
    paymentProof?: string | null;
    /**
     * ID of the user who created this payment. Optional because older records may not have it.
     */
    userId?: string | null;
}

export interface InvoiceWithPayments extends Invoice {
    payments: PaymentDetails[];
}

export interface CustomerDetails extends Customer {
    invoices: InvoiceWithPayments[];
    salesReturns?: SalesReturnDetails[];
}

export interface PaymentDetails extends Payment {
    invoiceNumber: string;
    customerName: string;
    paymentMethodName: string;
    invoiceId: string;
}

export interface FinancialTransaction {
    id: string;
    date: string;
    /**
     * Type of the financial transaction. Can be 'revenue' for incoming funds,
     * 'expense' for outgoing funds, or 'transfer' for internal money movement.
     */
    type: 'revenue' | 'expense' | 'transfer';
    description: string;
    amount: number;
    paymentMethodId: string;
    paymentMethodName: string;
    relatedId?: string | null; // e.g., invoiceId, supplierId

    /**
     * Optional flag used when the type is 'transfer' to indicate direction of the transfer.
     * 'out' means the money moved out of the payment method (negative),
     * 'in' means the money moved into the payment method (positive).
     * If undefined, the transaction represents a standard revenue or expense.
     */
    transferDirection?: 'in' | 'out';

    /**
     * ID of the user who performed this transaction, if tracked.
     */
    userId?: string | null;

    /**
     * Username of the user who performed this transaction, if available.
     */
    userName?: string | null;
}

/**
 * Represents a transfer of funds between two payment methods. Each transfer is attributed to the user who performed it.
 */
export interface PaymentMethodTransfer {
    id: string;
    fromMethodId: string;
    /** Optional human-readable name for the source payment method (joined via query). */
    fromMethodName?: string;
    toMethodId: string;
    /** Optional human-readable name for the destination payment method (joined via query). */
    toMethodName?: string;
    amount: number;
    transferDate: string;
    description?: string | null;
    /** ID of the user who performed the transfer, if tracked. */
    userId?: string | null;
    /** Username of the user who performed the transfer, if available. */
    userName?: string | null;
}

export interface ReportStats {
    totalRevenue: number;
    totalProfit: number;
    invoiceCount: number;
    avgInvoiceValue: number;
    totalExpenses: number;
    totalFixedAssetsValue?: number;
    fixedAssetsCount?: number;
}

export interface TopSellingProduct {
    productId: string;
    productName: string;
    totalSold: number;
}

export interface PurchaseInvoice {
    id: string;
    invoiceNumber?: string | null;
    supplierId: string;
    issueDate: string;
    totalAmount: number;
    amountPaid: number;
    status: 'paid' | 'unpaid' | 'partial';

    /**
     * ID of the user who created this purchase invoice. Optional because older records may not have it.
     */
    userId?: string | null;
}

export interface PurchaseInvoiceDetails extends PurchaseInvoice {
  supplierName: string;

  /**
   * Username of the user who created this purchase invoice, if available.
   */
  userName?: string | null;
}

export interface PurchaseInvoiceItem {
    id: string;
    purchaseInvoiceId: string;
    productId?: string | null;
    rawMaterialId?: string | null;
    quantity: number;
    costPrice: number;
    productName?: string | null;
    rawMaterialName?: string | null;
}

export interface PurchaseInvoiceDetailsWithItems extends PurchaseInvoiceDetails {
    items: PurchaseInvoiceItem[];
}

export interface SupplierPaymentDetails {
    id: string;
    supplierId: string;
    paymentMethodId: string;
    paymentMethodName: string;
    amount: number;
    paymentDate: string;
    paymentProof?: string | null;
    description?: string | null;
    referenceNumber?: string | null;
    /**
     * ID of the user who created this payment.
     */
    userId?: string | null;
    /**
     * Username of the user who created this payment.
     */
    userName?: string | null;
    purchaseInvoiceId?: string | null;
    purchaseInvoiceNumber?: string | null;
}

export interface ExternalDebt {
    id: string;
    supplierId: string;
    amount: number;
    description?: string | null;
    referenceNumber?: string | null;
    createdAt: string;
    userId?: string | null;
    userName?: string | null;
}

export interface PurchaseInvoiceWithPayments extends PurchaseInvoice {
    payments: SupplierPaymentDetails[];
}

export interface SupplierDetails extends Supplier {
    payments: SupplierPaymentDetails[];
    purchaseInvoices: PurchaseInvoiceWithPayments[];
    externalDebts: ExternalDebt[];
    purchaseReturns: PurchaseReturnDetails[];
}

export interface Expense {
    id: string;
    description: string;
    amount: number;
    expenseDate: string; // ISO date string
    paymentMethodId: string;
    supplierId?: string | null;
    /**
     * ID of the user who recorded this expense. Optional because older records may not have it.
     */
    userId?: string | null;
}

export interface ExpenseDetails extends Expense {
  paymentMethodName: string;
  supplierName?: string | null;
}

export interface InvoiceDetails extends Invoice {
    items: InvoiceItem[];

    /**
     * Username of the user who created this invoice, if available.
     */
    userName?: string | null;
}

export interface CompanyInfo {
    name: string;
    nameEn: string;
    logo: string | null;
    address: string;
    phones: string;
    vatPercentage: number;
    invoiceTemplate: string;
    businessType: string | null;
    isWeightBarcodeEnabled: boolean;

    /**
     * Indicates whether invoices should be automatically printed immediately after they are created.
     * When true, the invoice creation form will display a print preview dialog and trigger printing
     * automatically. When false, the user must manually print invoices from the invoices list.
     */
    autoPrintInvoice?: boolean;
}

export interface FixedAsset {
    id: string;
    name: string;
    description?: string | null;
    purchasePrice: number;
    purchaseDate: string; // ISO date string
    bookValue: number;
    depreciationRate: number;
    status: 'active' | 'sold' | 'disposed';
    salePrice?: number | null;
    saleDate?: string | null;
    paymentMethodId?: string | null;
}

export interface FixedAssetDetails extends FixedAsset {
    paymentMethodName?: string | null;
    /**
     * Username of the user who created this asset, if available.
     */
    userName?: string | null;
}

export interface FixedAssetTransaction {
    id: string;
    assetId: string;
    transactionType: 'purchase' | 'sale' | 'depreciation';
    amount: number;
    transactionDate: string; // ISO date string
    description?: string | null;
    paymentMethodId?: string | null;
    /**
     * ID of the user who created this transaction. Optional because older records may not have it.
     */
    userId?: string | null;
}

export interface FixedAssetTransactionDetails extends FixedAssetTransaction {
    assetName?: string;
    paymentMethodName?: string | null;
    /**
     * Username of the user who created this transaction, if available.
     */
    userName?: string | null;
}

export interface PurchaseReturn {
    id: string;
    purchaseInvoiceId: string;
    returnNumber?: string | null;
    returnDate: string; // ISO date string
    totalAmount: number;
    reason?: string | null;
    status: 'pending' | 'approved' | 'completed';
    /**
     * ID of the user who created this return. Optional because older records may not have it.
     */
    userId?: string | null;
}

export interface PurchaseReturnDetails extends PurchaseReturn {
    supplierName: string;
    invoiceNumber?: string | null;
    /**
     * Username of the user who created this return, if available.
     */
    userName?: string | null;
    items?: PurchaseReturnItemDetails[];
}

export interface PurchaseReturnItem {
    id: string;
    purchaseReturnId: string;
    productId?: string | null;
    rawMaterialId?: string | null;
    quantity: number;
    costPrice: number;
}

export interface PurchaseReturnItemDetails extends PurchaseReturnItem {
    productName?: string | null;
    rawMaterialName?: string | null;
}

export interface SalesReturn {
    id: string;
    invoiceId: string;
    returnNumber?: string | null;
    returnDate: string; // ISO date string
    totalAmount: number;
    reason?: string | null;
    status: 'pending' | 'approved' | 'completed';
    userId?: string | null;
}

export interface SalesReturnDetails extends SalesReturn {
    customerName: string;
    invoiceNumber?: string | null;
    userName?: string | null;
    items?: SalesReturnItemDetails[];
}

export interface SalesReturnItem {
    id: string;
    salesReturnId: string;
    productId?: string | null;
    quantity: number;
    price: number;
}

export interface SalesReturnItemDetails extends SalesReturnItem {
    productName?: string | null;
}
