import 'server-only';
import * as os from 'os';
import * as crypto from 'crypto';

let serverId: string | null = null;

export async function getServerId(): Promise<string> {
  if (serverId) {
    return serverId;
  }

  // Generate a stable ID based on some machine-specific properties
  const networkInterfaces = os.networkInterfaces();
  const macAddress = Object.values(networkInterfaces)
    .flat()
    .find(iface => iface && !iface.internal && iface.mac !== '00:00:00:00:00:00')?.mac;

  const uniqueString = [
    os.hostname(),
    os.arch(),
    os.platform(),
    macAddress || '',
    os.totalmem().toString(),
  ].join('-');

  serverId = crypto.createHash('sha256').update(uniqueString).digest('hex');
  
  return serverId;
}
