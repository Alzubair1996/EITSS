
import 'server-only';
import { open, type Database } from 'sqlite';
import sqlite3 from 'sqlite3';
import { promises as fs } from 'fs';
import path from 'path';
import os from 'os';
import { PERMISSIONS } from './permissions';
import { hashPassword } from './server-auth';


// This helps avoid weird issues in development when hot-reloading.
declare global {
  var _db: Promise<Database<sqlite3.Database, sqlite3.Statement>> | undefined;
  var _db_restored: boolean | undefined;
}

if (process.env.NODE_ENV === 'development') {
    if (global._db) {
        console.log("Development reload: clearing cached database connection.");
        global._db.then(db => {
            db.close().catch(() => {});
        }).catch(() => {});
        global._db = undefined;
    }
}

const schema = `
  CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
  );

  CREATE TABLE IF NOT EXISTS units (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
  );

  CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT UNIQUE,
    categoryId TEXT NOT NULL,
    unitId TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    -- Cost price (سعر التكلفة) in local currency. Stored separately from the selling price.
    costPrice REAL NOT NULL DEFAULT 0,
    -- Selling price (سعر البيع) in local currency.
    price REAL NOT NULL,
    -- Selling price in USD, calculated using initialUSDRate at insertion time.
    priceUSD REAL,
    -- Cost price in USD, reserved for future use. Currently not populated.
    costPriceUSD REAL,
    initialUSDRate REAL,
    image TEXT,
    warranty TEXT,
    -- Expiry date of the product (تاريخ انتهاء الصلاحية). Nullable.
    expiryDate TEXT,
    isDynamicPrice BOOLEAN NOT NULL DEFAULT 1,
    FOREIGN KEY (categoryId) REFERENCES categories (id) ON DELETE RESTRICT,
    FOREIGN KEY (unitId) REFERENCES units (id) ON DELETE RESTRICT
  );

  CREATE TABLE IF NOT EXISTS raw_materials (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    unitId TEXT NOT NULL,
    quantityInStock REAL NOT NULL,
    FOREIGN KEY (unitId) REFERENCES units(id) ON DELETE RESTRICT
  );

  CREATE TABLE IF NOT EXISTS product_ingredients (
    id TEXT PRIMARY KEY,
    productId TEXT NOT NULL,
    rawMaterialId TEXT NOT NULL,
    quantityRequired REAL NOT NULL,
    FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (rawMaterialId) REFERENCES raw_materials(id) ON DELETE CASCADE,
    UNIQUE(productId, rawMaterialId)
  );

  CREATE TABLE IF NOT EXISTS customers (
    id TEXT PRIMARY KEY,
    fullName TEXT NOT NULL,
    phone TEXT UNIQUE,
    address TEXT,
    idNumber TEXT,
    type TEXT NOT NULL CHECK(type IN ('individual', 'company')),
    status TEXT NOT NULL CHECK(status IN ('active', 'inactive')),
    balance REAL NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS suppliers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT NOT NULL UNIQUE,
    address TEXT,
    balance REAL NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS payment_methods (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('cash', 'bank')),
    bankName TEXT,
    accountNumber TEXT,
    branch TEXT,
    balance REAL NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS invoices (
    id TEXT PRIMARY KEY,
    invoiceNumber TEXT UNIQUE NOT NULL,
    dailyOrderNumber INTEGER,
    customerId TEXT,
    customerName TEXT NOT NULL,
    customerPhone TEXT,
    subject TEXT,
    orderType TEXT,
    issueDate TEXT NOT NULL,
    totalAmount REAL NOT NULL,
    amountPaid REAL NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('paid','unpaid','partial','cancelled','proforma')),
    cancellationReason TEXT,
    -- Date the invoice was cancelled. Nullable for non-cancelled invoices.
    cancellationDate TEXT,
    -- ID of the user who created the invoice. Nullable for legacy records.
    userId TEXT,
    FOREIGN KEY (customerId) REFERENCES customers(id) ON DELETE SET NULL,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS invoice_items (
    id TEXT PRIMARY KEY,
    invoiceId TEXT NOT NULL,
    productId TEXT NOT NULL,
    productName TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    unitPrice REAL NOT NULL,
    warranty TEXT,
    FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (productId) REFERENCES products(id) ON DELETE RESTRICT
  );

  CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      invoiceId TEXT NOT NULL,
      paymentMethodId TEXT NOT NULL,
      amount REAL NOT NULL,
      paymentDate TEXT NOT NULL,
      paymentProof TEXT,
      userId TEXT,
      FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE,
      FOREIGN KEY (paymentMethodId) REFERENCES payment_methods(id) ON DELETE RESTRICT,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS purchase_invoices (
    id TEXT PRIMARY KEY,
    invoiceNumber TEXT,
    supplierId TEXT NOT NULL,
    issueDate TEXT NOT NULL,
    totalAmount REAL NOT NULL,
    amountPaid REAL NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('paid', 'unpaid', 'partial')),
    -- ID of the user who created the purchase invoice. Nullable for legacy records.
    userId TEXT,
    FOREIGN KEY (supplierId) REFERENCES suppliers(id) ON DELETE RESTRICT,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS purchase_invoice_items (
    id TEXT PRIMARY KEY,
    purchaseInvoiceId TEXT NOT NULL,
    productId TEXT,
    rawMaterialId TEXT,
    quantity INTEGER NOT NULL,
    costPrice REAL NOT NULL,
    FOREIGN KEY (purchaseInvoiceId) REFERENCES purchase_invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (productId) REFERENCES products(id) ON DELETE RESTRICT,
    FOREIGN KEY (rawMaterialId) REFERENCES raw_materials(id) ON DELETE RESTRICT
  );

  CREATE TABLE IF NOT EXISTS expenses (
    id TEXT PRIMARY KEY,
    description TEXT NOT NULL,
    amount REAL NOT NULL,
    expenseDate TEXT NOT NULL,
    paymentMethodId TEXT NOT NULL,
    supplierId TEXT,
    userId TEXT,
    FOREIGN KEY (paymentMethodId) REFERENCES payment_methods(id) ON DELETE RESTRICT,
    FOREIGN KEY (supplierId) REFERENCES suppliers(id) ON DELETE SET NULL,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
  );

  -- Table for transferring funds between payment methods.
  CREATE TABLE IF NOT EXISTS payment_method_transfers (
    id TEXT PRIMARY KEY,
    fromMethodId TEXT NOT NULL,
    toMethodId TEXT NOT NULL,
    amount REAL NOT NULL,
    transferDate TEXT NOT NULL,
    description TEXT,
    userId TEXT,
    FOREIGN KEY (fromMethodId) REFERENCES payment_methods(id) ON DELETE RESTRICT,
    FOREIGN KEY (toMethodId) REFERENCES payment_methods(id) ON DELETE RESTRICT,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  -- User and Role Management Tables
  CREATE TABLE IF NOT EXISTS roles (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    is_default BOOLEAN NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS role_permissions (
    roleId TEXT NOT NULL,
    permission TEXT NOT NULL,
    PRIMARY KEY (roleId, permission),
    FOREIGN KEY (roleId) REFERENCES roles(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    roleId TEXT,
    fullName TEXT,
    FOREIGN KEY (roleId) REFERENCES roles(id) ON DELETE SET NULL
  );

  -- Fixed Assets (الأصول الثابتة) Management
  CREATE TABLE IF NOT EXISTS fixed_assets (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    purchasePrice REAL NOT NULL,
    purchaseDate TEXT NOT NULL,
    bookValue REAL NOT NULL,
    depreciationRate REAL NOT NULL DEFAULT 0,
    status TEXT NOT NULL CHECK(status IN ('active', 'sold', 'disposed')),
    salePrice REAL,
    saleDate TEXT,
    paymentMethodId TEXT,
    FOREIGN KEY (paymentMethodId) REFERENCES payment_methods(id) ON DELETE SET NULL
  );

  -- Fixed Asset Transactions (حركات الأصول الثابتة)
  CREATE TABLE IF NOT EXISTS fixed_asset_transactions (
    id TEXT PRIMARY KEY,
    assetId TEXT NOT NULL,
    transactionType TEXT NOT NULL CHECK(transactionType IN ('purchase', 'sale', 'depreciation')),
    amount REAL NOT NULL,
    transactionDate TEXT NOT NULL,
    description TEXT,
    paymentMethodId TEXT,
    userId TEXT,
    FOREIGN KEY (assetId) REFERENCES fixed_assets(id) ON DELETE CASCADE,
    FOREIGN KEY (paymentMethodId) REFERENCES payment_methods(id) ON DELETE SET NULL,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
  );

  -- Purchase Returns (مرتجعات المشتريات)
  CREATE TABLE IF NOT EXISTS purchase_returns (
    id TEXT PRIMARY KEY,
    purchaseInvoiceId TEXT NOT NULL,
    returnNumber TEXT UNIQUE,
    returnDate TEXT NOT NULL,
    totalAmount REAL NOT NULL,
    reason TEXT,
    status TEXT NOT NULL CHECK(status IN ('pending', 'approved', 'completed')),
    userId TEXT,
    FOREIGN KEY (purchaseInvoiceId) REFERENCES purchase_invoices(id) ON DELETE RESTRICT,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
  );

  -- Purchase Return Items (أصناف مرتجعات المشتريات)
  CREATE TABLE IF NOT EXISTS purchase_return_items (
    id TEXT PRIMARY KEY,
    purchaseReturnId TEXT NOT NULL,
    productId TEXT,
    rawMaterialId TEXT,
    quantity INTEGER NOT NULL,
    costPrice REAL NOT NULL,
    FOREIGN KEY (purchaseReturnId) REFERENCES purchase_returns(id) ON DELETE CASCADE,
    FOREIGN KEY (productId) REFERENCES products(id) ON DELETE RESTRICT,
    FOREIGN KEY (rawMaterialId) REFERENCES raw_materials(id) ON DELETE RESTRICT
  );

  -- Supplier Payments (دفعات المورد) - Detailed payment tracking
  CREATE TABLE IF NOT EXISTS supplier_payments (
    id TEXT PRIMARY KEY,
    supplierId TEXT NOT NULL,
    paymentMethodId TEXT NOT NULL,
    amount REAL NOT NULL,
    paymentDate TEXT NOT NULL,
    paymentProof TEXT,
    description TEXT,
    referenceNumber TEXT,
    userId TEXT,
    purchaseInvoiceId TEXT,
    FOREIGN KEY (supplierId) REFERENCES suppliers(id) ON DELETE RESTRICT,
    FOREIGN KEY (paymentMethodId) REFERENCES payment_methods(id) ON DELETE RESTRICT,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (purchaseInvoiceId) REFERENCES purchase_invoices(id) ON DELETE SET NULL
  );

  -- External Debts (ديون خارجية للمورد) - Debts not tied to purchase invoices
  CREATE TABLE IF NOT EXISTS external_debts (
    id TEXT PRIMARY KEY,
    supplierId TEXT NOT NULL,
    amount REAL NOT NULL,
    description TEXT,
    referenceNumber TEXT,
    createdAt TEXT NOT NULL,
    userId TEXT,
    FOREIGN KEY (supplierId) REFERENCES suppliers(id) ON DELETE RESTRICT,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
  );

  -- Sales Returns (مرتجعات المبيعات)
  CREATE TABLE IF NOT EXISTS sales_returns (
    id TEXT PRIMARY KEY,
    invoiceId TEXT NOT NULL,
    returnNumber TEXT UNIQUE,
    returnDate TEXT NOT NULL,
    totalAmount REAL NOT NULL,
    reason TEXT,
    status TEXT NOT NULL CHECK(status IN ('pending', 'approved', 'completed')),
    userId TEXT,
    FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE RESTRICT,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
  );

  -- Sales Return Items (أصناف مرتجعات المبيعات)
  CREATE TABLE IF NOT EXISTS sales_return_items (
    id TEXT PRIMARY KEY,
    salesReturnId TEXT NOT NULL,
    productId TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    FOREIGN KEY (salesReturnId) REFERENCES sales_returns(id) ON DELETE CASCADE,
    FOREIGN KEY (productId) REFERENCES products(id) ON DELETE RESTRICT
  );
`;

async function seedInitialData(db: Database) {
    const settings = [
        { key: 'vat_percentage', value: '0' },
        { key: 'invoice_template_html', value: '' },
        { key: 'bank_proof_required', value: 'true' },
        { key: 'invoice_template', value: 'modern' },
        // Whether invoices should be automatically printed after creation. Defaults to true for convenience.
        { key: 'auto_print_invoice', value: 'true' },
    ];

    for (const setting of settings) {
        const existing = await db.get('SELECT key FROM settings WHERE key = ?', setting.key);
        if (!existing) {
            await db.run('INSERT INTO settings (key, value) VALUES (?, ?)', setting.key, setting.value);
        }
    }

    // Seed Roles and Admin user
    const adminRole = await db.get('SELECT id FROM roles WHERE name = ?', 'المدير');
    if (!adminRole) {
        console.log('Seeding Admin role and permissions...');
        const adminRoleId = `role_admin_${Date.now()}`;
        await db.run('INSERT INTO roles (id, name, is_default) VALUES (?, ?, ?)', adminRoleId, 'المدير', 1);

        for (const permission of Object.values(PERMISSIONS)) {
            await db.run('INSERT INTO role_permissions (roleId, permission) VALUES (?, ?)', adminRoleId, permission.key);
        }

        const adminUser = await db.get('SELECT id, fullName FROM users WHERE username = ?', 'admin') as { id: string, fullName: string | null } | undefined;
        if (!adminUser) {
            console.log('Seeding admin user...');
            const hashedPassword = await hashPassword('admin');
            await db.run('INSERT INTO users (id, username, password, roleId, fullName) VALUES (?, ?, ?, ?, ?)', `user_admin_${Date.now()}`, 'admin', hashedPassword, adminRoleId, 'مدير النظام');
        } else {
            await db.run("UPDATE users SET fullName = ? WHERE username = ? AND (fullName IS NULL OR fullName = '')", 'مدير النظام', 'admin');
        }
    }
}

export async function setupDatabase(db: Database) {
    await db.exec('PRAGMA foreign_keys = ON;');
    await db.exec('PRAGMA journal_mode = WAL;');
    await db.exec(schema);

    // Ensure new columns exist for user tracking on existing databases. These ALTERs are safe to run repeatedly.
    try {
        await db.exec('ALTER TABLE users ADD COLUMN fullName TEXT');
    } catch (e) {
        // Ignore if column already exists
    }
    try {
        await db.exec('ALTER TABLE payments ADD COLUMN userId TEXT');
    } catch (e) {
        // Ignore errors (likely column already exists)
    }
    try {
        await db.exec('ALTER TABLE expenses ADD COLUMN userId TEXT');
    } catch (e) {
        // Ignore errors (likely column already exists)
    }
    // Add user tracking columns to invoices and purchase_invoices if they do not exist.
    try {
        await db.exec('ALTER TABLE invoices ADD COLUMN userId TEXT');
    } catch (e) {
        // Ignore if the column already exists.
    }
    // Ensure invoices have a cancellationDate column for recording cancellation timestamps.
    try {
        await db.exec('ALTER TABLE invoices ADD COLUMN cancellationDate TEXT');
    } catch (e) {
        // Ignore if the column already exists.
    }
    try {
        await db.exec('ALTER TABLE purchase_invoices ADD COLUMN userId TEXT');
    } catch (e) {
        // Ignore if the column already exists.
    }

    // Ensure cost tracking columns exist in products table for existing databases.
    try {
        await db.exec("ALTER TABLE products ADD COLUMN costPrice REAL DEFAULT 0");
    } catch (e) {
        // Column may already exist; ignore errors.
    }
    try {
        await db.exec("ALTER TABLE products ADD COLUMN costPriceUSD REAL");
    } catch (e) {
        // Column may already exist; ignore errors.
    }

    // Ensure expiry date column exists in products table for existing databases.
    try {
        await db.exec("ALTER TABLE products ADD COLUMN expiryDate TEXT");
    } catch (e) {
        // Column may already exist; ignore errors.
    }
    
    // Migration: Convert supplier_payments from purchaseInvoiceId to supplierId
    try {
        // Check if old table structure exists
        const checkOld = await db.get("SELECT sql FROM sqlite_master WHERE type='table' AND name='supplier_payments'") as { sql: string } | undefined;
        if (checkOld && checkOld.sql.includes('purchaseInvoiceId') && !checkOld.sql.includes('supplierId')) {
            console.log('Migrating supplier_payments table structure...');
            
            // Create temporary table with new structure
            await db.exec(`
                CREATE TABLE IF NOT EXISTS supplier_payments_new (
                    id TEXT PRIMARY KEY,
                    supplierId TEXT NOT NULL,
                    paymentMethodId TEXT NOT NULL,
                    amount REAL NOT NULL,
                    paymentDate TEXT NOT NULL,
                    paymentProof TEXT,
                    description TEXT,
                    referenceNumber TEXT,
                    userId TEXT,
                    purchaseInvoiceId TEXT,
                    FOREIGN KEY (supplierId) REFERENCES suppliers(id) ON DELETE RESTRICT,
                    FOREIGN KEY (paymentMethodId) REFERENCES payment_methods(id) ON DELETE RESTRICT,
                    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL,
                    FOREIGN KEY (purchaseInvoiceId) REFERENCES purchase_invoices(id) ON DELETE SET NULL
                )
            `);
            
            // Migrate data: get supplierId from purchase_invoices
            await db.exec(`
                INSERT INTO supplier_payments_new 
                SELECT 
                    sp.id,
                    pi.supplierId,
                    sp.paymentMethodId,
                    sp.amount,
                    sp.paymentDate,
                    sp.paymentProof,
                    NULL as description,
                    NULL as referenceNumber,
                    sp.userId,
                    sp.purchaseInvoiceId
                FROM supplier_payments sp
                JOIN purchase_invoices pi ON sp.purchaseInvoiceId = pi.id
            `);
            
            // Drop old table and rename new
            await db.exec('DROP TABLE supplier_payments');
            await db.exec('ALTER TABLE supplier_payments_new RENAME TO supplier_payments');
            
            console.log('Migration completed successfully.');
        }
    } catch (e) {
        console.error('Migration error:', e);
        // Ignore errors - table might already be migrated or not exist
    }

    // Ensure purchaseInvoiceId column exists in supplier_payments table
    try {
        await db.exec('ALTER TABLE supplier_payments ADD COLUMN purchaseInvoiceId TEXT');
    } catch (e) {
        // Ignore if the column already exists.
    }
    
    if (global._db_restored) {
        console.log("Database restore detected, skipping initial data seed.");
        global._db_restored = false;
    } else {
        await seedInitialData(db);
    }

    // Ensure the admin role always includes the new permissions added after initial setup.
    // Specifically, transfer_payment_methods and manage_payment_methods must be granted to the admin.
    try {
        const adminRole = await db.get('SELECT id FROM roles WHERE name = ?', 'المدير') as { id: string } | undefined;
        if (adminRole) {
            const ensurePermission = async (permissionKey: string) => {
                const exists = await db.get(
                    'SELECT 1 FROM role_permissions WHERE roleId = ? AND permission = ?',
                    adminRole.id,
                    permissionKey
                );
                if (!exists) {
                    await db.run('INSERT INTO role_permissions (roleId, permission) VALUES (?, ?)', adminRole.id, permissionKey);
                }
            };
            await ensurePermission('transfer_payment_methods');
            await ensurePermission('manage_payment_methods');
        }
    } catch (e) {
        console.error('Failed to ensure admin has all necessary permissions:', e);
    }


}

export function getDbPath(): string {
  // This is now the single source of truth for the database path.
  // The sidecar environment variable is the most reliable way to set this in a packaged app.
  if (process.env.DATABASE_PATH) {
    return process.env.DATABASE_PATH;
  }

  // On Vercel / AWS Lambda serverless functions, the root filesystem is read-only.
  // We copy the bundled SQLite database to /tmp so it has read/write permissions.
  if (process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME) {
    const tmpDbPath = path.join(os.tmpdir(), 'balla.sqlite');
    try {
      const fsSync = require('fs');
      if (!fsSync.existsSync(tmpDbPath)) {
        const sourceDb = path.join(process.cwd(), 'balla.sqlite');
        if (fsSync.existsSync(sourceDb)) {
          fsSync.copyFileSync(sourceDb, tmpDbPath);
          console.log('[DB] Seeded /tmp/balla.sqlite from bundled database.');
        }
      }
    } catch (e) {
      console.error('[DB] Failed to copy balla.sqlite to /tmp:', e);
    }
    return tmpDbPath;
  }
  
  let cwd = process.cwd();
  
  // If running in Next.js standalone mode, the process.cwd() is under '.next/standalone'.
  // Go up two levels to find the database at the project root.
  if (cwd.endsWith(path.join('.next', 'standalone')) || cwd.includes(path.join('.next', 'standalone'))) {
    return path.resolve(cwd, '..', '..', 'balla.sqlite');
  }
  
  // For standard `npm run dev` outside of Tauri, this will be the fallback.
  return path.join(cwd, 'balla.sqlite');
}



async function initializeDb() {
    const dbPath = getDbPath();
    console.log("USING DATABASE PATH:", dbPath);
    const db = await open({
        filename: dbPath,
        driver: sqlite3.Database
    });
    


    await setupDatabase(db);
    
    // The hard migration logic is now in its own export, to be called manually.
    // We will leave the dev assertion here.
    if (process.env.NODE_ENV === 'development') {
      await assertProformaDDL(db);
    }
    

    return db;
}

async function assertProformaDDL(db:any) {
  if (process.env.NODE_ENV !== 'development') return;
  try {
    const r = await db.get("SELECT sql FROM sqlite_master WHERE type='table' AND name='invoices'");
    const ddl = r?.sql || "";
    if (!ddl.includes("'proforma'")) {
      console.error("FATAL DDL MISMATCH: 'proforma' is missing from CHECK constraint. Manual migration is required.");
      // This will throw only in dev to prevent silent failures.
      // throw new Error("FATAL: invoices table missing 'proforma' in CHECK. Run migration. DDL=" + ddl);
    }
  } catch (e) {
     console.error("Error during DDL assertion:", e);
  }
}

export async function hardRebuildInvoicesTable() {
  console.log('[HARD MIGRATE] Starting hard rebuild of invoices table...');
  const db = await getDbInstance(true);
  
  try {
    const r0 = await db.get("SELECT sql FROM sqlite_master WHERE type='table' AND name='invoices'");
    console.log("[HARD] BEFORE DDL =", r0?.sql || "<missing>");

    if (r0?.sql && r0.sql.includes("'proforma'")) {
      console.log("[HARD] DDL already contains 'proforma'. Aborting hard rebuild.");
      return { success: true, message: "No migration needed. Table is already up to date." };
    }

    await db.exec('BEGIN TRANSACTION;');
    
    // Check if the old table exists before renaming
    const oldTableExists = await db.get("SELECT name FROM sqlite_master WHERE type='table' AND name='invoices_old'");
    if(oldTableExists) {
        await db.exec('DROP TABLE invoices_old;');
        console.log("[HARD] Dropped pre-existing 'invoices_old' table.");
    }
    
    await db.exec('ALTER TABLE invoices RENAME TO invoices_old;');

    await db.exec(`
      CREATE TABLE invoices (
        id TEXT PRIMARY KEY,
        invoiceNumber TEXT UNIQUE NOT NULL,
        dailyOrderNumber INTEGER,
        customerId TEXT,
        customerName TEXT NOT NULL,
        customerPhone TEXT,
        subject TEXT,
        orderType TEXT,
        issueDate TEXT NOT NULL,
        totalAmount REAL NOT NULL,
        amountPaid REAL NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('paid','unpaid','partial','cancelled','proforma')),
        cancellationReason TEXT,
        -- ID of the user who created the invoice
        userId TEXT,
        FOREIGN KEY (customerId) REFERENCES customers(id) ON DELETE SET NULL,
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
      );
    `);

    // Smart INSERT that checks for column existence before trying to select it.
    await db.exec(`
      INSERT INTO invoices (
        id, invoiceNumber, dailyOrderNumber, customerId, customerName, customerPhone,
        subject, orderType, issueDate, totalAmount, amountPaid,
        status, cancellationReason, userId
      )
      SELECT
        id, invoiceNumber,
        CASE WHEN EXISTS(SELECT 1 FROM pragma_table_info('invoices_old') WHERE name='dailyOrderNumber') THEN dailyOrderNumber ELSE NULL END,
        customerId, customerName, customerPhone,
        subject,
        CASE WHEN EXISTS(SELECT 1 FROM pragma_table_info('invoices_old') WHERE name='orderType') THEN orderType ELSE NULL END,
        issueDate,
        totalAmount, amountPaid,
        status,
        CASE WHEN EXISTS(SELECT 1 FROM pragma_table_info('invoices_old') WHERE name='cancellationReason') THEN cancellationReason ELSE NULL END,
        CASE WHEN EXISTS(SELECT 1 FROM pragma_table_info('invoices_old') WHERE name='userId') THEN userId ELSE NULL END
      FROM invoices_old;
    `);

    await db.exec('DROP TABLE invoices_old;');
    await db.exec('COMMIT;');

    const r1 = await db.get("SELECT sql FROM sqlite_master WHERE type='table' AND name='invoices'");
    console.log("[HARD] AFTER DDL =", r1?.sql || "<missing>");

    return { success: true, message: "Hard rebuild of invoices table completed successfully." };
  } catch (error: any) {
    console.error('[HARD MIGRATE] Error during hard rebuild:', error);
    try {
        await db.exec('ROLLBACK;');
    } catch (rbError) {
        console.error('[HARD MIGRATE] Rollback failed:', rbError);
    }
    return { success: false, message: `Hard rebuild failed: ${error.message}` };
  }
}

export async function closeDb() {
    if (global._db) {
        console.log("Closing existing database connection.");
        const db = await global._db;
        await db.close();
        global._db = undefined;
    }
}


function getDbInstance(force: boolean = false) {
  if (process.env.NODE_ENV === 'production' && !force) {
    if (!global._db) {
       global._db = initializeDb();
    }
    return global._db;
  }

  if (!global._db || force) {
     if(force) console.log("Forcing re-initialization of database.");
     global._db = initializeDb();
  }
  return global._db;
}


export { getDbInstance };
