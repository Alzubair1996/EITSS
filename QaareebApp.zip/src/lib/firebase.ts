// Firebase Realtime Database Configuration & REST Helpers

export const firebaseConfig = {
  apiKey: "AIzaSyDvcaX9z0HIMWzmH5d6LCKcmaU0ptMHxYY",
  authDomain: "greendongol.firebaseapp.com",
  databaseURL: "https://greendongol-default-rtdb.firebaseio.com",
  projectId: "greendongol",
  storageBucket: "greendongol.firebasestorage.app",
  messagingSenderId: "526972441982",
  appId: "1:526972441982:web:56de29ec6a068e8cd48f2f"
};

const BASE_URL = firebaseConfig.databaseURL;

export interface FirebaseLicenseData {
  activated: boolean;
  expiry: string;
  signature: string;
  updatedAt: string;
}

/**
 * Fetch license details from Firebase Realtime Database using REST API
 */
export async function getOnlineLicense(serverId: string): Promise<FirebaseLicenseData | null> {
  try {
    const response = await fetch(`${BASE_URL}/licenses/${serverId}.json`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
      next: { revalidate: 0 } // Disable caching to get fresh status
    });
    
    if (!response.ok) {
      throw new Error(`Firebase request failed with status ${response.status}`);
    }
    
    const data = await response.json();
    return data as FirebaseLicenseData | null;
  } catch (error) {
    console.error("Firebase getOnlineLicense error:", error);
    return null;
  }
}

/**
 * Save/Update license details in Firebase Realtime Database using REST API
 */
export async function saveOnlineLicense(serverId: string, licenseData: FirebaseLicenseData): Promise<boolean> {
  try {
    const response = await fetch(`${BASE_URL}/licenses/${serverId}.json`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(licenseData)
    });
    
    if (!response.ok) {
      throw new Error(`Firebase request failed with status ${response.status}`);
    }
    
    return true;
  } catch (error) {
    console.error("Firebase saveOnlineLicense error:", error);
    return false;
  }
}
