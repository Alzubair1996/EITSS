import * as React from 'react';

type PageHeaderProps = {
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
};

export function PageHeader({ title, subtitle, children }: PageHeaderProps) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-2 w-full">
      <div className="space-y-1">
        <div className="h-1 w-10 rounded-full bg-primary/80" />
        <h1 className="text-2xl font-extrabold tracking-tight md:text-3xl font-headline text-foreground">
          {title}
        </h1>
        {subtitle && (
          <p className="text-sm text-muted-foreground leading-6">{subtitle}</p>
        )}
      </div>
      {children && (
        <div className="flex flex-wrap items-center gap-2 self-start sm:self-center">
          {children}
        </div>
      )}
    </div>
  );
}
