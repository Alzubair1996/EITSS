'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
  SidebarFooter,
  useSidebar,
} from '@/components/ui/sidebar';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  LayoutDashboard,
  Package,
  Boxes,
  Users,
  FileText,
  LineChart,
  Settings,
  Building,
  Scale,
  ChevronDown,
  Wallet,
  Landmark,
  ArrowRightLeft,
  Truck,
  ReceiptText,
  ShoppingCart,
  Brush,
  ClipboardList,
  Beaker,
  Maximize,
  Minimize,
  ShieldCheck,
  Building2,
  Calculator,
  RotateCcw,
  Sparkles,
  User,
} from 'lucide-react';
import Image from 'next/image';
import { LogoutButton } from '@/components/logout-button';
import { useEffect, useState } from 'react';
import type { CompanyInfo } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { IS_RESTAURANT_APP } from '@/lib/types';

// Grouping navigation items in sections for premium workspace organization
const navSections = [
  {
    title: 'عام',
    items: [
      { href: '/', label: 'لوحة التحكم', icon: LayoutDashboard, permission: 'view_dashboard' },
      { href: '/invoices', label: 'الفواتير والمبيعات', icon: FileText, permission: 'manage_invoices' },
      { href: '/purchases', label: 'المشتريات', icon: ShoppingCart, permission: 'manage_purchases' },
      { href: '/purchase-returns', label: 'مرتجعات المشتريات', icon: RotateCcw, permission: 'manage_purchases' },
    ]
  },
  {
    title: 'المخزون',
    permission: 'manage_inventory',
    items: [
      {
        label: 'المخزون والمنتجات',
        icon: Package,
        hide: IS_RESTAURANT_APP,
        subItems: [
          { href: '/products', label: 'المنتجات', icon: Package },
          { href: '/categories', label: 'الفئات والأنواع', icon: Boxes },
          { href: '/units', label: 'الوحدات والمقاييس', icon: Scale },
        ],
      },
      {
        label: 'إدارة المخزون والمواد',
        icon: Package,
        show: IS_RESTAURANT_APP,
        subItems: [
          { href: '/products', label: 'الأصناف (القائمة)', icon: ClipboardList },
          { href: '/materials', label: 'المواد الخام', icon: Beaker },
          { href: '/categories', label: 'فئات الأصناف', icon: Boxes },
          { href: '/units', label: 'الوحدات', icon: Scale },
        ],
      },
    ]
  },
  {
    title: 'الشركاء والجهات',
    items: [
      { href: '/customers', label: 'العملاء والمدينين', icon: Users, permission: 'manage_customers' },
      { href: '/suppliers', label: 'الموردين الدائنين', icon: Truck, permission: 'manage_suppliers' },
    ]
  },
  {
    title: 'المالية والتقارير',
    items: [
      { href: '/reports', label: 'التقارير والتحليلات', icon: LineChart, permission: 'view_reports' },
      { href: '/payment-transfers', label: 'تحويل بين الخزائن', icon: ArrowRightLeft, permission: 'transfer_payment_methods' },
      { href: '/payment-methods', label: 'طرق الدفع والحسابات', icon: Wallet, permission: 'manage_payment_methods' },
      {
        label: 'الحسابات المالية',
        icon: Landmark,
        permission: 'manage_finance',
        subItems: [
          { href: '/transactions', label: 'سجل المعاملات', icon: ArrowRightLeft },
          { href: '/expenses', label: 'المصروفات التشغيلية', icon: ReceiptText },
          { href: '/fixed-assets', label: 'الأصول الثابتة', icon: Building2 },
          { href: '/financial-accounts', label: 'الملخص المالي الشامل', icon: Calculator },
        ],
      },
    ]
  },
  {
    title: 'الإدارة والنظام',
    items: [
      {
        label: 'إعدادات متقدمة',
        icon: Settings,
        permission: 'manage_settings',
        subItems: [
          { href: '/settings/company', label: 'بيانات الشركة', icon: Building },
          { href: '/settings/templates', label: 'محرر القوالب', icon: Brush },
          { href: '/settings', label: 'خيارات النظام المتقدمة', icon: Settings },
        ],
      },
      { href: '/admin/users', label: 'صلاحيات الموظفين', icon: Users, permission: 'manage_users' },
      { href: '/profile', label: 'الملف الشخصي', icon: User },
    ]
  }
];

function FullscreenToggle() {
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };
  
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  return (
    <SidebarMenuItem>
      <SidebarMenuButton
        onClick={toggleFullScreen}
        tooltip={isFullscreen ? 'الخروج من وضع ملء الشاشة' : 'وضع ملء الشاشة'}
        className="w-full h-10 border border-primary/20 hover:border-primary/80 bg-primary/10 hover:bg-primary text-primary hover:text-white transition-all duration-200 rounded-xl font-bold flex items-center justify-center gap-2 group shadow-sm shadow-primary/5 active:scale-[0.98]"
      >
        {isFullscreen ? (
          <Minimize className="h-4.5 w-4.5 group-hover:scale-95 transition-transform" />
        ) : (
          <Maximize className="h-4.5 w-4.5 group-hover:scale-105 transition-transform" />
        )}
        <span>{isFullscreen ? 'تصغير الشاشة' : 'ملء الشاشة'}</span>
      </SidebarMenuButton>
    </SidebarMenuItem>
  );
}

export function MainSidebar({
  companyInfo,
  allowedPermissions = [],
  isLoggedIn = false,
  isActivated = true,
}: {
  companyInfo: CompanyInfo;
  allowedPermissions?: string[];
  isLoggedIn?: boolean;
  isActivated?: boolean;
}) {
  const pathname = usePathname();

  // Helper to check user permission on sections & items
  const hasAccess = (permission?: string) => {
    if (!permission) return true;
    return allowedPermissions.includes(permission);
  };

  return (
    <Sidebar side="right" collapsible="icon" variant="sidebar" className="border-l border-sidebar-border bg-sidebar shadow-[-12px_0_32px_-22px_rgb(15_23_42_/.7)]">
      
      {/* Sidebar Header Brand Panel */}
      <SidebarHeader className="border-b border-sidebar-border/70 py-5 px-5 bg-sidebar">
        <div className="flex items-center gap-3.5">
          <Link href="/" className="flex items-center gap-2 transition-transform duration-300 hover:scale-105">
            {companyInfo.logo ? (
              <div className="relative w-9 h-9 rounded-xl overflow-hidden border border-sidebar-border/40 bg-white p-0.5 shadow-md">
                <Image
                  src={companyInfo.logo}
                  alt="Company Logo"
                  fill
                  className="object-contain p-0.5"
                />
              </div>
            ) : (
              <div className="w-9 h-9 flex items-center justify-center bg-gradient-to-tr from-primary to-primary/80 rounded-xl shadow-md shadow-primary/25">
                <Sparkles className="w-4.5 h-4.5 text-white" />
              </div>
            )}
          </Link>
          <div className="flex flex-col group-data-[collapsible=icon]:hidden">
            <span className="text-sm font-extrabold font-headline text-sidebar-foreground tracking-tight line-clamp-1 leading-snug">
              {companyInfo.name || 'متجر'}
            </span>
            <div className="flex items-center gap-1.5 mt-1">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/logoEITSS.png" alt="EITSS Logo" className="h-5 w-auto object-contain bg-white px-1.5 py-0.5 rounded shadow-sm opacity-100" />
              <span className="text-[10px] font-bold text-sidebar-foreground/50 leading-none">شريك تقني EITSS</span>
            </div>
          </div>
        </div>
      </SidebarHeader>
      
      {/* Sidebar Navigation Options */}
      <SidebarContent className="py-3 px-3 scrollbar-thin scrollbar-thumb-sidebar-border/40 scrollbar-track-transparent">
        <SidebarMenu className="gap-4">
          
          {/* Activation Required banner */}
          {!isActivated && (
            <SidebarMenuItem>
              <SidebarMenuButton
                asChild
                isActive={pathname === '/activation'}
                className={`rounded-xl border border-red-500/20 bg-red-500/10 text-red-400 hover:bg-red-500/20 hover:text-red-300 transition-all font-bold`}
              >
                <Link href="/activation">
                  <ShieldCheck className="w-4 h-4 text-red-400" />
                  <span>تفعيل البرنامج</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          )}

          {/* Map Sections */}
          {navSections.map((section) => {
            // Check if section itself is hidden due to restaurant option
            const isSectionAllowed = !section.permission || hasAccess(section.permission);
            if (!isSectionAllowed) return null;

            // Pre-filter visible items in the section
            const visibleItems = section.items.filter((item: any) => {
              if (item.hide) return false;
              if (item.show === false) return false;
              if (!isLoggedIn && item.href === '/change-password') return false;
              return hasAccess(item.permission);
            });

            if (visibleItems.length === 0) return null;

            return (
              <div key={section.title} className="space-y-1 mt-2 first:mt-0">
                
                {/* Section Header Title Label */}
                <span className="text-[9px] font-extrabold tracking-wider text-sidebar-foreground/30 px-3 uppercase block select-none group-data-[collapsible=icon]:hidden">
                  {section.title}
                </span>

                {/* Section Items */}
                <div className="space-y-1.5">
                  {visibleItems.map((item: any) => {
                    
                    // Render sub-menu collapsible item
                    if (item.subItems) {
                      const visibleSubItems = item.subItems.filter((sub: any) => {
                        if (sub.hide) return false;
                        if (sub.show === false) return false;
                        return hasAccess(sub.permission);
                      });
                      if (visibleSubItems.length === 0) return null;

                      const isChildActive = visibleSubItems.some((sub: any) => pathname === sub.href);

                      return (
                        <Collapsible key={item.label} defaultOpen={isChildActive} asChild>
                          <SidebarMenuItem>
                            <div className="flex w-full flex-col relative">
                              <CollapsibleTrigger asChild>
                                <SidebarMenuButton
                                  className={`group/button rounded-xl hover:scale-[1.01] active:scale-[0.99] transition-all duration-200 ${
                                    isChildActive 
                                      ? 'bg-sidebar-accent text-sidebar-accent-foreground font-extrabold' 
                                      : 'text-sidebar-foreground/80 hover:bg-sidebar-foreground/10 hover:text-sidebar-foreground'
                                  }`}
                                  tooltip={item.label}
                                >
                                  <item.icon className={`w-4 h-4 ${isChildActive ? 'text-primary' : 'text-sidebar-foreground/60 group-hover/button:text-sidebar-foreground'}`} />
                                  <span>{item.label}</span>
                                  <ChevronDown className="ms-auto h-3.5 w-3.5 transition-transform duration-200 group-data-[state=open]:rotate-180" />
                                </SidebarMenuButton>
                              </CollapsibleTrigger>
                              
                              <CollapsibleContent asChild>
                                <SidebarMenuSub className="mr-4 pr-3.5 border-r border-sidebar-border/40 gap-1 mt-1 pb-1">
                                  {visibleSubItems.map((subItem: any) => {
                                    const isSubActive = pathname === subItem.href;
                                    return (
                                      <SidebarMenuSubItem key={subItem.href} className="relative">
                                        
                                        {/* Nested right-side visual dot indicator for active sub-item */}
                                        {isSubActive && (
                                          <span className="absolute -right-3.5 top-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-primary" />
                                        )}

                                        <SidebarMenuSubButton
                                          asChild
                                          isActive={isSubActive}
                                          className={`rounded-lg transition-all duration-150 ${
                                            isSubActive 
                                              ? 'text-primary font-bold bg-primary/5' 
                                              : 'text-sidebar-foreground/60 hover:bg-sidebar-foreground/5 hover:text-sidebar-foreground'
                                          }`}
                                        >
                                          <Link href={subItem.href} className="flex items-center gap-2 py-1.5">
                                            <subItem.icon className={`w-3.5 h-3.5 ${isSubActive ? 'text-primary' : 'text-sidebar-foreground/45'}`} />
                                            <span className="text-xs">{subItem.label}</span>
                                          </Link>
                                        </SidebarMenuSubButton>
                                      </SidebarMenuSubItem>
                                    );
                                  })}
                                </SidebarMenuSub>
                              </CollapsibleContent>
                            </div>
                          </SidebarMenuItem>
                        </Collapsible>
                      );
                    }

                    // Render standard single button link item
                    const isActiveItem = pathname === item.href;
                    return (
                      <SidebarMenuItem key={item.href} className="relative">
                        
                        {/* Neon visual vertical bar indicator on selection (RTL right-aligned) */}
                        {isActiveItem && (
                          <span className="absolute right-0 top-1/2 -translate-y-1/2 w-0.75 h-6 rounded-l-full bg-primary shadow-[0_0_8px_hsl(var(--primary))]" />
                        )}

                        <SidebarMenuButton
                          asChild
                          isActive={isActiveItem}
                          tooltip={item.label}
                          className={`rounded-xl hover:scale-[1.01] active:scale-[0.99] transition-all duration-200 ${
                            isActiveItem 
                              ? 'bg-sidebar-primary text-sidebar-primary-foreground font-extrabold hover:bg-sidebar-primary/90 shadow-sm shadow-sidebar-primary/20' 
                              : 'text-sidebar-foreground/80 hover:bg-sidebar-foreground/10 hover:text-sidebar-foreground'
                          }`}
                        >
                          <Link href={item.href}>
                            <item.icon className={`w-4 h-4 ${isActiveItem ? 'text-primary' : 'text-sidebar-foreground/60'}`} />
                            <span>{item.label}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </SidebarMenu>
      </SidebarContent>
      
      {/* Sidebar Footer Panel */}
      <SidebarFooter className="border-t border-sidebar-border/70 py-4 px-4 bg-sidebar">
        <SidebarMenu className="gap-2">
          <FullscreenToggle />
          {isLoggedIn && (
            <SidebarMenuItem>
              <LogoutButton />
            </SidebarMenuItem>
          )}
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}

export const MainSidebarSkeleton = () => (
  <Sidebar side="right" collapsible="icon" variant="sidebar" className="border-l border-sidebar-border">
    <SidebarHeader className="border-b border-sidebar-border/40 py-5 px-4">
      <div className="flex items-center gap-2">
        <Skeleton className="h-10 w-10 rounded-2xl bg-sidebar-border/20" />
        <Skeleton className="h-6 w-32 rounded-md bg-sidebar-border/20 group-data-[collapsible=icon]:hidden" />
      </div>
    </SidebarHeader>
    <SidebarContent className="py-4 px-3">
      <SidebarMenu className="gap-2">
        {[...Array(6)].map((_, i) => (
          <SidebarMenuItem key={i}>
            <div className="flex items-center gap-3 rounded-full p-2.5">
              <Skeleton className="h-5 w-5 bg-sidebar-border/20" />
              <Skeleton className="h-4 w-3/4 bg-sidebar-border/20 group-data-[collapsible=icon]:hidden" />
            </div>
          </SidebarMenuItem>
        ))}
      </SidebarMenu>
    </SidebarContent>
  </Sidebar>
);
