'use client';

import * as React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Delete } from 'lucide-react';

export function Calculator() {
  const [display, setDisplay] = React.useState('0');
  const [currentValue, setCurrentValue] = React.useState<number | null>(null);
  const [operator, setOperator] = React.useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = React.useState(false);

  const inputDigit = React.useCallback((digit: string) => {
    if (waitingForOperand) {
      setDisplay(digit);
      setWaitingForOperand(false);
    } else {
      setDisplay(prev => prev === '0' ? digit : prev + digit);
    }
  }, [waitingForOperand]);

  const inputDecimal = React.useCallback(() => {
    if (waitingForOperand) {
      setDisplay('0.');
      setWaitingForOperand(false);
    } else if (display.indexOf('.') === -1) {
      setDisplay(prev => prev + '.');
    }
  }, [display, waitingForOperand]);

  const clearDisplay = React.useCallback(() => {
    setDisplay('0');
    setCurrentValue(null);
    setOperator(null);
    setWaitingForOperand(false);
  }, []);

  const deleteLast = React.useCallback(() => {
    if (waitingForOperand) return;
    setDisplay(prev => prev.length > 1 ? prev.slice(0, -1) : '0');
  }, [waitingForOperand]);

  const calculate = (firstOperand: number, secondOperand: number, op: string) => {
    switch (op) {
      case '+':
        return firstOperand + secondOperand;
      case '-':
        return firstOperand - secondOperand;
      case '*':
        return firstOperand * secondOperand;
      case '/':
        return secondOperand === 0 ? 0 : firstOperand / secondOperand;
      default:
        return secondOperand;
    }
  };

  const performOperation = React.useCallback((nextOperator: string) => {
    const inputValue = parseFloat(display);

    if (currentValue === null) {
      setCurrentValue(inputValue);
    } else if (operator) {
      const result = calculate(currentValue, inputValue, operator);
      setCurrentValue(result);
      setDisplay(String(result));
    }

    setWaitingForOperand(true);
    setOperator(nextOperator);
  }, [display, currentValue, operator]);

  const handleEquals = React.useCallback(() => {
    const inputValue = parseFloat(display);
    if (operator && currentValue !== null) {
      const result = calculate(currentValue, inputValue, operator);
      setCurrentValue(result);
      setDisplay(String(result));
      setOperator(null);
      setWaitingForOperand(true);
    }
  }, [display, operator, currentValue]);

  // Keyboard Event Listener
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore keypresses if the focus is on a text input or textarea
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
        return;
      }

      const key = e.key;

      if (/[0-9]/.test(key)) {
        e.preventDefault();
        inputDigit(key);
      } else if (key === '.') {
        e.preventDefault();
        inputDecimal();
      } else if (key === '+') {
        e.preventDefault();
        performOperation('+');
      } else if (key === '-') {
        e.preventDefault();
        performOperation('-');
      } else if (key === '*' || key.toLowerCase() === 'x') {
        e.preventDefault();
        performOperation('*');
      } else if (key === '/') {
        e.preventDefault();
        performOperation('/');
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (key === 'Backspace') {
        e.preventDefault();
        deleteLast();
      } else if (key === 'Escape' || key.toLowerCase() === 'c') {
        e.preventDefault();
        clearDisplay();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [inputDigit, inputDecimal, performOperation, handleEquals, deleteLast, clearDisplay]);

  return (
    <Card className="w-full max-w-[340px] mx-auto border-0 shadow-2xl rounded-3xl overflow-hidden bg-card/65 backdrop-blur-md" dir="ltr">
      {/* Premium Digital Screen Display */}
      <div className="px-6 pt-8 pb-4 bg-gradient-to-b from-muted/30 to-transparent text-left select-all" dir="ltr">
        <div className="text-[10px] font-black text-muted-foreground/80 tracking-widest uppercase text-right h-4 mb-1 font-mono">
          {currentValue !== null ? `${currentValue} ${operator || ''}` : 'Active Session'}
        </div>
        <div className="text-4xl font-extrabold text-foreground tracking-tight overflow-x-auto whitespace-nowrap scrollbar-none font-mono">
          {display}
        </div>
      </div>

      <CardContent className="p-4 pt-2">
        <div className="grid grid-cols-4 gap-2">
          {/* Row 1 */}
          <Button onClick={clearDisplay} variant="ghost" className="h-14 rounded-2xl text-red-500 hover:text-red-600 hover:bg-red-500/10 text-base font-extrabold transition-all duration-150">
            C
          </Button>
          <Button onClick={deleteLast} variant="ghost" className="h-14 rounded-2xl text-muted-foreground hover:text-foreground hover:bg-muted/40 flex items-center justify-center transition-all duration-150">
            <Delete className="h-5 w-5" />
          </Button>
          <Button onClick={() => performOperation('/')} variant="secondary" className={React.useMemo(() => `h-14 rounded-2xl text-lg font-black transition-all duration-150 ${operator === '/' ? 'bg-primary text-primary-foreground shadow-md shadow-primary/20' : 'text-primary hover:bg-primary/10'}`, [operator])}>
            ÷
          </Button>
          <Button onClick={() => performOperation('*')} variant="secondary" className={React.useMemo(() => `h-14 rounded-2xl text-lg font-black transition-all duration-150 ${operator === '*' ? 'bg-primary text-primary-foreground shadow-md shadow-primary/20' : 'text-primary hover:bg-primary/10'}`, [operator])}>
            ×
          </Button>

          {/* Row 2 */}
          <Button onClick={() => inputDigit('7')} variant="outline" className="h-14 rounded-2xl text-base font-bold bg-background/50 hover:bg-background border-border/40 transition-all duration-150">
            7
          </Button>
          <Button onClick={() => inputDigit('8')} variant="outline" className="h-14 rounded-2xl text-base font-bold bg-background/50 hover:bg-background border-border/40 transition-all duration-150">
            8
          </Button>
          <Button onClick={() => inputDigit('9')} variant="outline" className="h-14 rounded-2xl text-base font-bold bg-background/50 hover:bg-background border-border/40 transition-all duration-150">
            9
          </Button>
          <Button onClick={() => performOperation('-')} variant="secondary" className={React.useMemo(() => `h-14 rounded-2xl text-lg font-black transition-all duration-150 ${operator === '-' ? 'bg-primary text-primary-foreground shadow-md shadow-primary/20' : 'text-primary hover:bg-primary/10'}`, [operator])}>
            −
          </Button>

          {/* Row 3 */}
          <Button onClick={() => inputDigit('4')} variant="outline" className="h-14 rounded-2xl text-base font-bold bg-background/50 hover:bg-background border-border/40 transition-all duration-150">
            4
          </Button>
          <Button onClick={() => inputDigit('5')} variant="outline" className="h-14 rounded-2xl text-base font-bold bg-background/50 hover:bg-background border-border/40 transition-all duration-150">
            5
          </Button>
          <Button onClick={() => inputDigit('6')} variant="outline" className="h-14 rounded-2xl text-base font-bold bg-background/50 hover:bg-background border-border/40 transition-all duration-150">
            6
          </Button>
          <Button onClick={() => performOperation('+')} variant="secondary" className={React.useMemo(() => `h-14 rounded-2xl text-lg font-black transition-all duration-150 ${operator === '+' ? 'bg-primary text-primary-foreground shadow-md shadow-primary/20' : 'text-primary hover:bg-primary/10'}`, [operator])}>
            +
          </Button>

          {/* Row 4 */}
          <Button onClick={() => inputDigit('1')} variant="outline" className="h-14 rounded-2xl text-base font-bold bg-background/50 hover:bg-background border-border/40 transition-all duration-150">
            1
          </Button>
          <Button onClick={() => inputDigit('2')} variant="outline" className="h-14 rounded-2xl text-base font-bold bg-background/50 hover:bg-background border-border/40 transition-all duration-150">
            2
          </Button>
          <Button onClick={() => inputDigit('3')} variant="outline" className="h-14 rounded-2xl text-base font-bold bg-background/50 hover:bg-background border-border/40 transition-all duration-150">
            3
          </Button>
          <Button onClick={handleEquals} className="row-span-2 h-[120px] rounded-2xl bg-gradient-to-b from-primary to-primary/80 hover:opacity-90 text-primary-foreground font-black text-xl shadow-lg shadow-primary/20 transition-all duration-150">
            =
          </Button>

          {/* Row 5 */}
          <Button onClick={() => inputDigit('0')} variant="outline" className="col-span-2 h-14 rounded-2xl text-base font-bold bg-background/50 hover:bg-background border-border/40 transition-all duration-150">
            0
          </Button>
          <Button onClick={inputDecimal} variant="outline" className="h-14 rounded-2xl text-base font-bold bg-background/50 hover:bg-background border-border/40 transition-all duration-150">
            .
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
