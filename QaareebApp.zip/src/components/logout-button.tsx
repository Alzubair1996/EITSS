import { logout } from '@/app/login/actions';
import { Button } from '@/components/ui/button';
import { LogOut } from 'lucide-react';

export function LogoutButton() {
  return (
    <form action={logout} className="w-full">
      <Button 
        type="submit" 
        variant="outline" 
        className="w-full h-10 border-destructive/20 hover:border-destructive/80 bg-destructive/10 hover:bg-destructive text-destructive hover:text-white transition-all duration-200 rounded-xl font-bold flex items-center justify-center gap-2 group shadow-sm shadow-destructive/5"
      >
        <LogOut className="h-4.5 w-4.5 group-hover:-translate-x-0.5 transition-transform" />
        <span>تسجيل الخروج</span>
      </Button>
    </form>
  );
}