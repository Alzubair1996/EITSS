
# Project Brief: Qareeb Store Management System (for C# Windows Forms)

## 1. High-Level Objective

Develop a comprehensive desktop application using C# and Windows Forms to manage the daily operations of a retail store ("Qareeb Store"). The application should handle inventory, sales, customer management, supplier management, and financial tracking. The user interface should be modern, intuitive, and inspired by Material Design principles, with a right-to-left (RTL) layout for the Arabic language.

The application will be backed by a local SQLite database.

## 2. Core Modules & Features

### 2.1. Dashboard
- **Purpose:** Provide an at-a-glance overview of key business metrics.
- **Components:**
    - Four summary cards displaying:
        1.  **Total Revenue:** Sum of `totalAmount` from all non-cancelled invoices.
        2.  **Total Customers:** Count of all registered customers.
        3.  **Active Invoices:** Count of invoices with `status` of 'unpaid' or 'partial'.
        4.  **Active Inventory:** Count of total product units in stock.
    - **Sales Chart:** A bar chart displaying sales revenue for the last 12 months.

### 2.2. Inventory Management
- **Purpose:** Manage the store's products, categories, and units.
- **Sub-modules:**
    - **Products:**
        - A data grid view to display all products with columns for Image, Name, Code, Category, Warranty, Quantity, and Price.
        - Full CRUD (Create, Read, Update, Delete) functionality through a dedicated form.
        - **Product Attributes:** `id`, `name`, `code` (SKU, must be unique), `categoryId`, `unitId`, `quantity` (stock), `price` (selling price), `warranty` (e.g., "1 year"), `image` (stored as a Base64 string or a link).
        - **Search/Filter:** Ability to filter the product list by name or code.
        - **Import:** A button to open a dialog for importing products from an Excel file. The dialog should display the required columns (`name`, `code`, `categoryName`, `unitName`, `quantity`, `price`, `warranty`).
    - **Categories:**
        - Simple CRUD for managing product categories (e.g., "Electronics", "Laptops").
    - **Units:**
        - Simple CRUD for managing product units (e.g., "Piece", "Box", "Set").

### 2.3. Sales & Invoicing
- **Purpose:** Create and manage sales invoices.
- **Features:**
    - **Invoice List:** A data grid showing all created invoices with columns for Invoice #, Customer, Date, Total Amount, and Status. Searchable by customer name or invoice number.
    - **Create Invoice Form:**
        - **Customer Selection:** Search and select an existing customer or enter details (name, phone) to create a new customer on the fly.
        - **Product Cart:** Search and add products from inventory to the invoice. For each item, the user can adjust the `quantity` and `unitPrice`. The system should prevent selling more than the available stock.
        - **Payment Types (Crucial Feature):**
            1.  **Full Payment:** The customer pays the total amount.
            2.  **Partial Payment:** The customer pays a portion of the total amount.
            3.  **Installment Payment:**
                - User selects a pre-defined **Installment Plan**.
                - The system calculates a new `totalAmount` by adding the plan's profit percentage to the original cart total.
                - User enters a `downPayment` amount.
                - Upon saving, the system must automatically generate a schedule of monthly `invoice_installments` records for the remaining balance, distributed over the plan's duration.
        - **Payment Details:** Select the payment method (from Payment Methods module) for the amount paid. If the method is a bank account, allow the user to attach an image of the payment proof.
        - **System Actions on Save:**
            - Deduct sold quantities from product stock.
            - Update the customer's `balance` (debt).
            - Update the `balance` of the selected payment method.
            - Generate the invoice and installment schedule if applicable.
    - **Print Invoice:** A dedicated, professional print-friendly view for each invoice, including the store's logo and business details.

### 2.4. Customer Relationship Management (CRM)
- **Purpose:** Manage customer data and track their financial status.
- **Features:**
    - **Customer List:** A data grid with all customers, showing Name, Phone, Type, Status, and Balance. Searchable by name or phone.
    - **CRUD for Customers:** Form for adding/editing customers. Attributes: `id`, `fullName`, `phone`, `address`, `idNumber`, `type` ('individual' or 'company'), `status` ('active' or 'inactive'), `balance`.
    - **Customer Details Page:** A dedicated view for each customer that shows:
        - Customer's personal information and current balance.
        - A list of their past invoices.
        - For each installment-based invoice, a detailed grid of its installments (`installmentNumber`, `dueDate`, `amount`, `status`).
        - **Settle Installment:** A "Pay" button next to each 'pending' installment. This opens a dialog where the user selects a payment method. Confirming the payment updates the installment's status to 'paid', adds the amount to the customer's balance (reducing their debt), and increases the balance of the chosen payment method.

### 2.5. Supplier & Purchase Management
- **Purpose:** Manage suppliers and track incoming stock.
- **Features:**
    - **Supplier List:** A data grid to display all suppliers with Name, Phone, Address, and Balance (our debt to them). Searchable by name or phone.
    - **CRUD for Suppliers:** Form for adding/editing suppliers.
    - **Purchase Invoices:**
        - A dedicated screen to create and view purchase invoices.
        - **Create Purchase Invoice Form:**
            - Select a supplier.
            - Add products from inventory.
            - For each product, specify the `quantity` purchased and the `costPrice` per unit.
            - Record any `amountPaid` to the supplier, selecting the payment method used.
        - **System Actions on Save:**
            - **Increase** the quantity of purchased products in the `products` table.
            - Update the supplier's `balance` (our debt to them increases by `totalAmount - amountPaid`).
            - Decrease the balance of the payment method used.

### 2.6. Financial Management
- **Purpose:** Track all money movement.
- **Sub-modules:**
    - **Payment Methods:**
        - CRUD for managing payment accounts (e.g., "Main Cash", "Bank Faisal").
        - Attributes: `name`, `type` ('cash' or 'bank'), `bankName`, `accountNumber`, `balance`.
    - **Expenses:**
        - A screen to record general business expenses (e.g., rent, salaries).
        - **Add Expense Form:** `description`, `amount`, `date`, `paymentMethodId` (the amount is deducted from this account's balance).
        - Can optionally be linked to a `supplierId` to record a payment made against an outstanding balance.
    - **Transactions Log:**
        - A read-only data grid showing all incoming customer payments (`payments` table). Columns: Date, Invoice #, Customer, Payment Method, Amount.

### 2.7. Settings
- **Purpose:** Configure application-wide parameters.
- **Features:**
    - **Installment Plans:**
        - CRUD for creating and managing installment plans.
        - Attributes: `name`, `durationMonths`, `profitPercentage`.

## 3. Database Schema (SQLite)

The application should use a local SQLite database with the following tables and relationships.

- **`products`**: id, name, code, categoryId, unitId, quantity, price, image, warranty
- **`categories`**: id, name
- **`units`**: id, name
- **`customers`**: id, fullName, phone, address, idNumber, type, status, balance
- **`suppliers`**: id, name, phone, address, balance
- **`payment_methods`**: id, name, type, bankName, accountNumber, branch, balance
- **`installment_plans`**: id, name, durationMonths, profitPercentage
- **`invoices`**: id, invoiceNumber, customerId, customerName, customerPhone, issueDate, originalAmount, totalAmount, amountPaid, status, installmentPlanId
- **`invoice_items`**: id, invoiceId, productId, productName, quantity, unitPrice, warranty
- **`invoice_installments`**: id, invoiceId, installmentNumber, amount, dueDate, status, paymentDate
- **`payments`**: id, invoiceId, paymentMethodId, amount, paymentDate, paymentProof
- **`purchase_invoices`**: id, invoiceNumber, supplierId, issueDate, totalAmount, amountPaid, status
- **`purchase_invoice_items`**: id, purchaseInvoiceId, productId, quantity, costPrice
- **`expenses`**: id, description, amount, expenseDate, paymentMethodId, supplierId

Relationships should be maintained via Foreign Keys. For example, `invoice_items.invoiceId` links to `invoices.id`.

## 4. UI/UX Guidelines

- **Layout:** Main sidebar on the left, content area on the right.
- **Language & Direction:** The UI text must be in Arabic, and the entire layout must be Right-to-Left (RTL).
- **Design System:** Emulate Google's Material Design. Use clean cards, appropriate shadows for depth, clear and legible fonts (like 'Roboto' or 'Inter'), and responsive controls.
- **User Feedback:** Use non-intrusive notifications (toasts) for success/error messages after an operation. Use modal dialogs for forms and confirmation prompts.

