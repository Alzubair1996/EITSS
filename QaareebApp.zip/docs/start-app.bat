@echo off
setlocal

REM ===== إعدادات =====
set PORT=9002
set NODE_ENV=production

REM مسار قاعدة البيانات داخل .next\standalone
set DB_PATH=%~dp0standalone\balla.sqlite

REM مهم: لازم نشتغل من جذر المشروع عشان Next يلاقي static/public
cd /d %~dp0

REM تشغيل السيرفر (النافذة هتكون مخفية لأننا هنستدعي الملف ده من VBS)
node "standalone\server.js"

endlocal
