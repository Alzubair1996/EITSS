' يشغّل start-prod.bat مخفي، وينتظر جاهزية السيرفر، ثم يفتح المتصفح
Option Explicit

Dim shell, fso, projDir, port, url, i, waitMs
Set shell = CreateObject("WScript.Shell")
Set fso   = CreateObject("Scripting.FileSystemObject")

' مجلد المشروع = مكان ملف الـ VBS نفسه
projDir = fso.GetParentFolderName(WScript.ScriptFullName)
port    = 9002  ' <-- لازم يطابق PORT في start-prod.bat
url     = "http://localhost:" & port & "/"
waitMs  = 300   ' زمن الانتظار بين المحاولات (ms)

' شغّل الـ BAT مخفي (0 = مخفي، False = لا تنتظر انتهاءه)
shell.Run "cmd /c """ & projDir & "\start-prod.bat""", 0, False

' انتظر لحدّ ما السيرفر يبقى جاهز (جس نبض بالرابط)
Dim http, ready
ready = False

For i = 1 To 80 ' ~ حوالي 24 ثانية (80 * 300ms)
  On Error Resume Next
  Set http = CreateObject("MSXML2.XMLHTTP")
  http.Open "GET", url, False
  http.Send
  If Err.Number = 0 Then
    If http.Status >= 200 And http.Status < 500 Then
      ready = True
      On Error GoTo 0
      Exit For
    End If
  End If
  On Error GoTo 0
  WScript.Sleep waitMs
Next

' افتح المتصفح (هيفتح في نافذة عادية)
If ready Then
  shell.Run url, 1, False
Else
  ' حتى لو ما تأكدنا من الجاهزية، حاول افتح المتصفح
  shell.Run url, 1, False
End If
