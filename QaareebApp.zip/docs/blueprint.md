# **App Name**: متجر Balla

## Core Features:

- Product Management: Add, edit, and delete product information including name, code, category, unit, quantity, price, and description. Products are linked to separate Category and Unit tables.
- Category Management: Manage product categories used to classify products.
- Unit Management: Manage units of measurement (e.g., piece, box, kilogram).
- Customer Management: Add, edit, and delete customer data including full name, phone, address, ID number, type (individual/company), and status.
- Payment Methods Management: Track and manage accepted payment methods. Each method includes its own currency and current balance (e.g., Cash - SDG, Bank Transfer - USD, etc.).
- Installments System: Allow invoice amounts to be divided into monthly installments. The system calculates installment amounts and installment profit based on the number of months, set in a separate configuration screen.
- Customer Ledger (حساب العميل): Show a detailed transaction history per customer, including paid/remaining balances, next due dates, and filtering options by date or invoice.
- Invoice Generation: Generate invoices in Arabic format (A4). Invoices support full/partial payments, choice of payment method, and optionally splitting into installments. Invoices are printable with company logo and fully RTL design.
- Reports Module: Generate reports such as sales by date, unpaid installments, low-stock products, and customer account summaries.
- AI Product Descriptions: Automatically generate product descriptions based on name, features, purpose, category, and market context. Designed to provide marketing-friendly suggestions in Arabic.

## Style Guidelines:

- Primary Color: Deep blue #3F51B5 – for headers, side menus, and key UI elements.
- Background Color: Light gray #ECEFF1 – clean and modern backdrop.
- Accent Color: Teal #009688 – used for buttons, highlights, and interactive components.
- Font: Use "PT Bold Heading" (Arabic supported) for all headings and body text to match modern Arabic typography and ensure consistency across RTL screens. (If not available, fallback to PT Sans or system Arabic sans-serif font.)
- Layout: Full Right-to-Left (RTL) layout for all UI components. Modern, flat-style design with subtle shadows and elevation for buttons and cards.
- Icons should be minimalist, preferably from Google’s Material Icons (RTL-aligned).